# factory-change

What to do when something already confirmed must change: a requirement, a constraint, a library, a decision. It computes the impact on each document of the factory flow, reopens only the affected ones, re-runs their gates, asks for one reconfirmation, records the decision, and opens follow-up tickets instead of rewriting finished ones.

```
brief → synthesis → PRD → design (+ ADRs) → tickets        a change enters at the earliest document it touches
```

## What it covers

- **Impact table:** each document (brief, synthesis, PRD, design and ADRs, tickets), what changes and why, or "no". A document the change does not touch is left alone.
- **Reopen and re-check:** affected documents go back to `draft`, are edited with the source of the change, and pass their gate again, downstream gates included.
- **One reconfirmation:** the changed items, one question, never `confirmed` on a partial answer.
- **Decision record:** in the brief and the PRD, and in an ADR when the design changed.
- **Done tickets:** they stay done; follow-up tickets carry the new criteria.

## Files

```
factory-change/
├── SKILL.md
└── evals/
    ├── evals.json             # An invoice entity added after confirmation, a library swap, a vague change
    └── trigger_queries.json
```

## How it relates to the other skills

It uses the gates of `factory-idea-interview`, `factory-idea-synthesis`, `factory-prd-writer`, `factory-tech-design` and `factory-prd-to-tickets`, and the ticket store's `ticket_create` and `ticket_update`. It does not write a document from nothing, stress-test a decision (`factory-grilling`), or fix a bug (`factory-implement`).
