---
name: factory-change
description: Use this skill when something already confirmed must change — a requirement, a constraint, a library or a decision in the brief, synthesis, PRD, tech design, ADRs or backlog — to compute the impact on each document, reopen only the affected ones, re-run their gates, ask for one reconfirmation, record the decision, and handle tickets already done. Triggers on "mudou o requisito", "agora precisa de X", "vamos trocar a biblioteca", "the client changed their mind", "add this to the PRD", "this contradicts the design", "reabre o brief". Not for the first draft of any document (use the skill that writes it), for stress-testing a decision (use factory-grilling), or for a bug in code (use factory-implement).
license: MIT
compatibility: Needs the documents of the factory flow in docs/ and the gate scripts of the skills that wrote them (check_brief, check_synthesis, check_domain, check_prd, check_design, check_tickets). With the factory-tickets MCP server, ticket edits go through ticket_update and ticket_create.
metadata:
  author: mhl42
  version: "1.2.1"
---

# Change

A change after confirmation touches several documents that were each confirmed on their own. Done by hand, it is easy to edit one and forget the rest, to mark everything `confirmed` on one "ok", or to rewrite tickets that are finished. This skill makes the impact explicit, reopens only what is affected, and closes with one reconfirmation.

```
brief → synthesis → domain model → PRD → design (+ ADRs) → tickets → build        a change enters at the earliest document it touches
```

Write in the user's language.

## Workflow

```
- [ ] 1. The change stated, in the user's own words
- [ ] 2. Impact table written and shown
- [ ] 3. Affected documents set to draft, edited, gates re-run
- [ ] 4. One reconfirmation asked
- [ ] 5. Decision recorded where the next reader looks
- [ ] 6. Tickets already done handled
```

### 1. State the change
One or two sentences, plus the user's own words, quoted. The quote becomes the source of the decision (`user, <date>`). If the change is vague ("make it nicer"), ask what it means, concretely, before computing anything.

Decide what kind it is, because it decides where the change enters:
- **Scope or requirement** (a new need, a dropped one): it enters at the brief.
- **Business rule** (a format, a limit, a state, an exception, found in review or in the code): it enters at the domain model, and reaches the PRD criteria and the design's *Rule enforcement* through its ID.
- **Constraint** (a library, a platform, a rule): it enters at the brief, and almost always reaches the design and an ADR.
- **Technical choice only** (the PRD stays true): it enters at the design.
- **Size** (the domain step's `depth valve`, or a trigger found late): it enters at the brief's *Depth*, and reopens every step the old size skipped, starting with the earliest.
- **Detail of one ticket**: it is the backlog only.

### 2. Impact table
Read each confirmed document and say what changes and why, or that it does not. **Never change a document the change does not touch.**

| Document | Changes? | What and why |
|----------|----------|--------------|
| Brief (`docs/prd-brief/<slug>.md`) | yes / no | the scope item, constraint, or decision |
| Synthesis | yes / no | an evidence row, a contradiction |
| Domain model (`docs/domain/<slug>.md`) | yes / no | a use case or flow, a rule, an entity, a lifecycle |
| PRD | yes / no | requirements and acceptance criteria, NFR, assumptions |
| Design and ADRs | yes / no | components, data model, a new or superseded ADR |
| Tickets | yes / no | tickets to add, change, or drop; which are `done` |

Look for the second-order effect. A constraint that was recorded as a rule and was in fact a preference reopens the documents that took it as given. A new entity (an invoice with a header and lines) reaches the data model, the FRs that use it, and the tickets that store it. Show the table and the cost (how many documents, how many tickets already done) before editing. If the user wants the change anyway, go on.

### 3. Reopen, edit, re-check
For each affected document, top-down:
1. Set `Status: draft`.
2. Apply the edit, with the source of the change on every new or changed item.
3. Re-run its gate: `check_brief.py`, `check_synthesis.py`, `check_domain.py`, `check_prd.py`, `check_design.py`, `check_tickets.py` (each in its skill's `scripts/`). A gate that fails or asks for answers is handled as the skill that wrote the document would (one numbered round of questions with recommended answers).
4. Re-run the downstream gates too: a PRD edit can make the design's coverage fail.

Leave the documents that the table marked "no" at `confirmed`.

### 4. One reconfirmation
Show the changed items of each document (not the whole document) and ask **one** question: confirm all of them? Do not set any document to `confirmed` on a partial answer. If the user confirms some and not others, those stay `draft`, and so do the ones that depend on them.

### 5. Record the decision
Where the next reader will look: the *Decisions* section of the brief and of the PRD, and an ADR in `docs/adr/` when the design changed (a new one, or a `Superseded by` on the old one). The entry says what was decided, when, by whom (the user's words), and what it replaced.

### 6. Tickets already done
Do not rewrite finished work. For each `done` ticket whose criteria no longer hold:
- Leave it `done`: it was true when it was accepted. Its evidence and history stay.
- Open a **follow-up ticket** (`ticket_create`, or a new `### T-NN` in the backlog) that serves the changed requirement, depends on the old one, and carries the new criteria.
- If a criterion of a done ticket was plainly wrong, and not just superseded, change it only with a reason (`ticket_update` asks for one) and say so in the report.
- Tickets not started, or `doing`, are edited or dropped in place.

The report lists the documents changed, the gates and their results, the decision recorded, and the tickets opened, edited and left alone.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Start the impact table from `project_manifest`: its `stale` list names every document and ticket that cites an item changed since it was written. `item_get(<id>)` lists what cites an item you are about to change, before you change it.
- Reopen a document by writing its new revision with `doc_write`: it becomes a draft by itself, and the gate runs. Rewriting the citing text closes its stale entry; a citation that still holds is closed with `stale_resolve(project, <path or T-NN>, [<ids>], note)`, the note saying why.
- Step 4's one reconfirmation is one `doc_confirm` per document, top-down (brief, domain model, PRD, design), each with the user's same answer: a document is refused while one of its inputs is still a draft.
- A ticket whose requirement changed shows as stale in the manifest and in `ticket_context`; close it with `stale_resolve` once its criteria are checked or a follow-up ticket exists.

## Gotchas

- Marking everything `confirmed` on one "sim". The user confirms what you showed, so show the changed items.
- Changing documents "while you are there". A document the change does not need is not edited.
- Treating a preference as a rule, or the reverse, in the original brief. Ask whether the changed constraint was a hard rule or a preference, and write which one in the decision.
- Editing the PRD and forgetting the design's NFR coverage, or the ticket that serves the requirement. Run the downstream gates.
- Deleting the old text. Keep what it replaced in the decision entry, so the history reads.
- Deciding the change alone because it looks obvious. The change and its cost are the user's to accept.
