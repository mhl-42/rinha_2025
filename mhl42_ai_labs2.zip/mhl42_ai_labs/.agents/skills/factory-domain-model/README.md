# factory-domain-model

Discovers and consolidates the business domain between the confirmed brief and the PRD: actors and permissions, use cases with their alternative and exception flows, business rules with an example and a counterexample each, entities with their relationships and invariants, lifecycles, and a glossary. Every item carries its status (`confirmed`, `inferred`, `proposed`, `rejected`) and its source, so a suggestion of the agent never passes for a requirement of the user.

```
brief (confirmed) → factory-domain-model → docs/domain/<slug>.md + check_domain.py → factory-prd-writer
```

## Why it exists

The `supermercado-pdv` POC passed every gate of the flow (brief, synthesis, PRD, design, tickets) and still left the domain shallow. Rules were decided after the PRD (invoice uniqueness ignoring case, "1.000" read as a thousand), and others exist only in the code with no source in any document (barcode length, whole quantities for `un`). The brief has no place for the domain, so the interview's stop rule ended before anyone asked about mistakes, changes after creation, input formats or lifecycles. See `docs/auditoria/2026-10-14-skills-factory.md`.

## What it covers

- **Discovery** in rounds of up to 5 questions, one recommendation per decision, concrete examples when the user cannot answer in the abstract.
- **Proposals** from what similar operations usually need, each with why and implications, `pending` until the user answers it.
- **Consolidation:** inferences and proposals shown for explicit validation; uncertainties left visible as `deferred` questions with their impact.
- **Diagrams** only when they answer a question faster than the text (usually the main lifecycle).
- **Gate:** `check_domain.py` → `READY` / `INVALID` / `NEEDS-ANSWERS`.

## Files

```
factory-domain-model/
├── SKILL.md
├── references/
│   ├── domain-template.md     # the document and its field values (English and Portuguese)
│   ├── discovery-guide.md     # order of discovery, questions per dimension, commonly forgotten areas
│   └── diagrams.md            # which diagram for which purpose
├── scripts/
│   └── check_domain.py        # the gate
└── evals/
    ├── evals.json
    └── trigger_queries.json
```

## How it relates to the other skills

It reads the brief of `factory-idea-interview` and the synthesis of `factory-idea-synthesis`, and continues the interview log's `Q` numbering. `factory-prd-writer` cites its use cases and rules by ID (`UC-03`, `BR-07`) and its gate checks that every confirmed one is covered. `factory-tech-design` maps its entities to the data model. `factory-change` reopens it like any other confirmed document.
