---
name: factory-domain-model
description: Use this skill after a PRD brief is confirmed and before the PRD is written, to discover and consolidate the business domain — actors and permissions, use cases with their alternative and exception flows, business rules with examples and counterexamples, entities, relationships, invariants, lifecycles and a glossary — asking the user about gaps, proposing what similar operations usually need as labelled proposals, and passing a quality gate before any requirement is written. Triggers on "model the domain", "what are the business rules", "quais são as regras de negócio", "mapeia o domínio", "casos de uso", "what states does an order go through", "o que eu esqueci nesse sistema?". Not for discovering the problem and the users (use factory-idea-interview), for writing requirements (use factory-prd-writer), or for tables, classes and the database (use factory-tech-design).
license: MIT
compatibility: Interactive sessions; the user answers and approves. scripts/check_domain.py needs Python 3.10+ (no dependencies). Expects the brief format of factory-idea-interview; reads the synthesis of factory-idea-synthesis when present.
metadata:
  author: mhl42
  version: "1.4.0"
---

# Domain Model

Find out **how the business works** before anyone writes requirements: who acts, what they do, what can go wrong, which rules hold, which things exist and how they change. The output is a confirmed domain model that the PRD cites rule by rule, so no rule has to be invented later in the code.

This is step 2b of the flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief → 2b factory-domain-model → 3 factory-prd-writer → 4 factory-tech-design → tickets
```

Write the questions and the document in the user's language.

## Before you start

- **Brief:** `docs/prd-brief/<slug>.md` with `Status: confirmed` and a `PASS` from its gate. If not, stop and send the user to factory-idea-interview. The brief's *Scope* and *Out of scope* bound the model: you discover the domain inside the scope, and you propose additions without adding them.
- **Depth:** the brief's *Depth* section gives the size and the triggers. It sets how deep this step goes (see *Calibrating depth* in [references/discovery-guide.md](references/discovery-guide.md)): a compact model for `small` and `medium`, every dimension for `large`, and extra discussion rounds on the gray areas for `complex`. A brief without *Depth* (written before it existed) is treated as `large`.
- **Lessons:** `docs/lessons.md`, when it exists. Every `confirmed` lesson becomes a check in step 2; candidates are not read (see `factory-review/references/lessons-template.md`).
- **Synthesis** (optional) and the **interview log** (`docs/prd-brief/<slug>.interview.md`): read every answer. Many rules are already there, bundled inside a long answer.
- Facts you can read (existing code, schemas, documents the user shared) are your job; cite them as `repo:` or `doc:`.

## Workflow

```
- [ ] 1. First draft from what is already known, every item with a source and a status
- [ ] 2. Gaps listed per dimension and against the commonly forgotten areas, and the attributes of every entity
- [ ] 3. Discovery rounds: questions and proposals, up to 5 per round, each with a recommendation
- [ ] 4. Consolidation: inferences and proposals shown for explicit validation
- [ ] 5. Diagrams for what the text cannot show quickly
- [ ] 6. check_domain.py → READY (or back to step 3)
- [ ] 7. User confirms; status set to confirmed
```

### 1. First draft
Copy [references/domain-template.md](references/domain-template.md) to `docs/domain/<slug>.md` and replace every `<...>` placeholder. Fill it only from the sources. For the level of detail of a good item, read one example from another business in [references/examples/](references/examples/) (retail and a clinic); never copy its rows: the gate refuses them, and they belong to another business. Split bundled answers: an answer that accepted "lots by expiry, no negative stock, expired lots not sold, duplicate invoice rejected" is four rules, each with its own ID, example and counterexample; so is "cancel up to 24 h before, one session per day, no double booking of a room, the reception can cancel any time" at a clinic.

Mark every item with its status. What the user said or explicitly accepted is `confirmed`. What you deduced from it is `inferred` (for example, "a session belongs to exactly one room" from "each room takes one patient at a time"). What you would add is a proposal. Never write an inference or a suggestion as `confirmed`.

### 2. Find the gaps
Follow [references/discovery-guide.md](references/discovery-guide.md): go through each dimension (actors, use cases, flows and exceptions, entities, invariants, lifecycles, rules, data and history, integrations), then through the table of commonly forgotten areas for **every** entity and use case. Each gap becomes a question, a proposal, or a line saying why it does not apply.

Then fill *Attributes* for every confirmed entity, with the list in *Attributes of each entity* of the guide: the attributes the user named are `confirmed`; the ones an operation of this kind usually keeps and the user did not mention are `proposed`, grouped per entity in one proposal so the user accepts them one by one. Keep them in business terms (kind, required, unique, when it changes, personal); ids and columns belong to the technical design.

Then go through the confirmed lessons of `docs/lessons.md`: each one is a gap this project already paid for once.

Do not stop at the user's vocabulary. Look for concepts the answers imply but never name (an invoice "header" that has its own rules, a sale that can be abandoned, a session the patient missed), words used with two meanings, and rules that contradict each other.

### 3. Discovery rounds
- Ask in **rounds of up to 5**, numbered, the questions that change the model most first: a new entity or state before a message wording. Ask a question alone when its answer decides what you ask next.
- **One recommendation per decision.** Give each question a recommended answer and a one-line reason, phrased so "yes" accepts it. If the recommendation would settle several rules, list them as numbered sub-items the user can accept one by one. A single "yes" to a bundle of rules hides which ones the user actually weighed.
- Offer **concrete examples** in the project's own business when the user cannot answer in the abstract: "If a customer brings 3 kg of apples and the scale says 2.997, what should the receipt show?" at a till, or "If a patient cancels at 10:01 a session that starts tomorrow at 10:00, is it refused?" at a clinic.
- **Proposals** come from your knowledge of similar operations. Each one says what, why, the implications, and your recommendation; it goes in *Proposals* as `pending` and in the round as its own numbered item. A proposal is never a requirement until the user accepts it.
- Record each answer in the interview log (continue the `Q` numbering) and update the model: accepted proposals become `confirmed` items citing `P-n`; rejected ones stay in the table with the reason.
- "Whatever you think" is not an answer to a decision. Restate your recommendation and ask for an explicit yes.

**Stop rule:** stop when the gate has nothing left in *Proposals* as `pending`, no item is `inferred` or `proposed`, and every open question is answered or formally `deferred` with its impact. If the user wants to stop earlier, defer the remaining questions with their impact, and say which requirements they put at risk.

### 4. Consolidate and validate
Before the gate, show the user, in one message: the actors and use cases (one line each), the rules (ID and one line), the lifecycles, and every item still `inferred` with its reasoning. Ask for explicit validation. Conflicts go to the user with both sides and a recommendation; never resolve one by picking the most recent answer. An uncertainty the user cannot settle now becomes a `deferred` open question with its impact and the milestone it must be decided before: hiding it to finish the step is worse than leaving it visible.

### 5. Diagrams
Use [references/diagrams.md](references/diagrams.md). Draw only what the text cannot show quickly (usually the main lifecycle and, for four or more entities, their relationships). A diagram repeats the text; when they disagree, fix the diagram.

### 6. Check
```bash
python <this-skill-dir>/scripts/check_domain.py docs/domain/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `INVALID` | 1 | Fix the structure: a missing section, an item without a source or status, a rule without example or counterexample, a use case without actor, main flow or alternative flows, an unknown reference, an accepted proposal without its result, a template placeholder left, a row copied from an example of another business. |
| `NEEDS-ANSWERS` | 2 | Pending proposals, inferred or proposed items, or open questions remain. Go back to step 3 with only those. |
| `READY` | 0 | Confirm. |

**Safety valve.** The gate compares the model with the brief's *Depth*: more rules, entities or lifecycles than the size allows, or a lifecycle when the triggers omit `state`, returns `NEEDS-ANSWERS` with a `depth valve` line. The size was wrong, not the model. Show the counts to the user, raise the size in the brief through factory-change, and reopen the steps the old size skipped. Never shrink the model to fit the size.

Warnings (a rule no use case, entity or lifecycle uses; an entity missing from the glossary; an actor with no use case) do not block, but fix them or say why they stay.

### 7. Confirm and hand off
Ask for explicit confirmation of the model, together with any remaining question. Then set `Status: confirmed`. If a confirmed rule changes the brief's scope, update the brief first (factory-change when the brief was already used downstream). Offer the next step: the PRD (factory-prd-writer), which cites the use cases and rules by ID instead of copying them.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Read the inputs with `doc_read`, or single ids with `item_get` (the definition and everything that cites it), instead of opening the files. Confirmed lessons are in `doc_read(project, "lessons", "lessons")`.
- Write with `doc_write(project, "domain", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run. Every round of answers is a new revision, so the history shows how each rule was decided.
- Confirm with `doc_confirm(project, "domain", <slug>, revision, user_answer)` after the user's yes, passing their reply verbatim, instead of editing the Status line. Show them the revision you confirm. It refuses while an input is not confirmed, the document cites an item that changed after it (`stale` in the manifest: rewrite the citing text, or `stale_resolve` with a note when it still holds), or the gate fails on the confirmed text; read the refusal to the user.
- A rule changed after the PRD cites it marks the citing requirements stale; the manifest lists them for factory-change.

## Gotchas

- Agents accept the user's first vocabulary and stop. The rules that hurt later are the ones nobody named: what happens on a mistake, what changes after creation, what a valid input looks like.
- A model full of proposals the user never weighed is the agent's design, not the user's domain. Keep proposals `pending` until each one gets its own answer.
- Tables and classes do not belong here. "Movement has a signed quantity column" is design; "a lot's balance is what came in minus what went out, and it is never negative" is domain.
- Do not mistake length for depth. A rule with a concrete example and counterexample is worth more than a page of description.
- In non-interactive runs (CI, scheduled jobs, autonomous loops), do not invent answers or accept your own proposals. Write the model with every unknown as an open question or a pending proposal; the gate returns `NEEDS-ANSWERS`, and the run reports that as a blocker.
