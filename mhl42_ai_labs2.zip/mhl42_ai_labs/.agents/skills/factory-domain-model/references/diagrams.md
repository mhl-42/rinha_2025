# Choosing Diagrams

A diagram shows knowledge already written in the tables and use cases. It never adds a rule of its own: when the text and the diagram disagree, the text wins and the diagram is fixed.

Draw one only when it answers a question faster than the text does. Each diagram in *Diagrams* starts with a `Purpose:` line and uses Mermaid, so it lives in the same file and shows in most viewers.

| Purpose | Diagram | Draw it when |
|---------|---------|--------------|
| Which states an entity goes through, and which moves are forbidden | `stateDiagram-v2` | an entity has three or more states, or a transition has a guard |
| How a use case branches into its exceptions | `flowchart` | a use case has three or more alternative flows that rejoin or end differently |
| How the entities relate, and how many of each | `erDiagram` (conceptual: names and cardinalities, no column types) | four or more entities, or a relationship whose cardinality was debated |
| Who talks to whom over time | `sequenceDiagram` | an integration with an external system, a device, or another actor in the middle of a flow |
| Which actor does which use case | a table is enough | three or more actors with different permissions; then a `flowchart LR` actor → use case |

Do not draw: a diagram per use case, a class diagram with methods, or a database schema. Those are design, not domain.

## Examples

```mermaid
stateDiagram-v2
    %% Purpose: the states of a sale and the moves the cashier cannot make
    [*] --> open: first line added (BR-04)
    open --> closed: payments cover the total (BR-06)
    open --> abandoned: cashier leaves the screen (BR-09)
    closed --> [*]
    abandoned --> [*]
```

```mermaid
erDiagram
    %% Purpose: an invoice has lines, each line creates one lot
    INVOICE ||--o{ LOT : "creates"
    PRODUCT ||--o{ LOT : "is stocked in"
    LOT ||--o{ MOVEMENT : "changes by"
```

Label states and transitions with the same words as the glossary and the rule IDs that guard them.
