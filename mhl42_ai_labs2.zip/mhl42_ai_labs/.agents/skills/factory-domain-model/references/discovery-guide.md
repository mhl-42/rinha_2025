# Discovering the Domain

## Contents
- Order of discovery
- Questions per dimension
- Commonly forgotten areas
- Attributes of each entity
- Proposing from domain knowledge
- Calibrating depth
- What does not belong here

## Order of discovery

Each step uses the answers of the one before. Do not ask about rules of an entity nobody has named yet.

1. **Actors and what each one does.** Who touches the system, and who is affected without touching it.
2. **Use cases.** For each actor, the tasks they finish with the system. Name each one with a verb ("cashier closes a sale", "receptionist books a session", "member borrows a tool").
3. **Main flow of each use case**, in 3–8 steps, in the user's words.
4. **Alternative and exception flows.** For each step: what can go wrong, what the actor can change their mind about, what the system refuses.
5. **Entities and their attributes**, from the nouns of the flows. Ask which ones have an identity of their own (a record people refer to) and which are only values (an amount, a date). Then, for each entity, list its attributes in *Attributes* (see *Attributes of each entity* below): what the users record, see and search by.
6. **Relationships and invariants.** How many of one per other; what must always be true.
7. **Lifecycles.** For each entity that changes state: its states, the events that move it, and which moves are forbidden.
8. **Rules not yet attached to anything**: calculations, limits, formats, permissions, time.

## Questions per dimension

Ask in rounds of up to 5, each with a recommended answer (see the skill's step 3). The questions below are a map, not a script.

**Actors and permissions**
- Who else uses or is affected by this, besides the users in the brief? (A supervisor who authorises, an auditor who reads, a system that calls it.)
- Is there anything one actor must never be able to do? Is there anything that needs a second person to approve?

**Use cases and flows**
- Walk me through one complete case, from the moment it starts to when it is finished. What does the person see and type?
- At step N, what happens if the data is wrong, missing, or refers to something that does not exist?
- Can the person undo or correct this step? Until when?
- What happens if the person stops halfway (closes the screen, the power fails)?

**Entities and attributes**
- What do people call this thing? Is there another name for it that means something different?
- How is one told apart from another (identity)? Can two be equal? Does case, spacing or format matter ("Alfa" and "alfa")?
- Which attributes are required, which optional, which computed? Which ones can change after creation?

**Relationships and invariants**
- Can an X exist without a Y? Can it have more than one?
- What must always be true, whatever happens? (A balance never below zero; two sessions never take the same room at the same time; a tool has at most one open loan.)

**Lifecycles**
- What states does it go through? Which state is final?
- Which transitions are forbidden? What happens to its related records when it changes state?

**Rules, limits and formats**
- What are the limits (zero, negative, maximum, empty)? What happens at exactly the limit?
- How is a number typed and shown here (decimal comma or point, thousands separator, units, rounding)?
- Does any rule depend on the date or time? Whose clock and time zone? Is "today" inclusive?

**Data and history**
- What must be kept after it changes (the price at the time of the sale, the fee agreed when the session was booked, who did what, when)?
- Must anything be deleted, kept for a period, or never deleted?

**Integrations**
- Which other systems, files or devices send or receive data? What happens when they are not there?

## Commonly forgotten areas

Before you finish, go through this list for **every** entity and use case. Each item either becomes a question, a proposal, or a line saying it does not apply. The POC that motivated this skill (`supermercado-pdv`, retail) missed the first four, and they came back as rules invented during implementation. The other columns show the same gap in other businesses: use the column closest to the project, and ask the question in its own terms.

| Area | Ask | Retail (the POC) | Scheduling (a clinic) | Services and lending (a workshop, a library) |
|------|-----|------------------|-----------------------|---------------------------------------------|
| Correcting a mistake | How does the actor undo a wrong entry without starting over? | Removing a wrong line from an open sale (missed) | Booking the wrong patient into a slot | Registering a loan to the wrong member |
| Changing after creation | Which attributes can change, and what happens to the records that used the old value? | Changing a product's price (missed) | Changing a physiotherapist's hours with sessions already booked | Changing the price of a service on open orders |
| Formats of input | What exactly is a valid code, number or date? Which separators? | Barcode length; "1.000" read as 1 instead of 1000 (missed) | Phone and e-mail formats; date typed as 03/04 | Plate or serial number formats |
| Identity and uniqueness | Do case, spaces, or accents make two things different? | "Distribuidora Alfa" vs "distribuidora alfa", decided after the PRD (missed) | Two patients sharing one e-mail (a daughter booking for her parents) | The same customer registered twice with and without accents |
| Quantities and units | Can a quantity have a fraction? What is the rounding rule? | `un` accepting only whole numbers | Session length (50 min) and what a "slot" is | Hours worked rounded to the quarter hour |
| Boundaries of time | Can a date be in the past or future? Which day counts as "expired"? | A lot received already expired | "24 h before": whose clock, and is 24:00 inclusive? | A loan due on a holiday |
| Interrupted work | What is left when the actor stops halfway? | Abandoning a sale existed only as an acceptance criterion | A booking started when the slot is taken by someone else | An order opened and never priced |
| Lifecycle of a header | When is a document (invoice, order, appointment) complete? Can it still change after that? | Invoice with no "closed" state | A session that happened, or that the patient missed | A service order that is delivered but not paid |
| Failure of storage or integration | What does the user see when the data cannot be saved or read? | Reached the design, but no criterion carried it to a ticket | The confirmation e-mail does not go out | The payment gateway is down |
| Empty and first use | What exists on the first run? Is there sample data? | — | Rooms and physiotherapists loaded before the first patient | Catalogue of services before the first order |
| Who did it | Must the system know who did each action, and when? | — | Who cancelled: the patient or the reception | Who received the returned tool |
| Simultaneity | Can two actors change the same thing at once? | Out of scope (one till), and said so | Two patients taking the last free slot | Two attendants editing the same order |

## Attributes of each entity

The users name a few attributes (a name, an e-mail); the ones they forget come back in the code as invented columns. For **every** confirmed entity, fill *Attributes* in business terms, then go through this list. Each item becomes a confirmed attribute, a `proposed` one (with its `P-n`), or nothing because it does not apply.

| Ask | Typical attributes | Retail | Scheduling (a clinic) | Services and lending |
|-----|--------------------|--------|-----------------------|----------------------|
| How do people find it and tell it apart? | a name or code they search by; what is unique, and within what | product code, barcode | patient e-mail (shared by a family) | plate, serial number, member card |
| Who is responsible for it, and where does it belong? | owner, sector, unit, branch | seller of the sale | physiotherapist of the patient | attendant of the order |
| What is it worth, and how is the value made? | amounts, discounts, taxes, which are calculated and from what | unit price, discount, total | session fee | hourly rate, deposit |
| What must be kept as it was at that moment? | values copied when the record is made, so a later change does not rewrite history | price at the time of the sale | fee agreed when booked | rate on the day of the order |
| Which state is it in, and since when? | status, active or inactive (instead of deleting), dates of each change | sale open or closed | session booked, done, missed | tool lent, returned, lost |
| Who registered or changed it, and when? | registered on, by whom; last change | who closed the sale | who cancelled: patient or reception | who received the returned tool |
| What do people attach or note? | photo, document, notes | product photo | — | photo of the damage on return |
| Which personal data does it hold, and which must it not hold? | contact, documents, health data; and the fields the brief forbids | customer tax id on the receipt | no phone, no CPF (privacy NFR) | member address |

Attributes are business facts. Leave out ids, foreign keys, column types and created/updated timestamps that nobody reads: the technical design adds them, and maps each attribute to a column.

## Proposing from domain knowledge

The user often does not know what to ask for. You know how similar operations work. Use that knowledge, but as **proposals**, never as requirements.

- When the domain is a known one (retail, scheduling, lending, booking, inventory, billing), list the processes such an operation normally has and check each against the brief's scope: in, out, or not discussed. Every "not discussed" that a user of the product would hit in the first week is a proposal.
- Do the same for the attributes: what an operation of this kind usually records about each entity (a user's photo and sector, a sale's discount and seller). Each one the user did not mention is a `proposed` row in *Attributes* that cites its proposal. Group them by entity in one proposal ("P-4: attributes of User: photo, sector, registered on"), so the user answers per attribute ("4a yes, 4b no").
- Each proposal has: what, why (the situation where its absence hurts), the implications (new entities, rules, screens, cost), and your recommendation. Record it in *Proposals* with status `pending`.
- Present proposals in the same numbered rounds as questions, so the user can answer each one on its own ("1 yes, 2 no, 3 later").
- A proposal the user accepts becomes items with status `confirmed` that cite it (`Source: P-3`). A rejected one stays in the table with its reason, and the PRD's *Out of scope* can cite it.
- Never let the volume of proposals bury the decisions that matter. Order them by how much they change the model (a new entity or state first, a message wording last), and leave cosmetic ones out.

When there is no real operation behind the project (a study, a portfolio, a proof of concept), the reference operation the brief names (a real supermarket, a real clinic, a real workshop) is the source of the proposals. Say so to the user: "There is no clinic to observe, so I will propose how a typical clinic does it, and you choose."

## Calibrating depth

The size comes from the brief's *Depth* (factory-idea-interview), set by the complexity triggers, not by how important the project is.

| Size (brief) | Use cases | Rules | Lifecycles | Diagrams | Gate limit before the valve opens |
|--------------|-----------|-------|------------|----------|-----------------------------------|
| small: one actor, no trigger | the 2–5 main tasks | inputs, outputs, edge cases | `None` | none | 5 rules, 3 entities, no lifecycle |
| medium: one or two triggers | every task in scope, with its exceptions | every rule the tests will prove | up to two | the main lifecycle, if any | 15 rules, 8 entities, 2 lifecycles |
| large: three or more triggers (a portfolio or POC with money, states and persistence is here) | all of the above, plus permissions per use case | plus audit, retention and calculations | all | flow, state and entity diagrams where they help | none |
| complex: ambiguity or a new domain | as large, plus a discussion round per gray area before writing its rules | as large | all | as large | none |

Depth is not length. A rule with an example and a counterexample is worth more than a paragraph about the domain.

## What does not belong here

- Technology: tables, columns, classes, frameworks, file formats of storage. The domain model says *what* must be recorded and *what* must hold; the technical design decides *how*.
- Screens and layout. The flows say what the actor does, not which button they press. (Keys and devices the brief fixed, like a barcode reader, are fine.)
- Requirements priorities and metrics. They belong to the PRD.
