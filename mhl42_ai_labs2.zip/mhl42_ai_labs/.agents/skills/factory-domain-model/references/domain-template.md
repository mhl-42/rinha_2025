# Domain Model Template

Save as `docs/domain/<slug>.md`. Keep the headings, the `### UC-01:` format, the field labels and the column names as they are (English, or the Portuguese aliases at the end), because `scripts/check_domain.py` reads them. Write the content in the user's language.

Scale it to the domain. A command-line tool with one user may have one actor, three rules and no lifecycle. A section that does not apply says `None` and why; it is never left out.

Every `<...>` is a placeholder: replace it, or remove the row. The gate refuses a model with a placeholder left. For what a filled item looks like, read an example from another business in [examples/](examples/): [a supermarket point of sale](examples/supermercado-pdv.md) (retail, in English) and [a physiotherapy clinic](examples/clinica-fisioterapia.md) (scheduling, with the Portuguese aliases). They show the level of detail, not the content: the gate also refuses rows copied from them.

````markdown
# Domain Model: <name>

Brief: docs/prd-brief/<slug>.md
Synthesis: docs/prd-brief/<slug>.synthesis.md
Status: draft
Date: YYYY-MM-DD

## Glossary
| Term | Definition | Source |
|------|------------|--------|
| <term the users say> | <what it means here, and what it does not mean> | <Qn> |

## Actors
| ID | Actor | Responsibilities | Permissions | Source |
|----|-------|------------------|-------------|--------|
| ACT-1 | <role> | <what this role does with the system> | <what it can do; what it must never do> | <Qn> |

## Use cases
### UC-01: <actor> <verb> <object>
Actor: ACT-1
Status: <confirmed / inferred / proposed>
Source: <brief:scope#n, Qn>
Trigger: <what starts it>
Main flow:
1. <what the actor does>
2. <what the system does or shows>
3. <...until the result>
Alternative flows:
- <step>a. <what goes wrong at that step>: <what the system does> (<BR-nn or P-n>).
Result: <what exists or changed when it ends>

## Business rules
| ID | Rule | Status | Source | Example | Counterexample |
|----|------|--------|--------|---------|----------------|
| BR-01 | <the rule, testable> | <status> | <Qn> | <a concrete case that follows it, with numbers or names> | <a concrete case that breaks it> |

## Entities
| Entity | Meaning | Key attributes | Relationships | Invariants | Status | Source |
|--------|---------|----------------|---------------|------------|--------|--------|
| <entity> | <what one of them is> | <attributes> | <belongs to / has many> | <what must always hold (BR-nn)> | <status> | <Qn> |

## Attributes
| Entity | Attribute | Meaning | Kind | Required | Unique | Changes | Personal | Rule | Status | Source |
|--------|-----------|---------|------|----------|--------|---------|----------|------|--------|--------|
| <entity> | <attribute, in the users' words> | <what it holds> | <text / number / money / date / date-time / yes/no / list of: a, b / list of <Entity> / reference → <Entity> / file / image; add ", calculated" when derived> | <yes / no> | <yes / no / within <scope>> | <yes / no / once / until <state> / by <actor>> | <yes / no> | <BR-nn or —> | <status> | <Qn or P-n> |

## Lifecycles
### <Entity that changes state>
| From | Event | To | Rule |
|------|-------|----|------|
| (none) | <event that creates it> | <first state> | <BR-nn> |
| <state> | <event> | <state> | <BR-nn> |

## Diagrams
<!-- Optional. One diagram per purpose (see references/diagrams.md), each with a "Purpose:" line, in Mermaid. -->

## Proposals
| ID | Proposal | Why | Implications | Status | Result |
|----|----------|-----|--------------|--------|--------|
| P-1 | <what you would add> | <the situation where its absence hurts> | <new entities, rules, screens, cost> | pending | |

## Open questions
| ID | Question | Why it matters | Status | Impact | Decide before |
|----|----------|----------------|--------|--------|---------------|
| DQ-1 | <question> | <what it decides in the model> | open | | |
````

## Field values

- **Status of an item** (use case, rule, entity): `confirmed` (the user said it, or explicitly accepted it), `inferred` (you deduced it from confirmed items and it still needs the user's yes), `proposed` (your suggestion, not yet accepted), `rejected` (the user said no; keep it, with the reason in *Source*, so nobody proposes it again). Portuguese: `confirmado/confirmada`, `inferido/inferida`, `proposto/proposta`, `rejeitado/rejeitada`.
- **Source:** where it came from. `Q5` (interview answer), `brief:scope#3`, `E4` / `C2` (synthesis), `P-1` (an accepted proposal), `doc:<file>` or `repo:<path>`. An `inferred` item cites what it was inferred from (`from BR-02, Q8`). A `confirmed` item that cites a proposal needs that proposal to be `accepted`.
- **Example / Counterexample:** a concrete case that follows the rule, and one that breaks it, with numbers or names. For a definition with no meaningful violation, write `n/a: <why>`.
- **Proposal status:** `pending`, `accepted`, `rejected` (`pendente`, `aceita`, `rejeitada`). *Result* is empty while pending; it names the items an accepted proposal created (`UC-07, BR-12`) or why it was rejected (`out of scope for v1`).
- **Open question status:** `open`, `answered`, `deferred` (`aberta`, `respondida`, `adiada`). `answered` names the item it settled in *Impact*. `deferred` is an accepted uncertainty: it needs the *Impact* if the guess is wrong and *Decide before* (a UC, a release, a ticket). The PRD must cite every deferred question.
- **Alternative flows:** numbered after the main-flow step they branch from (`2a`, `3b`). When a use case truly has none, write `None: <why>`.
- **Attributes:** one row per attribute of every confirmed entity, in business terms: no ids, foreign keys, column types or timestamps (the technical design adds them). *Kind* is a business kind: `text`, `number`, `money`, `date`, `date-time`, `time`, `duration`, `yes/no`, `e-mail`, `phone`, `list of: <values>` (a fixed set), `list of <Entity>` (many of another entity), `reference → <Entity>` (one of another entity), `file`, `image`; add `, calculated` when the value is derived (then *Required* is `n/a` and the *Rule* says how). *Unique* is `yes`, `no` or `within <scope>` ("within the sector"). *Changes* says when the value may change after creation: `yes`, `no`, `once`, `until <state>`, `by <actor>`; the UI's edit screens take their editable and locked fields from it. *Personal* marks personal data, for the privacy NFRs. An attribute you suggest is `proposed`, cites its `P-n`, and waits for the user's answer like any proposal.
- **Lifecycles:** one `### <Entity>` subsection per entity that changes state, with its transitions. `(none)` is the state before the entity exists. When no entity changes state, the section says `None: <why>`.
- **IDs:** `ACT-n`, `UC-nn`, `BR-nn`, `P-n`, `DQ-n`. Portuguese aliases `CU-nn` (caso de uso) and `RN-nn` (regra de negócio) are read as `UC` and `BR`. IDs are never reused, even for rejected items.

## Portuguese aliases

Headings: `Glossário`, `Atores`, `Casos de uso`, `Regras de negócio`, `Entidades`, `Atributos`, `Ciclos de vida`, `Diagramas`, `Propostas`, `Perguntas em aberto`. Header: `Brief:`, `Síntese:`. Use-case labels: `Ator:`, `Status:`, `Fonte:`, `Gatilho:`, `Fluxo principal:`, `Fluxos alternativos:`, `Resultado:`. Columns: `Termo`, `Definição`, `Fonte`, `Ator`, `Responsabilidades`, `Permissões`, `Regra`, `Exemplo`, `Contraexemplo`, `Entidade`, `Significado`, `Atributos principais`, `Relacionamentos`, `Invariantes`, `Atributo`, `Tipo`, `Obrigatório`, `Único`, `Alteração`, `Pessoal`, `De`, `Evento`, `Para`, `Proposta`, `Motivo`, `Implicações`, `Resultado`, `Pergunta`, `Por que importa`, `Impacto`, `Decidir antes de`.
