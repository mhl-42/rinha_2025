# Example: physiotherapy clinic (scheduling and services)

An excerpt of a domain model for online booking at a physiotherapy clinic, written with the Portuguese aliases. It is an **example of another business**, not text to copy: the gate refuses a domain model that repeats its rows (unless the model is this very project). Read it for the shape of a good item, then write your own from the interview.

What to notice:
- The actors include one who never logs in (the physiotherapist), because the rules depend on their schedule.
- A time rule says whose clock counts and what happens at exactly the limit.
- The lifecycle has a state the user did not name at first (`faltou`), found by asking what happens when the patient does not come.
- The attributes include one the clinic wanted out (no phone, no CPF) as a rule, and a proposed one (photo) that waits for the user's answer.
- The deferred question says what breaks if the guess is wrong and when it must be decided.

# Modelo de domínio: Autoagendamento da clínica de fisioterapia

Brief: docs/prd-brief/autoagendamento-fisioterapia.md
Síntese: docs/prd-brief/autoagendamento-fisioterapia.synthesis.md
Status: draft
Date: 2026-10-10

## Glossário
| Termo | Definição | Fonte |
|------|------------|--------|
| Horário livre | Intervalo de 50 min em que o fisioterapeuta atende e nenhuma sessão ocupa a sala | Q6 |

## Atores
| ID | Ator | Responsabilidades | Permissões | Fonte |
|----|-------|------------------|-------------|--------|
| ACT-1 | Paciente | Marca, cancela e remarca as próprias sessões | Só vê as próprias sessões e os horários do seu fisioterapeuta; não cria conta | Q2, Q4 |
| ACT-3 | Fisioterapeuta | Atende nas sessões; não usa o sistema | Nenhuma: a agenda dele é mantida pelo admin | Q3 |

## Casos de uso
### CU-01: Paciente marca uma sessão
Ator: ACT-1
Status: confirmado
Fonte: brief:scope#2, Q5
Gatilho: o paciente abre o link recebido por e-mail
Fluxo principal:
1. O sistema mostra os horários livres do fisioterapeuta do paciente nas próximas 2 semanas.
2. O paciente escolhe um horário.
3. O sistema confirma a sessão e envia o e-mail de confirmação.
Fluxos alternativos:
- 1a. O link expirou ou já foi usado: o sistema oferece enviar um novo link (RN-01).
- 2a. Outro paciente marcou o mesmo horário um instante antes: o sistema avisa e volta aos horários livres do mesmo dia (RN-03).
- 2b. O paciente já tem sessão no mesmo dia: a marcação é recusada (RN-04).
Resultado: uma sessão marcada, a sala ocupada e o e-mail de confirmação enviado.

## Regras de negócio
| ID | Regra | Status | Fonte | Exemplo | Contraexemplo |
|----|-------|--------|--------|---------|----------------|
| RN-02 | O paciente cancela ou remarca até 24 h antes do início, pelo horário de Brasília | confirmada | Q9 | Sessão na terça às 10:00; cancelar na segunda às 09:59 é aceito | Cancelar na segunda às 10:01 pelo site; só a recepção cancela depois disso |

## Entidades
| Entidade | Significado | Atributos principais | Relacionamentos | Invariantes | Status | Fonte |
|--------|---------|----------------|---------------|------------|--------|--------|
| Sessão | Um atendimento de 50 min de um paciente com um fisioterapeuta numa sala | início, situação | pertence a 1 Paciente, 1 Fisioterapeuta e 1 Sala | duas sessões marcadas nunca ocupam a mesma sala no mesmo horário (RN-03) | confirmada | Q6, Q7 |

## Atributos
| Entidade | Atributo | Significado | Tipo | Obrigatório | Único | Alteração | Pessoal | Regra | Status | Fonte |
|--------|-----------|---------|------|----------|--------|---------|----------|------|--------|--------|
| Paciente | e-mail | Para onde vão os links de acesso; pode ser compartilhado na família | e-mail | sim | não | pela recepção | sim | RN-07 | confirmado | Q11 |
| Paciente | fisioterapeuta responsável | Quem atende o paciente e define seus horários | referência → Fisioterapeuta | sim | não | pela recepção | não | — | confirmado | Q5 |
| Sessão | início | Data e hora em que a sessão começa, no horário de Brasília | data e hora | sim | dentro da sala | até 24 h antes, ou pela recepção | não | RN-02 | confirmado | Q9 |
| Fisioterapeuta | foto | Mostrada ao paciente na escolha do horário | imagem | não | não | sim | sim | — | proposto | P-4 |

## Ciclos de vida
### Sessão
| De | Evento | Para | Regra |
|------|-------|----|------|
| (none) | paciente ou recepção marca | marcada | RN-03 |
| marcada | cancelamento até 24 h antes, ou pela recepção a qualquer momento | cancelada | RN-02 |
| marcada | horário passa com o paciente atendido | realizada | RN-05 |
| marcada | horário passa sem o paciente | faltou | RN-06 |

## Diagramas
<!-- Opcional. -->

## Propostas
| ID | Proposta | Motivo | Implicações | Status | Resultado |
|----|----------|-----|--------------|--------|--------|
| P-2 | Lista de espera para horários cheios | Pacientes que não acham horário ligam para a recepção, que é o que o produto quer evitar | Nova entidade (pedido de espera), um e-mail quando um horário abre, uma regra de quem tem prioridade | pendente | |

## Perguntas em aberto
| ID | Pergunta | Por que importa | Status | Impacto | Decidir antes de |
|----|----------|----------------|--------|--------|---------------|
| DQ-2 | Faltas repetidas bloqueiam o autoagendamento? | Define se `faltou` tem efeito sobre o paciente | adiada | Se a clínica quiser bloquear, entra uma regra e um estado no paciente; as sessões já registradas servem de base | release 0.2 |
