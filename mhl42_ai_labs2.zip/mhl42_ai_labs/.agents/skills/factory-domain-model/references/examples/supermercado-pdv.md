# Example: supermarket point of sale (retail)

An excerpt of the domain model of the `supermercado-pdv` POC, one item per section, to show the level of detail each section expects. It is an **example of another business**, not text to copy: the gate refuses a domain model that repeats its rows (unless the model is this very project). Read it for the shape of a good item, then write your own from the interview.

What to notice:
- The alternative flows say what the system does at each step that can go wrong, and point to the rule or the pending proposal behind it.
- The rule has numbers in its example and counterexample.
- The entity's invariant cites the rule that keeps it true.
- The attributes say, for each value, its business kind, whether it is required, and when it can change; the price paid is copied into the sale line, so a later price change does not rewrite history.
- The proposal says why its absence hurts and what it would cost.

# Domain Model: Supermarket point of sale

Brief: docs/prd-brief/supermercado-pdv.md
Synthesis: docs/prd-brief/supermercado-pdv.synthesis.md
Status: draft
Date: 2026-10-02

## Glossary
| Term | Definition | Source |
|------|------------|--------|
| Lot | Units of one product received in one invoice line, with one expiry date | Q8 |

## Actors
| ID | Actor | Responsibilities | Permissions | Source |
|----|-------|------------------|-------------|--------|
| ACT-1 | Cashier | Registers sales and payments | Can sell; cannot receive stock or write off lots | Q3 |

## Use cases
### UC-01: Cashier sells products
Actor: ACT-1
Status: confirmed
Source: brief:scope#3, Q5
Trigger: a customer arrives at the till
Main flow:
1. The cashier reads or types each product code and the quantity.
2. The system shows each line and the running total.
3. The cashier records one or more payments until the total is covered.
4. The system closes the sale, writes off stock and shows the receipt.
Alternative flows:
- 1a. The code is unknown: the line is refused and the total does not change (BR-04).
- 1b. The cashier typed the wrong line: there is no way to undo it yet (P-1, pending).
- 3a. A card payment exceeds what is left: it is refused (BR-06).
Result: a closed sale, its payments, and lower stock.

## Business rules
| ID | Rule | Status | Source | Example | Counterexample |
|----|------|--------|--------|---------|----------------|
| BR-01 | Stock is written off from the lot that expires first (FEFO) | confirmed | Q8 | Lots A (exp. 01/11, 5) and B (exp. 01/12, 10); selling 7 leaves A=0, B=8 | Taking from B first while A still has units |

## Entities
| Entity | Meaning | Key attributes | Relationships | Invariants | Status | Source |
|--------|---------|----------------|---------------|------------|--------|--------|
| Lot | Units of one product from one invoice line | expiry date, cost, quantity received | belongs to 1 Invoice and 1 Product; has many Movements | balance = sum of its movements >= 0 (BR-02) | confirmed | Q8, Q13 |

## Attributes
| Entity | Attribute | Meaning | Kind | Required | Unique | Changes | Personal | Rule | Status | Source |
|--------|-----------|---------|------|----------|--------|---------|----------|------|--------|--------|
| Lot | expiry date | Last day the units may be sold | date | yes | no | no | no | BR-03 | confirmed | Q8 |
| Lot | balance | Units still in stock | number, calculated | n/a | — | never by hand | no | BR-02 | confirmed | Q13 |
| Sale line | unit price | Price charged for one unit at the moment of the sale | money | yes | no | no: kept even if the product's price changes | no | BR-11 | confirmed | Q10 |
| Sale | seller | Cashier who registered the sale | reference → Cashier | yes | no | no | yes | — | confirmed | Q3 |

## Lifecycles
### Sale
| From | Event | To | Rule |
|------|-------|----|------|
| (none) | first line added | open | BR-04 |
| open | all payments cover the total and the cashier closes | closed | BR-06 |
| open | the cashier leaves the screen | abandoned | BR-09 |

## Diagrams
<!-- Optional. One diagram per purpose (see references/diagrams.md), each with a "Purpose:" line, in Mermaid. -->

## Proposals
| ID | Proposal | Why | Implications | Status | Result |
|----|----------|-----|--------------|--------|--------|
| P-1 | The cashier can remove a line from an open sale | Reading the wrong product is the most common till mistake, and today the only way out is to abandon the whole sale | A new use case; the sale keeps no record of removed lines unless we decide to audit them | pending | |

## Open questions
| ID | Question | Why it matters | Status | Impact | Decide before |
|----|----------|----------------|--------|--------|---------------|
| DQ-1 | Can an invoice receive new lines after its first day? | Decides whether an invoice has a "closed" state | open | | |
