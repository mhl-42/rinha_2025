# /// script
# requires-python = ">=3.10"
# ///
"""Quality gate for a domain model written from references/domain-template.md.

Checks that every item has a status and a source, that rules have an example and a
counterexample, that use cases have an actor, a main flow and their alternative flows,
that every reference resolves, and that nothing the model inferred or proposed is left
waiting for the user's answer. The optional Attributes section (a warning when missing) lists each entity's attributes with a business
kind, required, unique and when they change. A placeholder of the template (<...>) left in the text, or a line
copied from one of the examples in references/examples/ (another business), makes it INVALID.

Usage:
  python check_domain.py docs/domain/<slug>.md

Exit codes:
  0 = READY          ready for the PRD
  1 = INVALID        the document breaks the structure rules; fix it
  2 = NEEDS-ANSWERS  pending proposals, inferred or proposed items, or open questions
  3 = usage error
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

SECTIONS = {
    "glossary": ("glossary", "glossário", "glossario"),
    "actors": ("actors", "atores"),
    "use_cases": ("use cases", "casos de uso"),
    "rules": ("business rules", "regras de negócio", "regras de negocio"),
    "entities": ("entities", "entidades"),
    "lifecycles": ("lifecycles", "ciclos de vida"),
    "proposals": ("proposals", "propostas"),
    "open_questions": ("open questions", "perguntas em aberto"),
}
OPTIONAL_SECTIONS = {
    "diagrams": ("diagrams", "diagramas"),
    # Added in 1.4.0: a warning when missing, so models written before it still pass; checked when present.
    "attributes": ("attributes", "atributos"),
}
COLUMNS = {
    "id": ("id",),
    "term": ("term", "termo"),
    "definition": ("definition", "definição", "definicao"),
    "source": ("source", "fonte"),
    "actor": ("actor", "ator"),
    "responsibilities": ("responsibilities", "responsabilidades"),
    "permissions": ("permissions", "permissões", "permissoes"),
    "rule": ("rule", "regra"),
    "status": ("status",),
    "example": ("example", "exemplo"),
    "counterexample": ("counterexample", "contraexemplo", "contra-exemplo"),
    "entity": ("entity", "entidade"),
    "meaning": ("meaning", "significado"),
    "attributes": ("key attributes", "atributos principais", "attributes", "atributos"),
    "relationships": ("relationships", "relacionamentos"),
    "invariants": ("invariants", "invariantes"),
    "from": ("from", "de"),
    "event": ("event", "evento"),
    "to": ("to", "para"),
    "proposal": ("proposal", "proposta"),
    "why": ("why", "motivo", "why it matters", "por que importa"),
    "implications": ("implications", "implicações", "implicacoes"),
    "result": ("result", "resultado"),
    "question": ("question", "pergunta"),
    "impact": ("impact", "impacto"),
    "before": ("decide before", "decidir antes de"),
    "attribute": ("attribute", "atributo"),
    "kind": ("kind", "tipo", "natureza"),
    "required": ("required", "obrigatório", "obrigatorio"),
    "unique": ("unique", "único", "unico"),
    "changes": ("changes", "alteração", "alteracao", "muda"),
    "personal": ("personal", "pessoal", "dado pessoal"),
}
# Business kinds of an attribute (not database types). "calculated" may follow any of them.
KINDS = (
    "text", "number", "money", "date-time", "date", "time", "duration", "yes/no", "list", "reference",
    "file", "image", "e-mail", "email", "phone",
    "texto", "número", "numero", "dinheiro", "data e hora", "data", "hora", "duração", "duracao", "sim/não",
    "sim/nao", "lista", "referência", "referencia", "arquivo", "imagem", "telefone",
)
REFERENCE_RE = re.compile(r"(?:reference|referência|referencia|list of|lista de)\s*(?:→|->|(?:to|a|para|de)\s)?\s*([^,;()]+)",
                          re.IGNORECASE)
YES_NO = {"yes", "no", "sim", "não", "nao", "n/a"}
ITEM_STATUSES = {
    "confirmed": "confirmed", "confirmado": "confirmed", "confirmada": "confirmed",
    "inferred": "inferred", "inferido": "inferred", "inferida": "inferred",
    "proposed": "proposed", "proposto": "proposed", "proposta": "proposed",
    "rejected": "rejected", "rejeitado": "rejected", "rejeitada": "rejected",
}
PROPOSAL_STATUSES = {
    "pending": "pending", "pendente": "pending",
    "accepted": "accepted", "aceita": "accepted", "aceito": "accepted",
    "rejected": "rejected", "rejeitada": "rejected", "rejeitado": "rejected",
}
QUESTION_STATUSES = {
    "open": "open", "aberta": "open",
    "answered": "answered", "respondida": "answered",
    "deferred": "deferred", "adiada": "deferred",
}
NONE_VALUES = {"none", "nenhuma", "nenhum", "n/a"}
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
SUBHEADING_RE = re.compile(r"^###\s+(.+?)\s*$", re.MULTILINE)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
FENCE_RE = re.compile(r"^```.*?^```", re.DOTALL | re.MULTILINE)
PLACEHOLDER_RE = re.compile(r"(?-i:\bTBD\b|\bTODO\b)|\?\?\?|\ba definir\b|<[^>!\n]+>", re.IGNORECASE)
UC_HEADING_RE = re.compile(r"^###\s+(UC|CU)-(\d+)\s*:\s*(.*)$", re.MULTILINE | re.IGNORECASE)
REF_RE = re.compile(r"\b(ACT|UC|CU|BR|RN|P|DQ)-(\d+)\b", re.IGNORECASE)
NONE_WITH_REASON_RE = re.compile(r"^\s*(none|nenhum|nenhuma)\b\s*[:—–-]\s*\S", re.IGNORECASE)
CANONICAL = {"cu": "UC", "rn": "BR"}


def norm(prefix: str, number: str) -> str:
    """Canonical id: Portuguese aliases CU/RN become UC/BR; UC and BR take two digits (UC-01), the rest one."""
    canonical = CANONICAL.get(prefix.lower(), prefix.upper())
    return f"{canonical}-{int(number):02d}" if canonical in ("UC", "BR") else f"{canonical}-{int(number)}"


def refs_in(text: str) -> set[str]:
    return {norm(p, n) for p, n in REF_RE.findall(text)}


SIZES = {"small": 0, "pequeno": 0, "medium": 1, "médio": 1, "medio": 1,
         "large": 2, "grande": 2, "complex": 3, "complexo": 3}
SIZE_NAMES = ("small", "medium", "large", "complex")
# What a model of each size may hold before the size is wrong; large and complex have no limit.
SIZE_LIMITS = {0: {"rules": 5, "entities": 3, "lifecycles": 0}, 1: {"rules": 15, "entities": 8, "lifecycles": 2}}
STATE_TRIGGER = {"state", "states", "state transitions", "estado", "estados", "transições de estado",
                 "transicoes de estado"}


def brief_depth(brief_text: str) -> tuple[int, set[str]] | None:
    """Size and triggers of the brief's Depth section (checked by check_brief.py), or None when it has none."""
    depth = re.search(r"^##\s+(depth|profundidade)\s*$(.*?)(?=^##\s|\Z)", brief_text,
                      re.IGNORECASE | re.MULTILINE | re.DOTALL)
    if not depth:
        return None
    size = field(depth.group(2), "size", "tamanho").lower().strip(".")
    if size not in SIZES:
        return None
    triggers_text = field(depth.group(2), "triggers", "gatilhos")
    triggers = {re.sub(r"\(.*?\)", "", item).strip().lower() for item in re.split(r"[,;]", triggers_text)}
    return SIZES[size], {"state" if item in STATE_TRIGGER else item for item in triggers if item}


def sections_of(text: str, spec: dict[str, tuple[str, ...]]) -> dict[str, str]:
    lookup = {alias: key for key, aliases in spec.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def table_rows(body: str) -> list[dict[str, str]]:
    """Rows of the first Markdown table in body, keyed by canonical column name."""
    lines = []
    for line in body.splitlines():
        if line.strip().startswith("|"):
            lines.append(line.strip())
        elif lines:
            break
    if len(lines) < 2:
        return []
    lookup = {alias: key for key, aliases in COLUMNS.items() for alias in aliases}
    keys = [lookup.get(cell.strip().lower(), cell.strip().lower()) for cell in lines[0].strip("|").split("|")]
    rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        rows.append(dict(zip(keys, cells + [""] * (len(keys) - len(cells)), strict=False)))
    return rows


def field(block: str, *labels: str) -> str:
    for label in labels:
        match = re.search(rf"^\s*{label}\s*:\s*(.*)$", block, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return ""


def labelled_block(block: str, labels: tuple[str, ...], stop: tuple[str, ...]) -> str | None:
    """Text after a 'Label:' line up to the next known label, or None when the label is absent."""
    start = re.search(rf"^\s*({'|'.join(labels)})\s*:\s*(.*)$", block, re.IGNORECASE | re.MULTILINE)
    if not start:
        return None
    rest = block[start.end() :]
    end = re.search(rf"^\s*({'|'.join(stop)})\s*:", rest, re.IGNORECASE | re.MULTILINE)
    return (start.group(2) + "\n" + (rest[: end.start()] if end else rest)).strip()


def is_none(body: str) -> bool:
    return body.strip().strip(".").lower() in NONE_VALUES or bool(NONE_WITH_REASON_RE.match(body))


def find(path_text: str, base: Path) -> Path | None:
    for candidate in [Path(path_text), base.parent / path_text, *(p / path_text for p in base.resolve().parents)]:
        if candidate.is_file():
            return candidate
    return None


class Gate:
    def __init__(self) -> None:
        self.invalid: list[str] = []
        self.pending: list[str] = []
        self.warnings: list[str] = []
        self.defined: dict[str, str] = {}  # canonical id -> where it was defined
        self.status: dict[str, str] = {}  # canonical id -> item or proposal status
        self.cited: list[tuple[str, str]] = []  # (where, text) to resolve at the end
        self.sources: dict[str, str] = {}  # item -> its Source, to check the proposals it cites

    def define(self, rid: str, where: str) -> None:
        if rid in self.defined:
            self.invalid.append(f"{rid} is defined twice ({self.defined[rid]} and {where})")
        self.defined[rid] = where

    def item_status(self, rid: str, status_text: str, source: str) -> None:
        status = ITEM_STATUSES.get(status_text.strip().lower())
        if status is None:
            self.invalid.append(f"{rid}: status must be confirmed, inferred, proposed or rejected (got {status_text!r})")
            return
        self.status[rid] = status
        self.sources[rid] = source
        if not source.strip():
            self.invalid.append(f"{rid}: no source (Qn, brief:, E/C, P-n, doc:, repo:)")
        if status in ("inferred", "proposed"):
            self.pending.append(f"{rid}: still {status}; ask the user to confirm or reject it")


EXAMPLES = Path(__file__).resolve().parent.parent / "references" / "examples"
TEMPLATE = Path(__file__).resolve().parent.parent / "references" / "domain-template.md"
MIN_COPIED = 40  # shorter lines (a header row, "(none)") are common to any model
SEPARATOR_RE = re.compile(r"^\s*\|[\s:|-]+\|\s*$")


def _normal(line: str) -> str:
    return re.sub(r"\s+", " ", line.strip()).lower()


def copied_from_examples(text: str) -> list[str]:
    """Lines of the model that repeat a line of an example of another business. An example's own project (the
    same Brief header) may of course repeat it."""
    if not EXAMPLES.is_dir():
        return []
    common = set()
    if TEMPLATE.is_file():
        common = {_normal(line) for line in TEMPLATE.read_text(encoding="utf-8").splitlines()}
    brief = _normal(field(text, "brief"))
    found = []
    for example in sorted(EXAMPLES.glob("*.md")):
        example_text = example.read_text(encoding="utf-8")
        if brief and brief == _normal(field(example_text, "brief")):
            continue
        raw = example_text.splitlines()
        # A table's header row and separator are the template's column names, shared by every model.
        headers = {i for i, line in enumerate(raw[:-1]) if SEPARATOR_RE.match(raw[i + 1])}
        lines = {
            _normal(line) for i, line in enumerate(raw) if i not in headers and not SEPARATOR_RE.match(line)
        }
        lines = {line for line in lines if len(line) >= MIN_COPIED and line not in common}
        for number, line in enumerate(text.splitlines(), start=1):
            if _normal(line) in lines:
                found.append(f"line {number} repeats the example {example.name} (another business): "
                             "write the model from this project's interview")
    return found


def check_attributes(gate: Gate, text: str, entities: list[dict[str, str]], entity_names: set[str]) -> None:
    """Each entity's attributes, in business terms: kind, required, unique, when it changes, status and source."""
    body = sections_of(text, OPTIONAL_SECTIONS).get("attributes")
    confirmed = {
        row["entity"].strip().lower(): row["entity"].strip() for row in entities
        if row.get("entity") and ITEM_STATUSES.get(row.get("status", "").strip().lower()) == "confirmed"
    }
    if body is None:
        if confirmed:
            gate.warnings.append("no '## Attributes' section: each entity's attributes (kind, required, unique, when "
                                 "they change) are left to the design and the code (recommended since 1.4.0)")
        return
    rows = table_rows(body)
    if not rows:
        if not is_none(body):
            gate.invalid.append("attributes table has no rows; write 'None: <why>' when no entity has attributes")
        return
    missing = [c for c in ("entity", "attribute", "kind", "required", "status", "source") if c not in rows[0]]
    if missing:
        gate.invalid.append(f"attributes table is missing column(s): {', '.join(missing)}")
        return
    seen: set[tuple[str, str]] = set()
    described: set[str] = set()
    for row in rows:
        entity, attribute = row.get("entity", "").strip(), row.get("attribute", "").strip()
        where = f"attribute '{entity}.{attribute}'"
        if not entity or not attribute:
            gate.invalid.append("attribute row without its entity or its name")
            continue
        if (entity.lower(), attribute.lower()) in seen:
            gate.invalid.append(f"{where} is listed twice")
        seen.add((entity.lower(), attribute.lower()))
        if entity.lower() not in entity_names:
            gate.invalid.append(f"{where}: '{entity}' is not in the Entities table")
        described.add(entity.lower())
        kind = row.get("kind", "").strip().lower()
        if not kind.startswith(KINDS):
            gate.invalid.append(f"{where}: kind must be a business kind (text, number, money, date, date-time, "
                                f"yes/no, list of ..., reference → <Entity>, file, image), got {row.get('kind')!r}")
        for target in REFERENCE_RE.findall(row.get("kind", "")):
            name = target.strip().strip(":").strip()
            if name and not name.lower().startswith(("value", "valor")) and ":" not in target                     and name.lower() not in entity_names:
                gate.invalid.append(f"{where}: refers to '{name}', which is not in the Entities table")
        if row.get("required", "").strip().lower().split(" ")[0] not in YES_NO:
            gate.invalid.append(f"{where}: Required must be yes or no (sim / não), or n/a for a calculated one")
        if "changes" in row and not row["changes"].strip():
            gate.invalid.append(f"{where}: say when it can change (yes, no, once, until <state>, by <actor>)")
        if "personal" in row and row["personal"].strip().lower() not in YES_NO:
            gate.invalid.append(f"{where}: Personal must be yes or no")
        gate.item_status(where, row.get("status", ""), row.get("source", ""))
        gate.cited.append((where, row.get("rule", "") + " " + row.get("source", "")))
    for key, name in confirmed.items():
        if key not in described:
            gate.invalid.append(f"entity '{name}' has no attributes; list them, or say in the entity's Meaning why "
                                "it has none")


def check(path: Path) -> Gate:
    gate = Gate()
    text = path.read_text(encoding="utf-8")
    sections = sections_of(text, SECTIONS)

    brief_text = field(text, "brief")
    depth: tuple[int, set[str]] | None = None
    if not brief_text:
        gate.invalid.append("header: missing 'Brief: <path>'")
    else:
        brief = find(brief_text, path)
        if brief is None:
            gate.invalid.append(f"header: brief not found at {brief_text}")
        else:
            brief_raw = brief.read_text(encoding="utf-8")
            if not re.search(r"^status:\s*(confirmed|confirmado)\b", brief_raw, re.IGNORECASE | re.MULTILINE):
                gate.invalid.append("the brief is not 'Status: confirmed'; confirm it (factory-idea-interview) first")
            depth = brief_depth(brief_raw)

    for key, aliases in SECTIONS.items():
        if key not in sections:
            gate.invalid.append(f"missing section '## {aliases[0].capitalize()}'")
        elif not sections[key]:
            gate.invalid.append(f"section '{aliases[0]}' is empty; write 'None: <why>' when it does not apply")

    visible = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    visible = FENCE_RE.sub(lambda m: "\n" * m.group(0).count("\n"), visible)
    for match in PLACEHOLDER_RE.finditer(visible):
        gate.invalid.append(f"placeholder {match.group(0)!r} on line {visible.count(chr(10), 0, match.start()) + 1}")
    gate.invalid += copied_from_examples(text)

    # Glossary
    terms = {row.get("term", "").strip().lower() for row in table_rows(sections.get("glossary", ""))}
    for row in table_rows(sections.get("glossary", "")):
        if not row.get("definition"):
            gate.invalid.append(f"glossary '{row.get('term', '?')}': no definition")

    # Actors
    actors = table_rows(sections.get("actors", ""))
    if "actors" in sections and not actors:
        gate.invalid.append("actors table has no rows")
    for row in actors:
        rid = row.get("id", "")
        if not REF_RE.fullmatch(rid) or not rid.upper().startswith("ACT"):
            gate.invalid.append(f"actor {row.get('actor') or '?'}: id must be ACT-n (got {rid!r})")
            continue
        gate.define(norm(*rid.split("-")), "actors")
        if not row.get("source"):
            gate.invalid.append(f"{rid}: no source")
        if not row.get("responsibilities"):
            gate.invalid.append(f"{rid}: no responsibilities")

    # Use cases
    use_cases = sections.get("use_cases", "")
    blocks = list(UC_HEADING_RE.finditer(use_cases))
    if "use_cases" in sections and not blocks:
        gate.invalid.append("no use cases ('### UC-01: <title>')")
    uc_actors: set[str] = set()
    for i, match in enumerate(blocks):
        rid = norm(match.group(1), match.group(2))
        block = use_cases[match.end() : blocks[i + 1].start() if i + 1 < len(blocks) else len(use_cases)]
        gate.define(rid, "use cases")
        gate.item_status(rid, field(block, "status"), field(block, "source", "fonte"))
        actor = field(block, "actor", "ator")
        if not actor:
            gate.invalid.append(f"{rid}: no Actor")
        uc_actors |= refs_in(actor)
        labels = ("main flow", "fluxo principal", "alternative flows", "fluxos alternativos", "result", "resultado",
                  "trigger", "gatilho", "status", "source", "fonte", "actor", "ator")
        main = labelled_block(block, ("main flow", "fluxo principal"), labels)
        steps = re.findall(r"^\s*\d+[.)]\s+\S", main or "", re.MULTILINE)
        if gate.status.get(rid) != "rejected" and len(steps) < 2:
            gate.invalid.append(f"{rid}: main flow needs at least 2 numbered steps")
        alternatives = labelled_block(block, ("alternative flows", "fluxos alternativos"), labels)
        if gate.status.get(rid) != "rejected":
            if alternatives is None or not alternatives:
                gate.invalid.append(f"{rid}: no 'Alternative flows:' (write 'None: <why>' when it truly has none)")
            elif alternatives.strip().lower().strip(".") in NONE_VALUES:
                gate.invalid.append(f"{rid}: 'Alternative flows: None' needs a reason ('None: <why>')")
        gate.cited.append((rid, block))

    # Business rules
    rules = table_rows(sections.get("rules", ""))
    if "rules" in sections and not rules and not is_none(sections["rules"]):
        gate.invalid.append("business rules table has no rows")
    for row in rules:
        raw = row.get("id", "")
        if not REF_RE.fullmatch(raw):
            gate.invalid.append(f"rule {row.get('rule', '?')[:40]!r}: id must be BR-nn (got {raw!r})")
            continue
        rid = norm(*raw.split("-"))
        gate.define(rid, "business rules")
        gate.item_status(rid, row.get("status", ""), row.get("source", ""))
        if not row.get("rule"):
            gate.invalid.append(f"{rid}: empty rule")
        if gate.status.get(rid) != "rejected":
            if not row.get("example"):
                gate.invalid.append(f"{rid}: no example")
            if not row.get("counterexample"):
                gate.invalid.append(f"{rid}: no counterexample (write 'n/a: <why>' when nothing can break it)")
        gate.cited.append((rid, row.get("source", "")))

    # Entities
    entities = table_rows(sections.get("entities", ""))
    if "entities" in sections and not entities and not is_none(sections["entities"]):
        gate.invalid.append("entities table has no rows")
    entity_names: set[str] = set()
    used_text: list[str] = []
    for row in entities:
        name = row.get("entity", "").strip()
        if not name:
            gate.invalid.append("entity row without a name")
            continue
        entity_names.add(name.lower())
        where = f"entity '{name}'"
        gate.item_status(where, row.get("status", ""), row.get("source", ""))
        if not row.get("meaning"):
            gate.invalid.append(f"{where}: no meaning")
        if name.lower() not in terms:
            gate.warnings.append(f"{where} is not in the glossary")
        gate.cited.append((where, " ".join(row.values())))
        used_text.append(row.get("invariants", "") + " " + row.get("relationships", ""))

    # Attributes
    check_attributes(gate, text, entities, entity_names)

    # Lifecycles
    lifecycles = sections.get("lifecycles", "")
    if lifecycles and not is_none(lifecycles):
        subs = list(SUBHEADING_RE.finditer(lifecycles))
        if not subs:
            gate.invalid.append("lifecycles: one '### <Entity>' per entity that changes state, or 'None: <why>'")
        for i, match in enumerate(subs):
            name = match.group(1).strip()
            body = lifecycles[match.end() : subs[i + 1].start() if i + 1 < len(subs) else len(lifecycles)]
            if name.lower() not in entity_names:
                gate.invalid.append(f"lifecycle '{name}': not an entity in the Entities table")
            transitions = table_rows(body)
            if not transitions:
                gate.invalid.append(f"lifecycle '{name}': no transitions (From | Event | To | Rule)")
            for row in transitions:
                if not row.get("from") or not row.get("event") or not row.get("to"):
                    gate.invalid.append(f"lifecycle '{name}': a transition needs From, Event and To")
            gate.cited.append((f"lifecycle '{name}'", body))
            used_text.append(body)
    elif lifecycles and is_none(lifecycles) and not NONE_WITH_REASON_RE.match(lifecycles):
        gate.invalid.append("lifecycles: 'None' needs a reason ('None: <why>')")

    # Proposals
    proposals = sections.get("proposals", "")
    if proposals and not is_none(proposals):
        for row in table_rows(proposals):
            raw = row.get("id", "")
            if not REF_RE.fullmatch(raw) or not raw.upper().startswith("P"):
                gate.invalid.append(f"proposal {row.get('proposal', '?')[:40]!r}: id must be P-n (got {raw!r})")
                continue
            rid = norm(*raw.split("-"))
            gate.define(rid, "proposals")
            status = PROPOSAL_STATUSES.get(row.get("status", "").strip().lower())
            if status is None:
                gate.invalid.append(f"{rid}: status must be pending, accepted or rejected (got {row.get('status')!r})")
                continue
            gate.status[rid] = status
            for column in ("proposal", "why", "implications"):
                if not row.get(column):
                    gate.invalid.append(f"{rid}: no {column}")
            if status == "pending":
                gate.pending.append(f"{rid}: pending proposal: {row.get('proposal', '')[:70]}")
            elif not row.get("result"):
                gate.invalid.append(f"{rid}: {status} proposal needs a Result (the items it created, or why rejected)")
            gate.cited.append((rid, row.get("result", "")))

    # Open questions
    questions = sections.get("open_questions", "")
    if questions and not is_none(questions):
        for row in table_rows(questions):
            raw = row.get("id", "")
            if not REF_RE.fullmatch(raw) or not raw.upper().startswith("DQ"):
                gate.invalid.append(f"question {row.get('question', '?')[:40]!r}: id must be DQ-n (got {raw!r})")
                continue
            rid = norm(*raw.split("-"))
            gate.define(rid, "open questions")
            status = QUESTION_STATUSES.get(row.get("status", "").strip().lower())
            if status is None:
                gate.invalid.append(f"{rid}: status must be open, answered or deferred (got {row.get('status')!r})")
                continue
            gate.status[rid] = status
            if status == "open":
                gate.pending.append(f"{rid}: open question: {row.get('question', '')[:70]}")
            elif status == "deferred" and (not row.get("impact") or not row.get("before")):
                gate.invalid.append(f"{rid}: a deferred question needs its Impact and 'Decide before'")
            elif status == "answered" and not row.get("impact"):
                gate.invalid.append(f"{rid}: an answered question names the item it settled in Impact")

    # References resolve; confirmed items cite accepted proposals only
    for where, body in gate.cited:
        for ref in sorted(refs_in(body)):
            if ref not in gate.defined:
                gate.invalid.append(f"{where}: {ref} is not defined in this document")
    for where, source in gate.sources.items():
        if gate.status.get(where) == "confirmed":
            for ref in sorted(refs_in(source)):
                if ref.startswith("P-") and ref in gate.defined and gate.status.get(ref) != "accepted":
                    gate.invalid.append(f"{where}: confirmed from {ref}, which is not an accepted proposal")

    # Safety valve: a model bigger than the size the brief declared reopens the sizing with the user
    if depth is not None:
        size, triggers = depth
        counts = {
            "rules": sum(1 for rid, where in gate.defined.items()
                         if where == "business rules" and gate.status.get(rid) != "rejected"),
            "entities": sum(1 for row in entities if row.get("entity") and
                            ITEM_STATUSES.get(row.get("status", "").strip().lower()) != "rejected"),
            "lifecycles": len(SUBHEADING_RE.findall(lifecycles)) if lifecycles and not is_none(lifecycles) else 0,
        }
        limits = SIZE_LIMITS.get(size)
        if limits:
            for name, count in counts.items():
                if count > limits[name]:
                    gate.pending.append(
                        f"depth valve: {count} {name} exceed the brief's size '{SIZE_NAMES[size]}' "
                        f"(up to {limits[name]}); raise the size in the brief's Depth with the user "
                        "(factory-change) and reopen the steps it skipped"
                    )
        if counts["lifecycles"] and "state" not in triggers:
            gate.pending.append("depth valve: the model has lifecycles, but the brief's triggers omit 'state'; "
                                "update the brief's Depth with the user (factory-change)")

    # Warnings: rules nobody uses, actors with no use case
    use_case_text = use_cases + " ".join(used_text)
    used = refs_in(use_case_text)
    for rid, where in gate.defined.items():
        if where == "business rules" and rid not in used and gate.status.get(rid) != "rejected":
            gate.warnings.append(f"{rid} is not used by any use case, entity or lifecycle")
        if where == "actors" and rid not in uc_actors:
            gate.warnings.append(f"{rid} is the actor of no use case")
    return gate


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    gate = check(Path(sys.argv[1]))
    for warning in dict.fromkeys(gate.warnings):
        print(f"warning: {warning}")
    if gate.invalid:
        print("INVALID")
        for item in dict.fromkeys(gate.invalid):
            print(f"  - {item}")
        return 1
    if gate.pending:
        print("NEEDS-ANSWERS")
        for item in dict.fromkeys(gate.pending):
            print(f"  - {item}")
        return 2
    print("READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
