---
name: factory-grill-me
description: A relentless interview to sharpen a plan or design. Run only when the user explicitly invokes it.
license: MIT
metadata:
  author: Matt Pocock (mattpocock/skills)
  version: "1.1.0"
  upstream: "mattpocock/skills skills/productivity/grill-me @ 49dd158 (MIT)"
disable-model-invocation: true
---

Load and follow the `factory-grilling` skill. Use scoped mode when the user names the decisions or points at a document that lists them (for example a PRD brief's *Decisions to stress-test*); otherwise use open mode on the plan in the conversation.

If the `factory-grilling` skill is not installed, tell the user that factory-grill-me needs it and stop.
