# factory-grilling and factory-grill-me

Copies of `grilling` and `grill-me` from [mattpocock/skills](https://github.com/mattpocock/skills) (`skills/productivity/`, commit `49dd158`), MIT licensed. The upstream license is kept in each skill folder as `LICENSE`.

- **factory-grilling** is the method, and the model can trigger it on its own: a design tree of decisions, asked in numbered rounds, each question with a recommended answer.
- **factory-grill-me** is a thin command that only the user can invoke (`/factory-grill-me`); it loads `factory-grilling`.

## Changes from upstream

| Change | Why |
|--------|-----|
| **Scoped mode**: when given a list of decisions, the tree contains only those | `factory-idea-interview` hands over its *Decisions to stress-test*; factory-grilling must not reopen the whole brief |
| **At most 5 questions per round**, most expensive-to-reverse first | Upstream asks the whole frontier at once; large rounds get skimmed, one-word answers |
| **Strongest objection** (⚠️) on costly-to-reverse decisions | Upstream maps decisions but never argues against its own recommendation, so the plan is never actually stress-tested |
| **Decision record** at the end (decisions, dropped items, unverified assumptions), and the source document is updated after confirmation | Upstream ends at "shared understanding" without writing it down; the next step (PRD, plan) needs it in writing |
| "Whatever you think" does not settle a decision; stop-anytime and non-interactive rules | Prevents silent assumptions and invented answers |
| Description with a "use" trigger and near-miss boundaries (`idea-interview`, code review); `license`, `compatibility`, and `metadata.upstream` fields | Better triggering, and provenance for tracking upstream changes |
| factory-grill-me says "load the `factory-grilling` skill" instead of "call the Skill tool" and states what happens when factory-grilling is missing | "Skill tool" is Claude Code wording; other agents load skills differently |
| Codex-only `agents/openai.yaml` not copied | Not used by the agents this project targets |

## Known deviation from the specification

`factory-grill-me` keeps `disable-model-invocation: true`, which the official validator (`agentskills validate`) rejects because it is not a field of the specification. This is intentional. Claude Code and Pi read it to make the skill user-invoked only. Without it, the model could trigger factory-grill-me on its own, and it would compete with `factory-grilling`. Agents that ignore the field still load the skill correctly. `factory-grilling` and `factory-idea-interview` pass the validator.

## How it fits the PRD flow

```
factory-idea-interview → brief → quality gate ── STRESS-TEST ──→ factory-grilling (scoped mode) → updates brief → gate → PASS → PRD
```
