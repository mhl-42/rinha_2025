---
name: factory-grilling
description: Grill the user relentlessly about a plan, decision, or design until every branch is settled — mapping the decisions as a tree, asking them in numbered rounds with a recommended answer each, and ending with a confirmed decision record. Use when the user wants to stress-test their thinking, uses any "grill" phrase ("grill me", "poke holes in this", "challenge this plan"), or when another skill hands over a list of decisions to stress-test (e.g. the Decisions to stress-test section of a PRD brief). Not for discovering what a vague idea is in the first place (use factory-idea-interview) or for reviewing finished code.
license: MIT
compatibility: Interactive sessions only. Works in any agent; uses sub-agents for fact-finding when the host has them.
metadata:
  author: Matt Pocock (mattpocock/skills)
  version: "1.1.0"
  upstream: "mattpocock/skills skills/productivity/grilling @ 49dd158 (MIT)"
---

# Grilling

Interview the user relentlessly until you reach a shared understanding. Map this as a **design tree**: every decision branches into the decisions that hang off it.

## Scope first

- **Scoped mode:** if you were given a list of decisions (by the user or by another skill, such as the *Decisions to stress-test* of a PRD brief), the tree contains only those decisions and what hangs off them. Do not reopen anything outside that list.
- **Open mode:** otherwise, build the tree from the plan or idea the user described.

## Rounds

Work the tree in **rounds**. The **frontier** is every decision whose prerequisites are already settled: the questions you can ask *now* without guessing at answers you have not heard yet.

Ask the frontier in one round, **at most 5 questions**, the most expensive-to-reverse first. Leave the rest for the next round. Number each question and give your recommended answer. Then wait for the user's answers before the next round.

Format a round like so:

```
❓ **Q1** - **<question title>**: <question body, might be multiple paragraphs, including multiple choices>

⚠️ <strongest objection or failure mode — for costly-to-reverse decisions only>

➡️ <your recommended answer>

---

❓ **Q2** - **<question title>**: <question body>

➡️ <your recommended answer>
```

Word each question so "yes" accepts your recommended answer.

For decisions that are costly to reverse (data model, public API, vendor, pricing, security model), include the strongest objection to your own recommendation. A plan that survives only friendly questions has not been grilled.

Each round the user answers reshapes the tree: settled decisions push the frontier outward and unblock questions that depended on them. Recompute the frontier and ask the next round. A question whose answer depends on another question still open in this round belongs to a *later* round, not this one.

## Facts versus decisions

Finding *facts* is your job, never the user's. When a frontier question needs a fact from the environment (filesystem, tools, docs), look it up, or dispatch a sub-agent to find it if the host has them. Do not ask the user for anything you could look up yourself. Do not block on it: a running exploration is an unsettled prerequisite, so only the questions downstream of it wait; ask the rest of the frontier now.

The *decisions* are the user's: put each to them and wait. "Whatever you think" settles nothing. Restate your recommendation as the decision and ask for an explicit yes.

## Finishing

The session is done when the frontier is empty: every branch of the design tree visited, nothing left silently assumed. Then write the **decision record**:

```
## Decisions
- <decision> — <reason> (Q<n>)

## Dropped / out of scope
- <item> — <why>

## Assumptions still unverified
- <assumption> — <how to check>
```

If the decisions came from a document (for example a PRD brief), update that document in the same turn: move each settled item into its *Decisions* section, move dropped items to *Out of scope*, and set the stress-test list to `None`. Then show the record (and what changed in the document) and ask for **one** confirmation. If the user corrects it, fix both. Do not act on the plan itself, beyond updating the document, until they confirm.

## Gotchas

- The user can stop at any time ("enough", "stop"). Write the decision record with what is settled and list the rest under *Assumptions still unverified*.
- In non-interactive runs (CI, scheduled jobs, autonomous loops) there is nobody to answer. Do not invent answers: report the open decisions as blockers.
- More than 5 questions per round produces skimmed, one-word answers. Keep rounds short and ordered by cost of reversal.
