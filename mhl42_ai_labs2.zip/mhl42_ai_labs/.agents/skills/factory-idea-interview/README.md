# factory-idea-interview

Interviews the user about a vague idea and produces a confirmed **PRD brief** that passes a quality gate. The PRD itself is written by a later step from that brief.

```
idea → interview → synthesis (factory-idea-synthesis) → brief → quality gate ─┬─ FAIL ──────→ interview (failing items only)
                                                                      ├─ STRESS-TEST → stress-test round (factory-grilling) → gate
                                                                      └─ PASS ──────→ PRD generation (next turn)
```

## Files

```
factory-idea-interview/
├── SKILL.md                     # Workflow, interview rules, routing on the gate result
├── references/
│   ├── question-bank.md         # Questions ordered by dependency (problem → users → metrics → scope → constraints → risks)
│   ├── brief-template.md        # The PRD brief; headings in English or Portuguese
│   └── quality-gate.md          # Automatic + semantic checks; why the stress-test comes after the gate
├── scripts/
│   └── check_brief.py           # Deterministic gate: exit 0 PASS, 1 FAIL, 2 STRESS-TEST
└── evals/
    ├── evals.json               # Output-quality cases
    └── trigger_queries.json     # Should/should-not trigger queries
```

## Relation to factory-grill-me

factory-grill-me is **not embedded**. It runs **after** the gate, and only on the decisions the brief lists under *Decisions to stress-test*:

- **Different jobs.** The interview discovers what the user wants. factory-grill-me (via the `factory-grilling` primitive) challenges decisions once they exist. Grilling first spends questions on a decision tree that is not defined yet.
- **Cost.** Grilling every brief wears the user out with objections to cheap, reversible choices. Scoping it to costly-to-reverse decisions keeps the hard questions where they pay off.
- **Composition.** In mattpocock/skills, grill-me is user-invoked (`disable-model-invocation: true`), and user-invoked skills do not call each other. This skill calls the model-invoked `grilling` primitive instead (in its scoped mode; a modified copy lives in `skills/grilling`), and falls back to the same method inline when it is not installed. The skill works on its own.

## Run the gate

```bash
python scripts/check_brief.py docs/prd-brief/<slug>.md
```

## Install

Copy `factory-idea-interview/` into a skills directory your agent reads (for example `.claude/skills/` or `.agents/skills/`). See `docs/install-skills.md` at the repository root.
