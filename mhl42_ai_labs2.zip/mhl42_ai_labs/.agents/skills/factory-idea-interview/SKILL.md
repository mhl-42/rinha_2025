---
name: factory-idea-interview
description: Use this skill when the user has an idea, feature, or product they want to turn into a PRD or spec but the request is still vague — interview them in short rounds of questions, write a confirmed PRD brief (problem, users, current workaround, outcome, metrics, product shape, scope, constraints, risks), and pass it through a quality gate before the domain is modelled and any PRD is written. Triggers on "I have an idea for…", "help me write a PRD", "let's spec out X", "I want to build an app that…", even if "PRD" is not mentioned. Not for writing the PRD from an already-confirmed brief, for stress-testing a finished plan or design (use factory-grill-me), or for tasks that are already specified well enough to implement.
license: MIT
compatibility: Interactive sessions only; needs the user to answer questions. scripts/check_brief.py needs Python 3.10+ (no dependencies). Works without factory-idea-synthesis, factory-domain-model or factory-grill-me/factory-grilling installed; uses them for the synthesis, domain and stress-test steps when present.
metadata:
  author: mhl42
  version: "1.4.1"
---

# Idea Interview → PRD Brief

Turn a vague idea into a **PRD brief**: a short, confirmed document that says what problem is solved, for whom, how success is measured, and what is in and out of scope. This skill does not model the business rules (factory-domain-model does, right after) and does not write the PRD. It ends when the brief passes the quality gate and the user confirms it.

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief + gate → 2b factory-domain-model → 3 factory-prd-writer
```

Write the questions and the brief in the user's language.

## Workflow

Copy this checklist and track it:

```
- [ ] 1. Hypothesis stated with confidence
- [ ] 2. Facts gathered from the repo/docs (not asked)
- [ ] 3. Interview until the stop rule holds, logging answers as Q1, Q2...
- [ ] 3b. Synthesis: answers organized, contradictions resolved, facts vs hypotheses
- [ ] 4. Brief drafted from the synthesis and explicitly confirmed
- [ ] 5. Quality gate: PASS (or routed back / to stress-test)
- [ ] 6. Brief saved; handoff offered
```

### 1. State a hypothesis
Write one sentence with your reading of the idea and a confidence percentage, for example: "You want a room-booking API for employees so double bookings stop — 60% confident; I don't know who the users are or what 'done' looks like."

### 2. Look up facts, ask about decisions
Facts the project can answer (stack, existing modules, current behavior, docs) are your job: read them. Only **decisions and preferences** go to the user. Never ask "what framework do you use?" when `pyproject.toml` says it.

### 3. Interview
- **Ask in rounds of up to 3 questions.** Put together questions that do not depend on each other's answers, number them, and give each a recommended answer and a one-line reason, phrased so "yes" accepts it. Ask a question **alone** when its answer changes what you would ask next (for example, the problem itself, or who the users are) or when it is a costly-to-reverse decision.
- The user may answer several questions at once or volunteer more. Use everything they say, and do not re-ask what is already answered.
- Follow the order in [references/question-bank.md](references/question-bank.md): problem → users and how they cope today → outcome and metrics → product shape → scope and out-of-scope → constraints → risks. Do not ask about solutions before the problem is clear.
- **One recommendation per decision.** A recommended answer that settles several things at once ("in scope: products, invoices, sales, split payment, receipt, write-off, balance; out: returns, discounts...") gets one "yes" for many decisions, and nobody knows which ones the user weighed. Number the parts so the user can accept them one by one, and leave rule-level detail (what is valid, what is refused, what happens on a mistake) to factory-domain-model.
- **Product shape, not technology.** Ask what form the product takes for its users (a library or SDK, a command line, a web app, a desktop or mobile app, a service, or a mix) and what that choice changes. When the answer is uncertain, show two or three options with their impact and record the shape as an assumption, not a decision. Do not recommend a language, framework or database here: those belong to factory-tech-design, after the domain and the requirements. If the user imposes one, record it under *Constraints* and ask whether it is a hard rule or a preference.
- **Depth, once the problem and the product shape are clear.** Go through the complexity triggers (data that persists, money, states, concurrency, permissions, integrations, personal data) in [references/question-bank.md](references/question-bank.md#0-depth), propose a size (small, medium, large, complex) and the steps it lets the factory skip, and ask the user to confirm. The triggers set a floor you cannot lower: the importance of the project does not change it. Write it in the brief's *Depth* section; every later step reads it to decide how much to ask and write.
- **No real operation behind it** (a study, a portfolio, a proof of concept): ask which real operation is the reference (a real supermarket, a real clinic) and how faithful the project must be to it. The domain step uses that reference to propose rules the user would not think of.
- Offer **concrete examples** when the user cannot answer in the abstract ("would a receptionist ever book for a patient over the phone?").
- When an answer sounds like a buzzword ("scalable", "simple", "modern"), ask what it means concretely in this case.
- "Whatever you think" or "sounds good" is not an answer to a decision. Offer 2-3 concrete options and ask again.
- **Stop rule:** stop when every section of the brief can be filled without guessing and you can predict the user's answers to your next three questions about the problem, the users and the scope. Questions about business rules, entities and exceptions are not a reason to keep interviewing here: write them down for factory-domain-model. If 5 rounds pass and the problem is still unclear, say so and ask whether to step back.
- **Answer log:** append each question and answer to `docs/prd-brief/<slug>.interview.md` as `Q1`, `Q2`... (question, recommended answer, user's answer). The synthesis cites these IDs.

### 3b. Synthesize
If the `factory-idea-synthesis` skill is installed, run it on the answer log. It organizes the answers, resolves contradictions with the user, separates facts from hypotheses, and writes the value proposition. Gaps it reports come back here as questions. Draft the brief from the synthesis once it reports `READY`.

If the brief's *Depth* skips the synthesis, or the skill is not installed, do a short inline pass before drafting: list contradictions between answers and ask about each one, and mark every prediction about users or customers as an assumption.

### 4. Draft and confirm the brief
Fill [references/brief-template.md](references/brief-template.md), from the synthesis when there is one (it lists which synthesis item goes to which section). Keep it to one or two pages. Mark everything you inferred, rather than heard, as an assumption. A decision the user accepted from your recommendation says so ("recommended, accepted in Q6"), so the next steps know it was not the user's own requirement. Put decisions that are costly to reverse under **Decisions to stress-test**.

Show the brief and ask for explicit confirmation. When the synthesis was just confirmed with nothing open, draft the brief in the same turn and ask for **one** confirmation of both. Apply corrections and show the changed lines again. After the user confirms, set `Status: confirmed` in the brief; factory-prd-writer refuses briefs without it.

### 5. Run the quality gate
Save the draft (default `docs/prd-brief/<slug>.md`) and run:

```bash
python <this-skill-dir>/scripts/check_brief.py docs/prd-brief/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

Then review the semantic checks in [references/quality-gate.md](references/quality-gate.md), which the script cannot judge. Route on the result:

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Missing or vague information. Go back to step 3 and ask **only** about the failing items, then re-run the gate. |
| `STRESS-TEST` | 2 | The brief is complete but lists decisions to stress-test. Run one stress-test round on those decisions only (see below), update the brief, re-run the gate. |
| `PASS` | 0 | Go to step 6. |

**Stress-test round:** if the `factory-grilling` skill is installed, use it in **scoped mode** with the items under *Decisions to stress-test*. It updates the brief after the user confirms. If it is not installed, use the same method: ask the strongest objection to each decision with a recommended answer, up to 3 independent decisions per message, and record the outcome under *Decisions*. Move the item to *Decisions* when it is settled, or to *Out of scope* if it was dropped. Do not reopen sections that already passed.

### 6. Hand off
Tell the user the brief path and the questions you set aside for the domain. The next step is the domain model (factory-domain-model): actors, use cases and their exceptions, business rules, entities and lifecycles. If the user already asked for a PRD, continue with the domain right away once the gate returns `PASS`, and say that the PRD comes after it. If factory-domain-model is not installed, do its consolidation inline before the PRD: list the use cases with their exceptions and the business rules with an example each, and ask the user to confirm them. Never start the PRD before the brief is confirmed and passes the gate.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Write the answer log with `doc_write(project, "interview", <slug>, ...)` from the first round on, the whole log each time (it has no status and is never confirmed). Create the project with `project_open(<slug>, name=...)` before that first write, so every later step finds it in the database.
- Write with `doc_write(project, "brief", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run. A brief that is `STRESS-TEST` cannot be confirmed until the grilling is done.
- Confirm with `doc_confirm(project, "brief", <slug>, revision, user_answer)` after the user's yes, passing their reply verbatim, instead of editing the Status line. Show them the revision you confirm. It refuses while an input is not confirmed, the document cites an item that changed after it (`stale` in the manifest: rewrite the citing text, or `stale_resolve` with a note when it still holds), or the gate fails on the confirmed text; read the refusal to the user.

## Gotchas

- Agents jump to solutions. A brief whose *Problem* says "build an app with login and a dashboard" describes a solution. Rewrite it as the user's pain and its cost.
- "Users" is not a persona. Name a role and the situation they are in ("receptionists booking rooms by phone during peak hours").
- Metrics without a number or a deadline are wishes. The gate rejects success-metric bullets with no digits.
- An empty *Out of scope* means scope was never discussed. The gate rejects it.
- Do not run the stress-test round before the gate. Grilling a vague idea wastes questions on decisions that are not yet defined, and the user tires before the important ones.
- Do not send a questionnaire. More than 3 questions per message, or questions that depend on each other, get shallow answers and hide which answer changed the plan.
- A brief where most answers are "accepted the recommendation" was written by the agent. In `supermercado-pdv`, 11 of the 13 answers (Q2 to Q12) were acceptances, and two of them settled six or more decisions each (Q5: 13 scope items; Q8: 6 stock rules). Split those recommendations, or move their details to the domain step.
- Sizing the work by how important the project feels. `supermercado-pdv` was a portfolio and was treated as small; it had persistence, money and states, which make it large. Size by the triggers.
- Narrating the process ("now I will run step 3"). Produce the questions and the brief; the user judges the output, not the play-by-play.
- Choosing the stack in the interview ("Python command line with SQLite") makes the technical design ratify it instead of deciding it. Record the user's impositions as constraints; leave the rest for factory-tech-design.
- In non-interactive runs (CI, scheduled jobs, autonomous loops), do not invent answers. Write the brief with every unknown under *Open questions*. The gate will FAIL, and the run should report that as a blocker.
