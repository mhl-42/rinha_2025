# PRD Brief Template

Copy the block below into `docs/prd-brief/<slug>.md` and fill every section. The headings must stay as they are (English or the Portuguese alias in parentheses), because `scripts/check_brief.py` finds sections by heading. Write the content in the user's language.

```markdown
# PRD Brief: <name>

Status: draft | confirmed
Date: YYYY-MM-DD

## Problem
<!-- The user's pain and its cost, without naming a solution. -->

## Target users
<!-- Role + situation. Who uses it, who judges success. -->

## Desired outcome
<!-- The concrete before/after for the user. -->

## Success metrics
<!-- One bullet per metric, each with a number: baseline -> target, by when. -->
- 

## Product shape
<!-- How users reach the product: library/SDK, CLI, web, desktop, mobile, service, or a mix; where it is used.
     Say whether it is decided or an assumption, and the options considered. No language, framework or database. -->

## Depth
<!-- How deep the factory goes for this product. The agent proposes it; the user confirms it (cite the answer).
     Size: small | medium | large | complex. Triggers: the complexity present, from the fixed list.
     Skipped steps: only synthesis (small or medium), domain model (small with no trigger) or ui design (no user interface: a library, an API, a job; a CLI or a bot has one),
     each as "<step> (<why>)", separated by ";". See references/question-bank.md, block 0. -->
Size:
Triggers:
Skipped steps:

## Scope
<!-- What v1 must do, as bullets. -->
- 

## Out of scope
<!-- What is explicitly not in v1. At least one bullet. -->
- 

## Constraints
<!-- Deadline, compliance, mandatory tech, integrations, data. Write "None" if there are none. -->

## Assumptions
<!-- Things inferred or not yet verified. Write "None" if there are none. -->

## Risks
<!-- Riskiest assumptions and how to check them. -->

## Decisions
<!-- Settled decisions, one bullet each, with the reason. -->

## Decisions to stress-test
<!-- Costly-to-reverse decisions not yet challenged. Write "None" when the stress-test round is done. -->

## Open questions
<!-- Must be "None" for the gate to pass. -->
None
```

*Product shape* (1.2.0) and *Depth* (1.3.0) are optional for the gate: it warns when one is missing and does not fail, so older briefs still pass. When *Depth* is present, the gate checks it (see references/quality-gate.md).

Portuguese headings accepted by the gate: `Problema`, `Usuários`, `Resultado esperado`, `Métricas de sucesso`, `Formato do produto`, `Profundidade` (`Tamanho:`, `Gatilhos:`, `Etapas puladas:`; sizes `pequeno`, `médio`, `grande`, `complexo`), `Escopo`, `Fora do escopo`, `Restrições`, `Premissas`, `Riscos`, `Decisões`, `Decisões para validar`, `Perguntas em aberto`.
