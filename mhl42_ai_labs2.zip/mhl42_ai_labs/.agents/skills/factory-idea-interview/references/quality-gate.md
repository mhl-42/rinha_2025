# Quality Gate

The gate has two layers. `scripts/check_brief.py` checks structure deterministically. You then check meaning with the list below. The brief passes only when both pass.

## Automatic checks (check_brief.py)

| Check | Fails when |
|-------|-----------|
| Required sections | Any section of the template is missing or empty |
| Placeholders | `TBD`, `TODO`, `???`, `a definir`, `<...>`, or an empty `- ` bullet remain |
| Measurable metrics | A *Success metrics* bullet has no digit |
| Out of scope | *Out of scope* has no bullet |
| Open questions | *Open questions* is anything other than `None` / `Nenhuma` |
| Stress-test | *Decisions to stress-test* is not `None` / `Nenhuma` → result `STRESS-TEST` (exit 2) |
| Product shape | *Product shape* is missing → **warning** only, so older briefs still pass |
| Depth | missing → **warning**. When present: a size of small/medium/large/complex; triggers from the fixed list; the size not below the triggers' floor (0 → small, 1–2 → medium, 3+ → large); only skippable steps (synthesis up to medium, domain model only at small with no trigger, ui design always), each with a reason |

## Semantic checks (you)

Mark each one; any "no" sends the item back to the interview as a FAIL.

- [ ] *Problem* describes a pain and its cost, and names no solution or technology.
- [ ] *Target users* names roles in situations, not "users" or "customers".
- [ ] Each metric traces to the *Desired outcome* and has a baseline or says the baseline is unknown and how it will be measured.
- [ ] *Scope* items each serve the problem; nothing in *Scope* is there "because apps usually have it".
- [ ] *Constraints* and *Assumptions* do not contradict each other or the *Scope*.
- [ ] Every inferred statement is under *Assumptions*, not presented as a fact.
- [ ] *Product shape* says how users reach the product, and says whether it is decided or still an assumption; no language, framework or database appears outside *Constraints*.
- [ ] Each decision says whether the user stated it or accepted the agent's recommendation.
- [ ] *Depth* was confirmed by the user, and its triggers come from the domain (data that persists, money, states, concurrency, permissions, integrations, personal data), not from how important the project is.
- [ ] The domain step (factory-domain-model) can start from this brief: the scope names the tasks users do, and the questions set aside for the domain are listed in the hand-off.

## Why the stress-test comes after the gate

Interviewing and stress-testing do different jobs. The interview finds out **what** the user wants. The stress-test challenges **decisions** once they exist. Running factory-grill-me first spends questions on a design tree that is not defined yet. Running it on every brief tires the user with objections to low-stakes choices. Scoping it to *Decisions to stress-test* after the gate puts the hard questions only where a wrong answer is expensive.
