# Question Bank

Ask in this order; a later block depends on answers from the earlier ones. Pick the questions that matter for this idea. The list is a map, not a script. Each question needs a recommended answer when you ask it.

## Contents
- 0. Depth (after the problem and the product shape are clear)
- 1. Problem
- 2. Users
- 3. Outcome and metrics
- 3b. Product shape
- 4. Scope
- 5. Constraints
- 6. Risks and decisions

## 0. Depth
Ask this once the problem, the users and the product shape are clear, and before the detailed scope. It decides how much the rest of the factory asks and writes.

Go through the triggers and ask only what you cannot tell from the answers so far:

| Trigger | Ask |
|---------|-----|
| persistence | Must anything be kept after the program closes? |
| money | Does it calculate, receive or record money? |
| state | Does anything go through stages (open, paid, cancelled)? |
| concurrency | Can two people or processes change the same thing at once? |
| auth | Do different people see or do different things? |
| integration | Does it call or receive from another system, file or device? |
| personal-data | Does it keep data about people? |

Then propose the size, with the triggers that justify it, and ask the user to confirm:

| Size | When | What the factory does |
|------|------|-----------------------|
| small | one user, no trigger, a few rules | brief; domain model may be skipped; one design option; one or a few tickets |
| medium | one or two triggers, rules but few states | synthesis may be skipped; compact domain model; one design option unless another is really viable |
| large | three or more triggers | every step |
| complex | ambiguity or a domain new to the user, whatever the triggers | every step, plus extra discussion rounds on the gray areas in the domain model |

The triggers set a floor that the agent cannot lower: a portfolio, a study or a proof of concept with money, states and persistence is **large**. "It is just a POC" is about the stakes, not the domain. The user may raise the size; lowering it below the floor needs a trigger to be really absent.

## 1. Problem
- What happens today without this? Walk me through the last time it went wrong.
- What does that cost (time, money, errors, customers lost)? How often?
- How big is it: how many users, records, requests, or tickets per day or month? (Needed for scope and later for the architecture.)
- Why now: what changed that makes this worth doing this quarter?
- If we did nothing for six months, what would happen?

## 2. Users
- Who feels the problem most? What role, and in what situation?
- Who uses the result day to day, and who decides whether it is a success? Are they the same people?
- How do they work around the problem today? Walk me through it, step by step. (The steps become the domain's use cases.)
- If there is no real operation (a study, a portfolio, a proof of concept): which real operation is the reference, and how faithful must the project be to it?
- Are there users who must **not** be affected (admins, partners, legacy clients)?

## 3. Outcome and metrics
- When this works, what is different for the user? Describe one concrete before/after.
- Which number tells us it worked, and what is its value today? Target value and by when?
- What would make you call this a failure even if it ships?

## 3b. Product shape
Ask about the form the product takes for its users, not about technology.
- Who reaches it, and how: a developer importing it (library or SDK), a person typing commands (CLI), people in a browser (web), on a computer without network (desktop), on a phone (mobile), another system calling it (service)? A mix?
- Where is it used: at a counter, in the field, offline, on a shared computer? Does it need a device (barcode reader, printer, camera)?
- When the answer is uncertain, show two or three shapes with what each one changes (deadline, offline use, installation, who can use it) and record the shape as an assumption. The technical design decides the stack later.

## 4. Scope
- What is the smallest version that solves the core problem? What can wait for v2?
- What looks related but is explicitly out of scope?
- Which existing features or flows must keep working unchanged?

## 5. Constraints
- Deadline, budget, or team size limits?
- Mandatory technology, hosting, compliance (LGPD/GDPR, audit), or integrations?
- Data: where does it come from, who owns it, how sensitive is it?
- How does the user enter and read the data: screens, a command line, files, a device (a barcode reader)? Is there a tool or library you want, or one you refuse? Record an imposed technology as a constraint; do not recommend one here.
- Is each constraint a hard rule or a preference? ("Only the standard library" was a preference, was recorded as a rule, and was reopened two documents later.)
- Is there a document with a header and lines (an invoice, an order, a receipt)? Is the header a record of its own, with its own rules (uniqueness, who issues it)? Note the answer; the rules themselves are explored in factory-domain-model.

## 6. Risks and decisions
- What is the riskiest assumption here? How could we check it cheaply?
- Which decision would be most expensive to reverse later (data model, vendor, pricing, public API)?
- What could make users reject this even if it works?

Decisions that come up here and are costly to reverse go under **Decisions to stress-test** in the brief.
