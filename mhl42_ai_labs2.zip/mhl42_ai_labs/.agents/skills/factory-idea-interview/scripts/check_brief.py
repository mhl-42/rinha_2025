# /// script
# requires-python = ">=3.10"
# ///
"""Quality gate for a PRD brief written from references/brief-template.md.

Usage:
  python check_brief.py docs/prd-brief/<slug>.md

Exit codes:
  0 = PASS         the brief is ready for PRD generation
  1 = FAIL         missing or vague information; go back to the interview
  2 = STRESS-TEST  complete, but lists decisions to stress-test first
  3 = usage error
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

# Section key -> accepted headings (English, Portuguese), compared case-insensitively.
SECTIONS: dict[str, tuple[str, ...]] = {
    "problem": ("problem", "problema"),
    "users": ("target users", "usuários", "usuarios", "público-alvo"),
    "outcome": ("desired outcome", "resultado esperado"),
    "metrics": ("success metrics", "métricas de sucesso", "metricas de sucesso"),
    "scope": ("scope", "escopo"),
    "out_of_scope": ("out of scope", "fora do escopo"),
    "constraints": ("constraints", "restrições", "restricoes"),
    "assumptions": ("assumptions", "premissas"),
    "risks": ("risks", "riscos"),
    "decisions": ("decisions", "decisões", "decisoes"),
    "stress_test": ("decisions to stress-test", "decisões para validar", "decisoes para validar"),
    "open_questions": ("open questions", "perguntas em aberto"),
}
# Optional sections: a warning when missing, so briefs written before them still pass.
OPTIONAL_SECTIONS: dict[str, tuple[str, ...]] = {
    "product_shape": ("product shape", "formato do produto"),
    "depth": ("depth", "profundidade"),
}

# Depth: the size of the flow, the complexity triggers present, and the steps skipped (with a reason).
SIZES = {"small": 0, "pequeno": 0, "medium": 1, "médio": 1, "medio": 1,
         "large": 2, "grande": 2, "complex": 3, "complexo": 3}
SIZE_NAMES = ("small", "medium", "large", "complex")
TRIGGERS: dict[str, tuple[str, ...]] = {
    "persistence": ("persistence", "persistência", "persistencia"),
    "money": ("money", "payments", "dinheiro", "pagamento", "pagamentos"),
    "state": ("state", "states", "state transitions", "estado", "estados", "transições de estado",
              "transicoes de estado"),
    "concurrency": ("concurrency", "concorrência", "concorrencia"),
    "auth": ("auth", "authentication", "permissions", "autenticação", "autenticacao", "permissões", "permissoes"),
    "integration": ("integration", "integrations", "external calls", "integração", "integracao", "integrações",
                    "integracoes"),
    "personal-data": ("personal data", "personal-data", "dados pessoais"),
}
STEPS: dict[str, tuple[str, ...]] = {
    "synthesis": ("synthesis", "síntese", "sintese", "factory-idea-synthesis"),
    "domain-model": ("domain model", "domain-model", "modelo de domínio", "modelo de dominio", "factory-domain-model"),
    "ui-design": ("ui design", "ui-design", "telas", "factory-ui-design"),
}
# Largest size at which a step may be skipped (ui-design: any size, when there is no screen to design).
SKIPPABLE_UP_TO = {"synthesis": 1, "domain-model": 0, "ui-design": 3}
NONE_VALUES = {"none", "nenhuma", "nenhum", "n/a"}
PLACEHOLDER_RE = re.compile(
    r"(?-i:\bTBD\b|\bTODO\b)|\?\?\?|\ba definir\b|<[^>!\n]+>|^\s*-\s*$",
    re.IGNORECASE | re.MULTILINE,
)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)


def parse_sections(text: str) -> dict[str, str]:
    lookup = {alias: key for key, aliases in {**SECTIONS, **OPTIONAL_SECTIONS}.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def depth_field(body: str, *labels: str) -> str | None:
    for label in labels:
        match = re.search(rf"^\s*{label}\s*:\s*(.*)$", body, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return None


def trigger_floor(count: int) -> int:
    """Smallest size the triggers allow: none -> small, one or two -> medium, three or more -> large."""
    return 0 if count == 0 else 1 if count <= 2 else 2


def check_depth(body: str) -> list[str]:
    """Rules of the Depth section: known size, known triggers, size not below the triggers' floor,
    and only the steps this size may skip, each with a reason."""
    failures: list[str] = []
    size_text = depth_field(body, "size", "tamanho")
    triggers_text = depth_field(body, "triggers", "gatilhos")
    skipped_text = depth_field(body, "skipped steps", "etapas puladas")
    for name, value in (("Size", size_text), ("Triggers", triggers_text), ("Skipped steps", skipped_text)):
        if value is None:
            failures.append(f"depth: missing '{name}:' line")
    if failures:
        return failures
    size = SIZES.get(size_text.lower().strip(".")) if size_text else None
    if size is None:
        failures.append(f"depth: size must be small, medium, large or complex (got {size_text!r})")
    trigger_lookup = {alias: key for key, aliases in TRIGGERS.items() for alias in aliases}
    triggers: set[str] = set()
    if triggers_text and not is_none(triggers_text):
        for item in re.split(r"[,;]", triggers_text):
            name = re.sub(r"\(.*?\)", "", item).strip().lower()
            if not name:
                continue
            if name not in trigger_lookup:
                failures.append(f"depth: unknown trigger {name!r} (use {', '.join(TRIGGERS)})")
            else:
                triggers.add(trigger_lookup[name])
    floor = trigger_floor(len(triggers))
    if size is not None and size < floor:
        failures.append(
            f"depth: {len(triggers)} trigger(s) ({', '.join(sorted(triggers))}) need at least size "
            f"'{SIZE_NAMES[floor]}'; the importance of the project does not lower it"
        )
    step_lookup = {alias: key for key, aliases in STEPS.items() for alias in aliases}
    if skipped_text and not is_none(skipped_text):
        for item in [part.strip() for part in skipped_text.split(";") if part.strip()]:
            match = re.match(r"^([^(:]+?)\s*(?:\((.+)\)|:\s*(.+))?$", item)
            name = (match.group(1) if match else item).strip().lower()
            reason = (match.group(2) or match.group(3) or "").strip() if match else ""
            step = step_lookup.get(name)
            if step is None:
                failures.append(f"depth: step {name!r} cannot be skipped (skippable: {', '.join(STEPS)})")
                continue
            if not reason:
                failures.append(f"depth: skipping {step} needs a reason, as '{step} (<why>)'")
            if size is not None and size > SKIPPABLE_UP_TO[step]:
                failures.append(f"depth: {step} cannot be skipped at size '{SIZE_NAMES[size]}'")
            if step == "domain-model" and triggers:
                failures.append(f"depth: the domain model cannot be skipped with triggers present "
                                f"({', '.join(sorted(triggers))})")
    return failures


def is_none(body: str) -> bool:
    return body.strip().strip(".").lower() in NONE_VALUES


def bullets(body: str) -> list[str]:
    return [line.strip()[2:].strip() for line in body.splitlines() if line.strip().startswith(("- ", "* "))]


def warnings_for(text: str) -> list[str]:
    sections = parse_sections(text)
    return [
        f"no '## {aliases[0].capitalize()}' section (recommended; see references/brief-template.md)"
        for key, aliases in OPTIONAL_SECTIONS.items()
        if not sections.get(key)
    ]


def check(text: str) -> tuple[list[str], list[str]]:
    sections = parse_sections(text)
    failures: list[str] = []

    for key, aliases in SECTIONS.items():
        if key not in sections:
            failures.append(f"missing section '## {aliases[0].title()}'")
        elif not sections[key]:
            failures.append(f"section '{aliases[0]}' is empty")

    # Blank out comments but keep their newlines so reported line numbers match the file.
    visible = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    for match in PLACEHOLDER_RE.finditer(visible):
        line = visible.count("\n", 0, match.start()) + 1
        found = match.group(0).strip()
        label = "empty bullet" if found == "-" else f"placeholder {found!r}"
        failures.append(f"{label} on line {line}")

    metrics = bullets(sections.get("metrics", ""))
    if sections.get("metrics") and not metrics:
        failures.append("success metrics need at least one bullet")
    for metric in metrics:
        if metric and not re.search(r"\d", metric):
            failures.append(f"metric has no number: {metric!r}")

    if sections.get("out_of_scope") and not bullets(sections["out_of_scope"]):
        failures.append("out of scope needs at least one bullet")

    if sections.get("open_questions") and not is_none(sections["open_questions"]):
        failures.append("open questions must be 'None' before the PRD")

    if sections.get("depth"):
        failures += check_depth(sections["depth"])

    stress = sections.get("stress_test", "")
    to_stress_test = [] if not stress or is_none(stress) else (bullets(stress) or [stress])
    return failures, to_stress_test


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    text = Path(sys.argv[1]).read_text(encoding="utf-8")
    for warning in warnings_for(text):
        print(f"warning: {warning}")
    failures, to_stress_test = check(text)
    if failures:
        print("FAIL")
        for failure in failures:
            print(f"  - {failure}")
        return 1
    if to_stress_test:
        print("STRESS-TEST")
        for item in to_stress_test:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
