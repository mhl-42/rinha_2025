# factory-idea-synthesis

Step 2 of the PRD flow. Turns interview answers (or notes and transcripts) into a synthesis document: answers by theme, an evidence table, contradictions, a value proposition, and gaps. The PRD brief is drafted from it.

```
1 factory-idea-interview ──answer log──→ 2 factory-idea-synthesis ─┬─ NEEDS-ANSWERS → contradictions: ask the user
       ↑                                           │                  gaps: back to factory-idea-interview
       └───────────────── gaps ────────────────────┤
                                                   └─ READY → brief → brief quality gate → factory-grilling (if needed) → PRD
```

## What it adds

- **Evidence types:** *Fact* (verifiable, with a source other than the user), *Reported* (seen by the user, unverified), *Hypothesis* (causes, future, other people's behavior; with confidence and a validation). Predictions about customers are always hypotheses.
- **Contradictions are never resolved silently.** Each one is recorded as `open` and put to the user with a recommended resolution.
- **Value proposition built from evidence:** each field cites evidence IDs, and a differentiator without evidence becomes a gap instead of marketing copy.
- **Traceability:** every claim in the brief and PRD can be traced to an evidence ID and its source (`Q3`, `repo:...`, `doc:...`).

## Files

```
factory-idea-synthesis/
├── SKILL.md
├── references/
│   ├── classification.md        # Fact / Reported / Hypothesis, confidence, contradiction types, how to resolve
│   ├── value-proposition.md     # Fields, statement template (EN/PT), quality checks, example
│   └── synthesis-template.md    # Document template + mapping to the PRD brief sections
├── scripts/
│   └── check_synthesis.py       # Exit 0 READY, 1 INVALID, 2 NEEDS-ANSWERS
└── evals/
    ├── evals.json
    └── trigger_queries.json
```

## Run the checker

```bash
python scripts/check_synthesis.py docs/prd-brief/<slug>.synthesis.md
```

Headings, table columns, and values are accepted in English or Portuguese.
