---
name: factory-idea-synthesis
description: Use this skill after an idea interview, or whenever the user has a pile of notes, answers, customer-call or user-research notes, or meeting transcripts about a product idea, to organize the answers by theme, find contradictions between them, separate verified facts from user reports and hypotheses, and write the value proposition — producing a synthesis document — and to draft the PRD brief from a confirmed synthesis. Triggers on "organize what we discussed", "summarize the interview", "what are we assuming here?", "does this idea hold together?", "what's the value proposition?", "here are my notes from customer calls", "draft the brief from the synthesis". Not for asking the discovery questions (use factory-idea-interview), for stress-testing decisions (use factory-grilling), or for writing the PRD itself.
license: MIT
compatibility: scripts/check_synthesis.py needs Python 3.10+ (no dependencies). Resolving contradictions needs the user; in non-interactive runs they are reported as open.
metadata:
  author: mhl42
  version: "1.3.1"
---

# Idea Synthesis

Turn interview answers into a **synthesis document**: an answer map, an evidence table (fact / reported / hypothesis), a list of contradictions, and a value proposition. The PRD brief is drafted from this document, so nothing reaches the brief unclassified or contradicted.

This is step 2 of the PRD flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief + quality gate → factory-grilling (if needed) → 2b factory-domain-model → PRD
```

Write the document in the user's language.

The brief's *Depth* may skip this step for a `small` or `medium` product with one source of answers and nothing to reconcile. Then the interview does a short inline pass instead, and no synthesis file is written: an empty file would say the step ran when it did not.

## Input

Use, in this order of trust:
1. Facts you can verify yourself: repository, docs, data the user shared.
2. The interview answer log (`docs/prd-brief/<slug>.interview.md`, answers numbered `Q1`, `Q2`...).
3. Notes, transcripts, or messages the user pastes.

Give every item a source: `Q3`, `repo:src/billing/plans.py`, `doc:pricing.pdf p.2`, `notes:2026-10-12`. An item without a source does not go in the document.

## Workflow

```
- [ ] 1. Answer map by theme
- [ ] 2. Evidence table: every claim typed Fact / Reported / Hypothesis
- [ ] 3. Contradictions listed, none resolved silently
- [ ] 4. Value proposition written from the evidence
- [ ] 5. Gaps listed
- [ ] 6. check_synthesis.py → READY, or back to the user / interview
- [ ] 7. Synthesis confirmed; brief drafted from it
```

### 1. Map the answers
Group what was said under: Problem, Users, Outcome, Scope, Constraints, Risks. Merge repeats and keep the source of each. Do not add anything the sources do not say.

### 2. Classify every claim
Follow [references/classification.md](references/classification.md):

- **Fact:** verifiable, with a source other than the user's memory (data, code, document, measurement).
- **Reported:** the user states it from experience ("we lose about 6 bookings a week"). It is useful but unverified.
- **Hypothesis:** a belief about causes, the future, or other people's behavior ("users will pay for this", "the delay is caused by phone calls"). Each needs a confidence level and a way to validate it.
- **Decision:** the user chose it (a scope item, a rule, a constraint). When the user said "yes" to your recommended answer, write "recommended, accepted" in the claim: it is the user's decision on your proposal, not something they observed. Split a recommendation that settled several rules into one row per rule.

Predictions about what users or customers will do are **always** hypotheses, however confident the user sounds. That includes how people will use something that does not exist yet, even when it is said in the present tense ("agents glance at the digest", "patients book on the app").

Before saving, check every row: if its source is an interview answer (`Q1`, `Q2`...), its type is Reported, Hypothesis or Decision, never Fact. The gate rejects a Fact sourced only from an answer, and it is better to catch it here.

### 3. Find contradictions
Compare every pair of related claims, and claims against constraints. [references/classification.md](references/classification.md) lists the types to look for (direct, scope versus constraint, metric versus outcome, user versus buyer, hypothesis versus fact).

**Never resolve a contradiction yourself**, not even by taking the most recent answer. Record each one with status `open`. Mark it `superseded` only when the user explicitly corrected themselves, and cite both answers.

Present the open contradictions in one numbered message (up to 5), each with both sides, a recommended resolution, and the reason, phrased so "yes" accepts it. Ask a contradiction separately only when its resolution changes another one. Record each answer as `resolved` with the decision.

### 4. Write the value proposition
Use [references/value-proposition.md](references/value-proposition.md). Build it **only from Facts and Reported items**, plus Hypotheses explicitly labelled as such. Every field cites evidence IDs. If a field can only be filled by guessing, leave the reason in *Gaps* instead.

### 5. List the gaps
Themes with no answer, or fields of the value proposition that the evidence does not support. Each gap becomes a question for factory-idea-interview.

### 6. Check
Save as `docs/prd-brief/<slug>.synthesis.md` (template: [references/synthesis-template.md](references/synthesis-template.md)) and run:

```bash
python <this-skill-dir>/scripts/check_synthesis.py docs/prd-brief/<slug>.synthesis.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `INVALID` | 1 | The document breaks the rules (unsourced claims, a Fact sourced only by the user, a Hypothesis with no validation, empty value proposition fields). Fix the document. |
| `NEEDS-ANSWERS` | 2 | Open contradictions or gaps remain. Resolve the contradictions with the user (step 3), and send gaps back to factory-idea-interview as questions. Re-run. |
| `READY` | 0 | Go to step 7. |

### 7. Confirm and hand over
Show the value proposition and the list of Hypotheses to the user and ask for explicit confirmation. If you were asked to continue to the brief, draft it in the same turn and ask for one confirmation covering both. Then draft the PRD brief from the synthesis using the mapping in [references/synthesis-template.md](references/synthesis-template.md#mapping-to-the-prd-brief): Hypotheses go to *Assumptions*, the riskiest ones also go to *Risks*, and resolved contradictions go to *Decisions*.

**Use the brief format, not your own.** If factory-idea-interview is installed, use its `references/brief-template.md` and run its `check_brief.py`. Otherwise use exactly the headings listed in [references/synthesis-template.md](references/synthesis-template.md#brief-format), in that order. Do not rename them or add numbered sections: factory-prd-writer and the brief gate find sections by these headings.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Read the inputs with `doc_read`, or single ids with `item_get` (the definition and everything that cites it), instead of opening the files.
- Write with `doc_write(project, "synthesis", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run. The synthesis has no confirmation in the store: it is ready when the gate says `READY`, and the user's confirmation of it is recorded when the brief built from it is confirmed.

## Gotchas

- Agents tidy contradictions away by picking one side. A synthesis with zero contradictions after a 10-question interview usually means they were hidden, not absent. Look again at scope versus deadline and at who uses versus who pays.
- "Our customers want X" is a hypothesis even when the user says it with certainty, unless it cites research, data, or sales records.
- A user's number ("about 30% of orders") is **Reported**, not Fact, until a source such as a query, report, or dashboard confirms it.
- The value proposition is not the feature list. "An app with booking and notifications" is a solution. The proposition says who gains what, compared with what they do today.
- Do not invent a differentiator. If the evidence shows no difference from the current alternative, write that in *Gaps*: it is the most important finding of the synthesis.
- An accepted recommendation typed as Reported hides who proposed it. In `supermercado-pdv`, E8 recorded the stock rules of Q8 (lots, FEFO, no negative balance) as "Reported, Q8", although the agent proposed them and the user only answered "accepts the recommended one".
- Business rules, entities and exceptions are not the synthesis's job. Record the decisions that exist; factory-domain-model explores the rest after the brief.
- Keep the synthesis traceable. The brief and the PRD will be challenged later, and every claim should lead back to an evidence ID and its source.
