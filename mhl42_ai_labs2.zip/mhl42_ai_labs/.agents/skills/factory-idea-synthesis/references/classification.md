# Classifying Claims and Finding Contradictions

## Contents
- Claim types
- Confidence for hypotheses
- Contradiction types
- Resolving contradictions

## Claim types

| Type | Test | Example | Needs |
|------|------|---------|-------|
| **Fact** | Could someone else check it without asking the user? | "The bookings table has 41k rows" (repo/db), "Plan B costs R$ 49" (pricing page) | A source that is not the user's memory |
| **Reported** | The user observed it but there is no record yet | "We lose about 6 bookings a week", "Receptionists complain every Monday" | Source `Qn`; note how it could be confirmed |
| **Hypothesis** | It is about causes, the future, or what other people will do or want | "Clinics will pay R$ 99/month", "No-shows happen because there is no reminder" | Confidence (low/medium/high) and a way to validate it |
| **Decision** | The user chose it: a scope item, a rule, a constraint they set | "Cancelling is allowed up to 24 h before" (Q5), "Stock leaves by expiry date, recommended and accepted" (Q8) | Source `Qn`; write "recommended, accepted" in the claim when the user said yes to your recommended answer |

Rules:
- When in doubt between Fact and Reported, choose Reported.
- When in doubt between Reported and Hypothesis, ask: did the user **see** it happen (Reported) or **expect** it (Hypothesis)?
- When the user **chose** it rather than saw it, it is a Decision. A "yes" to your recommended answer is a Decision of the user on your proposal: say so in the claim, because the next steps treat the user's own requirement and an accepted suggestion differently when they are challenged.
- One Decision per rule. An answer that accepted a recommendation with several rules ("expiry order, no negative stock, expired lots not sold") is split into one row each, so the domain model can give each its own example.
- Anything about the **new** product's use is a Hypothesis, whatever the tense: "agents glance at it", "the owner checks it weekly". Nobody can have seen people use something that does not exist yet. Reported items describe today's situation only.
- A Fact sourced only by `Qn` is invalid; the checker rejects it.
- Split compound claims: "We lose 6 bookings a week because there are no reminders" is one Reported item (the loss) and one Hypothesis (the cause).

## Confidence for hypotheses

- **High:** supported by indirect evidence (similar product data, several independent reports).
- **Medium:** plausible and consistent with the Reported items, without evidence.
- **Low:** the user's belief only, or contradicted by some evidence.

The validation must be cheap and concrete: "ask 5 clinic owners if they would pay R$ 99", "count no-shows with and without the reminder for 2 weeks", "query bookings by weekday".

## Contradiction types

| Type | Looks like |
|------|-----------|
| **Direct** | Q2 "only admins create rooms" versus Q7 "any employee adds a room" |
| **Scope versus constraint** | Eight features in scope, versus "launch in 3 weeks with one developer" |
| **Metric versus outcome** | The outcome is "fewer no-shows", but the metric is "number of bookings" |
| **User versus buyer** | The receptionist uses it, but the clinic owner pays, and the answers optimise only for one of them |
| **Hypothesis versus fact** | "Most patients book by phone" versus repo data showing 70% book through the website |
| **Implicit** | Constraint "no personal data stored" versus a scope item "send WhatsApp reminders" (which needs phone numbers) |

## Resolving contradictions

1. Record it with both sides, their sources, the type, and status `open`.
2. Ask the user, all independent contradictions in one numbered message (up to 5), each with a recommended resolution and the reason. Example: "Q2 says only admins create rooms; Q7 says any employee can. Recommended: only admins, because Q4 mentions room setup needs facilities approval. OK?"
3. Record the answer as `resolved`, with the decision in *Resolution*.
4. Use `superseded` only when the user corrected themselves explicitly during the interview ("actually, forget what I said about X"). Cite both answers.
5. If the user cannot decide, keep it `open`. The synthesis stays `NEEDS-ANSWERS`, which is the correct result.
