# Synthesis Template

Save as `docs/prd-brief/<slug>.synthesis.md`. Keep the headings and table column names as they are (English or the Portuguese alias), because `scripts/check_synthesis.py` reads them. Write the content in the user's language.

````markdown
# Idea Synthesis: <name>

Sources: docs/prd-brief/<slug>.interview.md, <other sources>
Date: YYYY-MM-DD

## Answer map
### Problem
- <claim> (Q1)
### Users
### Outcome
### Scope
### Constraints
### Risks

## Evidence
| ID | Claim | Type | Source | Confidence | Validation |
|----|-------|------|--------|------------|------------|
| E1 | Receptionists handle bookings by phone | Reported | Q1 | | Observe one peak hour |
| E2 | The clinic has 3 rooms and 9 therapists | Fact | doc:staff-list.xlsx | | |
| E3 | Patients will book online if it is available | Hypothesis | Q6 | medium | Landing page with a booking link for 2 weeks |

## Contradictions
| ID | Side A | Side B | Type | Status | Resolution |
|----|--------|--------|------|--------|------------|
| C1 | Only admins create rooms (Q2) | Any employee adds a room (Q7) | direct | resolved | Only admins; Q4 says rooms need facilities approval |

## Value proposition
| Field | Value |
|-------|-------|
| Target customer | |
| Problem | |
| Current alternative | |
| Proposed solution | |
| Key benefit | |
| Differentiator | |

Statement: For ... who ..., ... is a ... that .... Unlike ..., it ....

## Gaps
None
````

Rules the checker enforces:
- *Type* is `Fact`, `Reported`, `Hypothesis` or `Decision` (`Fato`, `Relato`, `Hipótese`, `Decisão`).
- Every row has a *Source*. A `Fact` cannot be sourced only by `Qn` answers.
- A `Hypothesis` needs *Confidence* (`low`/`medium`/`high`, or `baixa`/`média`/`alta`) and a *Validation*.
- *Status* is `open`, `resolved`, or `superseded` (`aberta`, `resolvida`, `substituída`); `resolved` and `superseded` need a *Resolution*.
- Every value proposition field and the *Statement* are filled.
- *Gaps* is `None` (`Nenhuma`), and no contradiction is `open`, for the result to be `READY`.

Portuguese aliases for headings: `Mapa de respostas`, `Evidências`, `Contradições`, `Proposta de valor`, `Lacunas`. Columns: `Afirmação`, `Tipo`, `Fonte`, `Confiança`, `Validação`, `Lado A`, `Lado B`, `Resolução`, `Campo`, `Valor`. Fields: `Cliente-alvo`, `Problema`, `Alternativa atual`, `Solução proposta`, `Benefício principal`, `Diferencial`. Statement: `Declaração:`.

## Brief format

The PRD brief (owned by factory-idea-interview) has a `Status: draft | confirmed` line and these `##` headings, in this order. English and Portuguese are both accepted:

| # | Heading | Portuguese |
|---|---------|------------|
| 1 | Problem | Problema |
| 2 | Target users | Usuários |
| 3 | Desired outcome | Resultado esperado |
| 4 | Success metrics | Métricas de sucesso |
| 5 | Scope | Escopo |
| 6 | Out of scope | Fora do escopo |
| 7 | Constraints | Restrições |
| 8 | Assumptions | Premissas |
| 9 | Risks | Riscos |
| 10 | Decisions | Decisões |
| 11 | Decisions to stress-test | Decisões para validar |
| 12 | Open questions | Perguntas em aberto |

Metrics, Scope, Out of scope, and Decisions are bullet lists (factory-prd-writer cites them as `brief:scope#2`). Each metric bullet needs a number; *Open questions* and *Decisions to stress-test* say `None` (`Nenhuma`) when empty.

## Mapping to the PRD brief

| Synthesis | PRD brief section |
|-----------|-------------------|
| Value proposition: Problem (+ cost) | Problem |
| Value proposition: Target customer; Users map | Target users |
| Value proposition: Key benefit | Desired outcome |
| Key benefit numbers; Outcome map | Success metrics (still need baseline → target) |
| Scope map | Scope / Out of scope |
| Constraints map, Facts that limit the solution | Constraints |
| Every Hypothesis and unconfirmed Reported item | Assumptions (with confidence) |
| Low-confidence or high-impact Hypotheses | Risks (with their validation) |
| Resolved contradictions | Decisions |
| Decision rows (with "recommended, accepted" when they came from your recommendation) | Decisions (scope-level ones); rule-level ones wait for factory-domain-model |
| Costly-to-reverse resolutions | Decisions to stress-test |
| Open contradictions and gaps | Open questions (the brief gate will FAIL until they are answered) |
