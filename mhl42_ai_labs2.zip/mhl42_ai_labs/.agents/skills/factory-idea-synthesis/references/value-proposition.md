# Value Proposition

Fill each field from the evidence table and cite the evidence IDs in brackets, e.g. `[E2, E5]`. Hypotheses may be used, but the citation makes them visible.

| Field | Question it answers |
|-------|---------------------|
| **Target customer** | Who, in what situation, has the problem? (role + context, not "users") |
| **Problem** | What pain or job, and what does it cost them today? |
| **Current alternative** | What do they do today instead (including "nothing", spreadsheets, phone calls)? |
| **Proposed solution** | What we offer, in one line, as a capability rather than a feature list |
| **Key benefit** | The change for the customer, measurable where possible |
| **Differentiator** | Why this beats the current alternative for this customer |

## Statement

Then write one sentence:

> For **<target customer>** who **<problem>**, **<product>** is a **<category>** that **<key benefit>**. Unlike **<current alternative>**, it **<differentiator>**.

(Portuguese: *Para **<cliente>** que **<problema>**, o **<produto>** é um(a) **<categoria>** que **<benefício>**. Diferente de **<alternativa atual>**, ele **<diferencial>**.*)

## Quality checks

- The *Problem* names no technology or feature.
- The *Current alternative* is real: it is how they cope today, not a competitor list from the internet.
- The *Key benefit* is stated from the customer's side ("receptionists stop handling double bookings"), not the product's side ("real-time sync").
- The *Differentiator* follows from the evidence. "Better UX", "AI-powered", or "easier" with no evidence is not a differentiator. Move it to *Gaps*.
- If the main fields rest on Low-confidence hypotheses, say so under the statement. The PRD will need a validation step first.

## Example

| Field | Value |
|-------|-------|
| Target customer | Physiotherapy clinic receptionists handling bookings by phone at peak hours [E1, E3] |
| Problem | About 6 lost or double bookings a week, each costing a session fee [E2 Reported] |
| Current alternative | Phone calls plus a shared paper agenda [E4 Fact: photo of agenda] |
| Proposed solution | Self-service booking for patients with live availability |
| Key benefit | Lost or double bookings 6/week → 0; fewer peak-hour calls [E2, E7 Hypothesis, medium] |
| Differentiator | Shows the clinic's real agenda, which the generic booking apps they tried cannot sync with [E5 Reported] |

> For physiotherapy clinic receptionists who lose about 6 bookings a week handling the agenda by phone, ClinicBook is a self-service booking tool that brings lost and double bookings to zero. Unlike the phone-and-paper agenda, it shows patients the clinic's real availability.
