# /// script
# requires-python = ">=3.10"
# ///
"""Check an idea synthesis written from references/synthesis-template.md.

Usage:
  python check_synthesis.py docs/prd-brief/<slug>.synthesis.md

Exit codes:
  0 = READY          ready to draft the PRD brief from
  1 = INVALID        the document breaks the classification rules; fix it
  2 = NEEDS-ANSWERS  open contradictions or gaps; ask the user / go back to the interview
  3 = usage error
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

SECTIONS = {
    "answers": ("answer map", "mapa de respostas"),
    "evidence": ("evidence", "evidências", "evidencias"),
    "contradictions": ("contradictions", "contradições", "contradicoes"),
    "value": ("value proposition", "proposta de valor"),
    "gaps": ("gaps", "lacunas"),
}
COLUMNS = {
    "id": ("id",),
    "claim": ("claim", "afirmação", "afirmacao"),
    "type": ("type", "tipo"),
    "source": ("source", "fonte"),
    "confidence": ("confidence", "confiança", "confianca"),
    "validation": ("validation", "validação", "validacao"),
    "side_a": ("side a", "lado a"),
    "side_b": ("side b", "lado b"),
    "status": ("status",),
    "resolution": ("resolution", "resolução", "resolucao"),
    "field": ("field", "campo"),
    "value": ("value", "valor"),
}
TYPES = {
    "fact": "fact", "fato": "fact",
    "reported": "reported", "relato": "reported",
    "hypothesis": "hypothesis", "hipótese": "hypothesis", "hipotese": "hypothesis",
    "decision": "decision", "decisão": "decision", "decisao": "decision",
}
STATUSES = {
    "open": "open", "aberta": "open",
    "resolved": "resolved", "resolvida": "resolved",
    "superseded": "superseded", "substituída": "superseded", "substituida": "superseded",
}
CONFIDENCES = {"low", "medium", "high", "baixa", "média", "media", "alta"}
VALUE_FIELDS = {
    "target customer": ("target customer", "cliente-alvo", "cliente alvo"),
    "problem": ("problem", "problema"),
    "current alternative": ("current alternative", "alternativa atual"),
    "proposed solution": ("proposed solution", "solução proposta", "solucao proposta"),
    "key benefit": ("key benefit", "benefício principal", "beneficio principal"),
    "differentiator": ("differentiator", "diferencial"),
}
NONE_VALUES = {"none", "nenhuma", "nenhum", "n/a"}
INTERVIEW_ONLY_RE = re.compile(r"^(q\d+)(\s*[,;/]\s*q\d+)*$", re.IGNORECASE)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
STATEMENT_RE = re.compile(r"^\s*(statement|declaração|declaracao)\s*:\s*(.*)$", re.IGNORECASE | re.MULTILINE)
PLACEHOLDER_RE = re.compile(r"\.\.\.|<[^>\n]+>|(?-i:\bTBD\b|\bTODO\b)", re.IGNORECASE)


def sections_of(text: str) -> dict[str, str]:
    lookup = {alias: key for key, aliases in SECTIONS.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def table_rows(body: str) -> list[dict[str, str]]:
    """Rows of the first Markdown table in body, keyed by canonical column name."""
    lines = [line.strip() for line in body.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    column_lookup = {alias: key for key, aliases in COLUMNS.items() for alias in aliases}
    header = [cell.strip().lower() for cell in lines[0].strip("|").split("|")]
    keys = [column_lookup.get(cell, cell) for cell in header]
    rows = []
    for line in lines[2:]:  # skip header and separator
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        rows.append(dict(zip(keys, cells + [""] * (len(keys) - len(cells)), strict=False)))  # extra cells dropped
    return rows


def is_none(body: str) -> bool:
    return body.strip().strip(".").lower() in NONE_VALUES


def check(text: str) -> tuple[list[str], list[str]]:
    sections = sections_of(text)
    invalid: list[str] = []
    pending: list[str] = []

    for key, aliases in SECTIONS.items():
        if key not in sections:
            invalid.append(f"missing section '## {aliases[0].capitalize()}'")

    evidence = table_rows(sections.get("evidence", ""))
    if "evidence" in sections and not evidence:
        invalid.append("evidence table has no rows")
    for row in evidence:
        rid = row.get("id") or "?"
        kind = TYPES.get(row.get("type", "").lower())
        source = row.get("source", "")
        if not row.get("claim"):
            invalid.append(f"{rid}: empty claim")
        if kind is None:
            invalid.append(f"{rid}: type must be Fact, Reported, Hypothesis or Decision (got {row.get('type')!r})")
        if not source:
            invalid.append(f"{rid}: no source")
        elif kind == "fact" and INTERVIEW_ONLY_RE.match(source):
            invalid.append(f"{rid}: a Fact cannot be sourced only by interview answers ({source}); use Reported")
        if kind == "hypothesis":
            if row.get("confidence", "").lower() not in CONFIDENCES:
                invalid.append(f"{rid}: hypothesis needs confidence low/medium/high")
            if not row.get("validation"):
                invalid.append(f"{rid}: hypothesis needs a validation")

    for row in table_rows(sections.get("contradictions", "")):
        rid = row.get("id") or "?"
        status = STATUSES.get(row.get("status", "").lower())
        if not row.get("side_a") or not row.get("side_b"):
            invalid.append(f"{rid}: contradiction needs both sides")
        if status is None:
            invalid.append(f"{rid}: status must be open, resolved or superseded (got {row.get('status')!r})")
        elif status == "open":
            pending.append(f"{rid}: open contradiction: {row.get('side_a')} <> {row.get('side_b')}")
        elif not row.get("resolution"):
            invalid.append(f"{rid}: {status} contradiction needs a resolution")

    if "value" in sections:
        values = {row.get("field", "").lower(): row.get("value", "") for row in table_rows(sections["value"])}
        for name, aliases in VALUE_FIELDS.items():
            value = next((values[a] for a in aliases if a in values), None)
            if value is None:
                invalid.append(f"value proposition: missing field '{name}'")
            elif not value or PLACEHOLDER_RE.search(value):
                pending.append(f"value proposition: '{name}' is empty")
        statement = STATEMENT_RE.search(sections["value"])
        if not statement or not statement.group(2).strip() or PLACEHOLDER_RE.search(statement.group(2)):
            pending.append("value proposition: statement is missing or still a template")

    gaps = sections.get("gaps")
    if gaps == "":
        pending.append("gaps: section is empty; write 'None' when there are no gaps")
    elif gaps and not is_none(gaps):
        pending += [f"gap: {line.strip().lstrip('-* ')}" for line in gaps.splitlines() if line.strip()]

    return invalid, pending


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    invalid, pending = check(Path(sys.argv[1]).read_text(encoding="utf-8"))
    if invalid:
        print("INVALID")
        for item in invalid:
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("READY")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
