# factory-implement

Step 6 of the flow: builds one ticket from the confirmed backlog (`docs/tickets/<slug>.md`), tests first, and reports the evidence.

```
factory-prd-to-tickets → docs/tickets/<slug>.md → factory-implement (one ticket per run) → status: done
```

## What it does

- Picks the next ticket whose dependencies are `done`.
- Turns each Given/When/Then criterion into a test and runs it red before writing code.
- Builds only what the ticket and its PRD requirements ask for.
- Handles spike tickets (timeboxed answer in `docs/spikes/`, no production code) and HITL tickets (lists the human steps first).
- Marks the ticket `done` only with evidence, and reports what was not verified.

## Files

```
factory-implement/
├── SKILL.md
├── references/
│   └── report-template.md   # Report format, per ticket
└── evals/
    ├── evals.json           # Next ticket, blocked dependency, HITL ticket, spike
    └── trigger_queries.json
```

The eval fixture is `evals/fixtures/docs/tickets/autoagendamento-fisioterapia.md` (a partial backlog with a mix of statuses).

## Status field

`factory-implement` writes a `Status:` line in each ticket: `todo`, `doing`, `done` or `blocked`. `factory-prd-to-tickets/scripts/check_tickets.py` accepts it and rejects any other value. A ticket without the line is `todo`.
