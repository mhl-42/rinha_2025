---
name: factory-implement
description: Use this skill to build one ticket from a confirmed backlog (docs/tickets/<slug>.md) — pick the next ticket whose dependencies are done, turn its Given/When/Then criteria into failing tests first, implement only what the ticket and the PRD requirements it serves ask for, run the tests and the definition of done, and report the evidence before marking it done. Also covers spike tickets (a timeboxed answer, not production code) and HITL tickets (the human steps are listed first). Triggers on "implement T-03", "build the next ticket", "pega o próximo ticket", "implementa o T-03", "small change to the receipt". Also a quick lane for a small change with no ticket, recorded as one. Not for writing the PRD, the design or the tickets (use factory-prd-writer, factory-tech-design, factory-prd-to-tickets), not for a change that adds a rule, an entity or a state (use factory-change), and not for reviewing someone else's code.
license: MIT
compatibility: Interactive or agentic coding sessions with the repository and its test tooling. Expects the ticket format of factory-prd-to-tickets. Uses the language skills (python-*, typescript-*, javascript-*, go-*, rust-*, swift-*, postgres-database) for code-level rules when the design's Stack names that language.
metadata:
  author: mhl42
  version: "1.8.0"
---

# Implement

Build one ticket at a time, from the confirmed backlog, with the tests written from its acceptance criteria. The ticket is the scope: it adds nothing the PRD does not ask for, and it changes nothing in the PRD or the design.

This is the build step of the flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief → 3 factory-prd-writer → 4 factory-tech-design → 5 factory-prd-to-tickets → factory-implement (one ticket per run)
```

Write code comments and commit messages in the language the repository already uses. Write the report in the user's language.

## Before you start

- **Backlog:** `docs/tickets/<slug>.md` with `Status: confirmed`. If it is missing or still a draft, stop and send the user to factory-prd-to-tickets.
- **Design and PRD:** the ticket's `Serves` ids point to them. Read the design's *Components*, *Data model*, *Deployment* and *Risks and spikes*, and the PRD requirements the ticket serves, with their acceptance criteria.
- **Ticket status:** each ticket may have a `Status:` line: `todo` (default), `doing`, `done` or `blocked`. Only `done` tickets unblock their dependants.

## Workflow

```
- [ ] 1. Ticket chosen: first ticket not done whose Depends on are all done
- [ ] 2. Mode checked: HITL steps listed and asked for
- [ ] 3. Context read: ticket, PRD requirements, design sections, cited ADRs, definition of done
- [ ] 4. Plan stated in 3–6 lines: files to touch, tests to write
- [ ] 5. Tests written from the acceptance criteria, run, and seen failing
- [ ] 6. Implementation, in scope only
- [ ] 7. Verification: tests, lint, definition of done, each criterion with evidence
- [ ] 8. Status set, report given, nothing committed unless asked
```

### 1. Choose the ticket
- Take the lowest ID that is not `done` and whose `Depends on` tickets are all `done`. If the user names a ticket, use it, but stop if a dependency is not `done` and say which one.
- Set `Status: doing` in the backlog file when you start.

### 2. Mode
- **AFK:** build it end to end.
- **HITL:** the ticket needs a person for something (a decision, credentials, a third-party account, a visual review). List those steps first and ask. Do the parts that do not depend on them. Never invent credentials or fake a third-party step to make a test pass. A HITL ticket that mixes both kinds of work is built in its machine part and left `doing` for the human part, or split in two (see factory-prd-to-tickets).

### 3. Context
Read the ticket's *Notes* and follow the ADRs it cites. Read the components it names, and the business rules it names in the domain model (`docs/domain/<slug>.md`), with their examples and counterexamples. If the ticket contradicts the PRD or the design, stop and report the conflict. Do not change the PRD or the design yourself.

When the code needs a rule nobody wrote (a valid format, a limit, what happens at a boundary), do not choose one silently. Ask, or implement the most conservative option and list it in the report under *Rules not in the documents*, so it goes back through factory-change to the domain model and the PRD.

### 4. Plan
Say what you will build in a few lines: the files, the tests, and anything you will not do because the ticket does not ask for it. For a `skeleton` or a `nfr` ticket, the plan must also name how it will be checked in the real environment (the design's *Deployment* section).

### 5. Tests first
- Turn each Given/When/Then into one test, with the same names and data as the criterion. A criterion with several examples gets one test per example.
- Before the first run, create the modules and functions the tests call, with the signatures from the criteria, raising `NotImplementedError` (or the language's equivalent). Then run the tests and confirm they fail on their assertions. A run that fails on `ImportError`, a missing module or a typo has not shown anything yet: fix that and run again.
- For each `Serves` NFR that the definition of done names (for example RNF-04 permissions), add the test the definition of done describes.

### 6. Implement
- Write the smallest code that makes the tests pass, then tidy it.
- Stay in scope. If you find something the PRD needs but the ticket does not cover, do not build it: write it under *Open questions* in the backlog and tell the user. New work becomes a new ticket through factory-prd-to-tickets.
- Apply the language skills that match the design's Stack for code rules (the table under *Rule skills* below; for Python also python-tooling). Their rules apply to this code too.

### 7. Verify
Run **every** command in the profile's `gates`, verbatim, from the profile's `workdir`, on the whole project. If the repository has a CI workflow, its `run:` steps are the gate and replace the list. A profile with no `gates` is run with its `test` and `lint`.

Running a subset is not verification: `mypy pdv tests` when the CI runs `mypy .`, or a single test file, hides failures that the CI will find. Then go through the definition of done in the backlog file, and check each acceptance criterion against an actual test result.

Report only what you ran. If a test was not run, or an item could not be checked here, say so. Do not write "done" on the strength of a plausible-looking change.

### 8. Status and report
- `done` only when every criterion has passing evidence and the definition of done holds. Otherwise `blocked` (write the blocker in *Notes*) or leave it `doing`.
- Do not commit or push unless the user asks.
- Report with [references/report-template.md](references/report-template.md).

## Small change without a ticket

A request that comes with no ticket ("make the receipt show the operator's name", "the balance screen should sort by expiry") can take a quick lane instead of a new PRD round, when **all** of these hold:

- it touches at most three files;
- it adds no business rule, entity, state or complexity trigger, and changes no confirmed acceptance criterion;
- it needs no new dependency and no design decision.

If any of them fails, stop: a new rule goes through factory-change (domain model, PRD, then tickets), and new work goes through factory-prd-to-tickets.

The lane:
1. **Spec in one line**, plus Given/When/Then criteria and the rule ids it touches (`BR-04`), shown to the user for a yes. It is the scope.
2. **List the steps** you will take. More than five steps, or a step that needs a rule nobody gave, means the lane was wrong: stop and use the full flow.
3. **Record it as a ticket**: `ticket_create`, or a new `### T-NN` in the backlog, `Type: feature` serving the FR it changes, or `Type: chore` with `Serves: none`. A change with no ticket is a change nobody can trace.
4. Then steps 5 to 8 above: tests first, implement, every gate, status with evidence. The independent review still applies.

## Spike tickets

A spike answers the question in its design row (`S1`–`S4`). It is not production code.

- Timebox it to the ticket's *Size*. Stop at the timebox and report the result.
- Put the throwaway code in a `spikes/` folder or a separate branch, and keep it out of the app.
- Write the result in `docs/spikes/<ticket-id>.md`: the question, what you did, the measured result against the exit criterion, and pass or fail.
- On a fail, mark the spike `done` only if the outcome was recorded, and list the tickets that depend on it, so the user can revisit them (for example a failed S4 changes the hosting ADR). Do not build those dependants.

## Ticket store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of truth for status and progress. Without them, use the `Status:` line of the markdown as described above.

- **Start of session:** `checkpoint_resume(project)` restores the saved context and the ticket in progress.
- **Choose:** `ticket_next(project)` returns the ticket in progress, or the lowest ready one. It replaces the scan in step 1.
- **Start:** `ticket_set_status(project, ticket_id, "doing")`. The server refuses it while a dependency is not done.
- **During:** `checkpoint_save` every few steps, with the summary, `next_step`, the files touched and the open decisions. Use `ticket_decompose` only if the ticket is too big for one pass.
- **Done:** `ticket_set_status(project, ticket_id, "done", evidence="<command>: <result>")`. The server refuses `done` without evidence, which is the same rule as step 8.
- **Blocked:** `ticket_set_status(project, ticket_id, "blocked")`, and write the blocker in a checkpoint.
- **End:** `project_export_markdown(project)` refreshes the backlog file so it shows the new status.

## Language profile

The commands for install, tests, lint, formatting and types depend on the language in the design's *Stack*. They are in `references/languages/<language>.json` (`install`, `gates`, `workdir`, `launcher`, `status`; `test` and `lint` are kept for the evaluation harness). Use the profile's commands; do not guess them. The `gates` list is what step 7 runs. Only a profile with `"status": "supported"` has been run by an example. A `planned` profile lists commands that nobody has run yet: confirm them on a small project before relying on them. To add a language, follow `references/languages/README.md`.

## Proposal: delegation to subagents, one ticket or one group each (not yet in force)

Status: proposal. The workflow above still runs in the main session. Do not use this section until the user approves it.

- **Unit of delegation: a ticket or a group; unit of evidence: always the ticket.** A subagent has a fixed cost (its prompt, its rule skills, reading the documents, running the gates) that it pays again for every delegation. Tickets that depend on each other, touch the same file or serve the same requirement share most of that cost, so one subagent builds them in sequence. `ticket_group_plan` proposes the groups (at most 3 tickets and 4 points, S=1 and M=2; spikes and HITL tickets stay alone); you confirm them, and say why in the plan. Never split a ticket's subtasks between subagents: they share modules and tests.
- **Context given to the subagent:** the ticket ids, the project, the numbers you reserved, and nothing else in the prompt. The subagent starts with `ticket_context`, which builds from the documents, at that moment, only what the tickets cite: the PRD requirements they serve, the use cases and rules those cite, the design lines that cite any of them, the decisions of the cited ADRs, the definition of done, the confirmed lessons, and your handoff notes. What it cannot find comes back as a warning, and the subagent reads that document whole. Record what is not in any document (a reserved number, a decision taken in this session, the report of a failed attempt) with `handoff_save`, not in the prompt only, so the next attempt gets it too.
- **One commit per ticket, in the worktree.** The subagent commits each ticket after its gates pass, and stops the group at the first ticket that does not pass: the rest are reported as not started and stay `todo`. The per-ticket commits let the review judge each ticket alone and let you merge the tickets that passed without the one that did not.
- **Rule skills:** every subagent loads the rule skills of the design's Stack, from this table (the language profile's `notes` list the same). One subagent per ticket, whatever rules it loads.

| Stack | Rule skills |
|-------|-------------|
| Python | `python-coding-standards`, `python-security`, `python-testing`; `python-database` when the ticket persists data |
| TypeScript | `typescript-coding-standards`, `typescript-testing`; `javascript-coding-standards` for Node runtime code |
| JavaScript | `javascript-coding-standards`, `typescript-testing` |
| Go | `go-coding-standards`, `go-testing` |
| Rust | `rust-coding-standards`, `rust-testing` |
| Swift | `swift-coding-standards`, `swift-testing` |
| PostgreSQL (any stack) | `postgres-database` when the ticket touches the schema, a migration or SQL |

- **Sequential by default.** Run one subagent at a time. Run tickets in parallel only when all of these hold: every `Depends on` is `done`, the tickets name disjoint files (their `Touches:` do not overlap), and neither touches a shared module (for example `__init__.py` or a schema).
- **Hot files.** A file named in the `Touches:` of two ready tickets (or edited by both, when there is no `Touches:`) is a hot file. Run those tickets one at a time, or accept the merge cost and say so in the plan. `check_tickets.py` warns about such pairs ahead of time.
- **Numbered artifacts** (database migrations, ADRs, ticket ids) are allocated by the main session before the delegation, one number per ticket, written into the prompt. Two agents never choose "the next number".
- **Isolation:** each parallel subagent works in its own git worktree. The main session merges them, one at a time, and re-runs the tests after each merge.
- **HITL tickets stay in the main session**, because they need a person.
- **Before delegating, the main session sets each ticket to `doing`** (`ticket_set_status`; the server refuses it while a dependency is not done). The implementer has no status tool: it checks that the ticket is `doing` and AFK, takes the lease with `handoff_claim`, saves checkpoints with `checkpoint_save`, and releases the lease when it ends. Its tools are an allowlist in the agent file (`tools:`): reads, `memory_add`, `checkpoint_save`, the handoff lease and `subtask_set_done`. It cannot change status, criteria, dependencies, documents or the backlog. The Codex agent (`.codex/agents/ticket-implementer.toml`) carries the same text but Codex cannot restrict tools, so the limit there is the instruction only.
- **The main session verifies, the subagent does not close.** The subagent reports the commands it ran and their output. The main session runs the gates and the definition of done again, then sets `done` with that evidence. A subagent report alone is never evidence.
- **Independent review.** For a ticket built by a subagent, a reviewer with a fresh context runs factory-review before `done`: a second subagent, or the main session if it did not write the code. The review checks the criteria against tests that really assert them, the scope, the definition of done and the design. The implementer never reviews its own work, and re-running the gates is not a review. If the reviewer finds a claim in the implementer's report that the re-run contradicts, the ticket goes back with that finding.
- **On failure:** the subagent stops at the timebox or on a blocked criterion, and reports it. In a group, the tickets after it were not started; they go back to the plan, alone or in a new group. The main session sets `blocked` with the blocker in *Notes*, and does not retry the ticket with a different scope.
- **Attempts:** the orchestrator gives each ticket up to three attempts with the Haiku implementer (`.claude/agents/ticket-implementer.md`), each one with the previous attempt's report and the failing output, saved with `handoff_save(kind="attempt")` so `ticket_context` returns it. Attempts count per ticket, not per group: a ticket that failed is retried alone. If the third attempt does not pass, one more attempt runs with a larger model. If that one fails too, the ticket is `blocked`. The limit is a rule in the orchestrator's prompt: the Agent tool has no retry count.
- **Turns per attempt:** the implementer sets `maxTurns: 80`, enough for a group of 4 points. An attempt that stops at the limit returns a partial output. The orchestrator resumes that subagent once to finish it, and counts an attempt as failed only if the resumed run still does not pass. `maxTurns` is a cap on one attempt, not a retry count.
- **Cost:** each subagent loads its own context. Use this only when the backlog has more than one ticket ready at a time; for a single ticket, the main session is cheaper. Before making groups the rule, measure: the same stretch of a backlog, one ticket per subagent and then in groups, comparing tokens, attempts and review findings. A group that needs more attempts than its tickets alone did costs more than it saves.

Open questions for the user before this takes effect: whether parallel worktrees are allowed on the project's machine, and whether the cost of separate contexts is acceptable.

## Gotchas

- Writing the code first and the tests afterwards: the tests then check what was built, not what was asked. Write them from the criteria.
- Adding a "small improvement" the ticket did not ask for. It is scope creep, even when it is good.
- Marking a HITL ticket done without the human step. The criterion that needs the person stays open, and `done` carries the datum the criterion names (the measured minutes, who ran it, on which system), not "ok".
- Using the design's examples as acceptance evidence. The criterion, not the design, decides what done means.
- Editing the backlog's acceptance criteria to match what was built. If a criterion is wrong, ask the user to change it.
- Deciding a business rule inside the code. In `supermercado-pdv`, the barcode length (8 to 14 digits) and "a unit-sold product takes only whole quantities" exist only in the code, with no source in any document; the next person to change them cannot know they were never agreed.
- Tests that read the real clock, or that use a fixed future date such as 2027 for an expiry: they pass today and fail on a date, with no change in the code. Inject a clock and use a date that does not age.
- Reporting "lint and types pass" after running them on the files you touched. The CI runs the whole project, so run the whole project: two files that are fine alone can collide (for example two `conftest.py`).

## Report

Use [references/report-template.md](references/report-template.md). Keep it short: the ticket, what changed, the tests and their results, each criterion with its evidence, the definition of done, open items, and the next ticket in order.
