# Language profiles

One JSON file per language. The factory skills read the profile for the language in the design's *Stack* section, so the same workflow runs for Python, JavaScript, Go or any other language.

| File | Status | Skill family |
|------|--------|--------------|
| `python.json` | supported (used by the example) | `python-*` |
| `typescript.json` | planned | `typescript-*` |
| `javascript.json` | planned | `javascript-*` (tests: `typescript-testing`) |
| `go.json` | planned | `go-*` |
| `rust.json` | planned | `rust-*` |
| `swift.json` | planned | `swift-*` |

`postgres-database` is not a language: it applies with any of them when the design's database is PostgreSQL.
| `_template.json` | template | copy it to add a language |

## Fields

- `install`, `test`, `lint`: shell commands run from the project root. The test command must exit non-zero when a test fails. They are kept for the evaluation harness (`evals/harness/run_checks.py`); a profile without `gates` is run with `test` and `lint`.
- `gates`: the list of checks an implementer runs before reporting, each `{ "name", "cmd" }`, one command that exits non-zero on failure. Run every gate, verbatim, on the whole project. Running a subset of files or a lighter command is not verification: it hides what the CI will find.
- `gates_source`: where the gate really comes from. When the repository has a CI workflow, its `run:` steps are the gate and replace the list.
- `workdir`: the folder the commands run from. It is the folder with the manifest (`pyproject.toml`, `package.json`), which can be a subfolder of the repository.
- `launcher`: interpreter names to try, in order. The first that answers is used. On Windows `python` can be the Microsoft Store alias, which does not run the project's tools.
- `status`: `supported` (an example runs it), `planned` (commands written, not run), or `template`.
- `skill_prefix`: the prefix of the language's rule skills. A new language with rule skills gets a new family in `scripts/validate_skills.py` (`FAMILIES`).

## Adding a language

1. Copy `_template.json` to `<language>.json` and fill every field with a command you have run. List in `gates` everything the language's CI would run: lint, format, types, tests.
2. Run the profile's `test` command on a small project in that language, and set `status` to `supported` only then.
3. If the language has rule skills, add the family prefix to `FAMILIES` and document it in the root README.
4. Run `python evals/harness/run_checks.py <project>` on an example in that language, so the evaluation database records it.
