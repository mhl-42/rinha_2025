# Implementation Report Template

Use this at the end of a ticket. Keep the headings. Write the content in the user's language.

```markdown
## T-03: Patient books a free slot

Status: done            (or doing / blocked: <blocker>)
Mode: AFK
Serves: RF-02, RF-03

### What changed
- agenda/views.py: booking view with the slot check
- agenda/tests/test_booking.py: 2 tests from the acceptance criteria
- templates/patient/slots.html: free-slot list

### Acceptance criteria
| Criterion | Test | Result |
|-----------|------|--------|
| Given a free slot, when the patient confirms, then the session appears in "my sessions" | test_patient_books_free_slot | pass |
| Given the slot was taken meanwhile, when the patient confirms, then "slot just taken" and no session | test_booking_taken_slot | pass |

### Verification
- Commands run: `pytest -q` (example values: 24 passed), `ruff check .` (example: no findings)
- Definition of done: tests in CI — not run here (no CI); permission test per role — pass (RNF-04)

### Rules not in the documents
- None. (Or: each rule the code needed that no document gave, such as a format, a limit or a boundary; what was implemented; to factory-change.)

### Not done / open
- Nothing from the ticket. Found in the PRD but not in this ticket: none.

### Next ticket
- T-04 (depends on T-03: now done)
```

Rules for the report:
- Every criterion has a test name and a real result (`pass`, `fail`, or `not run` with the reason).
- Quote the command output summary, not what you expect it to say.
- List what is not verified here (CI, a real device, a third-party account).
- List every business rule you had to decide that the domain model, the PRD and the ticket do not give, under *Rules not in the documents*.
