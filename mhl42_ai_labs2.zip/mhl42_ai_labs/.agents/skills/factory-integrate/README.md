# factory-integrate

The step after a subagent builds a ticket: verify its work, get it reviewed, commit it, merge it, prove it on the merged tree, set the ticket status with evidence, and remove the worktree. A subagent's report is never evidence, so this skill is where the main session turns it into a fact.

```
factory-implement (subagent, worktree) → report → factory-integrate → factory-review → merged, done, worktree removed
```

## What it covers

- **Before the first delegation:** the repository has a commit (worktree isolation needs one), the main checkout is clean, the gates are known, and numbered artifacts (migrations, ADRs, ticket ids) are allocated by the orchestrator, one per ticket.
- **Verification:** every gate of the language profile, verbatim and on the whole project, in the worktree and again on the merged tree. A subset of files does not count.
- **Review:** a reviewer who did not write the code runs factory-review before `done`.
- **Merge:** `--no-ff`, one ticket at a time; conflicts where both sides added code keep both sides; the test count after the merge must equal the sum of both sides.
- **Status:** `todo` to `doing` to `done`, with the commands, the numbers and the caveats (what was not run) as evidence. A HITL ticket needs the datum its criterion names.
- **Clean up:** `git worktree remove` and `git branch -d` (never `-D`).

## Files

```
factory-integrate/
├── SKILL.md
└── evals/
    ├── evals.json             # Subset-of-files gate, merge conflict, repository with no commit
    └── trigger_queries.json
```

## How it relates to the other skills

- It uses the language profile of `factory-implement` (`gates`, `workdir`) and the independent-review rule of `factory-review`.
- It does not write the ticket's code, does not judge the PRD fit, and does not release. Those are `factory-implement`, `factory-review` and `factory-ship`.
