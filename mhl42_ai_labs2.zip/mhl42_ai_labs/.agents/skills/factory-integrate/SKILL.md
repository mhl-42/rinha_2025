---
name: factory-integrate
description: Use this skill after a ticket-implementer subagent reports on a ticket or a group of tickets, to verify its work and bring it into the main branch — re-run the language profile's gates in its worktree, get an independent review, commit, merge with --no-ff, resolve conflicts keeping both sides, re-run the gates on the merged tree, set the ticket status with evidence, and remove the worktree. Also checks, before the first delegation, that the repository has a commit. Triggers on "integra o T-07", "o subagente terminou, mescla", "merge the ticket branch", "integrate the subagent's work", "fecha o ticket do subagente". Not for writing the ticket's code (use factory-implement), for judging it against the PRD (use factory-review), or for releasing (use factory-ship).
license: MIT
compatibility: Needs git with worktrees, the repository's gate tooling, and the factory-tickets MCP server for the status calls (without it, edit the Status line of the backlog). The gates come from the language profile of factory-implement, or from the CI workflow.
metadata:
  author: mhl42
  version: "1.1.0"
---

# Integrate

Take one ticket, or a group of tickets, that a subagent built in its own git worktree and bring it into the main branch, with the evidence the backlog needs per ticket. The subagent builds and reports. This skill is what turns the report into a fact: the main session re-runs everything, because a subagent's report is never evidence.

```
factory-implement (subagent, worktree) → report → factory-integrate → factory-review verdict → merged, Status: done, worktree removed
```

Write the report in the user's language. Commit messages follow the repository's language.

## Before the first delegation (once per project)

- `git rev-parse HEAD` must succeed. Worktree isolation branches from `HEAD`, so a repository with no commit makes the first delegation fail. If it has none, ask the user for an initial commit; do not make it yourself without being asked.
- The main checkout is clean (`git status --short` is empty) on the branch you will merge into.
- You know the gates: the language profile's `gates`, or the `run:` steps of the CI workflow when there is one.
- **Numbered artifacts** (database migrations, ADRs, ticket ids) are allocated by you before each delegation, one number per ticket, written into the prompt. Two agents never pick "the next number".
- **Hot files** (a file that two ready tickets both edit: a screen module, a migration list) mean those tickets run one at a time, or you accept the merge work and say so in the plan.

## Workflow

```
- [ ] 1. Report read, and its claims listed
- [ ] 2. Gates re-run in the worktree, all of them, on the whole project
- [ ] 3. Independent review: a verdict from factory-review
- [ ] 4. Committed in the worktree
- [ ] 5. Merged into the main branch with --no-ff
- [ ] 6. Gates re-run on the merged tree, and the test count checked
- [ ] 7. Status set with evidence
- [ ] 8. Worktree removed and branch deleted
- [ ] 9. Report given: what is done, caveats, what is unblocked
```

### 1. Read the report
List what it claims: the commands it ran, the counts, the files, the decisions it made, what it says it did not verify. These are things to check, not facts.

### 2. Re-run the gates
In the worktree, run every gate verbatim from the profile's `workdir`, on the whole project. A subset is not verification (`mypy pdv tests` is not `mypy .`). If one fails, send it back to the implementer with the output. Fix a one-line slip yourself only if you say so in the report.

### 3. Review
For a ticket built by a subagent, a reviewer who did not write it runs factory-review before `done`: a second subagent, or you, as long as you wrote none of the code. Re-running the gates is not a review. A claim in the report that your re-run contradicts goes into the evidence and back to the implementer.

### Groups
A subagent that built a group commits each ticket in its worktree, in order, and stops at the first one that did not pass. Integrate a group like this:
- Re-run the gates on the branch tip (step 2). Each commit of the group is one ticket.
- Review each ticket on its own commit (`git show <hash>`), against its own criteria (step 3). One ticket's verdict does not cover another.
- When every ticket is approved, merge the branch once. When one is not, merge up to the last approved commit (`git merge --no-ff <hash>`), re-run the gates on that merged tree, and send the rest back: the failed ticket alone, with the report saved by `handoff_save(kind="attempt")`.
- Set `done` per ticket (step 7), each with its own tests in the evidence. The tickets the subagent did not start stay `todo`.

### 4. Commit
For a group, the subagent's commits are already there: check that each one holds only its ticket, and reword a message only if it does not say what the ticket did. For a single ticket, in the worktree, one commit per ticket: `feat(T-NN): <result>` for a feature, `test(T-NN):` for a test-only ticket, `docs(T-NN):` for documentation, with a body that says what and why. Never `--no-verify`. Do not push unless asked.

### 5. Merge
From the main checkout, with the main branch checked out and clean:

```bash
git merge --no-ff worktree-<agent-id> -m "Merge T-NN: <title>"
```

Merge one ticket at a time, and run step 6 after each. Worktrees made before an earlier merge landed are out of date: expect conflicts in the hot files.

### 6. Conflicts and the merged tree
- Where **both sides added** code (two imports, two migrations, two blocks at the end of a file), keep both. Never take one side wholesale. Keep numbered things in their numeric order.
- Where both sides changed the same lines for different reasons, read both tickets, and keep the behavior of each. If you cannot, stop and ask.
- Re-run every gate on the merged tree. The number of tests must equal the main branch's count plus both sides' new tests. A lower number means something was dropped in the merge.
- Do not edit an implementer's test to make the merge pass. A test that fails after a merge is a finding.

### 7. Status
Use the ticket store: `todo` to `doing` to `done`, because the server refuses `todo` to `done`. The evidence is what you ran on the merged tree:

```
Merged as <commit>. On the merged tree (<OS>, <language version>): <gate>: <result>; ... <N> tests passed,
coverage <X>%. Criteria 1-3: <test names>. Reviewed by <who>: APPROVE. Caveats: <what was not run, such as
another OS, the CI, another language version>.
```

A caveat is part of the evidence. `done` with "Linux was not run" is honest; `done` with nothing said is not. For a HITL ticket, `done` needs the datum its criterion names (for example the measured minutes), not "ok". Without the ticket store, set `Status:` in the backlog file.

### 8. Clean up
```bash
git worktree remove <path>
git branch -d worktree-<agent-id>
```
`-d` refuses a branch that is not merged, and that refusal is the safety check. Do not use `-D`. If the worktree is dirty, look at what is in it before using `--force`.

### 9. Report
The ticket, the evidence, the caveats, the tickets now unblocked, and any hot file that will cost the next batch a conflict.

## Parallel batches
Several tickets can be built at once and integrated one by one. Order the merges so the ticket that owns a numbered artifact lands before the ones that depend on it. After each merge the next worktree is one commit behind: that is where the conflicts are.

## Gotchas

- Believing a green report. The two defects found in one project came from reports that were confident and wrong: a gate run on a subset, and a claim about code that was fine.
- A test that reads the real clock passes today and fails on a date. After a merge that makes some function read the clock, search for the tests that call it without one.
- An editable install in a throwaway virtual environment can point at a worktree you are about to delete. Run the tests from the project folder, and rebuild the environment outside any worktree.
- `git stash` is shared by all worktrees. Do not use a bare `git stash`; commit a work-in-progress commit instead.
- Line-ending warnings on every commit mean the repository has no `.gitattributes`. Say so once; do not renormalize files inside a ticket merge.
- Marking a ticket done to unblock the next one. The evidence decides.
