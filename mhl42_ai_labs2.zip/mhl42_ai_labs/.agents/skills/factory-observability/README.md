# factory-observability

Step 4c of the flow. From a confirmed PRD and tech design, decides how the product is observed in production and writes `docs/observability/<slug>.md`: the questions to answer, SLOs, the log schema, error tracking, metrics, traces, events, health checks, privacy of the telemetry, the collection and storage architecture, libraries, alerts with runbooks, dashboards per audience, operation and verification. The tickets are cut from it.

```
4 factory-tech-design → 4b factory-ui-design → 4c factory-observability ─┬─ FAIL → fix
                                                                         ├─ NEEDS-ANSWERS → ask the open questions
                                                                         └─ PASS → confirm → factory-prd-to-tickets
```

## What it enforces

- **Questions before tools.** 3 to 12 questions in the words of a role; every signal answers one, and every question has a signal.
- **Objectives, not thresholds.** An SLO has a source (a PRD requirement, or a `proposal` that stays an open question), a window and an error-budget policy; every SLO is protected by an alert.
- **A log schema.** Timestamp, level, service, event and a correlation id; never the secrets and personal data the PRD forbids.
- **Bounded metrics.** A closed set of label values, the number of series written down, no user, URL, e-mail or id as a label.
- **Silent failures are caught.** A scheduled job in the design needs a heartbeat that alerts on its absence; a probe runs outside the product's failure domain.
- **Alerts a person can act on.** Severity, route, owner and runbook for each; at most five pages.
- **Dashboards with a reason.** An audience, a question, at most eight panels.
- **Cost and retention.** A number and a unit per store, a cost estimate, an alternative that lost, and verified library versions.
- **Verification.** A test or a drill for logs, metrics and alerts.
- **Right-sized.** `basic`, `standard` and `advanced` tiers, so a nightly script does not get a tracing platform.

## Files

```
factory-observability/
├── SKILL.md
├── references/
│   ├── observability-template.md      # Headings, table columns and field values the checker reads
│   ├── signals.md                     # Logs, metrics, traces, errors, events, health: how to model each
│   ├── stack-options.md               # Pipeline, options per signal, tiers, retention, libraries per language
│   └── alerting-and-dashboards.md     # SLIs, SLOs, burn rates, alert quality, runbooks, dashboards
├── scripts/
│   └── check_observability.py         # Exit 0 PASS, 1 FAIL, 2 NEEDS-ANSWERS
└── evals/
    ├── evals.json                     # Small clinic (basic), advanced orders API, broken document, cardinality pushback
    └── trigger_queries.json
```

Fixtures (in `evals/fixtures/docs/observability/`):
- `autoagendamento-fisioterapia.md`: a complete `basic` document for the clinic PRD. It passes the gate.
- `autoagendamento-fisioterapia-broken.md`: the same document with known defects (a question no signal answers, a cron with no heartbeat, a library with no version, an alert with no runbook). It fails the gate.

## Run the gate

```bash
python skills/factory-observability/scripts/check_observability.py docs/observability/<slug>.md
```

On Windows, use `py -3` where `python` is the Microsoft Store shortcut.
