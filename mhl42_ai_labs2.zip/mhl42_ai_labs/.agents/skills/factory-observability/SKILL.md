---
name: factory-observability
description: Use this skill to design how a program is observed in production, from a confirmed PRD and tech design and before the tickets are cut — the questions the team must answer, SLIs and SLOs, log schema, error tracking, metrics and traces (names, labels, cardinality), business and audit events, collection and storage with retention and cost, libraries and versions, alerts with routing and runbooks, dashboards per audience, health checks and job heartbeats, privacy of telemetry, and how each signal is verified — checked by a quality gate. Triggers on "observability", "observabilidade", "logs and metrics", "monitoring", "alarmes", "dashboards", "how will we know it is broken", "SLO", "tracing", "como vamos monitorar isso". Not for choosing the application stack (use factory-tech-design), for writing log calls in a language (use the <language>-coding-standards skill), for PostgreSQL query statistics (use postgres-database), or for handling a live incident.
license: MIT
compatibility: scripts/check_observability.py needs Python 3.10+ (no dependencies). Expects the PRD format of factory-prd-writer and the design of factory-tech-design; works without the domain model. Library versions must be checked in their official documentation at write time.
metadata:
  author: mhl42
  version: "1.0.0"
---

# Observability

Design how the team will **know** that the product works, and **find out why** when it does not, without shipping new code to ask a new question. The output is one document, `docs/observability/<slug>.md`, that the tickets are cut from: the signals (logs, metrics, traces, errors, events), where they go and how long they stay, which ones raise an alarm, which ones are drawn on a dashboard, and how each is tested.

Observability is not a tool and not a dashboard. It starts from **questions** and from **objectives** (what "working" means for the user), and only then picks signals, storage and libraries. A design that starts from "we will use Grafana" is a tool list.

This is step 4c of the flow:

```
4 factory-tech-design → 4b factory-ui-design → 4c factory-observability → 5 factory-prd-to-tickets → build
```

Write the document in the user's language.

## Before you start

- **PRD:** `docs/prd/<slug>.md`, `Status: confirmed`. Its NFRs (availability, latency, privacy, audit, retention) are the source of the objectives and of the limits on what may be recorded.
- **Design:** `docs/design/<slug>.md`, `Status: confirmed`. Its *Components*, *Integrations*, *Errors and observability*, *Deployment* and stack are the inputs. This document expands that section; it does not contradict it. If the design says something the new document cannot keep, record the change with `factory-change`.
- **Mode:** existing project (brownfield) records what is already there with `existing:<file>` sources (a logger, a metrics endpoint, a vendor account) and decides only the gaps. New project: choose from the drivers.
- **Depth:** the brief's *Depth* sets the tier. `basic` (a script, a CLI, one small service): structured logs, error tracking, a health check, two or three alerts, no tracing. `standard` (a web product with a database and a few integrations): add metrics, SLOs, dashboards, release tracking. `advanced` (several deployable units, queues, regulated data, a real on-call): add distributed tracing, sampling, tiered retention, meta-monitoring. A tier is a default; every signal added above it needs a question that asks for it.

## Workflow

```
- [ ] 1. Inputs checked; mode and tier decided
- [ ] 2. Questions: what must be answerable, by whom, and at what moment (incident, release, weekly review)
- [ ] 3. Objectives: user journeys, SLIs, SLOs and the error-budget policy
- [ ] 4. Signals: logs, metrics, traces, errors, events, health, each traced to a question or an SLO
- [ ] 5. Privacy: what is never recorded, redaction, access, retention per signal
- [ ] 6. Architecture: collect, transport, store, query; hosting, cost, sampling, alternatives
- [ ] 7. Libraries and versions per language, with an alternative that lost
- [ ] 8. Alerts and dashboards: each alert has an owner, a route and a runbook; each dashboard has an audience and a question
- [ ] 9. Operation and verification: on-call, incident, review cadence, tests that prove the telemetry exists
- [ ] 10. check_observability.py → PASS; the user confirms
```

### 2. Questions first
Write 5 to 12 questions in the form a person would ask at the worst moment: "Is checkout failing, for whom, since when?", "Did the 14:00 release slow the search?", "Which customer's import is stuck?", "Why did the invoice job not run last night?". Every signal below must answer one of them, or be removed. Include the **non-incident** askers: product ("how many sessions were booked per day?"), finance ("what does the LLM cost per user?"), security and compliance ("who read this record?"). See [references/signals.md](references/signals.md#questions-worth-asking) for the questions most products forget.

### 3. Objectives
For each user journey that matters (not each endpoint), pick an **SLI** (a ratio of good events to valid events: requests under 500 ms, jobs finished before 06:00, e-mails delivered), a **SLO** (target and window, taken from a PRD NFR; never invent a number: ask or mark it as a proposal to confirm), and what the team does when the **error budget** is spent. If the PRD has no availability or latency NFR, say so and propose a target as an open question; do not alert on a threshold nobody agreed to. Method and burn-rate alerts: [references/alerting-and-dashboards.md](references/alerting-and-dashboards.md#objectives-and-burn-rates).

### 4. Signals
Use [references/signals.md](references/signals.md) as the catalog, and fill [references/observability-template.md](references/observability-template.md).
- **Logs:** one structured event per line (JSON), one schema for the whole product, UTC timestamps, a level policy, and a **correlation id** (request id, and trace id when there is tracing) on every line. Logs say *what happened*; they are not the place to count things.
- **Metrics:** name, type (counter, gauge, histogram), unit, labels, and a **bound on cardinality** for each label. Never put a user id, e-mail, URL with ids, or free text in a label.
- **Traces:** only where a request crosses processes or slow third parties. Say what is propagated (W3C `traceparent`), what is sampled, and what is always kept (errors, slow requests).
- **Errors:** captured with a stack, a release, an environment and the correlation id; grouped by cause; each group has an owner. An error that is only logged is not tracked.
- **Business and audit events:** a product event (booking created) is analytics; an audit event (who read or changed what) has its own store, immutability and retention. Do not mix them with application logs.
- **Health and liveness:** liveness (restart me), readiness (send me traffic), startup, dependency checks, and a **heartbeat** for every scheduled job (an alert when it does *not* run).

### 5. Privacy and security of the telemetry
Telemetry is a second database that nobody designed. State per field what is **never** recorded (passwords, tokens, card numbers, health data, free text typed by users, full request bodies), the redaction done in the code (an allow-list, not a deny-list), who can read each store, and the retention per signal. Tie each limit to a PRD privacy NFR (LGPD/GDPR: purpose, minimum, deletion on request). A log line that holds personal data must be deletable by the same rule as the table it came from, or must not hold it.

### 6. Architecture
Follow [references/stack-options.md](references/stack-options.md). Write the pipeline in four hops (instrument → collect → store → query), the store per signal with retention and an order-of-magnitude cost, and where the telemetry runs when the product itself is down (the monitor must not share the failure domain of the thing it watches). Default to the **boring** option that fits the team: a managed service or a single self-hosted stack, with **OpenTelemetry** at the code boundary so the backend can change without touching the code. Every row lists an alternative that lost.

### 7. Libraries
One row per language in the design: logger, metrics client, tracing SDK, error reporter, with the **verified version**. Do not repeat per-language rules: point to the `<language>-coding-standards` skill (for example `log-slog` in Go, `tracing` in Rust). An API you could not verify becomes a spike.

### 8. Alerts and dashboards
- **Alerts** are for conditions that need a human *now* and have an action. Page on symptoms the user feels (SLO burn, no successful bookings), not on causes (CPU 80%). Each alert: condition, window, severity (`page`, `ticket`, `info`), route, owner, **runbook**, and the SLO or question it protects. An alert without a runbook or an owner fails the gate. Count them: more than a handful of pages per week is a design defect.
- **Dashboards** are for questions, not for the data you have. One per audience (on-call, service owner, product, finance): at most 8 panels each, the top row answers "is it working?", and each panel names the metric and the question it answers. See [references/alerting-and-dashboards.md](references/alerting-and-dashboards.md#dashboards).

### 9. Operation and verification
Who is on call (for a team of one: the owner, and how they are reached), how an alert becomes an incident, where the post-incident notes go, how often the alerts and dashboards are reviewed and pruned, and **how the monitoring itself is monitored** (a dead-man's switch). Then the verification: a test or a drill for each signal class (a unit test asserts the log has the correlation id and no secret; a test asserts the metric exists after a request; a synthetic probe asserts the health endpoint; a game-day turns off a dependency and an alert fires).

### 10. Check
```bash
python <this-skill-dir>/scripts/check_observability.py docs/observability/<slug>.md
```

On Windows, if `python` is the Microsoft Store shortcut, use `py -3`.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: a signal with no question or SLO, an SLO with no source, a metric label of unbounded cardinality, an alert with no runbook, owner or route, a dashboard with no audience, a store with no retention, a library with no version or alternative, a PRD privacy NFR with no limit, a scheduled job with no heartbeat. |
| `NEEDS-ANSWERS` | 2 | *Open questions* is not empty (targets to agree, budget, who is on call). Ask them in one numbered round with a recommended answer each. |
| `PASS` | 0 | Show the questions, SLOs, alert list and monthly cost estimate; ask for confirmation; set `Status: confirmed`. |

After confirmation the next step is `factory-prd-to-tickets`: the instrumentation becomes tickets (a logging and correlation-id ticket belongs in the walking skeleton, not at the end).

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, follow the same protocol as `factory-tech-design`: `project_manifest` first, `doc_import` for untracked files, and write with `doc_write` instead of editing `docs/` by hand. If the server has no document type for observability, write the file as described above and tell the user.

## Gotchas

- **Tools before questions.** "Prometheus, Loki and Grafana" is a shopping list. Ask what must be answerable and what failure must wake someone, then see what the smallest stack is.
- **Logs as metrics.** Counting occurrences by grepping logs is slow, expensive and fragile. If you count it, it is a metric.
- **High cardinality.** One label with user ids multiplies the series by the number of users and the bill with it. Put the id in a log or a trace, not in a label.
- **Alert on causes.** CPU, memory and disk alerts page people for things users never notice. Alert on the symptom, graph the cause on a dashboard.
- **Silent failure.** A job that does not run produces no error and no log. Only a heartbeat that expects a signal and alerts on its absence catches it.
- **Telemetry that leaks.** Request bodies, SQL with parameters and exception messages carry personal data. Redact at the source; a scrubber in the backend is the second line.
- **Everything at debug in production.** Volume and cost grow without the answers improving. Define levels, sampling and retention per signal.
- **Sampling that drops the interesting ones.** Head sampling at 1% loses the one slow request. Keep all errors and slow traces (tail sampling) or sample by rule.
- **Dashboards nobody opens.** A dashboard without an audience and a question rots in a month. Prune on the review cadence.
- **The monitor shares the outage.** An alert sent from the server that is down never arrives. An external probe and a dead-man's switch live outside the failure domain.
- **Clock and time zone.** Use UTC and RFC 3339 in telemetry; format for the reader only on the dashboard.
- **Observability as scope creep.** A platform for a script that runs once a day is a project risk. At `basic`, structured logs, error tracking and a heartbeat are the design.
- **Invented targets.** "99.99% availability" with no NFR behind it commits the team to a number it never agreed to. Take the target from the PRD or ask.
- **Not testing it.** The first time the alert is exercised should not be the incident. Fire each page-level alert once in staging.
