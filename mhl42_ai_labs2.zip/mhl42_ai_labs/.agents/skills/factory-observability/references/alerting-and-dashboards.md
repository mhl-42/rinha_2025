# Objectives, alerts and dashboards

Used in steps 3 and 8.

## Objectives and burn rates

1. **Pick the journey**, not the endpoint: "book a session", "pay an invoice", "the nightly report arrives".
2. **Write the SLI** as `good events / valid events`. Examples: requests that return a non-5xx in under 800 ms; jobs that finish before the deadline; e-mails accepted by the provider within 5 minutes. Say what is excluded (health checks, bot traffic) and why.
3. **Set the SLO** (target over a window, usually 28 or 30 days) from the PRD. If the PRD is silent, propose one and mark it `proposal`: a number the team never agreed to is not an objective. A target is a trade-off: each extra nine costs money and slows delivery.
4. **Compute the error budget:** `1 - target` of valid events. With 99.5% over 30 days and about 100,000 requests, the budget is about 500 bad requests (or about 3.6 hours of full outage).
5. **Write the budget policy:** what happens when the budget is spent (freeze feature releases, prioritise reliability work) and what happens when plenty is left (ship faster, run experiments).
6. **Alert on burn rate**, not on the instantaneous ratio. Burn rate = how fast the budget is consumed relative to a steady spend (1.0 spends it exactly over the window). A common multi-window pair for a 30-day SLO:
   - **Page:** burn rate over 14.4 in both the last 5 minutes and the last 1 hour (2% of the budget in an hour).
   - **Page:** burn rate over 6 in both the last 30 minutes and the last 6 hours (5% in 6 hours).
   - **Ticket:** burn rate over 1 in both the last 6 hours and the last 3 days (10% in 3 days).
   The short window makes the alert reset quickly; the long window keeps it from firing on a blip. Use the pair from your platform's SLO feature when it has one.
7. **Low traffic:** with few requests, a single failure moves the ratio a lot. Use a probe as the SLI, longer windows, or a count-based alert ("5 failures in 10 minutes") with a minimum volume.

## Alerts

An alert is a promise that a person is needed now and knows what to do.

| Test | If the answer is no |
|------|---------------------|
| Does a user feel it, or will they soon? | make it a dashboard panel or a ticket |
| Is there something the responder can do? | fix the system to heal itself, or delete the alert |
| Is it urgent enough to interrupt sleep? | `ticket` |
| Is it new information, not a duplicate of another page? | merge or inhibit it |
| Is there a runbook? | write it before enabling the alert |

- **Severity:** `page` (person now), `ticket` (working hours), `info` (a dashboard only). Keep pages to a few per week for the whole team; a team that is paged daily stops reading pages.
- **Content of the message:** what is failing (the symptom), since when, which SLO, a link to the dashboard and the runbook, and the first query to run. No raw metric names alone.
- **Route:** page by phone push or call; ticket to the issue tracker; info to a channel. Define escalation (who after 10 minutes, who after 30), a quiet-hours rule only if the SLO allows it, and silence/maintenance windows that expire.
- **Grouping and inhibition:** one incident, one notification. When the database is down, suppress the downstream alerts that follow.
- **Missing data:** an alert on "no data" is separate from an alert on a bad value. Decide per rule whether silence means healthy (a counter that only moves on errors) or broken (the heartbeat).
- **Rules as code:** alert rules live in the repository, are validated in CI, and are reviewed like code. Record why each rule exists in its annotation.
- **Test:** fire every `page` alert once in staging (stop the dependency, send bad traffic) and confirm the route, the content and the runbook. Repeat after changing the route.

### Runbook (one per alert)

```
# <alert name>
Symptom:     what the user sees
Impact:      who and how many are affected
Confirm:     the dashboard and query that prove it is real
Usual causes: 3 or 4, most likely first
First action: the safest step (restart, roll back, scale, toggle a flag)
Escalate:    who, after how long, with what information
Afterwards:  what to record (incident note, ticket)
```

## Dashboards

A dashboard answers a question for an audience. A wall of graphs is not a dashboard.

- **On-call (service health):** the top row says "is it working?": the SLIs against their targets, error rate, p95 and p99 latency, traffic, and the probe result. Below: saturation (pools, queues, CPU, memory), dependencies, and the error tracker's top new issues. Deploy markers across all graphs.
- **Service owner (release and trends):** the same SLIs split by release, errors by release, the budget remaining, the slowest routes, and the cost trend.
- **Product:** the funnel (events per step), daily active actors, conversion between steps, and the cohort of a new release. Built on product events, not on logs.
- **Finance / operations:** cost per feature or per request (cloud, LLM tokens, SMS), quotas used, and the telemetry bill itself.
- **Security / compliance:** failed logins by source, permission denials, audit activity by actor, and the age of the last access review.

Rules of thumb:
1. At most 8 panels per dashboard; if you need more, you have two audiences.
2. Each panel states the question in its title ("Are bookings failing?"), shows the target or threshold as a line, and has units.
3. Prefer rates and percentiles to averages; histograms and heatmaps for latency.
4. Same time range and variables (environment, service, release) across panels; link a panel to the logs and traces it summarises.
5. Colour is for state (good, warning, bad), not decoration; check it in grayscale and for colour blindness. See the `dataviz` skill when installed.
6. Dashboards are code (JSON or a provisioning file in the repository), so they survive a rebuild and get reviewed.
7. Review them on the cadence in the *Operation* section; delete what nobody opened.

## Review cadence

| When | What |
|------|------|
| After every page | was it actionable, was the runbook right, what would have caught it earlier? |
| Weekly (10 minutes) | pages and tickets of the week, noisy rules, budget left |
| Monthly | dashboards unused, labels or metrics unused, telemetry cost against the estimate |
| Each release | the deploy marker is present; new code paths have logs, metrics and errors as the design says |
| Quarterly | fire the page-level alerts again, restore a backup, rehearse the on-call hand-over |
