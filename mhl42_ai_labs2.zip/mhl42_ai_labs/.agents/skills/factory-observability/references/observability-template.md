# Observability Template

Save as `docs/observability/<slug>.md`. Keep the headings, the table column names and the field values as they are, because `scripts/check_observability.py` reads them. Write the content in the user's language (Portuguese section names and column names are accepted: see the aliases at the end).

````markdown
# Observability: <name>

PRD: docs/prd/<slug>.md
Design: docs/design/<slug>.md
Tier: standard
Status: draft
Date: YYYY-MM-DD

## Questions

| id | Question | Asked by | Answered by |
|----|----------|----------|-------------|
| Q-01 | Are patients failing to book, for whom, since when? | on-call | M-01, SLO-01, A-01 |
| Q-02 | Did the last release slow the free-slots search? | owner | M-02, E-1 |
| Q-03 | Why did the reminder job not run last night? | on-call | H-03, A-03 |
| Q-04 | How many sessions are booked per day? | product | EV-01 |
| Q-05 | Who read or changed a patient record? | compliance | EV-02 |

Rules:
- 5 to 12 questions, each in the words of the person asking at the moment they ask it.
- *Asked by* is a role (on-call, owner, product, finance, compliance), never "everyone".
- *Answered by* lists the ids of the signals below (M-, SLO-, EV-, H-, A-, D-, E-). A question with no signal fails the gate.

## Objectives

| id | Journey | SLI | Target | Window | Source | Budget policy |
|----|---------|-----|--------|--------|--------|---------------|
| SLO-01 | Book a session | share of booking requests that finish with 2xx or 4xx in under 800 ms | 99.5% | 30 days | RNF-01 | below 25% of the budget left: freeze features until it recovers |
| SLO-02 | Send reminders | share of reminders sent before 07:00 | 99% | 30 days | proposal | ticket on miss |

Rules:
- One SLO per user journey that matters, not per endpoint.
- *Source* is a PRD requirement (`RNF-01`) or `proposal`; a `proposal` also appears under *Open questions* until the user agrees the number.
- The SLI is a ratio of good events to valid events. Say what counts as valid (a 4xx caused by the user is valid and good; a 5xx is bad).
- *Budget policy* says what the team does when the budget is spent. "Nothing" is a policy only when written as such.
- `Tier: basic` may write `None: <reason>` instead of the table (also for *Metrics* and *Dashboards*). Every SLO is protected by at least one alert.

## Logs

| field | Type | Required | Note |
|-------|------|----------|------|
| timestamp | RFC 3339, UTC | yes | |
| level | debug, info, warn, error | yes | error means a person may need to act |
| service | string | yes | name and version of the component |
| event | string | yes | stable snake_case name, not a sentence |
| request_id | string | yes | also trace_id when there is tracing |
| user_ref | opaque id | no | never the name or the e-mail |
| duration_ms | number | no | |
| error.kind / error.message | string | no | message redacted |

Level policy: <what each level means here; which level production runs at; how to raise it for one request>.

Rules:
- One schema for the whole product. The table must contain a timestamp, a level, a service, an event and a correlation id (`request_id` or `trace_id`).
- One JSON object per line, written to standard output; the platform ships it. The program does not open its own log files.

## Metrics

| id | Name | Type | Unit | Labels | Cardinality | Serves |
|----|------|------|------|--------|-------------|--------|
| M-01 | http_requests_total | counter | requests | route, method, status_class | 12 × 4 × 5 = 240 | Q-01, SLO-01 |
| M-02 | http_request_duration_seconds | histogram | seconds | route | 12 | Q-02, SLO-01 |
| M-03 | reminder_jobs_pending | gauge | jobs | none | 1 | Q-03 |

Rules:
- *Type* is `counter`, `gauge` or `histogram` (`summary` only with a reason). Names carry the unit and, for counters, end in `_total`.
- *Labels* are a closed set of values (a route template, a status class, an enum). A label named `user`, `user_id`, `email`, `url`, `path`, `session`, `request_id`, `trace_id`, `ip` or `message` fails the gate. Write `none` when there are no labels.
- *Cardinality* is the product of the label values; write the number. Keep one metric under about 1000 series.
- *Serves* cites a question or an SLO.

## Traces

| Boundary | Propagation | Sampling | Always kept |
|----------|-------------|----------|-------------|
| web → api → database, e-mail provider | W3C `traceparent` | 10% of requests | errors and requests over 1 s |

Rules:
- `Tier: basic` writes `None: <reason>` (for one process, logs with a request id are enough).
- Say what is sampled and what is never dropped.

## Errors

| id | Source | Tool | Grouping | Release tracking | Owner |
|----|--------|------|----------|------------------|-------|
| E-1 | api, web, jobs | <tool> | by exception type and top frame | release = git sha, environment tagged | owner |

Rules:
- Every unhandled exception and every handled error that loses user work reaches the tool with a stack, the release, the environment and the correlation id.
- Each group has an owner. A source map or a symbol file is uploaded for minified or compiled code.

## Events

| id | Event | Kind | Store | Retention | Serves |
|----|-------|------|-------|-----------|--------|
| EV-01 | session_booked | product | event table `analytics_events` | 24 months | Q-04 |
| EV-02 | record_read, record_changed | audit | append-only table `audit_log` | 5 years | Q-05 |

Rules:
- *Kind* is `product` or `audit`. An audit event says who, what, when and from where, is append-only, and has its own retention and access list; it is not an application log.
- `None: <reason>` when the PRD asks for neither.

## Health

| id | Target | Kind | Check | On failure |
|----|--------|------|-------|------------|
| H-01 | api | liveness | process answers `/healthz`, no dependency checks | the platform restarts it |
| H-02 | api | readiness | `/readyz` checks the database with a 500 ms timeout | the platform stops sending traffic |
| H-03 | reminder job | heartbeat | the job pings the monitor on success | alert A-03 when no ping in 26 h |
| H-04 | public site | probe | external check of the booking page every 1 min from 2 regions | alert A-01 |

Rules:
- *Kind* is `liveness`, `readiness`, `startup`, `heartbeat` or `probe`. A liveness check does not test dependencies (a database outage must not restart every instance).
- Every scheduled job in the design has a `heartbeat` row. The alert fires on the **absence** of the ping.

## Privacy

| id | Data | Rule | Where enforced | Serves |
|----|------|------|----------------|--------|
| P-01 | passwords, tokens, API keys | never recorded | allow-list serializer in the logger | RNF-03 |
| P-02 | e-mail, phone, free text | redacted | the logger replaces them with an opaque `user_ref`; never in labels | RNF-03 |
| P-03 | request and response bodies | never recorded | logger and error tool configured without bodies | RNF-03 |

Access: <who can read each store, how access is granted and logged>.
Deletion: <how a data-subject deletion request reaches the telemetry, or why it holds no personal data>.

Rules:
- *Rule* is one of `never recorded`, `redacted`, `hashed`, `allow-list`. Every PRD requirement about privacy, personal data, LGPD or GDPR is cited in *Serves* at least once.

## Architecture

```
code (OpenTelemetry SDK) → collector or platform agent → stores → query and alerts
```

| Signal | Store | Hosting | Retention | Cost / month | Alternative |
|--------|-------|---------|-----------|--------------|-------------|
| logs | <store> | managed | 30 days | ~US$ 0–25 | <alternative> (lost: <why>) |
| metrics | <store> | managed | 13 months | ~US$ 0–20 | <alternative> (lost: <why>) |
| errors | <tool> | managed | 90 days | free tier | <alternative> (lost: <why>) |
| traces | <store> | managed | 7 days | ~US$ 0–10 | <alternative> (lost: <why>) |

Failure domain: <where the monitoring runs relative to the product, and what still alerts when the product's host is down>.
Volume: <estimated log lines per day, series count, traces per day, and how the cost scales>.

Rules:
- One row per signal that is not `None`. *Retention* has a number and a unit (`30 days`, `13 months`). *Alternative* names what lost and why.
- The estimate is an order of magnitude with its basis in *Volume*; check the vendor's current price when you write it.

## Libraries

| Language | Purpose | Library | Version | Alternative |
|----------|---------|---------|---------|-------------|
| Python | logs | <library> | <x.y.z> | <alternative> |
| Python | metrics and traces | <library> | <x.y.z> | <alternative> |
| Python | errors | <library> | <x.y.z> | <alternative> |

Rules:
- One row per language in the design and per purpose. *Version* is one you read in the official documentation today; an API you could not verify becomes a spike under *Open questions*.

## Alerts

| id | Condition | Severity | Protects | Route | Owner | Runbook |
|----|-----------|----------|----------|-------|-------|---------|
| A-01 | SLO-01 burn rate over 14.4 for 5 min and over 6 for 30 min | page | SLO-01, Q-01 | phone push to on-call | owner | docs/runbooks/booking-failing.md |
| A-02 | the 30-day error budget of SLO-01 is under 25% | ticket | SLO-01 | issue tracker | owner | docs/runbooks/budget.md |
| A-03 | no heartbeat from the reminder job for 26 h | page | SLO-02, Q-03 | phone push to on-call | owner | docs/runbooks/reminders.md |

Rules:
- *Severity* is `page` (a person now), `ticket` (working hours) or `info` (a dashboard only). More than 5 `page` alerts fails the gate: merge them or demote them.
- *Protects* cites an SLO or a question. *Route*, *Owner* and *Runbook* are never empty. The runbook says how to confirm, the usual causes, the first action and when to escalate.
- Alert on symptoms. A cause (CPU, memory, disk) is a `ticket` or `info` with a reason.

## Dashboards

| id | Name | Audience | Question | Panels | Source |
|----|------|----------|----------|--------|--------|
| D-01 | Service health | on-call | Is it working now? | 6 | M-01, M-02, H-04 |
| D-02 | Release check | owner | Did the last release change latency or errors? | 5 | M-02, E-1 |
| D-03 | Product | product | How many sessions are booked per day? | 3 | EV-01 |

Rules:
- One dashboard per audience and question; at most 8 panels. The top row answers "is it working?". Each dashboard names its sources by id. Deploys are marked on the time axis.

## Operation

- **On call:** <who, how they are reached, what happens when they do not answer>.
- **Incident:** <how an alert becomes an incident, where it is written, who decides it is over>.
- **Review:** <how often alerts, dashboards and retention are reviewed and pruned; each page-level alert is fired once in staging>.
- **Watching the watchers:** <the dead-man's switch or external probe that alerts when the monitoring stops>.

## Verification

| Signal class | How it is verified | Where |
|--------------|--------------------|-------|
| logs | a test asserts the schema fields, the correlation id and the absence of secrets | tests/test_logging |
| metrics | a test makes a request and reads the metric | tests/test_metrics |
| alerts | each page-level alert fired once in staging by a drill | release checklist |
| health | a probe from outside after each deploy | smoke test |

Rules:
- One row for `logs`, `metrics` and `alerts`, and one for each other class the document uses. "Manual" is allowed with a named drill and its owner.

## Open questions

- SLO-02: confirm the 99% target with the owner (it is a proposal).
````

## Field values and aliases

| Field | Values |
|-------|--------|
| Tier | `basic`, `standard`, `advanced` |
| Status | `draft`, `confirmed` |
| Metric type | `counter`, `gauge`, `histogram`, `summary` |
| Event kind | `product`, `audit` |
| Health kind | `liveness`, `readiness`, `startup`, `heartbeat`, `probe` |
| Alert severity | `page`, `ticket`, `info` |
| Privacy rule | `never recorded`, `redacted`, `hashed`, `allow-list` |

Portuguese section names accepted: Perguntas, Objetivos, Logs, Métricas, Rastreamento, Erros, Eventos, Saúde, Privacidade, Arquitetura, Bibliotecas, Alertas, Painéis, Operação, Verificação, Perguntas em aberto. Column names: pergunta, objetivo, jornada, meta, janela, fonte, rótulos, cardinalidade, atende, responsável, rota, severidade, protege, runbook, retenção, custo, alternativa, versão.
