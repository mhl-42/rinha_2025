# Signals: what to record and how to model it

The catalog behind steps 2, 4 and 5. Pick signals from here only when a question or an SLO asks for them.

## Questions worth asking

The ones most designs forget, grouped by who asks:

| Asker | Question | Signal that answers it |
|-------|----------|------------------------|
| On-call | Is the user able to do the main thing right now? | a probe or an SLI on the journey, not a CPU graph |
| On-call | What changed just before it broke? | deploy and config markers on every graph |
| On-call | Is it us or a dependency? | outbound call metrics per dependency (rate, errors, latency) |
| On-call | Did a job not run? | heartbeat with an alert on absence |
| On-call | Is a queue growing faster than it drains? | depth and age of the oldest message |
| Owner | Did the release make it worse? | the same SLIs split by release, errors by release |
| Owner | Which customer or tenant is affected? | a tenant id in logs and traces, never in metric labels |
| Owner | Are we running out of something (disk, connections, quota, certificate)? | saturation gauges and expiry dates with a ticket-level alert |
| Product | Which steps of the journey lose users? | product events with a funnel |
| Finance | What does it cost per user or per request (cloud, LLM tokens, SMS)? | cost counters per feature, tokens in and out per call |
| Compliance | Who read or changed this record, and when? | audit events |
| Security | Who is failing to log in, and from where? | authentication events, rate of failures, permission denials |
| Frontend | What did the user's browser or phone see? | real-user monitoring: JS errors, Core Web Vitals, crashes by app version |

## Logs

- **Purpose:** the narrative of one event, for someone debugging a specific case. Not for counting, not for analytics, not for audit.
- **Format:** one JSON object per line on standard output. The platform or an agent ships it; the program owns no log files and no rotation.
- **Schema:** the same field names in every component: `timestamp` (RFC 3339, UTC), `level`, `service`, `version`, `event` (stable name), `request_id`, `trace_id`, plus event fields. Version the schema when a field changes meaning.
- **Levels:** `error` = a person may need to act; `warn` = unexpected but handled; `info` = business-relevant lifecycle (a job started, a payment captured); `debug` = off in production, switchable for one request or one service without a deploy.
- **Correlation:** accept an incoming `X-Request-ID` (validate length and charset) or create one; put it in every line, in outgoing calls and in the error tool. With tracing, the `trace_id` takes this role.
- **One event, one line:** log the outcome once with the duration, not "start" and "end" and "doing X" around it. Log an error once, where it is handled, with its cause chain; do not log and re-raise at every layer.
- **Never:** secrets, tokens, passwords, card numbers, full bodies, SQL with bound values, free text typed by users, health data, stack traces in responses to the client.

## Metrics

- **Counter:** only goes up (`requests_total`); read as a rate. **Gauge:** a current value (queue depth, pool in use). **Histogram:** a distribution in fixed buckets (latency); compute percentiles from the histogram on the backend, never average percentiles across instances.
- **Naming:** `<domain>_<what>_<unit>`, base units (seconds, bytes), `_total` for counters, snake_case, no unit in the label. Follow OpenTelemetry semantic conventions for HTTP, database, messaging and runtime where they exist, so dashboards and alerts from the ecosystem work unchanged.
- **Methods to choose the set:**
  - **RED** for each service that handles requests: Rate, Errors, Duration.
  - **USE** for each resource: Utilization, Saturation, Errors (pools, queues, disk, memory).
  - **Four golden signals:** latency, traffic, errors, saturation. Separate the latency of failed requests from the latency of successful ones.
- **Cardinality:** series = product of the label values. Allowed labels are closed sets: route *template* (`/sessions/{id}`), method, status class, outcome, dependency name. Forbidden: user, e-mail, raw URL, request id, trace id, free text. Estimate the number before you ship it.
- **Dependencies:** wrap each outbound client (database, e-mail provider, payment, LLM API) with the same three metrics and a timeout. A call without a metric is a blind spot.
- **Business metrics:** a counter for the event the product exists for (sessions booked, orders paid). It is the best "is it working?" signal there is, and it needs no infrastructure knowledge.
- **LLM and cost metrics** (when the product calls a model API): requests, input and output tokens, latency, errors and retries by model and feature, cost per request as a counter in a currency unit, and the rate of refusals or empty answers. Log prompt and response content only under an explicit privacy decision; hash or sample otherwise.

## Traces

- **When:** the request crosses processes or slow third parties and you must answer "where did the time go?". A single process with good logs and one duration histogram does not need traces.
- **Propagation:** the W3C `traceparent` header across HTTP, and the same context in message headers for queues, so a job started by a request joins the request's trace (or links to it).
- **Spans:** one per inbound request, per outbound call, per database statement group; attributes follow the semantic conventions; never put personal data or SQL values in attributes.
- **Sampling:** head sampling (decided at the start) is cheap and drops rare cases; tail sampling (decided at the end by a collector) keeps all errors and slow traces and needs a collector with memory. Start with a low fixed rate plus "always keep errors and slow", and revisit when the bill or the gaps hurt.
- **Link to logs:** the `trace_id` in every log line lets one click go from a slow span to its log lines.

## Errors and exceptions

- Capture unhandled exceptions, handled errors that lose user work, failed jobs and frontend errors, with a stack, release, environment, user reference (opaque) and correlation id.
- **Grouping** (fingerprint) by exception type and top application frame, so a thousand identical failures are one issue with a count. Set a rule for noise (bots, cancelled requests) rather than muting the source.
- **Release tracking:** tag every event with the release (git sha) and mark deploys, so "new in this release" and "regression" are answerable. Upload source maps or debug symbols in CI.
- **Triage:** every new group gets an owner and a state (new, ignored with a reason, fixed in a release). A list of 4,000 unresolved errors is the same as no tracking.
- **Alerts from errors:** a new group in production, or a rate above a baseline, is a `ticket`. Page only from the SLO.

## Events: product and audit

- **Product events** feed analytics: a name, a timestamp, an opaque actor reference, and a few properties. Keep a short tracking plan (name, trigger, properties, owner) so names do not drift. Sampling is acceptable.
- **Audit events** answer "who did what to which record, when, from where, and with what result". They are written in the same transaction as the change when the rule demands it, stored append-only (no update, no delete by the application role), retained for the period the law or the PRD sets, readable by a small named group, and reviewed. Never sampled.
- **Security events:** logins, failures, password resets, permission denials, role changes, token creation. Keep them in the audit store or a security log with its own alerts (a burst of failures from one source).

## Health, probes and jobs

- **Liveness:** "the process is stuck, restart it." No dependency calls. **Readiness:** "send me traffic." May check the database and required dependencies with a short timeout. **Startup:** gives a slow start time before liveness applies.
- **Synthetic probe:** an external request that performs the main journey (or a safe read of it) every minute or two from outside the product's network. It catches DNS, certificate, CDN and routing failures that internal checks never see.
- **Certificates and quotas:** a gauge for days until certificate and domain expiry, provider quotas, and disk or database size growth, alerted at `ticket` level well before the limit.
- **Jobs and cron:** emit "started", "succeeded", "failed" and the duration; ping a heartbeat monitor on success; alert when the ping is missing for longer than the schedule plus a grace period. Record the number of items processed so "ran but did nothing" is visible.
- **Queues:** depth, age of the oldest message, consumer lag, retry and dead-letter counts. Age matters more than depth.

## Data stores and runtime

- **Database:** connections in use versus the limit, slow-query statistics (`pg_stat_statements` for PostgreSQL: see `postgres-database`), replication lag, lock waits, disk growth, backup age and the time of the last successful restore test.
- **Runtime:** memory and garbage-collection pauses, event-loop lag (Node), goroutines (Go), thread and connection pools, file descriptors. Alert on saturation approaching a limit, graph the rest.
- **Continuous profiling:** optional at `advanced`; sampled CPU and memory profiles tagged by release answer "why is it using more CPU since Tuesday?".

## Telemetry hygiene

- **Time:** UTC everywhere; servers synchronised (NTP). Convert for the reader in the dashboard.
- **Redaction:** an allow-list of fields that may leave the process, applied in the logger and in the error tool; a backend scrubber is a second line, never the first.
- **Ownership:** every metric, alert and dashboard has an owner, or it is deleted on the next review.
- **Cost:** volume is the lever: lower the level, sample, drop noisy health-check logs, shorten retention for debug-grade data, and aggregate before storing. Set a budget alert on the telemetry bill itself.
- **Testing:** instrumentation is code. Test that required fields exist, secrets are absent, a request moves the metric, and an alert rule parses (`promtool check rules` or the vendor's equivalent) in CI.
