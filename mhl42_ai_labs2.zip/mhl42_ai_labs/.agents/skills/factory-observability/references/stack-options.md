# Architecture, storage and libraries

Used in steps 6 and 7. Check each product's current version, pricing and licence in its official documentation before you write it down; this file gives the shape of the choice, not the numbers.

## The pipeline

```
instrument (SDK in the code) → collect (agent, collector or platform) → store (per signal) → query and alert → visualise
```

- **Instrument with OpenTelemetry** at the code boundary (API and SDK for logs, metrics and traces, with semantic conventions). The backend then becomes configuration: an exporter endpoint, not a code change. This is the one "future-proofing" worth paying for.
- **Collect** with the platform's own agent when the host ships one (Render, Fly, Cloud Run, ECS and Kubernetes all ship stdout to a log service), or an OpenTelemetry Collector when you need to filter, redact, batch, sample or fan out to two backends. A collector is a component to run, update and monitor: add it for a driver, not by default.
- **Store** each signal in a store built for its shape. Logs are text events, metrics are time series, traces are span trees, errors are grouped issues, audit events are rows.
- **Query and alert** where the data is: the alert rules live next to the store and are kept in version control.

## Choosing by tier

| Tier | Typical shape | Why |
|------|---------------|-----|
| `basic` (script, CLI, one small service) | structured logs to stdout and the platform's log viewer; an error tracker (hosted free tier); a heartbeat monitor for jobs; an external uptime check | the whole design is a handful of cheap parts; no metrics store to run |
| `standard` (web product, database, integrations) | the above plus metrics (a managed Prometheus-compatible service, or the vendor's APM), SLO-based alerts, two or three dashboards, release markers | a user-facing product that needs to know when it is slow or failing |
| `advanced` (several deployable units, queues, regulated data) | OpenTelemetry Collector, logs + metrics + traces in one backend or a self-hosted set, tail sampling, tiered retention, meta-monitoring, on-call tooling | cross-service questions, volume and compliance justify the operating cost |

## Options by signal

Every row of the document's *Architecture* table lists one alternative that lost. These are the usual candidates; the "when" is a heuristic.

| Need | Self-hosted / open source | Managed | Choose when |
|------|---------------------------|---------|-------------|
| Instrumentation | OpenTelemetry SDKs | the vendor's agent (works, but locks code to the vendor) | always OpenTelemetry unless the vendor's agent is the only supported path |
| Collection | OpenTelemetry Collector, Grafana Alloy, Vector, Fluent Bit | the host platform's log drain | the platform drain is enough until you must redact, sample or route in the pipeline |
| Logs | Grafana Loki, OpenSearch / Elasticsearch, ClickHouse | the host's logs, Grafana Cloud, Datadog, Better Stack, CloudWatch Logs | Loki is cheap because it indexes labels only; full-text search at volume needs OpenSearch or ClickHouse |
| Metrics | Prometheus, VictoriaMetrics, Mimir | Grafana Cloud, Datadog, Amazon Managed Prometheus, Azure Monitor | one small stack: Prometheus; more than one instance of Prometheus or long retention: Mimir or VictoriaMetrics |
| Traces | Grafana Tempo, Jaeger | Honeycomb, Grafana Cloud, Datadog APM, X-Ray | Tempo with object storage is the low-cost self-hosted choice; Honeycomb is strong for exploration on wide events |
| Errors | Sentry (self-hosted), GlitchTip | Sentry, Rollbar, Bugsnag | GlitchTip is Sentry-compatible and light; Sentry's SDKs also work with several backends |
| Dashboards | Grafana | Grafana Cloud, the vendor's own | Grafana unless the vendor's APM already includes what you need |
| Alert routing and on-call | Alertmanager with Grafana OnCall style tools | PagerDuty, Opsgenie-style tools, Grafana IRM, Better Stack, a phone push channel | one person: a phone push channel is enough; a rota needs schedules and escalation |
| Uptime and probes | Blackbox exporter, Uptime Kuma | Better Stack, Checkly, UptimeRobot, CloudWatch Synthetics | the probe must run outside the failure domain of the product |
| Job heartbeats | a Pushgateway or a small endpoint | Healthchecks.io, Cronitor, Better Stack heartbeats | managed is cheaper than the time to build it |
| Real-user monitoring | OpenTelemetry web, Sentry browser SDK | Sentry, Datadog RUM, Grafana Faro | when the front end is a product surface |
| Audit trail | a table owned by the application with an append-only role, or an event log | a cloud audit service for platform actions | the application's audit stays in its own database; do not send it to the log pipeline |
| Product analytics | PostHog (self-hosted), Plausible | PostHog Cloud, Amplitude, Mixpanel | product questions are separate from operational ones; respect consent |
| LLM calls | OpenTelemetry GenAI conventions, Langfuse | Langfuse Cloud, LangSmith, Helicone | only when the product calls a model: traces of prompts, tokens, latency, cost, evaluations |
| Cost of the telemetry | the backend's usage page | the vendor's usage alerts | set a budget alert from day one |

## Build, buy, or both

- **One person or a small team:** buy (a managed backend with a free tier or a flat price), keep instrumentation in OpenTelemetry, and write the exit path in an ADR. Self-hosting a metrics, logs and traces stack is a part-time job.
- **Data residency or very high volume:** self-host the store, still buy the on-call and the external probe.
- **Existing tooling:** the company's standard wins unless it cannot answer the questions; then add the gap, not a second stack.
- **Lock-in is a cost, not a veto.** Name it in the ADR: what leaves with you (OpenTelemetry data, dashboards as code, alert rules in Prometheus format) and what does not (a vendor query language, saved views).

## Retention, cost and sampling

| Signal | Typical retention | Cost lever |
|--------|-------------------|------------|
| Logs | 7–30 days hot; archive to object storage only if a rule asks | level, drop health-check noise, sample successful requests, shorter retention for `debug` |
| Metrics | 13 months of aggregates (to compare year over year); raw samples 15–30 days | fewer series: cap cardinality, drop unused metrics, larger scrape interval |
| Traces | 3–14 days | sampling, tail sampling, span attributes limited |
| Errors | 30–90 days | grouping, rate limits, discarding known noise |
| Audit | the legal or PRD period (years) | none: do not reduce, store in cheap append-only storage |
| Product events | the analytics need (12–24 months) | aggregate old data |

Estimate with numbers: lines per day × bytes per line × retention days; series × scrape interval × bytes per sample; traces per day × spans × sampling rate. Write the basis next to the cost so the next person can redo it.

## Failure domain and meta-monitoring

- The monitoring must survive the failure it reports. An alert path that runs on the host that died never fires. Keep at least one check outside: an external probe and a heartbeat monitor.
- **Watch the watchers:** a "dead-man's switch" alert that always fires and is expected by an external service, which pages when the signal stops.
- Alert on the telemetry pipeline itself: dropped spans or logs, scrape failures, exporter queue full, ingest quota near limit.
- Telemetry must not take the product down: asynchronous export, bounded queues, timeouts, and a drop policy when the backend is slow.

## Libraries per language

The design says *what* is used; the language skill says *how*. Verify versions at write time.

| Language | Logging | Metrics and traces | Error tracker | Language skill |
|----------|---------|--------------------|---------------|----------------|
| Python | `structlog` or the standard `logging` with a JSON formatter | `opentelemetry-sdk`, `opentelemetry-instrumentation-*`; `prometheus-client` for pull | Sentry SDK | `python-coding-standards`, `python-tooling` |
| TypeScript / Node | `pino` (fast, JSON by default); `winston` as an alternative | `@opentelemetry/sdk-node` and auto-instrumentations; `prom-client` | Sentry SDK | `typescript-coding-standards`, `javascript-coding-standards` |
| Go | `log/slog` (standard library) | `go.opentelemetry.io/otel`; `prometheus/client_golang` | Sentry SDK | `go-coding-standards` (`log-slog`) |
| Rust | `tracing` with `tracing-subscriber` (JSON layer) | `opentelemetry` with `tracing-opentelemetry`; `metrics` crate | Sentry SDK | `rust-coding-standards` |
| Swift (iOS, macOS, server) | `os.Logger` on Apple platforms; `swift-log` on the server | `swift-otel`, `swift-metrics`; MetricKit on devices | Sentry SDK, Crashlytics | `swift-coding-standards` |
| Browser front end | a thin wrapper that forwards to the error tracker | OpenTelemetry web, Grafana Faro, Web Vitals library | Sentry Browser SDK | `typescript-coding-standards` |
| PostgreSQL | server log with `log_min_duration_statement`, `pg_stat_statements` | `postgres_exporter` | not applicable | `postgres-database` (`obs-query-stats`) |

For each language row in the design: one logger, one metrics client, one tracing SDK, one error reporter, each with a version and one alternative. Do not combine two loggers in one process.

## Decisions that deserve an ADR

The backend (or vendor), the self-host or buy choice, the retention of audit data, sampling of traces, and sending any personal data to a third-party telemetry vendor (a data-processing agreement and a data-residency check come with it).
