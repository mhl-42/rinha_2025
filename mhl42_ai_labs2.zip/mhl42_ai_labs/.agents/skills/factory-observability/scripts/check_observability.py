#!/usr/bin/env python3
"""Quality gate for an observability design written from references/observability-template.md.

Checks that the document is confirmed and that it holds together: every question is answered by a
signal and every signal serves a question or an SLO; each SLO has a source (a PRD requirement or a
proposal that is still an open question) and at least one alert; the log schema has the fields that
make logs searchable (timestamp, level, service, event, correlation id); no metric label has
unbounded cardinality; every scheduled job has a heartbeat; each privacy requirement of the PRD has
a rule; each store has a retention and an alternative; each library has a version and an
alternative; each alert has a severity, route, owner and runbook, and there are at most five pages;
each dashboard has an audience, a question and at most eight panels; and the verification covers
logs, metrics and alerts. Open questions block the document with NEEDS-ANSWERS.

Usage:
  python check_observability.py docs/observability/<slug>.md

Exit codes: 0 = PASS, 1 = FAIL, 2 = NEEDS-ANSWERS.
"""

from __future__ import annotations

import re
import sys
import unicodedata
from pathlib import Path

TIERS = {"basic", "standard", "advanced"}
METRIC_TYPES = {"counter", "gauge", "histogram", "summary"}
EVENT_KINDS = {"product", "audit"}
HEALTH_KINDS = {"liveness", "readiness", "startup", "heartbeat", "probe"}
SEVERITIES = {"page", "ticket", "info"}
PRIVACY_RULES = {"never recorded", "redacted", "hashed", "allow-list"}
MAX_PAGES = 5
MAX_PANELS = 8
MIN_QUESTIONS, MAX_QUESTIONS = 3, 12
BANNED_LABELS = {
    "user", "user_id", "userid", "email", "e-mail", "url", "path", "uri", "session", "session_id",
    "request_id", "trace_id", "span_id", "ip", "client_ip", "message", "error_message", "name",
}
LOG_FIELD_GROUPS = {
    "timestamp": ("timestamp", "time", "ts"),
    "level": ("level", "severity"),
    "service": ("service", "component"),
    "event": ("event", "message", "msg"),
    "correlation id": ("request_id", "trace_id", "correlation_id", "requestid", "traceid"),
}
SECTION_ALIASES = {
    "questions": ("questions", "perguntas"),
    "objectives": ("objectives", "objetivos"),
    "logs": ("logs",),
    "metrics": ("metrics", "metricas"),
    "traces": ("traces", "rastreamento", "traces e rastreamento"),
    "errors": ("errors", "erros"),
    "events": ("events", "eventos"),
    "health": ("health", "saude"),
    "privacy": ("privacy", "privacidade"),
    "architecture": ("architecture", "arquitetura"),
    "libraries": ("libraries", "bibliotecas"),
    "alerts": ("alerts", "alertas"),
    "dashboards": ("dashboards", "paineis"),
    "operation": ("operation", "operacao"),
    "verification": ("verification", "verificacao"),
    "open questions": ("open questions", "perguntas em aberto"),
}
COLUMN_ALIASES = {
    "pergunta": "question", "feita por": "asked by", "perguntado por": "asked by",
    "respondida por": "answered by", "jornada": "journey", "meta": "target", "janela": "window",
    "fonte": "source", "politica de orcamento": "budget policy", "campo": "field", "tipo": "type",
    "obrigatorio": "required", "nome": "name", "unidade": "unit", "rotulos": "labels",
    "cardinalidade": "cardinality", "atende": "serves", "agrupamento": "grouping",
    "acompanha release": "release tracking", "responsavel": "owner", "evento": "event",
    "armazenamento": "store", "retencao": "retention", "tipo de evento": "kind",
    "alvo": "target", "verificacao": "check", "em falha": "on failure", "dado": "data",
    "regra": "rule", "onde e garantido": "where enforced", "sinal": "signal",
    "hospedagem": "hosting", "custo mes": "cost month", "alternativa": "alternative",
    "linguagem": "language", "finalidade": "purpose", "biblioteca": "library", "versao": "version",
    "condicao": "condition", "severidade": "severity", "protege": "protects", "rota": "route",
    "painel": "name", "publico": "audience", "paineis": "panels", "origem": "source",
    "classe de sinal": "signal class", "como e verificado": "how it is verified", "onde": "where",
    "fronteira": "boundary", "propagacao": "propagation", "amostragem": "sampling",
    "sempre mantidos": "always kept", "origem do erro": "source", "ferramenta": "tool",
    "limite": "boundary",
}
ID_RE = re.compile(r"\b(?:SLO|Q|M|EV|H|A|D|E|P)-\d+\b")
PLACEHOLDER_RE = re.compile(r"\bTBD\b|\bTODO\b|\?\?\?|<[A-Za-z][^<>\n]{1,60}>")
NFR_ROW_RE = re.compile(r"^\|\s*(RNF-\d+)\s*\|(.*)$", re.MULTILINE)
PRIVACY_NFR_RE = re.compile(
    r"privacy|privacidade|personal data|dados pessoais|\bLGPD\b|\bGDPR\b|sensitive|sens[ií]vel|"
    r"store only|armazen\w+ apenas|n[aã]o armazen|PII|retention|reten[cç][aã]o|audit|auditoria",
    re.IGNORECASE,
)
JOB_RE = re.compile(
    r"\bcron\b|scheduled job|scheduler|background job|\bworker\b|tarefa agendada|job agendado|"
    r"rotina agendada|\bbatch\b|nightly|noturn[oa]",
    re.IGNORECASE,
)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
VERSION_RE = re.compile(r"\d+\.\d+")
RETENTION_RE = re.compile(
    r"\d+\s*(?:d|day|days|dia|dias|w|week|weeks|semana|semanas|m|mo|month|months|mes|meses|y|year|years|ano|anos|h|hour|hours|hora|horas)\b",
    re.IGNORECASE,
)
NUMBER_RE = re.compile(r"\d")
NONE_RE = re.compile(r"^\s*(?:none|nenhum|nenhuma)\b", re.IGNORECASE)


def plain(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", stripped.lower()).strip()


def canonical_section(heading: str) -> str:
    name = plain(re.sub(r"\(.*?\)", "", heading))
    for canonical, aliases in SECTION_ALIASES.items():
        if name in aliases:
            return canonical
    return name


def canonical_column(cell: str) -> str:
    name = plain(cell)
    return COLUMN_ALIASES.get(name, name)


def sections(text: str) -> dict[str, str]:
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        found[canonical_section(match.group(1))] = text[match.end() : end]
    return found


def table_rows(body: str) -> list[dict[str, str]]:
    lines = [ln.strip() for ln in body.splitlines() if ln.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [canonical_column(cell) for cell in lines[0].strip("|").split("|")]
    rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) == len(header):
            rows.append(dict(zip(header, cells)))
    return rows


def resolve(ref: str, doc: Path) -> Path | None:
    for parent in [doc.parent, *doc.parents]:
        candidate = parent / ref
        if candidate.is_file():
            return candidate
    return None


def is_none(body: str) -> bool:
    prose = [ln for ln in body.splitlines() if ln.strip() and not ln.strip().startswith("|")]
    return bool(prose) and bool(NONE_RE.match(prose[0].strip())) and not table_rows(body)


def ids_in(cell: str) -> set[str]:
    return set(ID_RE.findall(cell))


def empty(cell: str) -> bool:
    return not cell.strip() or cell.strip() in ("-", "—", "–", "n/a")


def check(path: Path) -> tuple[list[str], list[str]]:
    text = path.read_text(encoding="utf-8")
    failures: list[str] = []
    pending: list[str] = []
    body = sections(text)

    header = {k.lower(): v for k, v in re.findall(r"^(PRD|Design|Tier|Status):\s*(.+?)\s*$", text, re.MULTILINE | re.IGNORECASE)}
    if not re.search(r"^status:\s*confirmed\b", text, re.IGNORECASE | re.MULTILINE):
        failures.append("the document is not 'Status: confirmed'; confirm it with the user first")
    tier = header.get("tier", "").strip().lower()
    if tier not in TIERS:
        failures.append(f"Tier must be one of {', '.join(sorted(TIERS))}")

    for name in SECTION_ALIASES:
        if name not in body:
            failures.append(f"missing section '## {name.title()}'")
    if failures and any(f.startswith("missing section") for f in failures):
        return failures, pending

    prd_path = resolve(header["prd"], path) if "prd" in header else None
    prd_text = prd_path.read_text(encoding="utf-8") if prd_path else ""
    design_path = resolve(header["design"], path) if "design" in header else None
    design_text = design_path.read_text(encoding="utf-8") if design_path else ""
    nfrs = {m.group(1): m.group(2) for m in NFR_ROW_RE.finditer(prd_text)}
    if "prd" in header and prd_path is None:
        failures.append(f"PRD file '{header['prd']}' not found")

    defined: set[str] = set()

    def define(rows: list[dict[str, str]], column: str, where: str) -> None:
        for row in rows:
            rid = row.get(column, "").strip()
            if not ID_RE.fullmatch(rid):
                failures.append(f"{where}: '{rid or '(empty)'}' is not a valid id")
            elif rid in defined:
                failures.append(f"{where}: id {rid} is defined twice")
            else:
                defined.add(rid)

    questions = table_rows(body["questions"])
    objectives_none = is_none(body["objectives"])
    objectives = [] if objectives_none else table_rows(body["objectives"])
    metrics_none = is_none(body["metrics"])
    metrics = [] if metrics_none else table_rows(body["metrics"])
    errors = table_rows(body["errors"])
    events = [] if is_none(body["events"]) else table_rows(body["events"])
    health = table_rows(body["health"])
    alerts = table_rows(body["alerts"])
    dashboards_none = is_none(body["dashboards"])
    dashboards = [] if dashboards_none else table_rows(body["dashboards"])
    define(questions, "id", "questions")
    define(objectives, "id", "objectives")
    define(metrics, "id", "metrics")
    define(errors, "id", "errors")
    define(events, "id", "events")
    define(health, "id", "health")
    define(alerts, "id", "alerts")
    define(dashboards, "id", "dashboards")
    for row in table_rows(body["privacy"]):
        if row.get("id"):
            defined.add(row["id"].strip())

    def known(cell: str, where: str) -> None:
        for ref in ids_in(cell):
            if ref not in defined:
                failures.append(f"{where}: {ref} is not defined in this document")

    # Questions
    if not MIN_QUESTIONS <= len(questions) <= MAX_QUESTIONS:
        failures.append(f"questions: write {MIN_QUESTIONS} to {MAX_QUESTIONS} questions (found {len(questions)})")
    for row in questions:
        qid = row.get("id", "")
        if empty(row.get("question", "")):
            failures.append(f"{qid}: the question is empty")
        if empty(row.get("asked by", "")):
            failures.append(f"{qid}: needs an asker (a role such as on-call, owner, product)")
        answered = ids_in(row.get("answered by", ""))
        if not answered:
            failures.append(f"{qid}: no signal answers this question; add one or remove the question")
        known(row.get("answered by", ""), qid)

    # Objectives
    if objectives_none:
        if tier != "basic":
            failures.append("objectives: 'None' is allowed only with Tier: basic")
    elif not objectives:
        failures.append("objectives: write a table of SLOs, or 'None: <reason>' for Tier: basic")
    proposals = False
    for row in objectives:
        oid = row.get("id", "")
        source = row.get("source", "").strip()
        if source.lower() == "proposal" or source.lower() == "proposta":
            proposals = True
        elif source in nfrs or (not prd_text and re.fullmatch(r"RNF-\d+", source)):
            pass
        else:
            failures.append(f"{oid}: source must be a PRD requirement (RNF-NN) found in the PRD, or 'proposal'")
        if not NUMBER_RE.search(row.get("target", "")):
            failures.append(f"{oid}: target needs a number (for example 99.5%)")
        for column in ("journey", "sli", "window", "budget policy"):
            if empty(row.get(column, "")):
                failures.append(f"{oid}: '{column}' is empty")
    if proposals and not re.search(r"SLO-\d+|proposal|proposta", body["open questions"], re.IGNORECASE):
        failures.append("objectives: an SLO with source 'proposal' must be listed under 'Open questions' until the user agrees the target")

    # Logs
    fields = {plain(r.get("field", "")).replace(" ", "_") for r in table_rows(body["logs"])}
    fields |= {f.replace("_", ".") for f in fields}
    for group, names in LOG_FIELD_GROUPS.items():
        if not any(n in fields for n in names):
            failures.append(f"logs: the schema needs a '{group}' field ({' or '.join(names[:2])})")

    # Metrics
    if metrics_none and tier != "basic":
        failures.append("metrics: 'None' is allowed only with Tier: basic")
    elif not metrics_none and not metrics:
        failures.append("metrics: write a table of metrics, or 'None: <reason>' for Tier: basic")
    for row in metrics:
        mid = row.get("id", "")
        if row.get("type", "").strip().lower() not in METRIC_TYPES:
            failures.append(f"{mid}: type must be one of {', '.join(sorted(METRIC_TYPES))}")
        if empty(row.get("unit", "")):
            failures.append(f"{mid}: unit is empty (use 'none' for a dimensionless count)")
        labels = [lab.strip().lower() for lab in re.split(r"[,;]", row.get("labels", "")) if lab.strip()]
        for label in labels:
            if label in BANNED_LABELS:
                failures.append(f"{mid}: label '{label}' has unbounded cardinality; put it in a log or a trace")
        if labels and labels != ["none"] and not NUMBER_RE.search(row.get("cardinality", "")):
            failures.append(f"{mid}: cardinality needs the number of series (the product of the label values)")
        if not ids_in(row.get("serves", "")):
            failures.append(f"{mid}: serves no question or SLO; cite a Q- or SLO- id, or remove the metric")
        known(row.get("serves", ""), mid)

    # Traces
    traces_none = is_none(body["traces"])
    trace_rows = table_rows(body["traces"])
    if traces_none:
        if tier == "advanced":
            failures.append("traces: 'None' is not allowed with Tier: advanced")
    elif not trace_rows:
        failures.append("traces: write a table (boundary, propagation, sampling, always kept) or 'None: <reason>'")
    for row in trace_rows:
        for column in ("propagation", "sampling", "always kept"):
            if empty(row.get(column, "")):
                failures.append(f"traces: '{column}' is empty for '{row.get('boundary', '')}'")

    # Errors
    if not errors:
        failures.append("errors: write at least one row (source, tool, grouping, release tracking, owner)")
    for row in errors:
        eid = row.get("id", "")
        for column in ("source", "tool", "owner"):
            if empty(row.get(column, "")):
                failures.append(f"{eid}: '{column}' is empty")

    # Events
    for row in events:
        evid = row.get("id", "")
        if (row.get("kind") or row.get("type", "")).strip().lower() not in EVENT_KINDS:
            failures.append(f"{evid}: kind must be product or audit")
        if not RETENTION_RE.search(row.get("retention", "")):
            failures.append(f"{evid}: retention needs a number and a unit (for example 24 months)")
        if empty(row.get("store", "")):
            failures.append(f"{evid}: store is empty")
        if not ids_in(row.get("serves", "")):
            failures.append(f"{evid}: serves no question; cite a Q- id")
        known(row.get("serves", ""), evid)

    # Health
    kinds = set()
    for row in health:
        hid = row.get("id", "")
        kind = (row.get("kind") or row.get("type", "")).strip().lower()
        kinds.add(kind)
        if kind not in HEALTH_KINDS:
            failures.append(f"{hid}: kind must be one of {', '.join(sorted(HEALTH_KINDS))}")
        if empty(row.get("check", "")) or empty(row.get("on failure", "")):
            failures.append(f"{hid}: needs a check and what happens on failure")
        if kind == "liveness" and re.search(r"database|banco|dependenc|depend", row.get("check", ""), re.IGNORECASE) \
                and not re.search(r"\bno\b|\bnot\b|sem|n[aã]o", row.get("check", ""), re.IGNORECASE):
            failures.append(f"{hid}: a liveness check must not test dependencies (an outage would restart every instance)")
    if not health:
        failures.append("health: write at least one row")
    if JOB_RE.search(design_text) and "heartbeat" not in kinds:
        failures.append("health: the design has a scheduled job or worker, so a 'heartbeat' row is needed (alert on its absence)")

    # Privacy
    privacy = table_rows(body["privacy"])
    if not privacy:
        failures.append("privacy: write a table of what is never recorded or is redacted")
    for row in privacy:
        pid = row.get("id", "")
        if row.get("rule", "").strip().lower() not in PRIVACY_RULES:
            failures.append(f"{pid}: rule must be one of {', '.join(sorted(PRIVACY_RULES))}")
        if empty(row.get("where enforced", "")):
            failures.append(f"{pid}: say where the rule is enforced")
    for rid, rest in nfrs.items():
        if PRIVACY_NFR_RE.search(rest) and rid not in body["privacy"] and rid not in body["events"]:
            failures.append(f"{rid} is a privacy, retention or audit requirement in the PRD but is not cited in 'Privacy' or 'Events'")
    for label in ("access", "deletion", "acesso", "exclusao", "exclusão"):
        if re.search(rf"^\s*{label}\s*:", body["privacy"], re.IGNORECASE | re.MULTILINE):
            break
    else:
        failures.append("privacy: add 'Access:' (who reads each store) and 'Deletion:' (how a deletion request reaches the telemetry)")

    # Architecture
    arch = table_rows(body["architecture"])
    needed = {"logs", "errors"} | (set() if metrics_none else {"metrics"}) | (set() if traces_none else {"traces"})
    seen = set()
    for row in arch:
        signal = row.get("signal", "").strip().lower()
        seen.add(signal)
        if empty(row.get("store", "")) or empty(row.get("hosting", "")):
            failures.append(f"architecture: '{signal}' needs a store and a hosting")
        if not RETENTION_RE.search(row.get("retention", "")):
            failures.append(f"architecture: '{signal}' retention needs a number and a unit (for example 30 days)")
        if empty(row.get("cost month", row.get("cost / month", ""))) :
            failures.append(f"architecture: '{signal}' needs a cost estimate (free tier is an answer)")
        if empty(row.get("alternative", "")):
            failures.append(f"architecture: '{signal}' needs an alternative that lost, and why")
    for signal in sorted(needed - seen):
        failures.append(f"architecture: no row for '{signal}'")
    if not re.search(r"^\s*failure domain\s*:\s*\S|^\s*dom[ií]nio de falha\s*:\s*\S", body["architecture"], re.IGNORECASE | re.MULTILINE):
        failures.append("architecture: add 'Failure domain:' (what still alerts when the product's host is down)")

    # Libraries
    libraries = table_rows(body["libraries"])
    if not libraries:
        failures.append("libraries: write one row per language and purpose")
    for row in libraries:
        label = f"{row.get('language', '?')} {row.get('purpose', '')}".strip()
        if not VERSION_RE.search(row.get("version", "")):
            failures.append(f"libraries: '{label}' needs a verified version (for example 1.4.2)")
        if empty(row.get("library", "")) or empty(row.get("alternative", "")):
            failures.append(f"libraries: '{label}' needs a library and an alternative")

    # Alerts
    pages = 0
    protected: set[str] = set()
    if not alerts:
        failures.append("alerts: write at least one alert (a heartbeat or an SLO burn)")
    for row in alerts:
        aid = row.get("id", "")
        severity = row.get("severity", "").strip().lower()
        if severity not in SEVERITIES:
            failures.append(f"{aid}: severity must be page, ticket or info")
        pages += severity == "page"
        for column in ("condition", "route", "owner", "runbook"):
            if empty(row.get(column, "")):
                failures.append(f"{aid}: '{column}' is empty; an alert needs a route, an owner and a runbook")
        refs = ids_in(row.get("protects", ""))
        if not refs:
            failures.append(f"{aid}: protects no SLO or question")
        protected |= refs
        known(row.get("protects", ""), aid)
    if pages > MAX_PAGES:
        failures.append(f"alerts: {pages} page-level alerts; keep at most {MAX_PAGES} (merge them or demote to ticket)")
    for row in objectives:
        if row.get("id") not in protected:
            failures.append(f"{row.get('id')}: no alert protects this SLO")

    # Dashboards
    if dashboards_none and tier != "basic":
        failures.append("dashboards: 'None' is allowed only with Tier: basic")
    elif not dashboards_none and not dashboards:
        failures.append("dashboards: write at least one dashboard, or 'None: <reason>' for Tier: basic")
    for row in dashboards:
        did = row.get("id", "")
        for column in ("name", "audience", "question"):
            if empty(row.get(column, "")):
                failures.append(f"{did}: '{column}' is empty; a dashboard answers a question for an audience")
        count = re.search(r"\d+", row.get("panels", ""))
        if not count:
            failures.append(f"{did}: panels needs a number")
        elif int(count.group()) > MAX_PANELS:
            failures.append(f"{did}: {count.group()} panels; keep at most {MAX_PANELS} or split by audience")
        if not ids_in(row.get("source", "")):
            failures.append(f"{did}: cite the signals it draws (M-, EV-, E-, H- ids)")
        known(row.get("source", ""), did)

    # Operation
    operation = body["operation"].lower()
    for label, pattern in (
        ("on call", r"on[- ]call|plant[aã]o"),
        ("incident", r"incident"),
        ("review", r"review|revis[aã]o"),
        ("watching the watchers", r"dead[- ]man|watching the watchers|meta-?monitor|monitor(?:a|ing)? o monitor|sonda externa|external probe"),
    ):
        if not re.search(pattern, operation):
            failures.append(f"operation: cover '{label}'")

    # Verification
    verification = table_rows(body["verification"])
    classes = " ".join(
        plain(r.get("signal class", "")).replace("alertas", "alerts").replace("metricas", "metrics") for r in verification
    )
    for required in ("logs", "alerts") + (() if metrics_none else ("metrics",)):
        if required not in classes:
            failures.append(f"verification: no row for '{required}'")
    for row in verification:
        if empty(row.get("how it is verified", row.get("check", ""))):
            failures.append(f"verification: '{row.get('signal class', '')}' says nothing about how")

    if PLACEHOLDER_RE.search(re.sub(r"^```.*?^```", "", text, flags=re.MULTILINE | re.DOTALL)):
        failures.append("the document still has placeholders (TBD, TODO, ??? or <angle brackets>)")

    open_questions = body["open questions"].strip()
    if open_questions and not NONE_RE.match(open_questions) and open_questions not in ("-",):
        pending.append("open questions remain; ask them in one numbered round with recommended answers")

    return failures, pending


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"Error: {path} not found", file=sys.stderr)
        return 1
    failures, pending = check(path)
    if failures:
        print("FAIL")
        for item in failures:
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
