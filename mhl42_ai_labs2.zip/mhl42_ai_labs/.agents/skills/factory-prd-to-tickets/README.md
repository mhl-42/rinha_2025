# factory-prd-to-tickets

Step 5 of the flow. From a confirmed PRD and a confirmed tech design, writes an ordered backlog in `docs/tickets/<slug>.md`: spikes and a walking skeleton first, then vertical slices. It can export the backlog to GitHub issues after the user approves.

```
4 factory-tech-design → 5 factory-prd-to-tickets ─┬─ FAIL → fix
                                  ├─ NEEDS-ANSWERS → ask the open questions
                                  └─ PASS → confirm → (optional) export_github.py → build
```

## What it enforces

- **Inputs confirmed.** The PRD and the design must be `Status: confirmed`, and the design must point to the same PRD.
- **Risk first.** Every design spike has a spike ticket, and a walking skeleton (repository, CI, deploy) comes before the features. Every feature ticket depends on it.
- **Vertical slices.** A feature ticket serves one to three FRs, with Given/When/Then criteria. Size is S or M, never L.
- **Coverage.** Every FR is in a feature ticket. Every NFR is in a ticket or in the definition of done.
- **Build order.** Dependencies point only to earlier tickets.
- **No new scope.** A feature ticket that serves no FR fails.
- **Export only after approval.** `export_github.py` previews by default and creates issues only with `--apply`.

## Files

```
factory-prd-to-tickets/
├── SKILL.md
├── references/
│   ├── ticket-template.md   # Template, field values, Portuguese aliases
│   ├── slicing.md           # Order, vertical slices, splitting, size and mode, NFRs
│   └── export.md            # GitHub issues and other trackers
├── scripts/
│   ├── check_tickets.py     # Exit 0 PASS, 1 FAIL, 2 NEEDS-ANSWERS
│   └── export_github.py     # Preview, or --apply to create the issues with gh
└── evals/
    ├── evals.json           # Clinic backlog, export request, pushback on layer tickets
    ├── trigger_queries.json
    (fixtures: ../../evals/fixtures/)
```

## Run the checker

```bash
python scripts/check_tickets.py docs/tickets/<slug>.md
```
