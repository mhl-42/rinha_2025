---
name: factory-prd-to-tickets
description: Use this skill to break a confirmed PRD and its confirmed tech design into an ordered backlog of tickets — spikes and a walking skeleton first, then thin vertical slices that each serve PRD requirements, with dependencies, size, Given/When/Then acceptance criteria, and a definition of done for the non-functional requirements — checked by a quality gate, and optionally exported as GitHub issues after the user approves. Triggers on "break the PRD into tickets", "create the backlog", "turn the design into tasks/issues", "quebra em tarefas", "gera os tickets/issues". Not for writing the PRD (use factory-prd-writer), choosing the stack (use factory-tech-design), or implementing a ticket.
license: MIT
compatibility: scripts/check_tickets.py and scripts/export_github.py need Python 3.10+ (no dependencies); the export also needs the GitHub CLI (gh). Expects the PRD format of factory-prd-writer and the design format of factory-tech-design.
metadata:
  author: mhl42
  version: "1.6.0"
---

# PRD to Tickets

Turn the confirmed PRD and tech design into a backlog someone (a developer or an agent) can pick up ticket by ticket, in order. Tickets add no scope: each one serves PRD requirements or a design spike.

This is step 5 of the flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief → 3 factory-prd-writer → 4 factory-tech-design → 4b factory-ui-design (when the design has screens) → 5 factory-prd-to-tickets → build
```

Write the tickets in the user's language.

## Before you start

- **PRD:** `docs/prd/<slug>.md` with `Status: confirmed`. **Design:** `docs/design/<slug>.md` with `Status: confirmed`, whose `PRD:` header points to the same PRD.
- **UI spec:** when the design's `Platforms:` header names a user interface (`web`, `mobile`, `desktop`, `tui`, `cli` or `chat`), `docs/ux/<slug>.md` with `Status: confirmed`. The gate fails without it.
- If any of them is missing or still a draft, stop and send the user to factory-prd-writer, factory-tech-design or factory-ui-design. Do not cut tickets from a draft: open questions there become rework here. A product with a user interface and no UI spec is the common case: run factory-ui-design now, not after the tickets.
- Read the design's *Components*, *Data model* (column by column, with the domain attribute each column comes from), *Rule enforcement*, *Errors and observability*, *Integrations* (the *If it fails* column), *Risks and spikes*, and *Deployment*, and the PRD's requirements with their priority and acceptance criteria. When the PRD links a domain model, read its rules too: the tickets carry them by ID.

## Workflow

```
- [ ] 1. Inputs checked (both confirmed, same PRD)
- [ ] 2. First tickets: one spike ticket per design spike, then the walking skeleton
- [ ] 3. Vertical slices for the FRs, Must first (references/slicing.md)
- [ ] 4. Definition of done for the NFRs that apply to every ticket
- [ ] 5. check_tickets.py → PASS
- [ ] 6. User confirms; status set to confirmed (then, with the server, `factory_next` names the first ticket to build)
- [ ] 7. Optional: export to GitHub issues, only after the user says yes
```

### 2. Spikes and skeleton first
- **Spikes:** one ticket per design spike (`S1`, `S2`...). Copy its question, and use its exit criterion as the acceptance criterion and its timebox as the size.
- **Walking skeleton:** one ticket that sets up the repository, CI, the deployment from the design, and one trivial page or endpoint running in the real environment. Every feature ticket depends on it, directly or through another ticket. Use the language skills for the details (for Python, `python-tooling`).

### 3. Vertical slices
Follow [references/slicing.md](references/slicing.md). In short:
- A ticket is a **vertical slice**: it goes through every layer it needs (data, logic, UI or API, tests) and leaves something the user of that FR can see or call. "Create all the models" or "build the UI" are horizontal layers, not tickets.
- Each feature ticket serves one to three FRs and copies the acceptance criteria it covers from the PRD, in Given/When/Then. When those criteria come from business rules, name the rules in *Notes* (`BR-07, BR-08`), so the implementer reads the rule and its counterexample in the domain model.
- **Screens travel.** With a UI spec, each screen ticket copies the screen's states as criteria, and every cell of *Records* (list, create with its open fields, edit with its editable and locked fields, delete with its confirmation and refusals) becomes a criterion of the ticket that builds that screen. A record whose create, edit or delete is in no ticket is not built.
- **Data travels.** A ticket that creates or changes a table names it, with its columns from the design's *Data model* (type, null, key), in *Notes*, and its migration in *Touches*. The columns of a table are built once, by the first ticket that needs the table; a later ticket that adds columns says which. The required, unique and locked attributes (domain *Attributes*: *Required*, *Unique*, *Changes*) become criteria: "Given a sale already closed, when the discount is changed, then it is refused".
- **Failure behaviour travels.** Every behaviour the design states for a failure (what the user sees when the database cannot be opened, when an integration is down) becomes a criterion of the ticket that builds that part, or a line of the definition of done. A failure mode that lives only in the design is not built.
- **Size** is `S` (up to half a day) or `M` (up to two days). `L` means the ticket must be split.
- **Depends on** lists earlier tickets only, so the ticket order is a valid build order.
- **Mode** is `AFK` (an agent can finish it alone from the ticket) or `HITL` (needs a human: a decision, credentials, a visual review, access to a third party).
- Order by value and risk: Must FRs first, and the riskiest Must early.
- **Touches** (optional, recommended when the design names files or modules): the files the ticket expects to change. Two tickets with no dependency between them that name the same file are a hot file: the checker warns, and you either declare the dependency or leave them as a pair to run one at a time. A file that many tickets name (a screen module, a list of migrations) is a design smell: see references/slicing.md.

### 4. Definition of done
List what applies to **every** ticket: tests in CI, lint, and the NFRs that are rules for all code (privacy, permissions, accessibility). An NFR that needs its own work (a load test, a backup restore drill) becomes a ticket with `Type: nfr`. Every NFR ends up in one of the two places.

Write the file from [references/ticket-template.md](references/ticket-template.md) to `docs/tickets/<slug>.md`.

### 5. Check
```bash
python <this-skill-dir>/scripts/check_tickets.py docs/tickets/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: a product with screens and no confirmed UI spec (run factory-ui-design), an FR or NFR not covered, a design spike without a ticket, a ticket of size L, a dependency on a later or unknown ticket, a feature ticket that serves no FR, missing Given/When/Then, unknown references. |
| `NEEDS-ANSWERS` | 2 | *Open questions* is not empty. Ask them in one numbered round, with a recommended answer for each, and update the file. |
| `PASS` | 0 | Confirm. |

Warnings (spikes after feature tickets, tickets serving many FRs, two independent tickets that touch the same file, a HITL measure with no datum to record) do not block, but fix them or say why they stay.

### 6. Confirm
Show a short table (ID, title, type, size, mode, depends on) and the first three tickets to start with. Ask for explicit confirmation. Then set `Status: confirmed`.

### 7. Export (optional)
Only when the user asks for issues in a tracker, and only after they confirm the target repository. Creating issues is visible to other people, so preview first:

```bash
python <this-skill-dir>/scripts/export_github.py docs/tickets/<slug>.md --repo OWNER/REPO            # preview, creates nothing
python <this-skill-dir>/scripts/export_github.py docs/tickets/<slug>.md --repo OWNER/REPO --apply    # after the user says yes
```

The script creates the issues in ticket order and replaces `T-NN` dependencies with the issue numbers. For other trackers, see [references/export.md](references/export.md).

## Ticket store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the tickets live in SQLite and `docs/tickets/<slug>.md` is an export. Use the tools for these steps; without them, the markdown steps above still apply.

- **After step 5 passes on the draft:** `project_open(project=<slug>, prd_path=..., design_path=...)`, then `project_import_markdown(path="docs/tickets/<slug>.md", project=<slug>)`.
- **Changes to tickets:** use `ticket_add_dependency` and `ticket_decompose` (every criterion must be covered by a subtask), not the file. Then `project_export_markdown` to refresh the file.
- **Check:** `project_validate(project=<slug>)` runs the same gate as step 5, with the same exit codes.
- **Step 6, after the user confirms:** `project_open(project=<slug>, status="confirmed")`.

Hand edits to the markdown are lost on the next export. Make them in the database.

## Gotchas

- Agents slice by layer ("models", "API", "frontend"), which leaves nothing testable until the end. Slice by user-visible behavior.
- In `supermercado-pdv`, the design said what happens when SQLite cannot be opened, but no ticket had it as a criterion: it surfaced as a traceback in review and became T-19 at the end of the backlog.
- Agents add tickets for things the PRD does not ask for: an admin dashboard, metrics, a mobile app, "refactor". The gate fails a feature ticket that serves no FR. Put the idea in *Open questions*.
- A ticket that says "implement RF-03" without its acceptance criteria forces the implementer to reopen the PRD and guess. Copy the criteria.
- Features that depend on a spike's answer must list the spike ticket in *Depends on*. If the spike fails, those tickets are the ones to revisit.
- Do not start implementing. The output is the backlog; `factory-implement` builds one ticket per run.
