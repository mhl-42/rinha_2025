# Exporting Tickets

The tickets file is the source of truth. Exporting copies it to a tracker so people can assign and discuss tickets there.

Creating issues is visible to everyone with access to the repository or project. Always show the preview, name the target, and wait for an explicit yes.

## GitHub issues

```bash
python scripts/export_github.py docs/tickets/<slug>.md --repo OWNER/REPO           # preview only
python scripts/export_github.py docs/tickets/<slug>.md --repo OWNER/REPO --apply   # create the issues
```

- Needs `gh` installed and logged in (`gh auth status`). The user logs in; never ask for or type a token.
- Issues are created in ticket order. In each body, `T-NN` in *Depends on* is replaced with `#<issue number>`.
- Labels: `type:<type>`, `size:<size>`, `mode:<mode>`. Add `--labels` to create them first if they do not exist.
- The script refuses a tickets file that is not `Status: confirmed`.
- After creating the issues, it writes a line `Issue: #<n>` under each ticket heading, so running it again skips tickets that already have an issue.

## Other trackers

For Jira, Linear, Azure Boards, or GitLab, use the tracker's CLI or MCP server if one is installed. Map the fields like this:

| Ticket | Tracker |
|--------|---------|
| Title | Summary / title |
| Type | Issue type or label |
| Serves, Notes, Acceptance criteria | Description |
| Depends on | "Blocked by" links |
| Size | Estimate / story points (S = 1, M = 3) |
| Mode | Label (`afk`, `hitl`) |

If none is installed, the tickets file is enough: the build step reads it directly.
