# Slicing the Backlog

## Contents
- Order
- Vertical slices
- Splitting a ticket
- Size and mode
- Hot files
- NFRs
- Examples

## Order

1. **Spikes** for the design's risks. They are cheap and they can change later tickets.
2. **Walking skeleton:** repository, CI, deployment to the real environment, one trivial page or endpoint. After it, every ticket ends in a deploy.
3. **The thinnest end-to-end path of the core Must FR** (for a booking app: see free slots and book one). It proves the architecture.
4. **The other Must FRs**, riskiest first.
5. **Should**, then **Could**.

When the PRD or design fixes a release order (for example, staff features go live before the patient features), follow it, and say so in the ticket notes.

## Vertical slices

A vertical slice crosses every layer it needs and ends in behavior a user of the FR can see or call, with tests.

| Horizontal (avoid) | Vertical (use) |
|--------------------|----------------|
| Create all the database tables | Receptionist registers a patient (table, form, list, tests) |
| Build the REST API | Patient cancels a session 24 h ahead (rule, endpoint, page, tests) |
| Frontend for the patient area | Patient sees the free slots of their therapist |

The data model grows with the slices: each ticket adds the tables and fields it needs.

## Splitting a ticket

If a ticket is `L`, serves more than three FRs, or has more than six acceptance criteria, split it:
- **By acceptance criterion:** the happy path first, the edge cases (conflict, expired link, 24 h rule) in a follow-up ticket.
- **By role:** the receptionist's version first, the patient's version later, reusing the same rule.
- **By rule:** the simplest rule first (fixed slots), the full rule next (rooms and therapists together).

Each part must still be a vertical slice and must still copy its own acceptance criteria.

## Size and mode

- `S`: up to half a day. `M`: up to two days. Anything larger is guesswork; split it.
- `AFK`: the ticket has everything an agent needs (criteria, components, entities) and no external dependency.
- A ticket that mixes a machine part and a human part is split in two: `T-NN` (AFK) builds and tests what a machine can check, and `T-NN+1` (HITL, depends on `T-NN`) holds only the human verification. Do not leave a person's measurement as the last criterion of a build ticket: it gets closed with "not measured".
- The criterion of a HITL ticket names the **datum to record** ("total time in minutes", "who ran it", "operating system", "how many of 20 landed"). Its `done` needs that datum in the evidence, not "ok". The checker warns when a HITL criterion is a measure and nothing says what is recorded.
- `HITL`: a person is needed, such as for credentials, DNS, a vendor account, a decision, a visual or accessibility review, or a test with real users. Spikes against third parties and the skeleton are usually HITL.

## Hot files

A file that two tickets both change is where parallel work collides at merge. Declare it with `Touches:`; the checker warns when two tickets with no dependency between them name the same file.

- If one really needs the other's change, declare the dependency (`Depends on:`), so the order is forced.
- If they are independent and the file is only appended to (an import, a list entry, a block at the end), keep both and say in *Notes* that they run one at a time, or accept the merge work. Do not hide it by leaving `Touches:` out.
- If one file shows up in the `Touches:` of many tickets, the cause is the design: the file is a single point of editing. Ask for a split in the design (a module per screen, one file per migration) instead of sequencing everything.
- Numbered things (migration numbers, ADR numbers, ticket ids) are not a file conflict, but they collide in the same way. The orchestrator assigns each ticket its number before delegating, and the ticket's *Notes* can carry it.

## NFRs

- A rule for all code goes to the **Definition of done** with its id: privacy fields, permission tests, accessibility, lint, test coverage.
- A piece of work goes to a **ticket** with `Type: nfr`: a load or concurrency test, a backup restore drill, a performance measurement, a security review.
- Use the *How to verify* column of the design's NFR coverage as the acceptance criterion.

## Rules and failure modes

- A business rule reaches a ticket through the PRD criterion that cites it. Name the rule ids in *Notes* so the implementer reads its example and counterexample in the domain model.
- The design's *Rule enforcement* says where each rule holds (domain code, a database constraint, both). The ticket that builds that place carries the rule's test.
- Every failure behaviour of the design (*Integrations* "If it fails", *Errors and observability*) lands in a ticket criterion or in the definition of done. Check the list before the gate: the checker cannot see these.

## Examples

**Feature ticket:**
```
### T-05: Receptionist cancels a session at any time
Type: feature
Serves: RF-08
Depends on: T-04
Size: S
Mode: AFK
Acceptance criteria:
- Given a booked session, when the receptionist cancels it, then the slot becomes free and no reminder is sent
Notes: Component reception; reuses the cancel rule of T-04 without the 24 h limit.
```

**NFR ticket:**
```
### T-12: Concurrency test for double booking
Type: nfr
Serves: RF-13, RNF-04
Depends on: T-03
Size: S
Mode: AFK
Acceptance criteria:
- Given 50 parallel requests for the last free slot, when they run, then exactly one session is created and the others get "slot just taken"
```
