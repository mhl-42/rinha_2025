# Ticket Template

Save as `docs/tickets/<slug>.md`. Keep the headings and field names (English, or the Portuguese aliases at the end), because `scripts/check_tickets.py` reads them. Write the content in the user's language.

````markdown
# Tickets: <name>

PRD: docs/prd/<slug>.md
Design: docs/design/<slug>.md
Status: draft
Date: YYYY-MM-DD

## Definition of done
Applies to every ticket:
- Tests for the acceptance criteria pass in CI; lint passes
- No personal field outside name and e-mail (RNF-01): the schema test passes
- Every new entry point (view, route, screen, or command of a command-line program) has a permission test per role, which checks that the data is unchanged when the role is refused (RNF-04). The ticket names its entry points in *Notes*.

## Tickets

### T-01: Spike: reminder e-mails reach the inbox
Type: spike
Serves: S1, RF-06
Depends on: none
Size: S
Mode: HITL
Acceptance criteria:
- 20 test sends from the clinic domain, at least 18 land in the inbox (exit criterion of S1)
Notes: Timebox 1 day. If it fails, revisit T-08.

### T-02: Walking skeleton
Type: skeleton
Serves: none
Depends on: none
Size: M
Mode: HITL
Acceptance criteria:
- Given a push to main, when CI passes, then the app is deployed to staging and the health page answers 200
Notes: Repository, CI, staging on the host chosen in docs/adr/0003-hosting.md.

### T-03: Patient books a free slot
Type: feature
Serves: RF-02, RF-03
Depends on: T-02
Size: M
Mode: AFK
Touches: agenda/sessions.py, web/booking.py, tests/test_booking.py
Acceptance criteria:
- Given a free slot, when the patient confirms, then the session appears in "my sessions" and the slot is no longer free
- Given the slot was taken meanwhile, when the patient confirms, then they see "slot just taken" and no session is created
Notes: Components agenda and patient_web; entity Session.

## Open questions
None
````

## Field values

- **ID:** `T-NN`, unique, in build order.
- **Type:** `spike`, `skeleton`, `feature`, `nfr`, `chore` (`spike`, `esqueleto`, `funcionalidade`, `rnf`, `tarefa`).
  - `spike` serves a design spike id (`S1`).
  - `feature` serves at least one FR.
  - `nfr` serves at least one NFR.
  - `chore` is setup work that a later ticket needs (a data import tool, seed data). Use it rarely.
- **Serves:** PRD ids (`RF-03`, `RNF-02`, ranges such as `RF-02 a RF-04`), design spike ids (`S1`), or `none` for the skeleton and chores.
- **Depends on:** earlier ticket ids, or `none`.
- **Size:** `S` (up to half a day) or `M` (up to two days). `L` / `G` fails: split the ticket.
- **Mode:** `AFK` (an agent can finish it alone) or `HITL` (needs a person).
- **Acceptance criteria:** at least one bullet. For `feature` and `nfr` tickets, at least one bullet in Given/When/Then (Dado/Quando/Então). For a spike, the exit criterion.
- **Touches:** optional. The files the ticket expects to change, separated by commas, with an optional note in parentheses (`pdv/storage.py (migration)`). The checker warns when two tickets with no dependency between them name the same file. Put it before *Acceptance criteria*.
- **Notes:** optional. Components, entities, ADRs.
- **Status:** optional. `todo` (default), `doing`, `done` or `blocked`. `factory-implement` sets it while it builds the ticket. `done` unblocks the tickets that depend on it.

## Portuguese aliases

Headings: `Definição de pronto`, `Tickets`, `Perguntas em aberto`. Header: `PRD:`, `Design:` or `Desenho:`. Fields: `Tipo`, `Atende`, `Depende de`, `Tamanho` (`P`, `M`, `G`), `Modo`, `Critérios de aceite`, `Toca`, `Notas`. `none` = `nenhum` / `nenhuma`.
