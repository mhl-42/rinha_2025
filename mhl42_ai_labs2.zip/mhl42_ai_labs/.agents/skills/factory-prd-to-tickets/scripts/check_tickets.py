# /// script
# requires-python = ">=3.10"
# ///
"""Quality gate for a backlog written from references/ticket-template.md.

Checks that the PRD and design are confirmed, every PRD functional requirement is served by a
feature ticket, every NFR is in a ticket or the definition of done, every design spike has a
spike ticket, a walking skeleton comes before the features, dependencies point to earlier
tickets, sizes are S or M, and acceptance criteria are present. A HITL ticket whose criterion is a measure
(minutes, a percentage, p95, "at least N") must say what is recorded, or it gets a warning. The optional "Touches:" field lists the
files a ticket expects to change; two tickets that can run at the same time and name the same file get a
warning (they would conflict at merge). When the design's 'Platforms:' header names a user interface
(web, mobile, desktop, tui, cli or chat), the UI spec (docs/ux/<design slug>.md, beside docs/design/) must exist and be confirmed.

Usage:
  python check_tickets.py docs/tickets/<slug>.md

Exit codes:
  0 = PASS
  1 = FAIL           fix the listed items
  2 = NEEDS-ANSWERS  open questions remain
  3 = usage error
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

SECTIONS = {
    "dod": ("definition of done", "definição de pronto", "definicao de pronto"),
    "tickets": ("tickets",),
    "open_questions": ("open questions", "perguntas em aberto"),
}
FIELDS = {
    "type": ("type", "tipo"),
    "serves": ("serves", "atende"),
    "depends": ("depends on", "depende de"),
    "size": ("size", "tamanho"),
    "mode": ("mode", "modo"),
    "criteria": ("acceptance criteria", "critérios de aceite", "criterios de aceite"),
    "touches": ("touches", "toca"),
    "notes": ("notes", "notas"),
    "issue": ("issue",),
    "status": ("status", "estado"),
}
STATUSES = {"todo", "doing", "done", "blocked", "a fazer", "fazendo", "feito", "bloqueado"}
TYPES = {
    "spike": "spike",
    "skeleton": "skeleton",
    "esqueleto": "skeleton",
    "feature": "feature",
    "funcionalidade": "feature",
    "nfr": "nfr",
    "rnf": "nfr",
    "chore": "chore",
    "tarefa": "chore",
}
SIZES = {"s": "S", "p": "S", "m": "M", "l": "L", "g": "L"}
MODES = {"afk", "hitl"}
NONE_VALUES = {"none", "nenhum", "nenhuma", "n/a", "-", "—"}
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
TICKET_RE = re.compile(r"^###\s+(T-\d+)\s*[:—–-]\s*(.+?)\s*$", re.MULTILINE)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
PLACEHOLDER_RE = re.compile(r"(?-i:\bTBD\b|\bTODO\b)|\?\?\?|\ba definir\b|<[^>!\n]+>", re.IGNORECASE)
REQ_RE = re.compile(r"\b(FR|RF|NFR|RNF)-(\d+)\b", re.IGNORECASE)
RANGE_RE = re.compile(
    r"\b(FR|RF|NFR|RNF)-(\d+)\s*(?:–|—|-|to|a|até|ate)\s*(?:FR|RF|NFR|RNF)-(\d+)\b",
    re.IGNORECASE,
)
SPIKE_ID_RE = re.compile(r"\bS(\d+)\b")
OTHER_ID_RE = re.compile(r"\b([MA]\d+)\b")
TICKET_ID_RE = re.compile(r"\bT-(\d+)\b")
MEASURE_RE = re.compile(
    r"\b\d+(?:[.,]\d+)?\s*(?:min|minutes?|minutos?|h|hours?|horas?|s|ms|seconds?|segundos?|%)(?!\w)"
    r"|\bp\d{2}\b|\b\d+\s+(?:of|de)\s+\d+\b|\b(?:at least|pelo menos|under|em menos de|no more than)\s+\d+",
    re.IGNORECASE,
)
RECORD_RE = re.compile(r"\b(record\w*|registr\w*|anot\w*|log(?:ged)?|measured|medid\w+|informe\w*)\b", re.IGNORECASE)
GWT_RE = re.compile(
    r"\b(given|dado|dada|dados|dadas)\b.*\b(when|quando)\b.*\b(then|então|entao)\b",
    re.IGNORECASE,
)


@dataclass
class Ticket:
    tid: str
    title: str
    fields: dict[str, str] = field(default_factory=dict)
    criteria: list[str] = field(default_factory=list)
    line: int = 0


def kind(prefix: str) -> str:
    return "NFR" if prefix.upper() in ("NFR", "RNF") else "FR"


def req_ids(text: str) -> set[tuple[str, int]]:
    ids = {(kind(p), int(n)) for p, n in REQ_RE.findall(text)}
    for p, start, end in RANGE_RE.findall(text):
        ids |= {(kind(p), n) for n in range(int(start), int(end) + 1)}
    return ids


def label(rid: tuple[str, int], style: dict[str, str]) -> str:
    return f"{style.get(rid[0], rid[0])}-{rid[1]:02d}"


def sections_of(text: str) -> dict[str, str]:
    lookup = {alias: key for key, aliases in SECTIONS.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def header(text: str, *labels: str) -> str:
    for name in labels:
        match = re.search(rf"^\s*{name}\s*:\s*(.*)$", text, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return ""


def find(path_text: str, base: Path) -> Path | None:
    for candidate in [
        Path(path_text),
        base.parent / path_text,
        *(p / path_text for p in base.resolve().parents),
    ]:
        if candidate.is_file():
            return candidate
    return None


def touched_files(value: str) -> set[str]:
    """The paths in a Touches line: comma-separated, a trailing "(note)" dropped, slashes normalized."""
    paths = (re.sub(r"\([^)]*\)", "", part).strip().replace("\\", "/").lower() for part in value.split(","))
    return {path for path in paths if path and not is_none(path)}


def ancestors(tid: str, deps: dict[str, list[str]]) -> set[str]:
    found: set[str] = set()
    stack = list(deps.get(tid, []))
    while stack:
        node = stack.pop()
        if node not in found:
            found.add(node)
            stack.extend(deps.get(node, []))
    return found


def is_none(value: str) -> bool:
    return value.strip().strip(".").lower() in NONE_VALUES


def confirmed(text: str) -> bool:
    return bool(re.search(r"^status:\s*(confirmed|confirmado)\b", text, re.IGNORECASE | re.MULTILINE))


# The user interfaces a product can have (the same list as check_ux.py, check_design.py and the ticket server's
# factory_next; a test keeps them equal).
INTERFACES = {"web", "mobile", "desktop", "tui", "cli", "chat"}


def check_ui_spec(design: str, design_path: Path) -> list[str]:
    """A product with a user interface gets its UI spec (factory-ui-design) before the tickets."""
    platforms = {p.strip().lower() for p in header(design, "platforms", "plataformas").split(",") if p.strip()}
    screens = sorted(platforms & INTERFACES)
    if not screens:
        return []
    spec = design_path.resolve().parent.parent / "ux" / design_path.name
    shown = f"docs/ux/{design_path.name}"
    if not spec.is_file():
        return [(f"the design has a user interface (Platforms: {', '.join(screens)}) but {shown} does not exist: "
                 "design it with factory-ui-design first")]
    if not confirmed(spec.read_text(encoding="utf-8")):
        return [f"{shown} is not 'Status: confirmed'; confirm it (factory-ui-design) first"]
    return []


def parse_tickets(text: str) -> list[Ticket]:
    lookup = {alias: key for key, aliases in FIELDS.items() for alias in aliases}
    matches = list(TICKET_RE.finditer(text))
    tickets = []
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        next_heading = HEADING_RE.search(text, match.end(), end)
        body = COMMENT_RE.sub("", text[match.end() : next_heading.start() if next_heading else end])
        ticket = Ticket(
            match.group(1).upper(),
            match.group(2),
            line=text.count("\n", 0, match.start()) + 1,
        )
        current = ""
        for raw in body.splitlines():
            line = raw.strip()
            field_match = re.match(r"^([^:]{2,30}):\s*(.*)$", line)
            if field_match and field_match.group(1).strip().lower() in lookup:
                current = lookup[field_match.group(1).strip().lower()]
                ticket.fields[current] = field_match.group(2).strip()
            elif current == "criteria" and re.match(r"^[-*]\s+\S", line):
                ticket.criteria.append(line[1:].strip())
            elif current == "notes" and line:
                ticket.fields["notes"] += " " + line
        tickets.append(ticket)
    return tickets


def check(path: Path) -> tuple[list[str], list[str], list[str]]:
    failures: list[str] = []
    pending: list[str] = []
    warnings: list[str] = []
    text = path.read_text(encoding="utf-8")
    sections = sections_of(text)

    # PRD and design
    prd_fr: set[tuple[str, int]] = set()
    prd_nfr: set[tuple[str, int]] = set()
    prd_other: set[str] = set()
    design_spikes: set[int] = set()
    style = {"FR": "FR", "NFR": "NFR"}
    prd_text = header(text, "prd")
    prd_path = find(prd_text, path) if prd_text else None
    if not prd_text:
        failures.append("header: missing 'PRD: <path>'")
    elif prd_path is None:
        failures.append(f"header: PRD not found at {prd_text}")
    else:
        prd = prd_path.read_text(encoding="utf-8")
        if not confirmed(prd):
            failures.append("the PRD is not 'Status: confirmed'; confirm it (factory-prd-writer) first")
        for prefix, number in re.findall(r"^###\s+(FR|RF)-(\d+)", prd, re.IGNORECASE | re.MULTILINE):
            prd_fr.add(("FR", int(number)))
            style["FR"] = prefix.upper()
        for prefix, number in re.findall(r"^\|\s*(NFR|RNF)-(\d+)\s*\|", prd, re.IGNORECASE | re.MULTILINE):
            prd_nfr.add(("NFR", int(number)))
            style["NFR"] = prefix.upper()
        prd_other = set(re.findall(r"^\|\s*([MA]\d+)\s*\|", prd, re.MULTILINE))

    design_text = header(text, "design", "desenho")
    design_path = find(design_text, path) if design_text else None
    if not design_text:
        failures.append("header: missing 'Design: <path>'")
    elif design_path is None:
        failures.append(f"header: design not found at {design_text}")
    else:
        design = design_path.read_text(encoding="utf-8")
        if not confirmed(design):
            failures.append("the design is not 'Status: confirmed'; confirm it (factory-tech-design) first")
        design_prd = find(header(design, "prd"), design_path) if header(design, "prd") else None
        if prd_path is not None and (design_prd is None or design_prd.resolve() != prd_path.resolve()):
            failures.append("the design's 'PRD:' header points to a different PRD than this file")
        design_spikes = {int(n) for n in re.findall(r"^\|\s*S(\d+)\s*\|", design, re.MULTILINE)}
        failures += check_ui_spec(design, design_path)

    for key, aliases in SECTIONS.items():
        if key not in sections:
            failures.append(f"missing section '## {aliases[0].capitalize()}'")
    if not sections.get("dod"):
        failures.append("section 'definition of done' is empty")

    visible = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    for match in PLACEHOLDER_RE.finditer(visible):
        failures.append(f"placeholder {match.group(0)!r} on line {visible.count(chr(10), 0, match.start()) + 1}")

    def check_refs(value: str, where: str) -> set[tuple[str, int]]:
        ids = req_ids(value)
        if prd_path is not None:
            for rid in sorted(ids - prd_fr - prd_nfr):
                failures.append(f"{where}: {label(rid, style)} does not exist in the PRD")
            for other in OTHER_ID_RE.findall(value):
                if other not in prd_other:
                    failures.append(f"{where}: {other} does not exist in the PRD")
        if design_path is not None:
            for number in SPIKE_ID_RE.findall(value):
                if int(number) not in design_spikes:
                    failures.append(f"{where}: S{number} is not a spike in the design")
        return ids

    # Tickets
    tickets = parse_tickets(text)
    if "tickets" in sections and not tickets:
        failures.append("no tickets found (headings must be '### T-NN: title')")
    position: dict[str, int] = {}
    for index, ticket in enumerate(tickets):
        if ticket.tid in position:
            failures.append(f"{ticket.tid}: duplicate id")
        position.setdefault(ticket.tid, index)

    fr_served: set[tuple[str, int]] = set()
    nfr_served: set[tuple[str, int]] = set()
    spikes_ticketed: set[int] = set()
    types: dict[str, str] = {}
    deps: dict[str, list[str]] = {}
    for ticket in tickets:
        where = f"{ticket.tid} (line {ticket.line})"
        for name in ("type", "serves", "depends", "size", "mode"):
            if not ticket.fields.get(name):
                failures.append(f"{where}: missing '{FIELDS[name][0].capitalize()}:'")
        ttype = TYPES.get(ticket.fields.get("type", "").strip().lower(), "")
        if ticket.fields.get("type") and not ttype:
            failures.append(f"{where}: Type must be spike, skeleton, feature, nfr or chore")
        types[ticket.tid] = ttype

        serves = ticket.fields.get("serves", "")
        ids = check_refs(serves, where)
        frs = {i for i in ids if i[0] == "FR"}
        spike_ids = {int(n) for n in SPIKE_ID_RE.findall(serves)}
        nfr_served |= {i for i in ids if i[0] == "NFR"}
        if ttype == "feature":
            if not frs:
                failures.append(f"{where}: a feature ticket must serve at least one FR (no new scope)")
            fr_served |= frs
            if len(frs) > 3:
                failures.append(
                    f"{where}: serves {len(frs)} FRs; a slice serves one to three, split it (references/slicing.md)"
                )
        elif ttype == "nfr" and not ids - frs:
            failures.append(f"{where}: an nfr ticket must serve at least one NFR")
        elif ttype == "spike":
            if not spike_ids:
                failures.append(f"{where}: a spike ticket must serve a design spike id (S1, S2...)")
            spikes_ticketed |= spike_ids

        size = SIZES.get(ticket.fields.get("size", "").strip().lower(), "")
        if ticket.fields.get("size") and not size:
            failures.append(f"{where}: Size must be S or M")
        elif size == "L":
            failures.append(f"{where}: size L, split it into tickets of size S or M (references/slicing.md)")

        mode = ticket.fields.get("mode", "").strip().lower()
        if mode and mode not in MODES:
            failures.append(f"{where}: Mode must be AFK or HITL")

        # Optional progress field, set by factory-implement; absent means todo.
        status = ticket.fields.get("status", "").strip().lower()
        if status and status not in STATUSES:
            failures.append(f"{where}: Status must be todo, doing, done or blocked")

        if not ticket.criteria:
            failures.append(f"{where}: no acceptance criteria (bullets under 'Acceptance criteria:')")
        elif ttype in ("feature", "nfr") and not any(GWT_RE.search(c) for c in ticket.criteria):
            failures.append(f"{where}: acceptance criteria need at least one Given/When/Then (Dado/Quando/Então)")
        if ticket.fields.get("mode", "").strip().lower() == "hitl":
            evidence_text = " ".join([*ticket.criteria, ticket.fields.get("notes", "")])
            if any(MEASURE_RE.search(c) for c in ticket.criteria) and not RECORD_RE.search(evidence_text):
                warnings.append(
                    f"{ticket.tid} is HITL with a measured criterion but does not say what is recorded "
                    "(the figure, who ran it, on which system); 'ok' would be the only possible answer "
                    "(references/slicing.md)"
                )
        if len(ticket.criteria) > 6:
            warnings.append(f"{ticket.tid} has {len(ticket.criteria)} acceptance criteria: consider splitting")

        depends = ticket.fields.get("depends", "")
        dep_ids = [] if is_none(depends) else [f"T-{n}" for n in TICKET_ID_RE.findall(depends)]
        if depends and not is_none(depends) and not dep_ids:
            failures.append(f"{where}: Depends on must list ticket ids (T-NN) or none")
        normalized = []
        for dep in dep_ids:
            match = next((t for t in position if int(t[2:]) == int(dep[2:])), None)
            if match is None:
                failures.append(f"{where}: depends on {dep}, which does not exist")
            elif position[match] >= position[ticket.tid]:
                failures.append(
                    f"{where}: depends on {match}, which comes later; order tickets so dependencies come first"
                )
            else:
                normalized.append(match)
        deps[ticket.tid] = normalized

    # Coverage
    for rid in sorted(prd_fr - fr_served):
        failures.append(f"{label(rid, style)} is not served by any feature ticket")
    dod_nfr = check_refs(sections.get("dod", ""), "definition of done")
    for rid in sorted(prd_nfr - nfr_served - dod_nfr):
        failures.append(f"{label(rid, style)} is in no ticket and not in the definition of done")
    for number in sorted(design_spikes - spikes_ticketed):
        failures.append(f"design spike S{number} has no spike ticket")

    # Skeleton first
    skeletons = [t for t, k in types.items() if k == "skeleton"]
    if tickets and not skeletons:
        failures.append("no walking skeleton ticket (Type: skeleton)")

    def reaches_skeleton(tid: str, seen: set[str]) -> bool:
        if types.get(tid) == "skeleton":
            return True
        seen.add(tid)
        return any(reaches_skeleton(d, seen) for d in deps.get(tid, []) if d not in seen)

    if skeletons:
        for tid, ttype in types.items():
            if ttype in ("feature", "nfr") and not reaches_skeleton(tid, set()):
                failures.append(
                    f"{tid}: must depend on the walking skeleton ({skeletons[0]}), directly or through another ticket"
                )
    first_feature = next((i for i, t in enumerate(tickets) if types[t.tid] == "feature"), None)
    if first_feature is not None:
        for index, ticket in enumerate(tickets):
            if types[ticket.tid] in ("spike", "skeleton") and index > first_feature:
                warnings.append(
                    f"{ticket.tid} ({types[ticket.tid]}) comes after feature tickets; spikes and skeleton go first"
                )

    # Hot files: two tickets with no dependency between them that name the same file
    touches = {t.tid: touched_files(t.fields.get("touches", "")) for t in tickets}
    for i, first in enumerate(tickets):
        for second in tickets[i + 1 :]:
            shared = touches[first.tid] & touches[second.tid]
            if shared and first.tid not in ancestors(second.tid, deps) and second.tid not in ancestors(first.tid, deps):
                warnings.append(
                    f"{first.tid} and {second.tid} both touch {', '.join(sorted(shared))} and neither depends on "
                    "the other: run them one at a time, or declare the dependency (references/slicing.md)"
                )

    body = sections.get("open_questions", "")
    if body and not is_none(body):
        pending += [f"open question: {line.strip().lstrip('-* ')}" for line in body.splitlines() if line.strip()]
    return failures, pending, warnings


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    failures, pending, warnings = check(Path(sys.argv[1]))
    for warning in warnings:
        print(f"warning: {warning}")
    if failures:
        print("FAIL")
        for item in dict.fromkeys(failures):
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
