# /// script
# requires-python = ">=3.10"
# ///
"""Export a confirmed tickets file to GitHub issues with the GitHub CLI (gh).

Without --apply it only prints what it would create. With --apply it creates the issues in
ticket order, replaces T-NN dependencies with issue numbers, and writes 'Issue: #<n>' under
each ticket heading so a second run skips tickets that already have an issue.

Usage:
  python export_github.py docs/tickets/<slug>.md --repo OWNER/REPO [--labels] [--apply]

Exit codes:
  0 = done (or preview printed)
  1 = gh failed, or the file is not confirmed / not PASS
  3 = usage error
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from check_tickets import (
    SIZES,
    TICKET_ID_RE,
    TYPES,
    Ticket,
    check,
    confirmed,
    parse_tickets,
)

LABEL_COLORS = {"type": "1d76db", "size": "fbca04", "mode": "5319e7"}


def labels_of(ticket: Ticket) -> list[str]:
    return [
        f"type:{TYPES.get(ticket.fields.get('type', '').strip().lower(), 'feature')}",
        f"size:{SIZES.get(ticket.fields.get('size', '').strip().lower(), 'M')}",
        f"mode:{ticket.fields.get('mode', 'AFK').strip().lower()}",
    ]


def body_of(ticket: Ticket, issues: dict[str, str], source: Path) -> str:
    depends = ticket.fields.get("depends", "")
    for tid, number in issues.items():
        depends = re.sub(rf"\b{tid}\b", f"{tid} ({number})", depends)
    lines = [
        f"**Serves:** {ticket.fields.get('serves', '')}",
        f"**Depends on:** {depends}",
        f"**Size:** {ticket.fields.get('size', '')} · **Mode:** {ticket.fields.get('mode', '')}",
        "",
        "### Acceptance criteria",
        *(f"- [ ] {c}" for c in ticket.criteria),
    ]
    if ticket.fields.get("notes"):
        lines += ["", "### Notes", ticket.fields["notes"]]
    lines += ["", f"_From `{source.as_posix()}` ({ticket.tid})._"]
    return "\n".join(lines)


def gh(args: list[str]) -> str:
    proc = subprocess.run(["gh", *args], check=False, capture_output=True, text=True, encoding="utf-8")
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or proc.stdout.strip())
    return proc.stdout.strip()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("tickets", type=Path)
    parser.add_argument("--repo", required=True, help="OWNER/REPO")
    parser.add_argument("--labels", action="store_true", help="create the type/size/mode labels first")
    parser.add_argument("--apply", action="store_true", help="create the issues (default: preview only)")
    args = parser.parse_args()
    if not args.tickets.is_file():
        print(f"not found: {args.tickets}", file=sys.stderr)
        return 3

    text = args.tickets.read_text(encoding="utf-8")
    if not confirmed(text):
        print("the tickets file is not 'Status: confirmed'; confirm it first")
        return 1
    failures, pending, _ = check(args.tickets)
    if failures or pending:
        print("check_tickets.py does not PASS; fix it first")
        return 1

    tickets = parse_tickets(text)
    issues = {t.tid: t.fields["issue"] for t in tickets if t.fields.get("issue")}
    todo = [t for t in tickets if t.tid not in issues]
    if not args.apply:
        print(f"Preview: {len(todo)} issues to create in {args.repo} ({len(issues)} already exported)")
        for t in todo:
            print(f"  {t.tid}: {t.title}  [{', '.join(labels_of(t))}]")
        print("Nothing was created. Run again with --apply after the user confirms.")
        return 0

    if shutil.which("gh") is None:
        print("gh (GitHub CLI) is not installed")
        return 1
    try:
        if args.labels:
            for name in sorted({lab for t in todo for lab in labels_of(t)}):
                gh(
                    [
                        "label",
                        "create",
                        name,
                        "--repo",
                        args.repo,
                        "--force",
                        "--color",
                        LABEL_COLORS[name.split(":")[0]],
                    ]
                )
        for t in todo:
            url = gh(
                [
                    "issue",
                    "create",
                    "--repo",
                    args.repo,
                    "--title",
                    f"{t.tid}: {t.title}",
                    "--body",
                    body_of(t, issues, args.tickets),
                    *[arg for lab in labels_of(t) for arg in ("--label", lab)],
                ]
            )
            number = "#" + url.rstrip("/").rsplit("/", 1)[-1]
            issues[t.tid] = number
            text = re.sub(
                rf"^(###\s+{t.tid}\s*[:—–-].*)$",
                rf"\1\nIssue: {number}",
                text,
                count=1,
                flags=re.MULTILINE,
            )
            args.tickets.write_text(text, encoding="utf-8")
            print(f"{t.tid} → {url}")
    except RuntimeError as exc:
        print(f"gh failed: {exc}")
        return 1
    unresolved = {f"T-{n}" for t in todo for n in TICKET_ID_RE.findall(t.fields.get("depends", ""))} - set(issues)
    if unresolved:
        print(f"warning: dependencies without an issue: {', '.join(sorted(unresolved))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
