# factory-prd-writer

Step 3 of the PRD flow. Writes `docs/prd/<slug>.md` from a confirmed PRD brief (and its synthesis, when there is one) and checks it with a quality gate.

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief + gate → factory-grilling (if needed) → 3 factory-prd-writer ─┬─ FAIL → fix
                                                                                           ├─ NEEDS-ANSWERS → ask the user (update brief if scope changes)
                                                                                           └─ PASS → confirm → tickets
```

## What it enforces

- **Traceability.** Every requirement, metric, NFR, and decision cites the brief (`brief:scope#2`) or the synthesis (`E3`, `C1`), and the checker verifies that each reference exists.
- **Coverage.** Every brief Scope bullet has at least one functional requirement, and every success metric has a metric row.
- **No invented scope.** Features that are not in the brief go to *Open questions*. They enter the PRD only after the brief is changed.
- **Testable criteria.** Given/When/Then, without vague words such as "fast", "easy" or "correctly" unless there is a number.
- **Honest priorities.** MoSCoW, with a warning when more than 60% of the requirements are Must.
- **Assumptions with validation.** A low-confidence assumption must say which requirement or milestone it blocks.

## Files

```
factory-prd-writer/
├── SKILL.md
├── references/
│   ├── prd-template.md      # Template, reference syntax, field values, Portuguese aliases
│   └── requirements.md      # How to write FRs, criteria, NFRs, priorities, assumptions
├── scripts/
│   └── check_prd.py         # Exit 0 PASS, 1 FAIL, 2 NEEDS-ANSWERS
└── evals/
    ├── evals.json
    ├── trigger_queries.json
    (fixtures: ../../evals/fixtures/)
```

## Run the checker

```bash
python scripts/check_prd.py docs/prd/<slug>.md
```

It reads the brief and the synthesis named in the PRD header (`Brief:` / `Synthesis:`).
