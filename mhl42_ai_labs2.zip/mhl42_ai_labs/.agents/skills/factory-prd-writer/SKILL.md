---
name: factory-prd-writer
description: Use this skill to write a PRD (product requirements document) from a confirmed PRD brief, its domain model and its idea synthesis — numbered functional requirements with MoSCoW priority and Given/When/Then acceptance criteria, measurable non-functional requirements, metrics, assumptions with a validation plan — every item traced back to the brief and to the use cases and business rules of the domain model, then checked by a quality gate. Triggers on "write the PRD", "generate the requirements document", "turn the brief into a PRD", "gera o PRD". Not for interviewing a vague idea (use factory-idea-interview), organizing raw answers (use factory-idea-synthesis), discovering business rules (use factory-domain-model), choosing the stack or architecture (use factory-tech-design), or breaking a finished PRD into tickets (use factory-prd-to-tickets).
license: MIT
compatibility: scripts/check_prd.py needs Python 3.10+ (no dependencies). Expects the brief format of factory-idea-interview, the domain model of factory-domain-model and, optionally, the synthesis format of factory-idea-synthesis.
metadata:
  author: mhl42
  version: "1.3.1"
---

# PRD Writer

Write the PRD from a **confirmed brief** and a **confirmed domain model**. The PRD adds structure, not scope: it turns each brief item, use case and business rule into requirements a team can build and test, and every requirement points back to where it came from.

This is step 3 of the PRD flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief + gate → factory-grilling (if needed) → 2b factory-domain-model → 3 factory-prd-writer → tech design → tickets
```

Write the PRD in the user's language.

## Before you start

Check the inputs; do not write a PRD from a conversation summary.

- **Brief:** `docs/prd-brief/<slug>.md` with `Status: confirmed`, which has passed its quality gate (`check_brief.py` → `PASS`). If it fails, or there is no brief, stop and send the user to factory-idea-interview.
- **Domain model:** `docs/domain/<slug>.md` with `Status: confirmed` and `READY` from `check_domain.py`. If there is none, stop and send the user to factory-domain-model, unless the brief's *Depth* skips it (only possible for a `small` product with no complexity trigger). Then write the PRD from the brief alone; the gate checks that the skip is in the brief.
- **Synthesis** (optional): `docs/prd-brief/<slug>.synthesis.md` with `READY`. When present, cite its evidence (`E3`) and resolved contradictions (`C1`).

## Workflow

```
- [ ] 1. Inputs checked (brief PASS, domain model READY and confirmed, synthesis READY if present)
- [ ] 2. PRD drafted from the template, every item traced
- [ ] 3. check_prd.py → PASS
- [ ] 4. Self-review against references/requirements.md
- [ ] 5. User confirms; status set to confirmed
```

### 2. Draft
Copy [references/prd-template.md](references/prd-template.md) to `docs/prd/<slug>.md` and fill it. [references/requirements.md](references/requirements.md) has the rules and examples. Read it before writing requirements.

- **One or more functional requirements per brief Scope bullet.** Each one has an ID (`FR-01`), a MoSCoW priority, a user story, at least one Given/When/Then acceptance criterion, and a `Source` with references such as `brief:scope#2` or `E3`.
- **From the domain model:** every confirmed use case becomes one or more FRs, citing it (`UC-03`). Its main flow gives the main criterion, and each alternative or exception flow gives a criterion of its own. Every confirmed rule (`BR-07`) is cited by the FR or NFR it constrains, and its example and counterexample become Given/When/Then criteria. Cite the rule; do not copy its text. The domain model stays the one place where the rule is written, so a change reaches every requirement through the ID. Put the domain path in the header (`Domain: docs/domain/<slug>.md`).
- **Not confirmed is not a requirement.** An `inferred` or `proposed` item, or a `pending` proposal, cannot be an FR's source: go back to factory-domain-model. A `rejected` item can be cited in *Out of scope*. Every `deferred` question of the domain model appears under *Assumptions* or *Risks*, with its impact.
- **Metrics** come from the brief's success metrics, one row per brief metric, with baseline, target, and deadline.
- **Constraints** become non-functional requirements with a measurable threshold.
- **Assumptions:** every hypothesis from the brief or synthesis gets a validation and the requirement or milestone it must happen **before**. A low-confidence assumption that the value proposition depends on blocks the Must requirements that rely on it.
- **Out of scope** is copied from the brief and extended only with items the user confirmed.

**Do not invent scope or rules.** If a requirement or a criterion seems necessary but nothing in the brief or the domain model supports it (login, notifications, admin panel, export, a limit, a format, a boundary like "expires today is still valid"...), do not add it. Put it under *Open questions* and ask the user. If they accept it, add it to the brief first, then to the PRD.

### 3. Check
```bash
python <this-skill-dir>/scripts/check_prd.py docs/prd/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: an untraced requirement, a brief scope item or metric with no coverage, a vague or non-Given/When/Then criterion, a missing priority, placeholders, more than 60% Must without a priority note (ask the user). |
| `NEEDS-ANSWERS` | 2 | *Open questions* is not empty. Ask them in one numbered round (up to 5), each with a recommended answer, together with the priority question if there is one. Update the brief if an answer changes scope, then the PRD. |
| `PASS` | 0 | Self-review, then confirmation. |

The checker resolves `brief:` references against the brief file named in the PRD header, `E`/`C` references against the synthesis, and `UC`/`BR`/`DQ` references against the domain model. It also verifies that every brief Scope bullet and every success metric is covered, that every confirmed use case and rule is covered by an FR or NFR or listed in *Out of scope*, that no unconfirmed item is cited, and that every deferred question is cited.

### 4. Self-review
The checker cannot judge meaning. Before showing the PRD, check that:
- each acceptance criterion could become an automated test as written;
- no requirement describes the implementation ("use Redis", "a React modal") unless the brief has that as a constraint;
- *Context and problem* describes the pain and its cost only. The solution belongs in the requirements;
- priorities are honest: with 5 or more requirements, if more than 60% are Must, the checker fails. Ask the user which ones could wait, in the same round as the other questions. If they keep them, record their reason, in their words, as `Priority note: ...` at the top of *Functional requirements*. If they do not answer, leave the question under *Open questions* and do not write the note yourself: a reason the agent invents is not a reason.

### 5. Confirm
Show the requirement list (ID, title, priority) and the assumptions that block work. Ask for explicit confirmation in the same message as any remaining questions, so the user answers and confirms in one reply. Then set `Status: confirmed` and offer the next step (technical design, then tickets).

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Read the inputs with `doc_read`, or single ids with `item_get` (the definition and everything that cites it), instead of opening the files. `project_manifest` shows whether the brief and the domain model are confirmed and which items are still open.
- Write with `doc_write(project, "prd", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run.
- Confirm with `doc_confirm(project, "prd", <slug>, revision, user_answer)` after the user's yes, passing their reply verbatim, instead of editing the Status line. Show them the revision you confirm. It refuses while an input is not confirmed, the document cites an item that changed after it (`stale` in the manifest: rewrite the citing text, or `stale_resolve` with a note when it still holds), or the gate fails on the confirmed text; read the refusal to the user.

## Gotchas

- Agents pad PRDs with the features every app has. The traceability rule exists to stop that: a requirement whose only justification is "apps usually have it" has no `Source`.
- "The system should be fast and easy to use" is not a requirement. Ask what fast means (`p95 < 300 ms`) and who finds it easy (`a receptionist books in under 3 clicks`).
- Acceptance criteria describe observable behavior from the outside. "The booking is saved in the bookings table" is an implementation check. "Then the room shows as unavailable for that slot" is a behavior.
- *Context and problem* is not a pitch. "The digest replaces the manual sweep" belongs in the requirements, not the problem.
- Copy decisions from the brief; do not reopen them. A PRD that changes a settled decision without asking undoes the factory-grilling.
- A criterion that states a rule nobody gave is invented scope. In `supermercado-pdv`, RF-10 decided "a lot that expires today is still sellable" with no source in the brief or the interview, and the rule that supplier names ignore case was only asked in the review of T-06, after the PRD and the design were confirmed (commit 3db6fa8). Rules go to the domain model first, then the PRD cites them.
- One requirement, one behavior. "Users can book, cancel and reschedule" is three requirements with different acceptance criteria.
