# PRD Template

Save as `docs/prd/<slug>.md`. Keep the headings, the `FR-` heading format, the field labels, and the table columns as they are (English, or the Portuguese aliases listed at the end), because `scripts/check_prd.py` reads them. Write the content in the user's language.

````markdown
# PRD: <name>

Brief: docs/prd-brief/<slug>.md
Domain: docs/domain/<slug>.md
Synthesis: docs/prd-brief/<slug>.synthesis.md
Status: draft
Date: YYYY-MM-DD

## Context and problem
<!-- From the brief's Problem and the value proposition; cite sources. -->

## Users
<!-- Personas from the brief's Target users: role, situation, goal. -->

## Goals and metrics
| ID | Metric | Baseline | Target | Deadline | Source |
|----|--------|----------|--------|----------|--------|
| M1 | Lost or double bookings per week | 6 | 0 | 2026-12-31 | brief:metrics#1 |

## Functional requirements
<!-- If more than 60% are Must after asking the user: Priority note: <the user's reason> -->

### FR-01: Patient books an available slot
Priority: Must
Source: brief:scope#1, UC-02, BR-04, E3
Story: As a patient, I want to book a free slot myself, so that I do not have to call the clinic.
Acceptance criteria:
- Given a slot is free, when the patient confirms the booking, then the slot shows as unavailable to everyone else.
- Given two patients confirm the same slot at the same time, when both requests arrive, then exactly one booking succeeds and the other patient sees a "slot taken" message.

## Non-functional requirements
| ID | Requirement | Measure | Source |
|----|-------------|---------|--------|
| NFR-01 | Store no personal data besides name and e-mail | 0 personal fields beyond name/e-mail in the schema | brief:constraints |

## Out of scope
- Recurring bookings (brief:out-of-scope#1)

## Assumptions and validation
| ID | Assumption | Confidence | Validation | Before |
|----|------------|------------|------------|--------|
| A1 | Patients will book online if it is available | medium | Booking link for 2 weeks; target 30% of bookings | FR-01 release |

## Risks
- <risk> — <mitigation> (source)

## Decisions
- <decision> — <reason> (brief:decisions#1 / C1)

## Open questions
None
````

## Reference syntax

| Reference | Points to |
|-----------|-----------|
| `brief:<section>` | A whole section of the brief, e.g. `brief:constraints` |
| `brief:<section>#n` | The n-th bullet of that section, e.g. `brief:scope#2` |
| `E3`, `C1` | Evidence row and contradiction in the synthesis |
| `UC-02`, `BR-04` | Use case and business rule in the domain model; only `confirmed` ones as a source |
| `DQ-3` | A question the domain model `deferred`; cite it under *Assumptions* or *Risks* |

`<section>` is one of `problem`, `users`, `outcome`, `metrics`, `scope`, `out-of-scope`, `constraints`, `assumptions`, `risks`, `decisions`.

## Field values

- **Priority:** `Must`, `Should`, `Could`. Anything that is "Won't" belongs in *Out of scope*.
- **Acceptance criteria:** each bullet contains Given/When/Then (Portuguese: Dado/Quando/Então).
- **Confidence:** `low`, `medium`, `high` (`baixa`, `média`, `alta`). A `low` assumption needs a *Before*.

## Portuguese aliases

Headings: `Contexto e problema`, `Usuários`, `Objetivos e métricas`, `Requisitos funcionais`, `Requisitos não funcionais`, `Fora do escopo`, `Premissas e validação`, `Riscos`, `Decisões`, `Perguntas em aberto`. Requirement headings: `### RF-01: <título>` and `RNF-01` in the table. Labels: `Prioridade:`, `Fonte:`, `História:`, `Critérios de aceite:`, `Nota de prioridade:`. Header: `Brief:`, `Domínio:`, `Síntese:`. Domain ids: `CU-nn` and `RN-nn` are read as `UC-nn` and `BR-nn`. Columns: `Métrica`, `Linha de base`, `Meta`, `Prazo`, `Fonte`, `Requisito`, `Medida`, `Premissa`, `Confiança`, `Validação`, `Antes de`. Priorities: `Must/Should/Could` (or `Obrigatório/Desejável/Opcional`).
