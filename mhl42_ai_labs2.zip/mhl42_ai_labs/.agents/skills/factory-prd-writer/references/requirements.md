# Writing Requirements

## Contents
- Functional requirements
- From the domain model
- Acceptance criteria
- Non-functional requirements
- Priorities
- Assumptions and validation
- Traceability

## Functional requirements

One requirement describes one behavior the user can observe. Split on "and":

| Bad | Good |
|-----|------|
| FR-01: Users can book, cancel and reschedule | FR-01 book, FR-02 cancel, FR-03 reschedule, each with its own criteria |
| FR-04: The system uses WebSockets for live updates | FR-04: Availability shown to a patient is never more than 5 s old |
| FR-05: Admin dashboard | FR-05: Clinic owner sees no-shows per therapist per week (from brief:scope#4) |

The story names the user from the brief, not "the user": *As a receptionist at peak hours...*

## From the domain model

The domain model already holds the use cases, their flows and the rules with examples. The PRD turns them into requirements without copying them:

| Domain model | PRD |
|--------------|-----|
| Confirmed use case `UC-03` | One or more FRs with `Source: ..., UC-03`; the story names its actor |
| Main flow | The main Given/When/Then criterion |
| Alternative or exception flow `3a` | A criterion of its own (the refusal, the message, what stays unchanged) |
| Confirmed rule `BR-07` with its example and counterexample | Cited in the FR or NFR it constrains; the example becomes the accepted case, the counterexample the refused one |
| `deferred` question `DQ-2` | A row under *Assumptions* (with its validation) or a bullet under *Risks* |
| `rejected` item or proposal | A bullet under *Out of scope* when someone could expect it |
| `inferred` or `proposed` item, `pending` proposal | Nothing yet: it goes back to factory-domain-model |

Write the rule's ID, not its text: one place to change, many places that follow.

## Acceptance criteria

Write each criterion as Given/When/Then, from outside the system, specific enough to become a test without asking anyone.

| Bad | Why | Good |
|-----|-----|------|
| The booking works correctly | Not testable | Given a free slot, when the patient confirms, then the slot is unavailable to others |
| The page loads fast | Vague | Given 50 concurrent users, when a patient opens availability, then it renders in under 2 s (p95) |
| The booking row is inserted | Implementation | Given ..., when ..., then the receptionist sees the booking in the day view |
| Errors are handled | No behavior | Given the slot was taken meanwhile, when the patient confirms, then they see "slot taken" and three nearest free slots |

Cover, for each Must requirement: the main path, the most likely failure, and any rule from the brief (limits, permissions, concurrency).

## Non-functional requirements

Derive them from the brief's *Constraints* and from facts in the synthesis. Each needs a measure:

| Area | Example measure |
|------|-----------------|
| Performance | p95 < 300 ms for availability with 50 concurrent users |
| Availability | 99.5% monthly during clinic hours |
| Privacy / LGPD | No personal data besides name and e-mail; deletion on request within 15 days |
| Security | Only clinic staff with role `admin` can create rooms |
| Accessibility | WCAG 2.1 AA for the patient booking flow |

Do not invent numbers. If the brief has no basis for a threshold, ask (Open questions) or record the threshold as an assumption with a validation.

## Priorities

- **Must:** the release fails its success metrics without it.
- **Should:** important, but the metric can be met without it, possibly with a workaround.
- **Could:** nice to have; first to cut.

With 5 or more requirements, if more than 60% are Must, the checker fails: ask the user which ones could wait. A release where everything is Must has no priorities. If the user keeps them after seeing the list, record their reason as `Priority note: ...` under *Functional requirements*.

## Assumptions and validation

Every hypothesis from the brief's *Assumptions* or the synthesis evidence (type Hypothesis) appears in the assumptions table with:
- the **validation**: cheap, concrete, with a pass threshold ("landing page for 2 weeks; ≥ 30% of bookings online");
- **Before**: the requirement or milestone it must be validated before. If the value proposition depends on a low-confidence assumption, it blocks the Must requirements that rely on it. In that case the first milestone is the experiment, not the build.

## Traceability

Every FR, NFR, metric, decision, and out-of-scope item cites where it came from. The checker enforces these rules:
- every `brief:` reference resolves to an existing section or bullet, and every `E`/`C` reference to an existing synthesis row;
- every brief *Scope* bullet is covered by at least one FR;
- every brief *Success metrics* bullet is covered by a metric row;
- with a `Domain:` header: every confirmed use case and rule is cited by an FR or NFR (in its source or its criteria) or in *Out of scope*, no unconfirmed one is cited as a requirement, and every deferred question is cited.

A requirement nobody can trace is scope the user never asked for. Remove it, or ask the user about it under *Open questions*.
