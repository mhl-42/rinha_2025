# /// script
# requires-python = ">=3.10"
# ///
"""Quality gate for a PRD written from references/prd-template.md.

Checks structure, priorities, Given/When/Then criteria, measurable NFRs, and
traceability: every brief:/E/C reference must resolve, and every brief Scope
bullet and success metric must be covered. When the header links a domain model
('Domain: docs/domain/<slug>.md'), every UC/BR/DQ reference must resolve to an item
of that model, only confirmed use cases and rules may be cited, and every confirmed
one must be covered by a requirement or listed in Out of scope.

Usage:
  python check_prd.py docs/prd/<slug>.md

Exit codes:
  0 = PASS
  1 = FAIL           fix the listed items
  2 = NEEDS-ANSWERS  open questions remain; ask the user
  3 = usage error
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

PRD_SECTIONS = {
    "context": ("context and problem", "contexto e problema"),
    "users": ("users", "usuários", "usuarios"),
    "metrics": ("goals and metrics", "objetivos e métricas", "objetivos e metricas"),
    "functional": ("functional requirements", "requisitos funcionais"),
    "nonfunctional": ("non-functional requirements", "requisitos não funcionais", "requisitos nao funcionais"),
    "out_of_scope": ("out of scope", "fora do escopo"),
    "assumptions": ("assumptions and validation", "premissas e validação", "premissas e validacao"),
    "risks": ("risks", "riscos"),
    "decisions": ("decisions", "decisões", "decisoes"),
    "open_questions": ("open questions", "perguntas em aberto"),
}
# Brief sections, keyed by the name used in brief:<section> references.
BRIEF_SECTIONS = {
    "problem": ("problem", "problema"),
    "users": ("target users", "usuários", "usuarios", "público-alvo"),
    "outcome": ("desired outcome", "resultado esperado"),
    "metrics": ("success metrics", "métricas de sucesso", "metricas de sucesso"),
    "scope": ("scope", "escopo"),
    "out-of-scope": ("out of scope", "fora do escopo"),
    "constraints": ("constraints", "restrições", "restricoes"),
    "assumptions": ("assumptions", "premissas"),
    "risks": ("risks", "riscos"),
    "decisions": ("decisions", "decisões", "decisoes"),
}
COLUMNS = {
    "id": ("id",),
    "metric": ("metric", "métrica", "metrica"),
    "baseline": ("baseline", "linha de base"),
    "target": ("target", "meta"),
    "deadline": ("deadline", "prazo"),
    "source": ("source", "fonte"),
    "requirement": ("requirement", "requisito"),
    "measure": ("measure", "medida"),
    "assumption": ("assumption", "premissa"),
    "confidence": ("confidence", "confiança", "confianca"),
    "validation": ("validation", "validação", "validacao"),
    "before": ("before", "antes de"),
}
PRIORITIES = {"must", "should", "could", "obrigatório", "obrigatorio", "desejável", "desejavel", "opcional"}
MUST = {"must", "obrigatório", "obrigatorio"}
CONFIDENCES = {"low", "medium", "high", "baixa", "média", "media", "alta"}
LOW = {"low", "baixa"}
NONE_VALUES = {"none", "nenhuma", "nenhum", "n/a"}
VAGUE_WORDS = re.compile(
    r"\b(fast|quick(ly)?|easy|easily|simple|intuitive|user-friendly|correctly|properly|appropriately|"
    r"rápid[oa]|rapid[oa]|fácil|facil|simples|intuitiv[oa]|corretamente|adequadamente)\b",
    re.IGNORECASE,
)
GWT_RE = re.compile(r"\b(given|dad[oa]s?)\b.*\b(when|quando)\b.*\b(then|então|entao)\b", re.IGNORECASE | re.DOTALL)
FR_RE = re.compile(r"^###\s+(FR|RF)-(\d+)\s*:\s*(.*)$", re.MULTILINE | re.IGNORECASE)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
PLACEHOLDER_RE = re.compile(r"(?-i:\bTBD\b|\bTODO\b)|\?\?\?|\ba definir\b|<[^>!\n]+>", re.IGNORECASE)
BRIEF_REF_RE = re.compile(r"brief:([a-z-]+)(?:#(\d+))?", re.IGNORECASE)
SYN_REF_RE = re.compile(r"\b([EC]\d+)\b")
DOMAIN_REF_RE = re.compile(r"\b(UC|CU|BR|RN|DQ)-(\d+)\b", re.IGNORECASE)
DOMAIN_CANONICAL = {"cu": "UC", "rn": "BR"}
DOMAIN_STATUSES = {
    "confirmed": "confirmed", "confirmado": "confirmed", "confirmada": "confirmed",
    "inferred": "inferred", "inferido": "inferred", "inferida": "inferred",
    "proposed": "proposed", "proposto": "proposed", "proposta": "proposed",
    "rejected": "rejected", "rejeitado": "rejected", "rejeitada": "rejected",
    "open": "open", "aberta": "open",
    "answered": "answered", "respondida": "answered",
    "deferred": "deferred", "adiada": "deferred",
}


def domain_id(prefix: str, number: str) -> str:
    canonical = DOMAIN_CANONICAL.get(prefix.lower(), prefix.upper())
    return f"{canonical}-{int(number):02d}" if canonical in ("UC", "BR") else f"{canonical}-{int(number)}"


SKIPPED_STEP_ALIASES = {
    "domain-model": ("domain model", "domain-model", "modelo de domínio", "modelo de dominio", "factory-domain-model"),
    "synthesis": ("synthesis", "síntese", "sintese", "factory-idea-synthesis"),
    "ui-design": ("ui design", "ui-design", "telas", "factory-ui-design"),
}


def brief_skipped_steps(brief_text: str) -> set[str] | None:
    """Steps the brief's Depth section skips, or None when the brief has no Depth section (older briefs).
    The brief gate (check_brief.py) already checked that each skip is allowed for the size and triggers."""
    depth = re.search(r"^##\s+(depth|profundidade)\s*$(.*?)(?=^##\s|\Z)", brief_text,
                      re.IGNORECASE | re.MULTILINE | re.DOTALL)
    if not depth:
        return None
    line = re.search(r"^\s*(skipped steps|etapas puladas)\s*:\s*(.*)$", depth.group(2), re.IGNORECASE | re.MULTILINE)
    lookup = {alias: key for key, aliases in SKIPPED_STEP_ALIASES.items() for alias in aliases}
    skipped: set[str] = set()
    for item in (line.group(2) if line else "").split(";"):
        name = re.split(r"[(:]", item, maxsplit=1)[0].strip().lower()
        if name in lookup:
            skipped.add(lookup[name])
    return skipped


def domain_items(text: str) -> dict[str, str]:
    """Status of every use case, rule and open question in a domain model (references/domain-template.md)."""
    items: dict[str, str] = {}
    heads = list(re.finditer(r"^###\s+(UC|CU)-(\d+)\b.*$", text, re.IGNORECASE | re.MULTILINE))
    for i, match in enumerate(heads):
        block = text[match.end() : heads[i + 1].start() if i + 1 < len(heads) else len(text)]
        block = re.split(r"^##\s", block, maxsplit=1, flags=re.MULTILINE)[0]
        status = re.search(r"^\s*status\s*:\s*(\S+)", block, re.IGNORECASE | re.MULTILINE)
        items[domain_id(match.group(1), match.group(2))] = status.group(1).lower() if status else ""
    status_col: int | None = None
    for line in text.splitlines():
        if not line.strip().startswith("|"):
            status_col = None
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        lowered = [cell.lower() for cell in cells]
        if "status" in lowered:
            status_col = lowered.index("status")
            continue
        found = re.fullmatch(r"(BR|RN|DQ)-(\d+)", cells[0], re.IGNORECASE) if cells else None
        if found and status_col is not None and status_col < len(cells):
            items[domain_id(found.group(1), found.group(2))] = cells[status_col].lower()
    return {rid: DOMAIN_STATUSES.get(status, status) for rid, status in items.items()}


def field(block: str, *labels: str) -> str:
    for label in labels:
        match = re.search(rf"^\s*{label}\s*:\s*(.*)$", block, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return ""


def sections_of(text: str, spec: dict[str, tuple[str, ...]]) -> dict[str, str]:
    lookup = {alias: key for key, aliases in spec.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def bullets(body: str) -> list[str]:
    return [line.strip()[2:].strip() for line in body.splitlines() if line.strip().startswith(("- ", "* "))]


def table_rows(body: str) -> list[dict[str, str]]:
    lines = [line.strip() for line in body.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    lookup = {alias: key for key, aliases in COLUMNS.items() for alias in aliases}
    keys = [lookup.get(cell.strip().lower(), cell.strip().lower()) for cell in lines[0].strip("|").split("|")]
    rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        rows.append(dict(zip(keys, cells + [""] * (len(keys) - len(cells)), strict=False)))
    return rows


def is_none(body: str) -> bool:
    return body.strip().strip(".").lower() in NONE_VALUES


def resolve(path_text: str, prd_path: Path) -> Path | None:
    for candidate in (Path(path_text), prd_path.parent / path_text):
        if candidate.is_file():
            return candidate
    # docs/prd/x.md with "Brief: docs/prd-brief/y.md": try from the directory that contains docs/
    for parent in prd_path.resolve().parents:
        if (parent / path_text).is_file():
            return parent / path_text
    return None


class Gate:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.pending: list[str] = []
        self.warnings: list[str] = []
        self.brief_refs: set[tuple[str, int | None]] = set()
        self.domain: dict[str, str] | None = None  # domain item id -> status, when the header links a model
        self.domain_refs: set[str] = set()

    def refs(self, text: str, where: str, brief: dict[str, list[str]] | None, syn_ids: set[str] | None) -> int:
        """Validate the references in text; return how many valid references it has."""
        count = 0
        for prefix, number in DOMAIN_REF_RE.findall(text):
            rid = domain_id(prefix, number)
            if self.domain is None:
                self.failures.append(f"{where}: cites {rid} but no domain model is linked ('Domain: <path>')")
                continue
            status = self.domain.get(rid)
            if status is None:
                self.failures.append(f"{where}: {rid} does not exist in the domain model")
            elif rid.startswith("DQ-") and status not in ("deferred", "answered"):
                self.failures.append(f"{where}: {rid} is still {status} in the domain model")
            elif not rid.startswith("DQ-") and status != "confirmed" and where != "out_of_scope":
                self.failures.append(
                    f"{where}: {rid} is {status or 'without status'} in the domain model; only confirmed use "
                    "cases and rules become requirements (confirm it there first, or leave it out)"
                )
            else:
                self.domain_refs.add(rid)
                count += 1
        for section, index in BRIEF_REF_RE.findall(text):
            section = section.lower()
            idx = int(index) if index else None
            if brief is None:
                self.failures.append(f"{where}: cites brief:{section} but the brief could not be read")
            elif section not in brief:
                self.failures.append(f"{where}: unknown brief section 'brief:{section}'")
            elif idx is not None and not 1 <= idx <= len(brief[section]):
                self.failures.append(f"{where}: brief:{section}#{idx} does not exist ({len(brief[section])} bullets)")
            else:
                self.brief_refs.add((section, idx))
                count += 1
        for ref in SYN_REF_RE.findall(text):
            if syn_ids is None:
                self.failures.append(f"{where}: cites {ref} but no synthesis is linked in the header")
            elif ref not in syn_ids:
                self.failures.append(f"{where}: {ref} does not exist in the synthesis")
            else:
                count += 1
        return count


def check(prd_path: Path) -> Gate:
    gate = Gate()
    text = prd_path.read_text(encoding="utf-8")
    sections = sections_of(text, PRD_SECTIONS)

    # Inputs
    brief: dict[str, list[str]] | None = None
    brief_text = field(text, "brief")
    brief_path = resolve(brief_text, prd_path) if brief_text else None
    if not brief_text:
        gate.failures.append("header: missing 'Brief: <path>'")
    elif brief_path is None:
        gate.failures.append(f"header: brief not found at {brief_text}")
    else:
        raw = brief_path.read_text(encoding="utf-8")
        if not re.search(r"^status:\s*(confirmed|confirmado)\b", raw, re.IGNORECASE | re.MULTILINE):
            gate.failures.append("the brief is not 'Status: confirmed'; confirm it (factory-idea-interview) first")
        brief_sections = sections_of(raw, BRIEF_SECTIONS)
        brief = {key: bullets(brief_sections.get(key, "")) for key in BRIEF_SECTIONS}

    domain_text = field(text, "domain", "domínio", "dominio")
    if domain_text:
        domain_path = resolve(domain_text, prd_path)
        if domain_path is None:
            gate.failures.append(f"header: domain model not found at {domain_text}")
        else:
            raw_domain = domain_path.read_text(encoding="utf-8")
            domain_header = re.split(r"^##\s", raw_domain, maxsplit=1, flags=re.MULTILINE)[0]  # use cases have a Status too
            if not re.search(r"^status:\s*(confirmed|confirmado)\b", domain_header, re.IGNORECASE | re.MULTILINE):
                gate.failures.append("the domain model is not 'Status: confirmed'; confirm it (factory-domain-model) first")
            gate.domain = domain_items(raw_domain)
    elif brief_path is not None:
        skipped = brief_skipped_steps(brief_path.read_text(encoding="utf-8"))
        if skipped is None:
            gate.warnings.append("no domain model is linked ('Domain: <path>') and the brief has no Depth section "
                                 "that skips it; new projects write one (factory-domain-model)")
        elif "domain-model" not in skipped:
            gate.failures.append("the brief's Depth does not skip the domain model: write it (factory-domain-model) "
                                 "and link it with 'Domain: <path>'")

    syn_ids: set[str] | None = None
    syn_text = field(text, "synthesis", "síntese", "sintese")
    if syn_text:
        syn_path = resolve(syn_text, prd_path)
        if syn_path is None:
            gate.failures.append(f"header: synthesis not found at {syn_text}")
        else:
            syn_ids = set(re.findall(r"^\|\s*([EC]\d+)\s*\|", syn_path.read_text(encoding="utf-8"), re.MULTILINE))

    for key, aliases in PRD_SECTIONS.items():
        if key not in sections:
            gate.failures.append(f"missing section '## {aliases[0].capitalize()}'")
        elif not sections[key] and key not in ("risks", "decisions"):
            gate.failures.append(f"section '{aliases[0]}' is empty")

    visible = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    for match in PLACEHOLDER_RE.finditer(visible):
        gate.failures.append(f"placeholder {match.group(0)!r} on line {visible.count(chr(10), 0, match.start()) + 1}")

    # Functional requirements
    functional = sections.get("functional", "")
    blocks = list(FR_RE.finditer(functional))
    if "functional" in sections and not blocks:
        gate.failures.append("no functional requirements ('### FR-01: <title>')")
    must = 0
    for i, match in enumerate(blocks):
        rid = f"{match.group(1).upper()}-{match.group(2)}"
        block = functional[match.end() : blocks[i + 1].start() if i + 1 < len(blocks) else len(functional)]
        priority = field(block, "priority", "prioridade").lower()
        if priority not in PRIORITIES:
            gate.failures.append(f"{rid}: priority must be Must, Should or Could (got {priority or 'nothing'!r})")
        elif priority in MUST:
            must += 1
        source = field(block, "source", "fonte")
        if not source or gate.refs(source, rid, brief, syn_ids) == 0:
            gate.failures.append(f"{rid}: no valid Source (brief:<section>#n, E<n>, C<n>, UC-nn or BR-nn)")
        body = block.replace(source, "", 1) if source else block
        gate.refs(body, rid, brief, syn_ids)  # rules cited in the criteria count as covered
        if not field(block, "story", "história", "historia"):
            gate.failures.append(f"{rid}: missing Story")
        criteria_match = re.search(r"^\s*(acceptance criteria|critérios de aceite|criterios de aceite)\s*:\s*$(.*)",
                                   block, re.IGNORECASE | re.MULTILINE | re.DOTALL)
        criteria = bullets(criteria_match.group(2)) if criteria_match else []
        if not criteria:
            gate.failures.append(f"{rid}: no acceptance criteria")
        for criterion in criteria:
            short = criterion[:60]
            if not GWT_RE.search(criterion):
                gate.failures.append(f"{rid}: criterion is not Given/When/Then: {short!r}")
            if VAGUE_WORDS.search(criterion) and not re.search(r"\d", criterion):
                gate.failures.append(f"{rid}: vague criterion without a number: {short!r}")
    if len(blocks) >= 5 and must / len(blocks) > 0.6:  # small lists can legitimately be mostly Must
        if field(functional, "priority note", "nota de prioridade"):
            gate.warnings.append(f"{must} of {len(blocks)} requirements are Must (accepted in the priority note)")
        else:
            gate.failures.append(
                f"{must} of {len(blocks)} requirements are Must (> 60%): ask the user which ones could wait; "
                "if they keep them, record 'Priority note: <their reason>' under Functional requirements"
            )

    # Non-functional requirements
    for row in table_rows(sections.get("nonfunctional", "")):
        rid = row.get("id") or "NFR-?"
        if not row.get("measure"):
            gate.failures.append(f"{rid}: no measure")
        elif VAGUE_WORDS.search(row["measure"]) and not re.search(r"\d", row["measure"]):
            gate.failures.append(f"{rid}: vague measure without a number")
        if not row.get("source") or gate.refs(row["source"], rid, brief, syn_ids) == 0:
            gate.failures.append(f"{rid}: no valid Source")

    # Metrics
    metric_rows = table_rows(sections.get("metrics", ""))
    if "metrics" in sections and not metric_rows:
        gate.failures.append("goals and metrics table has no rows")
    for row in metric_rows:
        rid = row.get("id") or "M?"
        for column in ("target", "deadline"):
            if not row.get(column):
                gate.failures.append(f"{rid}: missing {column}")
        if not row.get("source") or gate.refs(row["source"], rid, brief, syn_ids) == 0:
            gate.failures.append(f"{rid}: no valid Source")

    # Assumptions
    for row in table_rows(sections.get("assumptions", "")):
        rid = row.get("id") or "A?"
        confidence = row.get("confidence", "").lower()
        if confidence not in CONFIDENCES:
            gate.failures.append(f"{rid}: confidence must be low/medium/high")
        if not row.get("validation"):
            gate.failures.append(f"{rid}: no validation")
        if confidence in LOW and not row.get("before"):
            gate.failures.append(f"{rid}: low-confidence assumption needs 'Before' (what it blocks)")

    # References in the remaining sections
    covered_by_requirements = set(gate.domain_refs)
    for key in ("out_of_scope", "decisions", "risks", "context", "users", "assumptions", "open_questions"):
        before = set(gate.domain_refs)
        body = sections.get(key, "")
        if key in ("assumptions", "open_questions"):  # only domain ids here; brief refs were never checked in these
            body = " ".join(m.group(0) for m in DOMAIN_REF_RE.finditer(body))
        gate.refs(body, key, brief, syn_ids)
        if key == "out_of_scope":
            covered_by_requirements |= gate.domain_refs - before

    # Coverage of the domain model: every confirmed use case and rule is a requirement or out of scope,
    # and every deferred question is visible in the PRD.
    if gate.domain is not None:
        for rid, status in sorted(gate.domain.items()):
            if status == "confirmed" and rid not in covered_by_requirements:
                gate.failures.append(f"{rid} (confirmed in the domain model) is not covered by any FR or NFR, "
                                     "nor listed in Out of scope")
            elif status == "deferred" and rid not in gate.domain_refs:
                gate.failures.append(f"{rid} is deferred in the domain model; cite it in Assumptions or Risks")

    # Coverage of the brief
    if brief is not None:
        for section, label in (("scope", "FR"), ("metrics", "metric row")):
            for n, item in enumerate(brief[section], start=1):
                if (section, n) not in gate.brief_refs:
                    gate.failures.append(f"brief:{section}#{n} is not covered by any {label}: {item[:60]!r}")

    open_questions = sections.get("open_questions", "")
    if open_questions and not is_none(open_questions):
        gate.pending += [line.strip().lstrip("-* ") for line in open_questions.splitlines() if line.strip()]
    return gate


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    gate = check(Path(sys.argv[1]))
    for warning in gate.warnings:
        print(f"warning: {warning}")
    if gate.failures:
        print("FAIL")
        for item in dict.fromkeys(gate.failures):
            print(f"  - {item}")
        return 1
    if gate.pending:
        print("NEEDS-ANSWERS")
        for item in gate.pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
