# factory-review

Step 7 of the flow: checks one ticket's implementation against the ticket's acceptance criteria, the PRD requirements it serves, the design, and the definition of done, then gives a verdict. It reviews only; it does not edit code.

```
factory-implement (T-03 → done) → factory-review (T-03) → APPROVE, or CHANGES NEEDED / BLOCKED
```

## What it checks

- Scope: every changed file serves a ticket line; no feature the PRD does not ask for.
- Criteria: each Given/When/Then has a test that asserts it, and the test fails when the behavior breaks.
- NFRs: privacy (personal fields), permissions, secrets and logs, accessibility rules from the PRD.
- Design: components, data model and ADR decisions followed; the code follows the design's *Architecture decisions* (layers, ports, slices, module cycles, table owners).
- Status: `done` only with evidence for every criterion.

## Files

```
factory-review/
├── SKILL.md
├── references/
│   ├── architecture-checks.md # What to check in the code for each architecture choice, and how
│   ├── findings-template.md   # Verdict, criteria table and findings, one format
│   └── lessons-template.md
├── scripts/
│   └── check_imports.py       # Python import graph: forbidden imports, slice internals, module cycles
└── evals/
    ├── evals.json             # Privacy blocker, scope creep, no code to review, mutations, architecture violation
    └── trigger_queries.json
```

Eval fixtures:
- `evals/fixtures/review/T-03-missing-criteria.patch`: a booking form with a phone field and a test that checks only the redirect.
- `evals/fixtures/review/T-03-scope-creep.patch`: a booking view that is correct, plus an unauthorised CSV export of patient data.
- `evals/fixtures/review/T-03-layer-skip.patch`: correct tests, but the patient view writes `agenda.models` directly instead of calling `agenda.services`, and `agenda` imports `paciente_web` back (a module cycle).
- The ticket, PRD and design come from `evals/fixtures/docs/`.

## Severity and verdict

| Severity | Examples |
|----------|----------|
| blocker | criterion untested, privacy or permission NFR broken |
| major | scope creep, design deviation without a decision, architecture decision broken in the code |
| minor / nit | weak but valid test, naming |

`APPROVE` needs no blocker or major. `CHANGES NEEDED` sends the ticket back to `doing`. `BLOCKED` means the review cannot finish.
