---
name: factory-review
description: Use this skill to review the implementation of one ticket from a confirmed backlog (docs/tickets/<slug>.md) before it is marked done — check each acceptance criterion against a test that really asserts it, that nothing outside the ticket's scope was built, that the definition of done and the privacy, permission and security NFRs hold, that the design's components, ADRs and architecture decisions (layers, ports, slices, module cycles, table owners) were followed in the code, and that the status and the evidence agree, mutating each rule in an isolated copy to prove the tests catch it. Reports findings with severity and a verdict; it does not edit the code. Triggers on "review T-03", "revisa o ticket T-03 antes de fechar", "check the booking ticket against the PRD", "confere a implementação do ticket", "the ticket is done, is it really?". Not for building the ticket (use factory-implement), for reviewing the PRD, design or backlog documents, or for general code review with no ticket.
license: MIT
compatibility: Needs the repository, its test tooling, and the ticket, PRD and design files. Uses the git diff when the repository has commits; otherwise the files listed in the factory-implement report. Language skills (python-*, typescript-*, javascript-*, go-*, rust-*, swift-*, and postgres-database for PostgreSQL) supply the code-level rules when the design's Stack names that language.
metadata:
  author: mhl42
  version: "1.6.0"
---

# Review

Check a ticket's implementation against what the ticket, the PRD and the design asked for. The question is not "is this code good?" alone. It is "does this code do what the ticket says, and nothing it does not say?"

This runs after factory-implement, on a ticket that is `doing` or `done`:

```
factory-implement (builds T-03, Status: done) → factory-review (T-03) → verdict → fix or close
```

Write the findings in the user's language. Quote code and identifiers as they are.

## Before you start

- **Ticket:** the ticket in `docs/tickets/<slug>.md`, with its `Serves`, `Depends on`, `Mode`, acceptance criteria and notes.
- **PRD and design:** the requirements the ticket serves (copy their acceptance criteria), the design's *Components*, *Data model*, *Architecture decisions* (*Decisões de arquitetura*), *NFR coverage* and the ADRs the ticket cites.
- **The change:** if the repository has commits, `git diff <base>...HEAD` for the ticket's branch or commit range. If it has none, use the file list in the factory-implement report, and read each file in full.
- **Evidence:** the test and lint output. Run them yourself. Do not accept the implementer's summary as the result.

If there is no implementation to inspect, stop and say so. If there is one but the ticket still says `todo` or `blocked`, review it anyway and report the status mismatch as a finding: the status is what the backlog tells the team.

## Workflow

```
- [ ] 1. Scope: every changed file traces to the ticket's Serves
- [ ] 2. Criteria: each acceptance criterion has a test that asserts it
- [ ] 3. Tests run: they pass, and the criterion-level tests fail when the behavior breaks
- [ ] 4. Definition of done and NFRs: privacy, permissions, secrets, logs, accessibility
- [ ] 5. Design: components, data model, ADRs and architecture decisions followed
- [ ] 6. Status and evidence agree
- [ ] 7. Findings written with severity, and a verdict
```

### 1. Scope
- List every changed file and the ticket line it serves. A file that serves nothing is a finding.
- Look for behavior the PRD does not ask for: an export, an extra field, an admin screen, a "while I was here" change. These are scope creep, even when they look useful.
- Look for business rules the code decides that no document gives: a format, a limit, a refusal, a boundary ("expires today is still valid"). Each one is a `minor` finding when the implementer listed it under *Rules not in the documents*, and a `major` one when it was silent. The fix is not in the code: the rule goes to factory-change, to the domain model and the PRD.
- Check that the PRD and the design were not edited to fit the code.

### 2. Criteria
For each Given/When/Then:
- Name the test that covers it. No test, or a test that checks a different thing, is a blocker.
- Read the assertion. A test that only checks the status code of a page does not check "appears in my sessions". A test that ends before the `when` runs is not a test of the criterion.
- Check the data: the test must use the criterion's own example, not an easier one.

### 3. Tests
- Run every gate of the language profile (`gates` in `factory-implement/references/languages/<language>.json`, or the `run:` steps of the CI workflow when there is one), verbatim and on the whole project. Record the commands and the results.
- Compare the implementer's report with your own run. A claim that your run contradicts (a gate reported green that fails, a test reported as passing that does not run, a behavior described that the code does not have) is a `major` finding, and a `blocker` when it hid a failing gate. Quote both sides.
- Check that no test depends on today's date: anything that reads the clock gets an injectable clock in the tests, and a fixed future date (an expiry, a due date) is far enough not to age (2099) or comes from a fixed clock. A suite that passes today and fails on a date is a `major` finding. When the ticket makes an older function start reading the clock, search for the tests that call it without one.
- Check for weakened tests: skipped tests, removed assertions, broad `except` around the code under test, mocks that replace the behavior being specified (see the language skill's testing rules).
- **Discrimination sensor**, required for every criterion that comes from a business rule (the PRD or the ticket cites a `BR-nn`) and for the most important criterion otherwise. In an isolated copy (a temporary `git worktree add` on the ticket's commit, or a copy of the files in a temporary folder; never `git stash`, never the real tree), change the behavior the criterion specifies (invert the rule, move the boundary by one, drop the refusal), run the tests, and confirm at least one fails. Delete the copy, then check that `git status --porcelain` of the real tree is the same as before. A mutant that survives is a `major` finding: the test does not check the rule. Record each mutant and its result in the findings.

### 4. Definition of done and NFRs
Go through the definition of done in the backlog file and through each NFR the ticket serves. Typical blockers in this flow:
- A personal field beyond what the NFR allows (for example a phone or CPF where the PRD allows only name and e-mail).
- A permission check missing on a new view, or a role that can see another role's data.
- A secret, token or personal e-mail in the code, a fixture that is a real value, or a log line that prints a token.
- A new dependency or endpoint that the design does not list.
- Accessibility or size rules the PRD sets (for example minimum text size) on a new page.

### 5. Design
- New components, tables or columns must appear in the design, or be raised as a design change (not made silently).
- The ADR decisions the ticket cites must be followed (for example a database constraint the ADR requires, not an application-level check that replaces it).
- The code must follow each row of *Architecture decisions*. Map each Choice to its catalog entry and run the check [references/architecture-checks.md](references/architecture-checks.md) gives for it: no skipped layer (`layered`), no framework or infrastructure import in the domain (`hexagonal`), no slice importing another slice's internals (`vertical-slice`), no circular imports between modules (`modular-monolith`), each table touched only by its `Owner` (services). For Python, `scripts/check_imports.py` does the import checks; record its command and output. A violation is a finding that names the decision it breaks, with its file and line: `blocker` for a table written outside its owner, `major` for the others. A design without the section is reported as not checked.

### 6. Status and evidence
- `Status: done` needs passing evidence for every criterion and the definition of done. If something is unverified, the ticket is not done: say which item.
- Spikes: the decision record exists in `docs/spikes/<ticket-id>.md`, the throwaway code is outside the app, and the result matches the exit criterion.

### 7. Findings and verdict
Use [references/findings-template.md](references/findings-template.md). Each finding has a severity, a location (file and line), the ticket or NFR it breaks, and a suggested fix.

| Severity | Meaning |
|----------|---------|
| `blocker` | A criterion is not met or not tested, a privacy, permission or security NFR is broken, or the code does something the PRD forbids |
| `major` | Scope creep, a missing test for an edge the criterion names, a design deviation without a recorded decision (a skipped layer, a module cycle, a domain importing infrastructure) |
| `minor` | Naming, dead code, a test that is weaker than it should be but still checks the criterion |
| `nit` | Style only |

Verdict:
- `APPROVE`: no blockers or majors, and the status can be `done`.
- `CHANGES NEEDED`: blockers or majors; the ticket goes back to `doing` with the findings.
- `BLOCKED`: the review cannot finish (a test cannot run, a dependency is missing). Say what is needed.

## Lessons

When a finding shows a gap the specification could have caught (a rule decided in the code, a surviving mutant, a failure mode no criterion carried, a criterion that contradicts the domain model), add it to `docs/lessons.md` as a `candidate`, with the finding as its source ([references/lessons-template.md](references/lessons-template.md)). A clean review adds nothing. The user turns a candidate into `confirmed`; only confirmed lessons are read by factory-domain-model and factory-tech-design. The review never confirms its own lessons.

## Rules

- Review only. Do not edit the code, the tests, the PRD, the design or the backlog. Mutations happen only in the isolated copy, and `docs/lessons.md` is the one file the review may write. If the user asks for fixes, hand the findings to factory-implement.
- Do not change `Status:` yourself. Recommend it; the user or factory-implement sets it.
- Report what you ran and what you did not run. "Looks right" is not evidence.
- A finding needs a location and a reason. Drop findings you cannot tie to the ticket, the PRD, the design or the code's own correctness.

## Ticket store (factory-tickets MCP)

When the `factory-tickets` tools are connected, read the ticket and its evidence from the database. These calls are read-only:

- `ticket_get(project, ticket_id)` gives the criteria, the status and the subtasks.
- `events_list(project, ticket_id)` gives the history. The `done` event carries the evidence the implementer wrote; compare it with the test run you do yourself.
- `ticket_list(project)` shows whether the ticket's dependencies are done.

Review never calls `ticket_set_status` or `project_export_markdown`. A `done` with no matching evidence, or a status that disagrees with the history, is a finding.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Write lessons with `doc_write(project, "lessons", "lessons", markdown)`: the whole table, with the new lessons as `candidate`. It is the only document the review writes, and it never confirms one.

## Gotchas

- A green test suite does not prove the criterion: the tests may check the wrong thing. Read the assertions.
- The implementer's test names copy the criteria, but the body may not. Check the body.
- An implementer's summary is often right and sometimes confidently wrong, in both directions: a gate reported green on a subset of files, or a defect reported in code that is fine. Re-run it and test the claim before repeating it.
- A date written into a test ("valid until 2027") is a time bomb: the suite is green until that day. Read the fixtures and the `conftest.py`, not only the test bodies.
- The reviewer is not the author. If you wrote or fixed the code, ask for another reviewer.
- Privacy NFRs break quietly, through a form field or a log line, not through the feature itself. Check forms, serializers, exports and logs.
- A green test suite says nothing about the architecture: a view that writes the model directly passes the same tests as one that calls the service. Read the imports of every changed file.
- Spike tickets are reviewed for their record, not for production quality. Do not ask for tests of throwaway code.
