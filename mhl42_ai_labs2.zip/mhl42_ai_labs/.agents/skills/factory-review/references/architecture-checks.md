# Architecture checks

How the review checks that the code follows the design's *Architecture decisions* (*Decisões de arquitetura*). The design gate checked that each decision is justified; it cannot see the code. This step does.

## Contents
- Reading the decisions
- What to check per choice
- Running the import check
- Severity
- Reporting

## Reading the decisions

The table has one row per decision: `Dimension | Choice | Driver | Alternatives | ADR` (`Dimensão | Escolha | Direcionador | Alternativas | ADR`). Map each *Choice* to a catalog id with the aliases in `factory-tech-design/references/architecture-catalog.json` (`Monólito modular` is `modular-monolith`, `Camadas` and `Layered (views, services, models)` are `layered`). The words after the choice ("views, services, models") name the layers or modules; *Components* names the modules and their folders. Use those names, not the ones you would have chosen.

No *Architecture decisions* section (a design written before it existed): skip this step and say so in the report. A choice with no check below (CQRS, outbox, SSR...): check what its row's ADR says the code must do, if anything concrete, and otherwise list it as not checked.

Review only the files the ticket changed or added, plus the imports they create. An older violation that the ticket did not touch is not this ticket's finding: mention it once as a `minor` note for the backlog.

## What to check per choice

| Choice (catalog id) | Rule in the code | How to verify |
|---------------------|------------------|---------------|
| `layered` | No layer is skipped: presentation calls the application (service) layer, which calls the domain and the data layer. A view, controller, command handler or template tag that imports the repository, the ORM models for writing, or the database driver directly skips a declared layer. Business rules do not live in views or in SQL alone. | Import check with `--forbid <presentation>:<data layer>` for each skipped pair (`--forbid app.views:app.repositories`, `--forbid app.views:sqlite3`). For an ORM where models are also the data layer (Django), grep the presentation files for `.objects.`, `.save(`, `.delete(`, `cursor(`. |
| `hexagonal` | The domain (entities, rules, ports) imports nothing from the framework, the ORM, the database driver, HTTP clients or the adapters. Adapters depend on the domain, never the reverse. | Import check with `--forbid <domain>:<package>` for the web framework, the ORM, the driver, the HTTP client and the adapters package (`--forbid app.domain:django --forbid app.domain:requests --forbid app.domain:app.adapters`). A domain test that runs without the database is a good sign; one that needs it is a finding. |
| `vertical-slice` | A slice (one folder per use case or feature) does not import another slice's internals. It may call another slice through that slice's package (its `__init__`, the public entry) or through a shared module. | Import check with `--slices <features package>` (`--slices app.features`). |
| `modular-monolith` | No circular imports between modules (the catalog's `circular-dependencies` antipattern, `detect: code`). One module per component of *Components*. A module does not write another module's tables. | Import check with `--cycles --depth N`, where `N` is the number of dotted parts of a module name (`app.booking` is 2). For the tables, grep each module's queries and model writes against the *Data model*. |
| `service-based`, `microservices` | Each table is read and written only by its `Owner` (*Dono*) in the *Data model*. Another service gets the data by calling the owner's API or by consuming its events; no shared database connection, no foreign key across owners. | For every table the ticket's code touches, grep its name across the codebase (`grep -rn -w <table>` over models, migrations, SQL files and raw queries) and check each hit is inside the owner's folder. Check the service's database settings point to its own schema or database. |
| `plugin` | Plugins import only the core's published contract, and the core imports no plugin. | Import check with `--forbid <core>:<plugins package>` and, for each plugin, `--forbid <plugin>:<core internals>`. |

The design text names other local patterns (Repository, Strategy, dependency injection) for the code to follow; check them where the ticket's code uses them, as part of section 5 of the workflow.

Other languages: `check_imports.py` reads Python only. For other code, do the same checks with the language's tools (dependency-cruiser or madge for JavaScript and TypeScript, ArchUnit for Java, `go list -deps` for Go) or with grep over the import lines, and record the command you ran. When no tool is available, read the changed files' imports by hand and say so.

## Running the import check

```
py -3 <factory-review>/scripts/check_imports.py <source root> [--cycles --depth N] [--forbid FROM:TO ...] [--slices PACKAGE ...]
```

- `<source root>` is the folder the imports start from: `src` in a src layout, otherwise the project root.
- `FROM`, `TO` and `PACKAGE` are dotted prefixes. `TO` may be a third-party package (`django`, `sqlalchemy`).
- Imports under `if TYPE_CHECKING:` are skipped: they do not run.
- Exit codes: `0` PASS, `1` FAIL with one `FAIL file:line` per violation, `2` nothing to check (no Python files, or no check asked).

Record the exact command and its output in the findings, like any gate. When the project already has an import-boundary tool (import-linter contracts, a test that walks the imports), run that first and use this script only for what it does not cover. A boundary that the architecture depends on and that no test enforces is worth a `minor` suggestion: a contract or a test keeps it from eroding.

## Severity

| Violation | Severity |
|-----------|----------|
| A table written by a service that is not its `Owner`, or a foreign key across owners | `blocker`: the data now has two owners, which the design's gate rejects as `shared-database` |
| A circular import between modules of a modular monolith | `major` |
| A skipped layer, a domain that imports infrastructure, a slice that reaches into another | `major`: a design deviation without a recorded decision |
| The same violation already listed under *Rules not in the documents* or with an ADR that allows it | `minor`: point to the ADR or ask for one |
| An older violation the ticket did not touch | `minor`, as a note for the backlog |

The fix is in the code (move the call behind the service, add a port, call the other slice's public entry), or, when the code is right and the design is wrong, a design change through factory-change. The review does not choose between them; it names both.

## Reporting

Each finding names the decision it breaks, as `Architecture decisions: <Dimension> = <Choice>`, with the file and line from the import check or the grep. Under *What I ran*, list the import-check command and its result, and each decision you could not check and why.
