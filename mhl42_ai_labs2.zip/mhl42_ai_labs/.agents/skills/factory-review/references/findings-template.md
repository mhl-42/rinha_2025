# Review Findings Template

Use this at the end of a review. Keep the headings. Write the content in the user's language.

````markdown
## Review: T-03 Patient books a free slot

Verdict: CHANGES NEEDED
Status recommended: doing (back from done)
Commands run: `pytest -q` (example: 22 passed, 1 failed), `ruff check .` (example: no findings)

### Criteria
| Criterion | Test | Assertion checks it | Result |
|-----------|------|---------------------|--------|
| Given a free slot, when the patient confirms, then the session appears in "my sessions" | test_patient_books_free_slot | no: only the 302 status | fail |
| Given the slot was taken meanwhile, then "slot just taken" and no session | none | none | no test |

### Findings

1. **blocker**: `agenda/forms.py:6`: `patient_phone` field added
   - Breaks: RNF-01 (only name and e-mail may be stored for the patient)
   - Fix: remove the field; if the phone is needed later, raise it as a PRD change.

2. **blocker**: `agenda/tests/test_booking.py:4`: the test checks only the redirect
   - Breaks: T-03 criterion 1
   - Fix: assert that a Session exists for the patient and that the slot is no longer free.

### Discrimination sensor
| Criterion (rule) | Mutation | Tests that failed | Result |
|------------------|----------|-------------------|--------|
| Criterion 2 (BR-04) | accept a booking on a taken slot | test_booking_taken_slot | killed |

Isolated copy: temporary worktree, removed; `git status --porcelain` unchanged.

### Scope
- Files serving no ticket line: none.

### Not verified here
- CI run (no CI in this environment).

### Next
- Back to factory-implement for findings 1 and 2. Re-run this review after the fix.
````

Rules for findings:
- Every finding has a severity, a `file:line`, the ticket line or NFR it breaks, and a fix.
- The verdict follows the findings: any blocker or major means `CHANGES NEEDED`.
- Do not list a finding you did not verify in the code.
- A surviving mutant is a `major` finding, with the mutation that survived as its evidence.
- Gaps the specification could have caught also go to `docs/lessons.md` as candidates.
