# Lessons Template

`docs/lessons.md` holds the lessons of **this project**: gaps a review found that the specification could have caught. factory-domain-model and factory-tech-design read the confirmed ones, so the next feature asks the question this one forgot. It is not a log of bugs: a bug with no lesson for the specification does not go here.

```markdown
# Lessons: <project>

| ID | Lesson | Check it in | Source | Status |
|----|--------|-------------|--------|--------|
| L-1 | Ask how numbers are typed (decimal comma, thousands separator) for every quantity and amount | domain model: formats of input | review of T-10 (rule decided in the code) | confirmed |
| L-2 | Every failure mode of an integration needs a ticket criterion | tickets: definition of done | review of T-06 (database error with no criterion) | candidate |
```

- **Lesson:** written as the question or the check to do next time, not as the story of what happened.
- **Check it in:** the step and the part of it (`domain model: formats of input`, `design: Rule enforcement`, `tickets: definition of done`).
- **Source:** the review and the finding that produced it.
- **Status:** `candidate` (written by the review) or `confirmed` (the user agreed it is worth checking every time). Portuguese: `candidata`, `confirmada`. A lesson the user rejects is deleted, not kept as rejected.
- One lesson per gap. Before adding one, read the table: a repeated lesson is a sign the step that should check it is not reading this file.
