#!/usr/bin/env python3
"""Import-graph checks for a Python codebase, against the design's Architecture decisions.

Reads every .py file under SOURCE with the ast module (no code is imported or run), resolves its
imports, including relative ones, to dotted module names, and reports:

  --cycles                  circular imports between modules, grouped at --depth path components
                            (the catalog's circular-dependencies antipattern; modular monolith)
  --forbid FROM:TO          code under FROM must not import TO, a module of the project or a third-party
                            package (layered: views:app.repositories; hexagonal: app.domain:django)
  --slices PACKAGE          each child of PACKAGE is a slice; a slice may import another slice's package
                            (its public __init__) but not a module inside it (vertical slice)

FROM, TO and PACKAGE are dotted prefixes: "app.domain" matches app.domain and app.domain.order.
Imports inside `if TYPE_CHECKING:` are skipped. Each violation is printed as file:line.

Usage:
  python check_imports.py src --cycles --depth 2
  python check_imports.py src --forbid app.views:app.repositories --forbid app.domain:django
  python check_imports.py src --slices app.features

Exit codes: 0 = PASS, 1 = FAIL (violations), 2 = nothing to check (no .py files or no check asked).
"""

from __future__ import annotations

import argparse
import ast
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Edge:
    source: str
    target: str
    file: Path
    line: int


def module_name(path: Path, root: Path) -> tuple[str, bool]:
    """Dotted name of a file under root, and whether it is a package's __init__."""
    parts = list(path.relative_to(root).with_suffix("").parts)
    is_package = parts[-1] == "__init__"
    if is_package:
        parts = parts[:-1]
    return ".".join(parts), is_package


def is_type_checking(test: ast.expr) -> bool:
    return (isinstance(test, ast.Name) and test.id == "TYPE_CHECKING") or (
        isinstance(test, ast.Attribute) and test.attr == "TYPE_CHECKING")


def bound_names(tree: ast.Module) -> set[str]:
    """Names a module binds at its top level (what "from package import name" finds first)."""
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            names.add(node.name)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            names.update((alias.asname or alias.name).split(".")[0] for alias in node.names)
        elif isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            names.update(t.id for t in targets if isinstance(t, ast.Name))
    return names


def imports_of(tree: ast.Module, module: str, is_package: bool) -> list[tuple[str, int, str]]:
    """Every imported module name with its line and, for "from base import name", the base."""
    found: list[tuple[str, int, str]] = []
    package = module.split(".") if is_package else module.split(".")[:-1]

    skipped = {id(inner) for node in ast.walk(tree) if isinstance(node, ast.If) and is_type_checking(node.test)
               for stmt in node.body for inner in ast.walk(stmt)}
    for node in ast.walk(tree):
        if id(node) in skipped:
            continue
        if isinstance(node, ast.Import):
            found.extend((alias.name, node.lineno, "") for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                keep = len(package) - (node.level - 1)
                if keep < 0:
                    continue
                base = ".".join(package[:keep] + ([node.module] if node.module else []))
            else:
                base = node.module or ""
            # "from pkg import name" may import the submodule pkg.name; keep both, filtered later.
            found.extend((f"{base}.{alias.name}" if base else alias.name, node.lineno, base)
                         for alias in node.names if alias.name != "*")
            if base:
                found.append((base, node.lineno, ""))
    return found


def build_graph(root: Path) -> tuple[set[str], list[Edge]]:
    modules: set[str] = set()
    parsed: list[tuple[Path, str, bool, ast.Module]] = []
    for path in sorted(root.rglob("*.py")):
        if any(part.startswith(".") or part in ("venv", "node_modules", "__pycache__") for part in path.parts):
            continue
        name, is_package = module_name(path, root)
        if not name:
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except (SyntaxError, UnicodeDecodeError) as error:
            print(f"WARN {path}: cannot parse ({error})")
            continue
        modules.add(name)
        parsed.append((path, name, is_package, tree))
    exported = {name: bound_names(tree) for _, name, is_package, tree in parsed if is_package}
    edges: list[Edge] = []
    for path, name, is_package, tree in parsed:
        seen: set[tuple[str, int]] = set()
        for target, line, base in imports_of(tree, name, is_package):
            # "from pkg import name" imports the submodule pkg.name only when pkg is a package of the
            # project that has such a module and does not bind the name itself.
            if base and base in modules and (target not in modules
                                             or target.rsplit(".", 1)[1] in exported.get(base, set())):
                continue
            if (target, line) not in seen and target != name:
                seen.add((target, line))
                edges.append(Edge(name, target, path, line))
    return modules, edges


def under(name: str, prefix: str) -> bool:
    return name == prefix or name.startswith(prefix + ".")


def group(name: str, depth: int) -> str:
    return ".".join(name.split(".")[:depth])


def find_cycles(modules: set[str], edges: list[Edge], depth: int) -> list[list[str]]:
    """Strongly connected components with more than one group (Tarjan, iterative)."""
    graph: dict[str, set[str]] = {}
    for edge in edges:
        if not any(under(edge.target, m) or under(m, edge.target) for m in modules):
            continue
        source, target = group(edge.source, depth), group(edge.target, depth)
        if source != target:
            graph.setdefault(source, set()).add(target)
            graph.setdefault(target, set())
    index: dict[str, int] = {}
    low: dict[str, int] = {}
    stack: list[str] = []
    on_stack: set[str] = set()
    components: list[list[str]] = []
    counter = 0
    for start in sorted(graph):
        if start in index:
            continue
        work = [(start, iter(sorted(graph[start])))]
        index[start] = low[start] = counter
        counter += 1
        stack.append(start)
        on_stack.add(start)
        while work:
            node, children = work[-1]
            child = next(children, None)
            if child is not None:
                if child not in index:
                    index[child] = low[child] = counter
                    counter += 1
                    stack.append(child)
                    on_stack.add(child)
                    work.append((child, iter(sorted(graph[child]))))
                elif child in on_stack:
                    low[node] = min(low[node], index[child])
                continue
            work.pop()
            if work:
                low[work[-1][0]] = min(low[work[-1][0]], low[node])
            if low[node] == index[node]:
                component = []
                while True:
                    member = stack.pop()
                    on_stack.discard(member)
                    component.append(member)
                    if member == node:
                        break
                if len(component) > 1:
                    components.append(sorted(component))
    return sorted(components)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("source", type=Path, help="folder whose .py files are module roots (src, or the project)")
    parser.add_argument("--cycles", action="store_true", help="report circular imports between modules")
    parser.add_argument("--depth", type=int, default=2, help="path components that make a module for --cycles")
    parser.add_argument("--forbid", action="append", default=[], metavar="FROM:TO")
    parser.add_argument("--slices", action="append", default=[], metavar="PACKAGE")
    args = parser.parse_args(argv)

    if not (args.cycles or args.forbid or args.slices):
        print("NOTHING TO CHECK: pass --cycles, --forbid or --slices")
        return 2
    root = args.source.resolve()
    modules, edges = build_graph(root)
    if not modules:
        print(f"NOTHING TO CHECK: no .py files under {args.source}")
        return 2

    violations: list[str] = []

    def where(edge: Edge) -> str:
        return f"{edge.file.relative_to(root).as_posix()}:{edge.line}"

    for rule in args.forbid:
        source, _, target = rule.partition(":")
        if not source or not target:
            parser.error(f"--forbid needs FROM:TO, got {rule!r}")
        for edge in edges:
            if under(edge.source, source) and under(edge.target, target):
                violations.append(f"{where(edge)}: {edge.source} imports {edge.target} (forbidden: {rule})")

    for package in args.slices:
        level = package.count(".") + 2  # package.slice
        for edge in edges:
            if not (under(edge.source, package) and under(edge.target, package)):
                continue
            source_slice, target_slice = group(edge.source, level), group(edge.target, level)
            if source_slice == package or target_slice == package or source_slice == target_slice:
                continue
            if edge.target != target_slice:
                violations.append(f"{where(edge)}: {edge.source} imports {edge.target}, "
                                  f"inside slice {target_slice} (use {target_slice} or a shared module)")

    if args.cycles:
        for component in find_cycles(modules, edges, args.depth):
            members = set(component)
            lines = [where(e) + f" {e.source} -> {e.target}" for e in edges
                     if group(e.source, args.depth) in members and group(e.target, args.depth) in members
                     and group(e.source, args.depth) != group(e.target, args.depth)]
            violations.append(f"cycle between {', '.join(component)}: " + "; ".join(lines))

    print(f"{len(modules)} modules, {len(edges)} imports read")
    for violation in violations:
        print(f"FAIL {violation}")
    print("FAIL" if violations else "PASS")
    return 1 if violations else 0


if __name__ == "__main__":
    sys.exit(main())
