# factory-ship

Last step of the flow: builds and releases a version from the reviewed backlog. Staging is deployed through the pipeline the design describes, after the smoke test. Production is deployed only after the owner approves in the conversation. Every release has a record that `check_release.py` checks.

```
factory-review (APPROVE) → factory-ship → docs/releases/<slug>-<version>.md → staging → production (after owner approval)
```

## Files

```
factory-ship/
├── SKILL.md
├── scripts/
│   └── check_release.py          # Gate: PASS / FAIL / NEEDS-ANSWERS; --scan-secrets
├── references/
│   └── release-template.md       # The release record's headings and fields
└── evals/
    ├── evals.json                # Staging release, production without approval, failing CI, secret scan
    └── trigger_queries.json
```

Fixture: `evals/fixtures/docs/releases/autoagendamento-fisioterapia-0.1.0.md`, a first release with the skeleton and the spike, on staging, with production pending approval. Its tickets are in `evals/fixtures/docs/tickets/`.

## Run the gate

```bash
python skills/factory-ship/scripts/check_release.py docs/releases/<slug>-<version>.md
python skills/factory-ship/scripts/check_release.py docs/releases/<slug>-<version>.md --scan-secrets
```

The gate checks:
- every included ticket is `done` in the backlog, and every other ticket is deferred;
- the commit and `CI: pass` for that commit;
- migrations, configuration (secret names only) and the rollback with the previous version;
- staging has `Smoke test: pass`;
- production is recorded only with `Approved by:`, `Deployed at:` and a passing smoke test; otherwise the stage must be staging with production pending approval.

`--scan-secrets` scans the tracked files of the repository for private keys, AWS-style keys and literal passwords or tokens. It needs git.
