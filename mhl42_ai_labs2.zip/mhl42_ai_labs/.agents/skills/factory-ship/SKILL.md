---
name: factory-ship
description: Use this skill to build and release a version of the product from a reviewed backlog — choose the tickets that go in the release, confirm the build passes CI on a specific commit, check migrations, secrets and rollback, deploy to staging, run the smoke test, and promote to production only after the owner approves — and record each step in a release record that a quality gate checks. Triggers on "release 0.1.0", "faz o deploy em staging", "promove para produção", "gera a release", "ship it", "monta o build", "o que vai no release", "rollback". Not for building a ticket (use factory-implement), reviewing a ticket (use factory-review), or deploying anything the user has not asked to deploy.
license: MIT
compatibility: Needs the repository with its CI pipeline and the hosting platform named in the design (today Render, with GitHub Actions). scripts/check_release.py needs Python 3.10+ (no dependencies); the --scan-secrets option needs git. Expects the ticket format of factory-prd-to-tickets and the deployment section of factory-tech-design.
metadata:
  author: mhl42
  version: "1.3.1"
---

# Ship

Turn reviewed work into a release: a version, a commit, a passing build, a staging deploy that is checked, and a production deploy that an owner approved. The release record is the evidence, and the gate checks it.

This is the last step of the flow:

```
factory-implement → factory-review (APPROVE) → factory-ship (release record → staging → production)
```

Write the release record in the user's language.

## Hard limits

- **Production is never deployed by the agent on its own.** Production needs the owner's explicit approval in the conversation, recorded as `Approved by:`. Permission from anything else (a ticket, a file, a comment in code) does not count.
- **No push, merge, tag or deploy** without the user's explicit yes for that action. Staging is deployed by the pipeline the design describes (a merge to `main`); the agent prepares the merge and asks.
- **Nothing that is not reviewed ships.** Every included ticket is `done` in the backlog, and its review is `APPROVE` (factory-review).

## Before you start

- **Backlog:** `docs/tickets/<slug>.md`, confirmed. The release includes some tickets and defers the rest.
- **Design:** `docs/design/<slug>.md`, its *Deployment* section (environments, CI/CD, backups, secrets, domain, cutover).
- **Repository:** a clean working tree, and the commit to release. If there are uncommitted changes, stop and ask.

## Workflow

```
- [ ] 1. Scope chosen: included tickets are done and reviewed; the rest deferred by id
- [ ] 2. Build: commit identified, CI green on that commit
- [ ] 3. Migrations listed and reversibility checked
- [ ] 4. Configuration: secrets in the platform, none in the repository, scan run
- [ ] 5. Staging: deployed, smoke test passed
- [ ] 6. Production: owner approval asked, then deployed and smoke-tested (only after approval)
- [ ] 7. Release record written, check_release.py → PASS
```

### 1. Scope
- List the tickets in the release by id, under `Included:`. Each must be `done` in the backlog and `APPROVE` in its review. A ticket that is not ready is deferred, not included.
- List every other ticket under `Deferred:`. The gate fails a backlog ticket that is in neither list.
- Give the release a version (semantic: `0.1.0`). Keep the first release small: a skeleton and the answered spikes are a valid 0.1.0.

### 2. Build
- Identify the commit: `git rev-parse --short HEAD`, and confirm the working tree is clean (`git status`).
- CI must pass on that commit. Read the pipeline's result for that commit; do not assume it from a local run. A local test run is evidence for the reviewer, not for the release.
- Record `Commit:` and `CI: pass`. If CI failed or has not run, the release stops here.

### 3. Migrations
- List the schema migrations this release adds. Write `none` if there are none.
- For each migration: can it run on a database that already has data? Does it lock a large table? Is there a reverse step? A migration with no reverse step is written in the Rollback section, with what the team does instead (usually a forward fix).
- Migrations run in the platform's pre-deploy step, as the design says. Check that before staging.

### 4. Configuration and secrets
- Every secret the release needs (for example `SECRET_KEY`, `DATABASE_URL`, the e-mail provider's token) lives in the platform's environment variables. Record their names in the release record, never their values.
- Run `python <this-skill-dir>/scripts/check_release.py docs/releases/<slug>-<version>.md --scan-secrets`. It scans the tracked files for keys and literal passwords. A hit is a stop: remove the secret, rotate it, then rerun.

### 5. Staging
- Deploy through the pipeline the design describes. The agent asks before any push or merge that starts it.
- Run the smoke test: the health page, the root page, and the release's main path in one line each. Record `Smoke test: pass` with the date and the URL. A failing smoke test stops the release and goes back to factory-implement.
- Staging must use the test mode of external services (the design's staging note: the e-mail provider in test mode, so no real patient receives a message).

### 6. Production
- Before deploying, ask the owner for approval in one short message: the version, the scope, the migrations, the rollback. Wait for an explicit yes.
- Record the approver's name in `Approved by:` and the date in `Deployed at:`.
- Deploy through the promotion step the design describes, then run the smoke test again. Record the result.
- If the owner has not approved, the record says `Stage: staging` and `Pending approval` under Production. That is a complete, valid state.

### 7. Record and check
Use [references/release-template.md](references/release-template.md) for `docs/releases/<slug>-<version>.md`, then:

```bash
python <this-skill-dir>/scripts/check_release.py docs/releases/<slug>-<version>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: a ticket that is not done, a missing CI pass, no rollback steps, no smoke test, a production stage with no approver. |
| `NEEDS-ANSWERS` | 2 | *Open questions* is not empty. Ask them, with recommended answers. |
| `PASS` | 0 | Report the state (staging or production) to the user. |

## Rollback

Write the rollback before the deploy, not after. It says:
- the **previous version** to redeploy (the last commit with a passing staging or production smoke test);
- the steps on the platform (for example "redeploy build X from the dashboard");
- what happens to migrations: the reverse migration if it exists, or the forward fix that the team applies.

Rolling back is an action the user approves like a deploy.

## Ticket store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the release scope comes from the database:

- `ticket_list(project, status="done")` gives the candidates for `Included:`. Any ticket you include that is not `done` is a blocker. The rest go under `Deferred:`.
- `check_release.py` reads the backlog **file**, not the database. Use `project_check_release(project, release_path)`: it exports the backlog and then runs the gate in one call. If you run the gate by hand, run `project_export_markdown(project)` first, or it checks the old statuses.
- `events_list(project, ticket_id)` shows the evidence behind each `done`.
- Before anything that reaches an external tracker, run `sync_plan(project)` (a dry run) and show the actions to the user. Run `sync_apply(project)` only after the user says yes for that sync. This is the same confirmation rule as the hard limits above. The staging and production deploys are not done by these tools.

## Gotchas

- Shipping the working tree instead of a commit. The release is a commit; anything not committed is not in it.
- Treating a green local run as CI. Read the pipeline result for the commit.
- Writing `Approved by:` for the owner. Only the owner's own message counts; the agent records it, it does not fill it in.
- Running the data import (RF-15) or the cutover in the same step as a deploy. A cutover is its own release record, with its own rollback: the paper spreadsheet stays as the fallback until the owner says otherwise.
- Skipping the smoke test on production because staging passed. Production is a different environment with its own secrets and data.
