# Release Template

Save as `docs/releases/<slug>-<version>.md`. Keep the headings, the header labels and the `Stage:` values as they are, because `scripts/check_release.py` reads them. Write the content in the user's language. Never write a value for `Approved by:` on the owner's behalf.

````markdown
# Release: <name> <version>

Tickets: docs/tickets/<slug>.md
Design: docs/design/<slug>.md
Version: 0.1.0
Stage: staging
Date: YYYY-MM-DD

## Scope

Included: T-01, T-02
Deferred: T-03, T-04, T-05 (<reason, for example: booking comes in 0.2.0>)

<One or two lines on what this release gives the users.>

## Build

- Commit: 3f2a9c1d
- CI: pass (<pipeline and run link>)
- Artifact: <what the platform built from the commit>

## Migrations

None. <or a list: migration name, what it changes, whether it locks a large table>

## Configuration

- Secrets in repository: none
- Environment variables set on the platform for staging: <names only, never values>

## Staging

- URL: <staging URL>
- Deployed at: YYYY-MM-DD
- Smoke test: pass (<health page, root page, the release's main path>)

## Production

Pending approval.

<When production is done, replace the line above with:>
- Approved by: <owner's name, from the owner's message>
- Deployed at: YYYY-MM-DD
- Smoke test: pass (<what was checked>)

## Rollback

Previous version: <version and commit>. <Steps on the platform to redeploy it.> <What happens to migrations: reverse step, or forward fix.>

## Open questions

None
````

## Field values

- **Version:** semantic, `MAJOR.MINOR.PATCH`.
- **Stage:** `staging` or `production`. When it is `staging`, the Production section says `Pending approval`.
- **Included / Deferred:** ticket ids from the backlog. A ticket is in exactly one of the two lists, and every included ticket is `done`.
- **Commit:** 7 to 40 hexadecimal characters.
- **CI:** `pass` only, from the pipeline run for that commit.
- **Smoke test:** `pass` only, after the deploy.
- **Secrets in repository:** `none`. The secrets' names go under Configuration; their values never do.

## Portuguese aliases

Headings: `Escopo`, `Build`, `Migrações`, `Configuração`, `Staging`, `Produção`, `Rollback`, `Perguntas em aberto`. Header labels and the Included/Deferred/Commit/CI/Smoke test/Approved by fields stay in English; the checker reads them.
