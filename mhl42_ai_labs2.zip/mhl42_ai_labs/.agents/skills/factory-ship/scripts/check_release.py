#!/usr/bin/env python3
"""Quality gate for a release record written from references/release-template.md.

Checks the release record's structure and its evidence: every ticket it includes is done in the
backlog and every other ticket is listed as deferred; the build has a commit and a passing CI run;
the migrations and rollback steps are written; staging has a passing smoke test before production;
production is only recorded as released with a named approver; and, with --scan-secrets, the
tracked files contain no obvious secrets. Open questions block with NEEDS-ANSWERS.

Usage:
  python check_release.py docs/releases/<slug>-<version>.md
  python check_release.py docs/releases/<slug>-<version>.md --scan-secrets

Exit codes: 0 = PASS, 1 = FAIL, 2 = NEEDS-ANSWERS.
"""

from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

STAGES = ("staging", "production")
REQUIRED_SECTIONS = ("scope", "build", "migrations", "configuration", "staging", "production", "rollback")
SECTION_ALIASES = {
    "scope": ("scope", "escopo"),
    "build": ("build", "build e ci"),
    "migrations": ("migrations", "migrações", "migracoes"),
    "configuration": ("configuration", "configuração", "configuracao"),
    "staging": ("staging",),
    "production": ("production", "produção", "producao"),
    "rollback": ("rollback", "reversão", "reversao"),
    "open questions": ("open questions", "perguntas em aberto"),
}
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
TICKET_RE = re.compile(r"^###\s+(T-\d+)\s*[:—–-]", re.MULTILINE)
STATUS_RE = re.compile(r"^Status:\s*(\S+)", re.MULTILINE | re.IGNORECASE)
PLACEHOLDER_RE = re.compile(r"\bTBD\b|\bTODO\b|\?\?\?", re.IGNORECASE)
TICKET_ID_RE = re.compile(r"T-\d+")
SECRET_PATTERNS = [
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN (RSA |EC |OPENSSH |)PRIVATE KEY-----"),
    re.compile(r"(?i)(secret_key|api[_-]?key|password|token)\s*=\s*['\"][^'\"\s]{12,}['\"]"),
]
SCAN_SKIP_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".pdf", ".zip", ".woff", ".woff2"}


def normalise_section(heading: str) -> str:
    name = re.sub(r"\(.*?\)", "", heading).strip().lower()
    for canonical, aliases in SECTION_ALIASES.items():
        if name in aliases:
            return canonical
    return name


def sections(text: str) -> dict[str, str]:
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        found[normalise_section(match.group(1))] = text[match.end() : end]
    return found


def header_value(text: str, key: str) -> str:
    match = re.search(rf"^{key}:\s*(.+?)\s*$", text, re.MULTILINE | re.IGNORECASE)
    return match.group(1) if match else ""


def resolve(ref: str, spec: Path) -> Path | None:
    for parent in [spec.parent, *spec.parents]:
        candidate = parent / ref
        if candidate.is_file():
            return candidate
    return None


def ticket_ids_after(scope: str, label: str) -> set[str]:
    match = re.search(rf"^\s*-?\s*{label}:(.*)$", scope, re.IGNORECASE | re.MULTILINE)
    return set(TICKET_ID_RE.findall(match.group(1))) if match else set()


def ticket_statuses(tickets_text: str) -> dict[str, str]:
    statuses: dict[str, str] = {}
    matches = list(TICKET_RE.finditer(tickets_text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(tickets_text)
        status = STATUS_RE.search(tickets_text, match.end(), end)
        statuses[match.group(1)] = status.group(1).lower() if status else "todo"
    return statuses


def scan_secrets(start: Path) -> list[str]:
    try:
        repo = Path(
            subprocess.run(
                ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
                capture_output=True, text=True, check=True,
            ).stdout.strip()
        )
        # Tracked files plus untracked files that git does not ignore: a new file with a secret must not slip through.
        listing = subprocess.run(
            ["git", "-C", str(repo), "ls-files", "--cached", "--others", "--exclude-standard"],
            capture_output=True, text=True, check=True,
        ).stdout.splitlines()
    except (OSError, subprocess.CalledProcessError):
        return ["--scan-secrets needs a git repository with tracked files"]
    hits = []
    for name in listing:
        path = repo / name
        if path.suffix.lower() in SCAN_SKIP_SUFFIXES or not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for number, line in enumerate(text.splitlines(), start=1):
            if any(pattern.search(line) for pattern in SECRET_PATTERNS):
                hits.append(f"possible secret in {name}:{number}")
    return hits


def check(path: Path, do_scan: bool) -> tuple[list[str], list[str]]:
    failures: list[str] = []
    pending: list[str] = []
    text = path.read_text(encoding="utf-8")
    body = sections(text)

    version = header_value(text, "Version")
    if not re.fullmatch(r"\d+\.\d+\.\d+", version):
        failures.append("header: Version must be semantic, like 0.1.0")

    stage = header_value(text, "Stage").lower()
    if stage not in STAGES:
        failures.append("header: Stage must be 'staging' or 'production'")

    tickets_ref = header_value(text, "Tickets")
    tickets_path = resolve(tickets_ref, path) if tickets_ref else None
    if not tickets_ref:
        failures.append("header: missing 'Tickets: <path>'")
    elif tickets_path is None:
        failures.append(f"header: tickets file not found at {tickets_ref}")

    for name in REQUIRED_SECTIONS:
        if not body.get(name, "").strip():
            failures.append(f"missing section '## {name.capitalize()}'")

    # Scope: included tickets must be done; every backlog ticket must be included or deferred.
    scope = body.get("scope", "")
    included = ticket_ids_after(scope, "Included")
    deferred = ticket_ids_after(scope, "Deferred")
    if not included:
        failures.append("Scope needs an 'Included:' line with the ticket ids in this release")
    if tickets_path is not None:
        statuses = ticket_statuses(tickets_path.read_text(encoding="utf-8"))
        for tid in sorted(included):
            if statuses.get(tid) != "done":
                failures.append(f"{tid} is in this release but is '{statuses.get(tid, 'missing')}' in the backlog, not done")
        for tid in sorted(set(statuses) - included - deferred):
            failures.append(f"{tid} is neither included nor deferred in Scope")
        for tid in sorted(deferred & included):
            failures.append(f"{tid} is both included and deferred")

    build = body.get("build", "")
    if not re.search(r"^\s*-?\s*Commit:\s*[0-9a-f]{7,40}\b", build, re.IGNORECASE | re.MULTILINE):
        failures.append("Build needs 'Commit: <hash>' (7 to 40 hex characters)")
    if not re.search(r"^\s*-?\s*CI:\s*pass\b", build, re.IGNORECASE | re.MULTILINE):
        failures.append("Build needs 'CI: pass' from the pipeline run (a failing or missing run blocks the release)")

    if not body.get("migrations", "").strip():
        failures.append("Migrations: write the migrations in this release, or 'none'")
    rollback = body.get("rollback", "")
    if not re.search(r"^\s*-?\s*(Previous version|Versão anterior):", rollback, re.IGNORECASE | re.MULTILINE):
        failures.append("Rollback needs 'Previous version: <version>'")
    if len(rollback.strip()) < 40:
        failures.append("Rollback needs the steps, not only the version: what to redeploy and what to do with migrations")

    staging = body.get("staging", "")
    if not re.search(r"^\s*-?\s*Smoke test:\s*pass\b", staging, re.IGNORECASE | re.MULTILINE):
        failures.append("Staging needs 'Smoke test: pass' (health page and the release's main path) before any production step")

    production = body.get("production", "")
    if stage == "production":
        if not re.search(r"^\s*-?\s*Approved by:\s*\S.*", production, re.IGNORECASE | re.MULTILINE):
            failures.append("Production needs 'Approved by: <name>' from the owner; the agent cannot approve a production deploy")
        if not re.search(r"^\s*-?\s*Deployed at:\s*\d{4}-\d{2}-\d{2}", production, re.IGNORECASE | re.MULTILINE):
            failures.append("Production needs 'Deployed at: YYYY-MM-DD' once the deploy has run")
        if not re.search(r"^\s*-?\s*Smoke test:\s*pass\b", production, re.IGNORECASE | re.MULTILINE):
            failures.append("Production needs 'Smoke test: pass' after the deploy")
    elif not re.search(r"pending approval|aguardando aprovação|aguardando aprovacao", production, re.IGNORECASE):
        failures.append("Stage is staging, so Production must say 'pending approval' and nothing else")

    configuration = body.get("configuration", "")
    if not re.search(r"^\s*-?\s*Secrets in repository:\s*none\b", configuration, re.IGNORECASE | re.MULTILINE):
        failures.append("Configuration needs 'Secrets in repository: none' (secrets live in the platform's environment variables)")

    if PLACEHOLDER_RE.search(text):
        failures.append("the release record still has placeholders (TBD, TODO or ???)")

    if do_scan:
        failures.extend(scan_secrets(path.resolve().parent))

    open_questions = body.get("open questions", "").strip()
    if open_questions and open_questions.lower() not in ("none", "nenhuma", "nenhum", "-"):
        pending.append("open questions remain; ask them in one numbered round with recommended answers")

    return failures, pending


def main() -> int:
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if len(args) != 1:
        print(__doc__, file=sys.stderr)
        return 1
    path = Path(args[0])
    if not path.is_file():
        print(f"Error: {path} not found", file=sys.stderr)
        return 1
    failures, pending = check(path, do_scan="--scan-secrets" in sys.argv)
    if failures:
        print("FAIL")
        for item in failures:
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
