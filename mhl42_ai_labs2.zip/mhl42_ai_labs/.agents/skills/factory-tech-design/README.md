# factory-tech-design

Step 4 of the flow. From a confirmed PRD, decides the stack and architecture and writes `docs/design/<slug>.md`, plus one ADR per costly decision in `docs/adr/`. Uncertainties become spikes, which become the first tickets.

```
3 factory-prd-writer → 4 factory-tech-design ─┬─ FAIL → fix
                              ├─ NEEDS-ANSWERS → factory-grilling (costly decisions) / ask open questions
                              └─ PASS → confirm → tickets (spikes and project skeleton first)
```

## What it enforces

- **Drivers before choices.** Deadline, team, compliance, volume, and NFR thresholds are listed first, and every stack row cites them (`RNF-02`, `brief:constraints#2`) or the existing code (`existing:pyproject.toml`).
- **Boring by default.** One deployable app and managed services for small teams.
- **Architecture decisions per dimension.** Deployment, code organization, data and integration, and interface are decided separately, one row each, against `references/architecture-catalog.json`: costly patterns (services, CQRS, event sourcing, saga, micro-frontends) need a requirement that asks for them, an alternative and an ADR; a small project raises the bar; antipatterns the document shows (a table with two owners, a foreign key across services, a saga with one deployable unit) fail; a pattern named in the text but not declared gets a warning.
- **Alternatives and ADRs.** Each stack choice names an alternative that lost. Costly-to-reverse choices need an ADR with Context, Decision, Alternatives, and Consequences.
- **Coverage.** Every FR is served by a component, and every NFR has a row saying how it is met and how to verify it.
- **Existing projects stay as they are.** In `existing` mode the current stack is a fact, cited from the repository, and only new parts are decided.
- **No new scope.** Components the PRD does not ask for go to open questions.

## Files

```
factory-tech-design/
├── SKILL.md
├── references/
│   ├── design-template.md   # Template, field values, Portuguese aliases
│   ├── adr-template.md      # ADR format
│   ├── choosing.md          # Decision order, heuristics, architecture styles, NFR → design, spikes
│   ├── architecture-styles.md   # The catalog for the agent: each style and pattern, evidence, costs
│   └── architecture-catalog.json # The same entries as rules for the checker (severity, evidence, needs)
├── scripts/
│   └── check_design.py      # Exit 0 PASS, 1 FAIL, 2 NEEDS-ANSWERS
└── evals/
    ├── evals.json           # New project, existing Django project, pushback on microservices
    ├── trigger_queries.json
    (fixtures: ../../evals/fixtures/)
```

## Run the checker

```bash
python scripts/check_design.py docs/design/<slug>.md
```
