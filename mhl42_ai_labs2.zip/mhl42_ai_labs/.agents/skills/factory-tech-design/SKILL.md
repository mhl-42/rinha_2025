---
name: factory-tech-design
description: Use this skill to decide the architecture and the engineering for a confirmed PRD before it is broken into tickets — first the architecture (drivers, up to three viable options compared on them, a recommendation the user approves, ADRs), then the engineering (stack and versions, components, data model mapped from the domain model, persistence and consistency, where each business rule is enforced, errors and observability, test strategy, deployment) and spikes for what is uncertain — for a new project or a feature in an existing codebase. Triggers on "what stack should we use", "which database and framework", "design the architecture for this PRD", "technical design", "desenho técnico", "qual stack / banco / framework usar", "como vamos construir isso". Not for writing the PRD (use factory-prd-writer), for breaking work into tickets (use factory-prd-to-tickets), or for implementing code.
license: MIT
compatibility: scripts/check_design.py needs Python 3.10+ (no dependencies). Expects the PRD format of factory-prd-writer and, when the PRD links one, the domain model of factory-domain-model. Uses the factory-grilling skill for costly decisions when installed.
metadata:
  author: mhl42
  version: "1.7.0"
---

# Tech Design

Decide **how** to build what the PRD describes, in two phases. **Architecture** first: the drivers, the options that are really viable, and a recommendation the user approves. **Engineering** second: stack and versions, components, data model, persistence and consistency, where each business rule is enforced, errors, tests and deployment. Record each decision that is costly to reverse in an ADR, and turn each uncertainty into a spike. The tickets are cut from this design.

The two phases stay in one skill and one document on purpose: for the small teams this factory targets, a separate architecture document would be a handoff with little in it. The checkpoint between them is the user's choice of architecture.

This is step 4 of the flow:

```
1 factory-idea-interview → 2 factory-idea-synthesis → brief → 2b factory-domain-model → 3 factory-prd-writer → 4 factory-tech-design → tickets → build
```

Write the documents in the user's language.

## Before you start

- **PRD:** `docs/prd/<slug>.md` with `Status: confirmed`. If it is missing or not confirmed, stop and send the user to factory-prd-writer.
- **Domain model:** the `Domain:` file the PRD links (`docs/domain/<slug>.md`), confirmed. Its entities, lifecycles and rules are the input of the data model and of *Rule enforcement*. Put the same path in the design header.
- **Mode:**
  - **Existing project (brownfield):** the repository has a manifest (`pyproject.toml`, `package.json`, `go.mod`, `pom.xml`...) or application code. The current stack is a **fact**: read it, record it with `existing:<file>` sources, and decide only what is new. Do not propose rewrites or a second framework.
  - **New project (greenfield):** choose the stack from the PRD's constraints and NFRs.
- **Platforms:** once the interface is chosen, write it in the header, comma-separated: `web`, `mobile`, `desktop`, `tui` (a full-screen terminal program), `cli` (commands and prompts in a terminal) or `chat` (a messaging bot or a voice assistant); or `Platforms: none` only when nobody operates the product by hand (a library, an API for other programs, a scheduled job). It decides the next step: a product with a user interface goes through factory-ui-design before the tickets. factory-ui-design's references/platforms.md maps other interfaces (kiosk, TV, smartwatch, browser extension) to these.

## Workflow

```
- [ ] 1. Inputs checked; mode decided (existing or new)
- [ ] 2. Drivers listed: the constraints, NFRs and quality attributes that shape the design
- [ ] 3. Phase 1: viable architecture options compared on the drivers; recommendation; user's choice; Architecture decisions per dimension
- [ ] 4. Phase 2: stack and versions, components, data model, persistence, rule enforcement, integrations, errors, tests, NFR coverage, deployment
- [ ] 5. ADRs for costly decisions; spikes for uncertainties
- [ ] 6. check_design.py → PASS (stress-test costly decisions with factory-grilling if listed)
- [ ] 7. User confirms; status set to confirmed
```

### 2. Drivers first
List the facts that will decide the design before choosing anything: deadline and team size, the skills the team has, compliance rules, expected volume, budget, mandatory platforms, and the NFR thresholds. Each driver cites the PRD (`RNF-02`, `brief:constraints#2`). A design whose choices do not trace back to drivers is a fashion choice.

### 3. Phase 1: choose the architecture
Follow [references/choosing.md](references/choosing.md#comparing-architecture-options). Write *Architecture options*: up to three options that are really viable, each with its pros, cons, operating cost, consequences for tests, persistence and evolution, and risks, compared on the drivers. Do not force three when one is clearly adequate, and do not propose microservices, DDD, event sourcing or queues because they are well known. Recommend one, and when the choice is significant, **stop and ask the user to choose** before writing Phase 2. A technology the brief recorded as a preference is one of the options, not the answer. The brief's *Depth* sets the effort: for `small` and `medium`, one option with the reason the others are not viable is normal; for `complex`, the gray areas become spikes before the choice. In short:
- **Prefer the boring option** the team already knows and that meets the drivers. Every unfamiliar technology needs a driver that justifies it.
- **Default to one deployable unit** (a modular monolith) and managed services for small teams. Splitting into services, adding queues, or adopting Kubernetes needs an NFR that requires it (scale, isolation, independent deploys), not a guess about the future.
- **Each stack row lists at least one alternative** and why it lost.

Then write *Architecture decisions*: one row per decision, in four dimensions decided separately (deployment, code organization, data and integration, interface), each choice taken from [references/architecture-styles.md](references/architecture-styles.md) with the requirement that needs it as its Driver. Read the entry before choosing: its evidence, its costs, the simpler alternatives, and the questions the ADR must answer. A pattern the catalog marks for review (services, CQRS, event sourcing, saga, micro-frontends, server-driven UI, or anything outside the catalog) needs a driver whose requirement really asks for it, an alternative and an ADR; for a `small` project, queues, serverless and hexagonal are held to the same bar. What a pattern adds (an Owner per table with services, a read model with CQRS, idempotency criteria with queues) goes into the sections of Phase 2.

If a decision is costly to reverse (language, framework, database, hosting, data model, auth, a paid vendor), mark it and write an ADR from [references/adr-template.md](references/adr-template.md) in `docs/adr/NNNN-<title>.md`.

### 4. Phase 2: write the engineering
Copy [references/design-template.md](references/design-template.md) to `docs/design/<slug>.md` and fill it. Check each library's current version and its compatibility in its official documentation, and write the version; an API or a compatibility you could not verify becomes a spike.
- **Components:** each one lists the FRs it serves. Every FR must be served. Prefer a layout with no file that every feature must edit (one module per screen, one file per migration): see *No single point of editing* in [references/choosing.md](references/choosing.md).
- **Data model:** column by column (Table, Column, Type, Null, Key, From), from the domain model's entities and their *Attributes*, not from every noun. Each column's *From* names the domain attribute (`Entity.attribute`), the rule, or `technical`; every table has a primary key and every foreign key points to a table of the model. A concept can become a table, a value inside another record, or derived data; say which (see *From the domain to the data* in [references/choosing.md](references/choosing.md)). Lifecycle states become status fields or derived data. Apply privacy NFRs here: fields that must not exist are as important as the ones that do.
- **Persistence and consistency:** the store (or "None" and what that means for the user), transaction boundaries, concurrency, integrity constraints, migrations, retention and backup.
- **Rule enforcement:** one row per confirmed business rule: the component (and database constraint) where it holds, and the test that proves it.
- **Errors and observability:** what the user sees when something fails, what is logged, what is never logged. For a product that runs in production beyond a script, the full telemetry design (SLOs, metrics, alerts, dashboards, storage) is the next document: `factory-observability`.
- **Test strategy:** the levels, the test data, how time and randomness are controlled, and what only a person can check.
- **Integrations:** what each external system is for, and what the product does when it fails.
- **NFR coverage:** one row per NFR, saying how the design meets it and **how to verify** it (a test, a measurement, a review).
- **Deployment:** environments, hosting, CI/CD, backups, and secrets.
- **Risks and spikes:** anything you are not sure will work (a vendor's API, deliverability, performance at the stated volume) becomes a spike, with a question, an exit criterion, and a timebox. Spikes become the first tickets.

**Do not add scope.** An admin panel, analytics, a mobile app, or observability dashboards that the PRD does not ask for go to *Open questions*, not into components.

### 6. Check
```bash
python <this-skill-dir>/scripts/check_design.py docs/design/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: an FR not served, an NFR not covered, a stack choice without alternatives or source, a costly decision without an ADR, an incomplete spike, unknown PRD references, a domain entity with no place in the data model, a confirmed domain attribute with no column, a table without a primary key, a foreign key to an unknown table, a column without its Null or From, a confirmed rule with no row in *Rule enforcement*, an architecture decision in the wrong dimension or without the driver, alternative or ADR its catalog entry asks for, a pattern without the one it needs (a saga with one deployable unit), a table with two owners or a foreign key across services. |
| `NEEDS-ANSWERS` | 2 | *Decisions to stress-test* or *Open questions* are not empty. Run the `factory-grilling` skill in scoped mode on the decisions (it updates this document), and ask the open questions in one numbered round with recommended answers. |
| `PASS` | 0 | Confirm. |

### 7. Confirm
When the PRD or the brief says the user enters data through a user interface, show at least two interface options before confirming (for example a plain command line and a text UI, or a web page and a desktop window), with what each one does to the constraints and the deadline, and let the user choose. An interface that the PRD does not fix is a decision, not a default.

Show the stack table, the architecture in two or three sentences, the ADR list, and the spikes, and ask for explicit confirmation together with any remaining questions. Then set `Status: confirmed` and offer the next step, chosen by the `Platforms:` header:
- **`web`, `mobile`, `desktop`, `tui`, `cli` or `chat`:** the interface comes first: the `factory-ui-design` skill (step 4b), which writes `docs/ux/<slug>.md`. Do not offer the tickets yet; the tickets gate fails without a confirmed UI spec.
- **`none`:** breaking the PRD and this design into tickets (the `factory-prd-to-tickets` skill), with the spikes and the project skeleton first.

## Language skills

When the language's rule skills are installed, they hold the detailed rules. Use them instead of restating them here. For Python: `python-tooling` for the project skeleton and CI, `python-database` for the data model and migrations (no ORM by default), `python-security` for secrets, auth, and outbound calls. For TypeScript, JavaScript, Go, Rust and Swift: the `<language>-coding-standards` skill (errors, concurrency, security, configuration) and `<language>-testing` (`typescript-testing` for JavaScript). With PostgreSQL in any stack: `postgres-database` for column types, keys, migrations on live tables, transactions and roles. The design says *what* is used; those skills say *how* to use it well.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Read the inputs with `doc_read`, or single ids with `item_get` (the definition and everything that cites it), instead of opening the files.
- Write with `doc_write(project, "design", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run.
- Each ADR is its own document: `doc_write(project, "adr", "NNNN-<title>", ...)`. It is stored as `proposed` (`proposto`) and becomes `accepted` (`aceito`) with `doc_confirm(project, "adr", "NNNN-<title>", revision, user_answer)`. Take the next ADR number from the manifest, never by guessing.
- Confirm with `doc_confirm(project, "design", <slug>, revision, user_answer)` after the user's yes, passing their reply verbatim, instead of editing the Status line. Show them the revision you confirm. It refuses while an input is not confirmed, the document cites an item that changed after it (`stale` in the manifest: rewrite the citing text, or `stale_resolve` with a note when it still holds), or the gate fails on the confirmed text; read the refusal to the user.

## Gotchas

- Agents propose the architecture of a large company: microservices, Kubernetes, Kafka, event sourcing. For one or two developers with a deadline, that is a project risk, not a quality. Declare each in *Architecture decisions* with the requirement that needs it, or remove it; the checker warns about one named in the text and not declared.
- One word is not an architecture. "Microservices with CQRS" is two decisions in two dimensions, each with its own driver, and either can be dropped without the other.
- The checker reads the requirement the Driver cites, not the Driver cell: a CQRS justified by "RNF-01: store no names" fails, because nothing in it asks for separate reads.
- "Scalable" is not a driver. Use the volume from the PRD or brief (users, requests, records per day). If there is none, ask.
- In an existing project, the stack is not up for discussion unless the PRD makes it impossible to meet an NFR. Then write that as a decision to stress-test, with the evidence.
- A privacy NFR ("store only name and e-mail") must show up in the data model as the **absence** of fields, and in the NFR coverage with a verification (for example, a schema test).
- An integration without a failure mode is a future incident. Say what the user sees when the e-mail provider, the SSO, or the LLM API is down.
- Do not write code or project scaffolding here. The skeleton is the first ticket.
- A stack chosen in the interview arrives as a fact and gets ratified. In `supermercado-pdv`, the language row's reason was "the brief fixes Python", although the user had only accepted a recommendation. Ask whether it is a rule or a preference, and compare options when it is a preference.
- Turning every domain noun into a table, or every table into a class, copies the vocabulary without deciding anything. A balance computed from movements, or a receipt that is only a view of a closed sale, needs no table of its own.
- A failure mode written only in *Integrations* or *Errors* gets lost on the way to the tickets. Say it as behaviour ("the program shows the cause and exits with code 2"), so factory-prd-to-tickets can turn it into a criterion.
