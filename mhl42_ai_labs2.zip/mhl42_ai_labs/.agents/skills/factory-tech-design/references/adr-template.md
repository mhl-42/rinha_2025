# ADR Template

One file per costly decision: `docs/adr/NNNN-<short-title>.md`, numbered in order. ADRs are not edited after acceptance. A later change gets a new ADR that says `Supersedes: NNNN`.

```markdown
# ADR 0001: Use Django for the booking system

Status: proposed
Date: YYYY-MM-DD
Design: docs/design/<slug>.md

## Context
<!-- The drivers that force a decision, citing the PRD (RNF-02, RF-12). What happens if we choose badly. -->

## Decision
<!-- What we will do, in one or two sentences. -->

## Alternatives considered
- <alternative> — <why it lost, tied to a driver>

## Consequences
<!-- What becomes easier, what becomes harder, and what we commit to (skills, costs, lock-in). -->
```

`Status` is `proposed` until the design is confirmed, then `accepted`.

Portuguese headings: `Contexto`, `Decisão`, `Alternativas consideradas`, `Consequências`. Status values: `proposto`, `aceito`.

`scripts/check_design.py` checks that each ADR referenced by a costly stack row exists and has the four sections.
