# Architecture Styles and Patterns

The catalog behind *Architecture decisions*. Each entry says when to consider it, when to avoid it, the evidence in the PRD that justifies it, what it costs, and what it adds to the design. The rules the gate applies (severity, the evidence words, what a pattern needs) live in [architecture-catalog.json](architecture-catalog.json); the ids in backquotes are the same.

## Contents
- Four dimensions, decided separately
- How the gate reads a decision
- Deployment
- Code organization
- Data and integration
- Interface
- Antipatterns
- Outside the catalog

## Four dimensions, decided separately

An architecture is not one word. Decide each dimension on its own, because they combine freely: a modular monolith can be hexagonal inside, use CQRS for its reports, and render its pages on the server.

| Dimension | Question | Typical choices |
|-----------|----------|-----------------|
| **Deployment** | How many units are deployed and run? | modular monolith, service-based, microservices, serverless |
| **Code organization** | How is the code of one unit arranged? | layered, hexagonal, vertical slice, plugin |
| **Data and integration** | How do data and work flow between parts? | none (local transactions), event-driven, CQRS, event sourcing, saga, outbox, batch |
| **Interface** | How is the user interface built and served? | server rendering, SPA, MVC/MVVM, BFF, micro-frontends |

CQRS does not need event sourcing, and event-driven work does not need microservices: a modular monolith with a job queue is event-driven. Choose them separately and give each its own driver.

Design patterns and principles (Strategy, Repository, dependency injection, SOLID) are local decisions taken while building a ticket. They do not go in *Architecture decisions*; factory-review checks them in the code.

## How the gate reads a decision

One row per decision in *Architecture decisions*: `Dimension | Choice | Driver | Alternatives | ADR`. The Choice names one entry of this catalog (in English or Portuguese); a second pattern of the same dimension goes in its own row.

| Severity | What the gate asks |
|----------|--------------------|
| `info` | Nothing beyond the row. The defaults live here. |
| `advisory` | A warning when the Driver cites nothing. |
| `review` | A Driver that cites a PRD requirement or the brief, whose text carries the entry's evidence; at least one alternative; an ADR with its four sections. Otherwise it fails. |
| `blocking` | Always fails: an antipattern, or a pattern without the one it needs (a saga with one deployable unit). |

For a project whose brief has `Size: small`, some entries are stricter (`severity_small`): event-driven, serverless and hexagonal cost more than a small project can repay.

The gate does not judge whether the ADR answers the entry's questions well. Answer them in the ADR's *Context* and *Consequences*; factory-grilling stress-tests the answers when the decision is in *Decisions to stress-test*.

A pattern named in the design text but missing from *Architecture decisions* gets a warning: declare it, or take it out. Mentions inside *Architecture options* and in Alternatives cells are fine; they are what was compared.

## Deployment

### Modular monolith (`modular-monolith`)
One codebase, one deploy, modules with explicit boundaries (one per component). **The default** for new projects and small teams: one transaction for a whole operation, one place to test, one thing to run. A local CLI or desktop program is a monolith too.
- **Avoid when:** an NFR requires parts to scale, fail or be released separately.
- **Adds:** one module per component; a rule for which module may import which.

### Service-based architecture (`service-based`)
A few coarse services (two to six), each owning its data. The middle step when one unit no longer meets a requirement and microservices would be too much.
- **Evidence:** a requirement for independent release, isolation (compliance, a risky integration), different scaling, or separate teams.
- **Costs:** remote calls, partial failures, more deploys and monitoring.
- **Adds:** an `Owner` column in the Data model; what each call does when the other service is down.

### Microservices (`microservices`)
Many small services deployed independently, each with its own data and team.
- **Evidence:** teams that must release independently, isolation or scaling that differs per part. "It will scale" is not evidence.
- **Questions:** Is independent deployment a real need? What are the bounded contexts and who owns each one's data? How are timeouts, retries, duplicates and partial failures handled? How are transactions across services coordinated? Can the team run and observe every service?
- **Costs:** network failures, eventual consistency, distributed tests and tracing, an operating cost per service. For one or two developers with a deadline, a project risk.
- **Adds:** ADR; an `Owner` per table; a spike on the riskiest call; ticket criteria for timeouts and retries.

### Serverless (`serverless`)
Functions or managed services run on demand.
- **Evidence:** spiky or rare load, a cost requirement that rewards paying per use.
- **Costs:** cold starts, execution limits, vendor lock-in, harder local debugging.
- **Adds:** NFR coverage for latency including cold starts.

### Space-based architecture (`space-based`)
Processing and state spread over in-memory grids to remove a central database bottleneck.
- **Evidence:** a measured throughput or latency requirement that a database with caching cannot meet. Almost never for a CRUD.
- **Adds:** ADR; a load-test spike at the stated volume.

## Code organization

### Layered (n-tier) (`layered`)
Presentation, application, domain and infrastructure (or the classic three tiers). Simple and familiar; **the default** for CRUD and conventional business systems.
- **Avoid when:** features keep crossing every layer for one change; consider vertical slices.
- **Adds:** in *Architecture*, which layer may call which, and where the business rules live (not in controllers or SQL alone).

### Hexagonal / Clean / Onion (`hexagonal`)
The business rules do not depend on frameworks, databases or external services; adapters plug into ports. Related approaches, not identical.
- **Evidence:** a complex domain, rules that must be tested without the database, an external provider that must be replaceable (a payment gateway, a broker, a market data API).
- **Avoid when:** the project is a small CRUD: the ports are code to maintain with nothing to swap (premature abstraction).
- **Adds:** the ports and their adapters in *Components*.

### Vertical slice (`vertical-slice`)
Code grouped by use case or feature (one folder per screen or command) instead of by technical layer.
- **Fits:** use-case-driven apps and APIs, tickets built in parallel (it avoids a single point of editing).
- **Costs:** duplication between slices; shared rules need an owner.

### Plugin / Microkernel (`plugin`)
A small core with stable contracts; features added as plugins.
- **Evidence:** third parties or users add behaviour (IDEs, automation tools, pluggable strategies).
- **Costs:** a contract to keep stable; plugin failures inside the core.
- **Adds:** the plugin contract in *Components*; a test plugin in the *Test strategy*.

## Data and integration

`None` (local transactions only) is a valid choice, and the usual one for a monolith.

### Event-driven / queues (`event-driven`)
Components react to events or take work from a queue.
- **Evidence:** work that must survive a restart, be retried, run in the background, or be decoupled in time. A scheduled job is often enough.
- **Costs:** a broker to run; duplicates and ordering; harder end-to-end tests.
- **Adds:** idempotency and retry criteria for the tickets; a failure path (dead letters) in *Errors and observability*.

### CQRS (`cqrs`)
Separate models for writing and for reading.
- **Evidence:** reports, dashboards, search or listings much heavier or shaped differently from the writes.
- **Questions:** Is the asymmetry measurable? Is eventual consistency acceptable? Would a view or an index solve it?
- **Adds:** ADR; the read model (a projection, a materialized view) in the *Data model*; a consistency test.

### Event sourcing (`event-sourcing`)
The stored events are the source of truth; the state is rebuilt from them.
- **Evidence:** a requirement to rebuild past states, audit every change, or answer "what was true at time T". A history table written in the same transaction usually meets an audit requirement at a fraction of the cost.
- **Costs:** event versioning forever; queries need projections; unfamiliar to most teams.
- **Adds:** ADR; a spike on replay and event versioning.

### Saga (`saga`)
A business operation split into local steps across services, with a compensation for each.
- **Needs:** a distributed deployment (service-based, microservices). With one deployable unit, a local transaction does it.
- **Adds:** ADR; a ticket criterion per compensation; the in-progress states in the UI spec.

### Transactional outbox (`outbox`)
The business change and the event are written in the same local transaction; a relay publishes the event.
- **Needs:** events or queues declared (event-driven or services).
- **Adds:** idempotent consumers (at-least-once delivery).

### API composition (`api-composition`)
A query or screen combines data from several services.
- **Needs:** services. In a monolith, one query joins the data.
- **Adds:** what the screen shows when one source is slow or down.

### Pipes and filters (`pipes-and-filters`)
Processing as a chain of steps (imports, ETL, transformations).
- **Adds:** what happens to a record that fails halfway.

### Batch processing (`batch`)
Work done in scheduled runs instead of in real time.
- **Adds:** rerun and overlap behaviour; the age of the data shown to users.

## Interface

MVC, SPA and server rendering are not alternatives to one another: they describe different aspects and can coexist. Interface decisions apply only when `Platforms` names an interface.

### MVC / MVP / MVVM (`mvc`)
Separate model, view and the code between them. The usual structure of web frameworks and of desktop and mobile toolkits.

### Single-page application (`spa`)
The interface runs mostly in the browser. Costs: bundle size, client state, search engines.

### Server rendering (SSR / SSG / ISR / islands) (`ssr`)
Pages rendered or generated on the server, with islands of interactivity where needed. Usually the simplest web interface for forms and records.

### Backend for frontend (`bff`)
A backend per client (web, mobile).
- **Evidence:** two or more client platforms whose needs differ. With one platform it is duplication.

### Micro-frontends (`micro-frontends`)
The interface split into parts deployed independently.
- **Evidence:** several teams that must release parts of the interface independently.
- **Costs:** integration, versions, design system, performance.

### Server-driven UI (`server-driven-ui`)
The backend sends the structure of the screens.
- **Evidence:** screens that must change without a client release (app stores).
- **Costs:** coupling between the UI contract and every client version.

## Antipatterns

The gate detects the first three in the design document.

### Shared database between services (`shared-database`)
With a distributed deployment, every table has an `Owner` (a component). A table with two owners fails: one service owns it, the others call that service.

### Distributed monolith (`distributed-monolith`)
Services joined by foreign keys across owners, or released together. They pay the cost of distribution and keep the coupling of a monolith. The gate fails a foreign key between tables of different owners.

### Interface decision without an interface (`interface-without-ui`)
An *Interface* row when `Platforms: none`.

### Premature abstraction (`premature-abstraction`)
Ports, generic repositories and layers for a project that will never swap them. The catalog raises the severity of hexagonal for `Size: small`.

### Circular dependencies between modules (`circular-dependencies`)
Modules that import each other. A code property: factory-review checks it.

## Outside the catalog

Data mesh, lakehouse, blackboard, rule engines, the actor model, peer-to-peer, broker and master-worker architectures have no entry yet. A choice the catalog does not know is treated as `review`: a driver that cites the PRD or the brief, an alternative, and an ADR. Add an entry to the catalog (and a section here) when a real project needs one.
