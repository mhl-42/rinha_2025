# Choosing the Stack and Architecture

## Contents
- Order of decisions
- Comparing architecture options
- Heuristics
- Architecture style
- NFR to design
- Existing projects
- From the domain to the data
- Persistence and consistency
- Libraries and versions
- No single point of editing
- When to spike

## Order of decisions

Decide in this order, because each one constrains the next:
1. **Hosting and platform** (mandatory cloud, on-premise, budget)
2. **Language and framework** (team skills, deadline)
3. **Database** (data shape, consistency, volume)
4. **Architecture style and components**
5. **Integrations and their failure modes**
6. **Deployment and operations**

## Comparing architecture options

Present options only when more than one is really viable for these drivers. One clearly adequate option is written as one row with the reason the others are not viable; inventing two straw men to reach three is worse than none.

- **Up to three options**, each with: when it fits, pros, cons, operating cost (money and effort), what it does to tests, persistence and evolution, and its risks.
- **Compare on explicit criteria**, each one a driver with its source (`RNF-02`, `brief:constraints#1`). A criterion nobody stated ("future scale") is not a criterion.
- **Recommend one**, with the drivers that decide it. When the choice is significant (costly to reverse, or it changes cost, deadline or who can operate it), the user chooses before Phase 2 starts; record the choice in an ADR.
- Quality attributes to look for in the drivers: simplicity, maintainability, performance, security, availability, scalability, operating cost, deployment, team skills, distribution (who installs it), offline use.
- A technology fixed in the brief is a constraint only if the user said it is a hard rule. If it was a preference, it is one of the options, not the answer.

## Heuristics

| Situation | Default | Change only if |
|-----------|---------|----------------|
| 1–3 developers, deadline in weeks | One deployable app (modular monolith), managed database, a PaaS or one VM | An NFR needs isolation or independent scaling |
| CRUD with business rules and an admin | A batteries-included framework (Django, Rails, Laravel, Spring) | The team knows another stack better |
| Relational data with rules (bookings, money, stock) | PostgreSQL | A driver needs something else (e.g. embedded → SQLite) |
| Background work (reminders, digests) | A scheduled job or a task queue in the same app | Volume or latency proves it insufficient |
| Login for staff | The framework's auth, or the company SSO if it exists | — |
| Login for customers without passwords | E-mail magic link via the framework | Compliance needs MFA |
| Files | Managed object storage | — |
| Search over business data | The database's full-text search | Measured relevance or volume needs more |

Every technology the team does not know costs time. Count it against the deadline in the reason column.

## Architecture style

Decide four dimensions separately: **deployment** (modular monolith, services, serverless), **code organization** (layered, hexagonal, vertical slice, plugin), **data and integration** (none, event-driven, CQRS, event sourcing, saga, outbox, batch) and **interface** (server rendering, SPA, MVC, BFF, micro-frontends). They combine freely: CQRS does not need event sourcing, and a queue does not need microservices.

[architecture-styles.md](architecture-styles.md) has each entry: when to consider it, when to avoid it, the evidence in the PRD that justifies it, its costs, and what it adds to the design. In short:
- **Modular monolith** and **layered** are the defaults. Anything else needs a driver.
- **Separate services:** only for a stated NFR, such as different scaling profiles, an isolation/compliance boundary, or teams that must deploy independently. Each table then has one owner.
- **Event-driven / queues:** only when work must survive restarts, be retried, or be decoupled in time, and a scheduled job is not enough.
- **Serverless functions:** for spiky, rare workloads, when cold starts and vendor limits are acceptable.

Write the decisions in *Architecture decisions*, one row each, and the style in two to five sentences in *Architecture*, citing the drivers.

## NFR to design

| NFR kind | Where it lands in the design | Verification |
|----------|------------------------------|--------------|
| Privacy (store only X) | Data model has no other personal fields; logs and exports do not leak them | Schema test; log review |
| Performance (p95 < N ms at M users) | Indexes, caching, query design | Load test at M users |
| Availability | Hosting tier, backups, health checks | Uptime monitor; restore drill |
| Security / roles | Auth component, permission checks per role | Tests per role and endpoint |
| Accessibility | UI component library, font sizes, tap targets | Automated a11y check plus a manual test with the persona |
| Deadline / team | Fewer technologies, managed services | Plan review |
| Cost | Hosting and vendor choices with monthly estimate | Monthly bill vs. budget |

## Existing projects

- Read the manifests, settings, and main modules first. Cite them as `existing:<path>`.
- Extend the existing structure (apps, modules, packages). Follow its conventions even when you would choose differently.
- Propose a new technology only when the PRD cannot be met otherwise, as a *Decision to stress-test* with the evidence.

## From the domain to the data

The domain model says what exists and what must hold; the data model decides how it is stored. They are not the same list.

- **Not every noun is a table.** A concept with no identity of its own (an amount, a period, an address) is a value inside another record. A concept that is computed (a balance, a "vencido" flag) can be derived instead of stored; say which, and why.
- **States** of a lifecycle become a status field, a set of timestamps, or are derived from other data. Forbidden transitions become checks in code and, where cheap, in the database.
- **Invariants** become constraints (unique, foreign key, check) where the store supports them, and domain code where it does not. Name both in *Rule enforcement*.
- **History** the domain asks to keep (price at the time of the sale, who did what) is copied or made immutable, not looked up later.
- Every confirmed entity appears in *Data model*, or in *Persistence and consistency* with the reason it is not stored.
- **Attributes become columns.** Each confirmed attribute of the domain model (its *Attributes* section) becomes a column whose *From* names it (`Session.start`), unless it is calculated (then derived, or stored with the rule that keeps it in step) or there is a reason it is not stored. The business kind sets the type: `money` as integer cents or a fixed decimal, never a float; `date-time` with its time zone; `list of: <values>` as a check constraint or a lookup table; `reference → X` as a foreign key; `list of X` as a table of its own (a sale's lines), never ids packed in one column; `image` and `file` as a stored path or object key, not bytes in the row. *Required* sets `Null`, *Unique* sets a unique index (`within <scope>` makes it composite), *Changes* `no` is enforced in code and, where cheap, by the database.
- **Technical columns** (ids, foreign keys, `created_at`, `updated_at`, a version for optimistic locking, `deleted_at` for a soft delete) are added here, with `technical` in *From*.

## Persistence and consistency

Do not assume a database. Ask what must survive a restart, who reads it, and how much there is.

| Need | Usually |
|------|---------|
| Nothing survives the run (a converter, a calculator) | No persistence: say so, and what the user loses on exit |
| One user, one machine, structured data with rules | An embedded database (SQLite) or files with a schema |
| Several users or processes writing the same data | A server database with transactions (PostgreSQL) |
| Documents read whole, few cross-document rules | A document store, or JSON in a relational column |

Then decide: the operations that must be atomic (transaction boundaries), who can write concurrently and what happens on conflict, which integrity rules the store enforces, how the schema evolves (numbered migrations), and how long data is kept, backed up and restored.

## Libraries and versions

Look things up in this order, and stop at the first step that answers:

1. **The codebase:** what is already used, its conventions and versions (`existing:<path>`).
2. **The project's documents:** README, `docs/`, the ADRs, `docs/lessons.md`.
3. **The library's official documentation**, through a documentation tool when the host has one, or its site, package index and changelog.
4. **Other sources** on the web, preferring the maintainers' own.
5. **Uncertain:** when nothing above answers, write "not verified: <what and why>" and turn it into a spike. Never present a guess as a fact.

- Check the current version, its supported runtimes and its licence in the official source (the project's documentation, its package index page, its changelog) before writing it in the stack. Record the version and where you checked it.
- Do not write an API, a feature or a compatibility you have not verified. If you cannot check it, it becomes a spike.
- Each library has a reason tied to a driver or an FR. "Commonly used" is not a reason.

## No single point of editing

Tickets are built in parallel, and every file that all of them edit becomes a merge conflict. When laying out components and files:

- One module per screen, command or feature (a `screens/` package), not one large module that every feature extends.
- One file per migration in a directory (`migrations/0004_x.sql`), numbered by the orchestrator, not one list that every ticket appends to.
- Shared registries (the list of commands, the menu) in a small file that only the ticket that adds an entry touches, and say which one in *Components*.
- Say it in the design when a large shared module is a deliberate choice: the tickets then run one at a time over it.

## When to spike

Create a spike when a decision depends on something nobody has verified:
- a third-party API's limits, approval process, or price;
- deliverability (e-mail, SMS, push);
- performance at the stated volume;
- a library or service the team has never used.

A spike has a yes/no question, an exit criterion with a number, and a timebox in days. If the spike fails, the design changes. Say which decision it would change.
