# Design Template

Save as `docs/design/<slug>.md`. Keep the headings and table columns (English, or the Portuguese aliases at the end), because `scripts/check_design.py` reads them. Write the content in the user's language.

````markdown
# Tech Design: <name>

PRD: docs/prd/<slug>.md
Domain: docs/domain/<slug>.md
Mode: new | existing
Platforms: web
Status: draft
Date: YYYY-MM-DD

## Drivers
- 1 developer, launch by 2026-11-24 (RNF-02)
- Store only patient name and e-mail (RNF-01)

## Architecture options
<!-- Phase 1. Up to three options that are really viable, compared on the drivers. When one is clearly enough,
     one row and "Other options were not viable because ...". The user chooses when the choice is significant. -->
<!-- Name each option by its choice per dimension (deployment / code organization / data and integration /
     interface), so the options differ where it matters: "Modular monolith, layered, no messaging". -->
| Option | Fits when | Pros | Cons | Operating cost | Tests and evolution | Risks |
|--------|-----------|------|------|----------------|---------------------|-------|
| Modular monolith, layered, no messaging, server-rendered pages | 1–3 developers, one team | One deploy, simple transactions | Scales as one unit | One small VM or PaaS | Whole app tested in one run | Module boundaries erode without checks |

| Criterion (driver) | Option 1 | Option 2 |
|--------------------|----------|----------|
| Deadline of 6 weeks (RNF-02) | fits | 3 more weeks for the API layer |

Recommendation: <option> because <drivers>. Chosen by the user: <yes, date> | <pending>.

## Architecture decisions
<!-- The chosen option, one row per decision, from references/architecture-styles.md. Deployment and code
     organization are required; data and integration and interface when they apply ("None" is a valid data
     choice; no interface row when Platforms is none). One pattern per row: CQRS and an outbox are two rows.
     Driver: the PRD requirement or brief item that needs it. Patterns the catalog marks for review (services,
     CQRS, event sourcing, saga, micro-frontends...) need that driver, an alternative and an ADR. -->
| Dimension | Choice | Driver | Alternatives | ADR |
|-----------|--------|--------|--------------|-----|
| Deployment | Modular monolith | RNF-02 | Separate API and frontend: 3 more weeks | |
| Code organization | Layered (views, services, models) | RNF-02 | Vertical slices: the team knows Django's layout | |
| Data and integration | None (local transactions) | | | |
| Interface | Server rendering (Django templates) | RF-02, RNF-05 | SPA: a second build for 5 screens | |

## Stack
| Area | Choice | Alternatives | Reason | Source | Costly to reverse | ADR |
|------|--------|--------------|--------|--------|-------------------|-----|
| Backend | Python 3.12 + Django 5 | FastAPI + separate frontend | Built-in admin and auth cover RF-12 and RF-16 in the deadline; the freelancer knows it | RNF-02, RF-12 | yes | docs/adr/0001-django.md |

## Architecture
<!-- Style (modular monolith, services...) and why, citing drivers. Two to five sentences. -->

## Components
| Component | Responsibility | Serves |
|-----------|----------------|--------|
| booking | Availability, booking, cancel, reschedule | RF-02, RF-03, RF-04, RF-05, RF-13 |

## Data model
<!-- Column by column. One row per column; the Table cell may be left empty on the rows that follow its first.
     From: the domain attribute ("Entity.attribute") or rule (BR-nn) the column comes from, or "technical"
     (ids, timestamps, versions). Every confirmed domain attribute that is not calculated has a column here, or a
     line in Persistence and consistency saying why it is not stored. Many of one entity inside another (a sale's
     products) is a table of its own, never a list of ids in one column. With a distributed deployment
     (services), add an Owner column: the one component that owns each table; no foreign key crosses owners. -->
| Table | Column | Type | Null | Key | From | Serves | Notes |
|-------|--------|------|------|-----|------|--------|-------|
| patient | id | bigint | no | PK | technical | | |
| | name | varchar(120) | no | | Patient.name | RF-10 | |
| | email | varchar(254) | no | index | Patient.e-mail | RF-10 | shared by a family (BR-07); no phone or CPF column (RNF-01) |
| | physiotherapist_id | bigint | no | FK → physiotherapist.id | Patient.physiotherapist | RF-10 | |
| | created_at | timestamptz | no | | technical | | |
| physiotherapist | id | bigint | no | PK | technical | | |
| | name | varchar(120) | no | | Physiotherapist.name | RF-12 | |
| session | id | bigint | no | PK | technical | | |
| | patient_id | bigint | no | FK → patient.id | Session.patient | RF-03 | |
| | starts_at | timestamptz | no | unique (room_id, starts_at) | Session.start, BR-03 | RF-03 | stored in UTC, shown in America/Sao_Paulo |
| | fee_cents | integer | no | | Session.fee | RF-03 | copied when booked; a later price change does not touch it |

Optional, when it helps: an entity-relationship diagram in Mermaid (`erDiagram`) right after the table.

## Persistence and consistency
<!-- Phase 2. What is stored, where, and what must hold together. Or "None: <why>" with what that means
     for the user (nothing survives a restart, the data lives in the files they pass in). -->
- Store: relational / document / files / none, and why (data shape, integrity rules, volume)
- Transactions: which operations must succeed or fail as one (e.g. closing a sale writes the sale, its lines and the stock movements)
- Concurrency: who can write the same data at the same time, and what happens then
- Integrity: unique keys, foreign keys, checks that mirror the business rules (see Rule enforcement)
- Migrations and versioning: how the schema changes after the first release
- Retention, backup and restore: what is kept, for how long, how it is restored

## Rule enforcement
<!-- One row per confirmed business rule of the domain model: where it holds and how a test proves it.
     A rule enforced in two places (domain code and a database check) names both. -->
| Rule | Enforced in | How to verify |
|------|-------------|---------------|
| BR-07 | stock module (refuses the sale) and a CHECK on the lot balance | Unit test with balance 5 and a sale of 6; schema test |

## Integrations
| System | Purpose | Serves | If it fails |
|--------|---------|--------|-------------|
| Transactional e-mail provider | Login link and reminders | RF-01, RF-06 | Login link: show "try again"; reminder: retry for 6 h, then log |

## NFR coverage
| NFR | How it is met | How to verify |
|-----|---------------|---------------|
| RNF-01 | Patient table has only name and e-mail | Schema test fails if a new personal field is added |

## Errors and observability
<!-- Phase 2. How errors reach the user (messages, exit codes), what is logged and where, what is never logged
     (personal data, secrets), and how someone finds out that something failed. -->

## Test strategy
<!-- Phase 2. Which levels (unit for the rules, integration with the real database, end-to-end for the main flow),
     what is not tested automatically and who checks it, test data, and how time and randomness are controlled. -->

## Deployment
<!-- Environments, hosting, CI/CD, backups, secrets. -->

## Risks and spikes
| ID | Question | Why it matters | Exit criterion | Timebox |
|----|----------|----------------|----------------|---------|
| S1 | Do reminder e-mails reach Gmail and Outlook inboxes from the clinic domain? | RF-06 and A4 depend on it | 20 test sends, ≥ 18 in the inbox | 1 day |

## Decisions to stress-test
None

## Open questions
None
````

## Field values

- **Domain:** the domain model the PRD links. With it, every confirmed entity appears in *Data model* (or in *Persistence and consistency* with why it is not stored) and every confirmed rule has a row in *Rule enforcement*.
- **Architecture decisions:** one row per decision; *Dimension* is `deployment`, `code organization`, `data and integration` or `interface` (`publicação`, `organização do código`, `dados e integração`, `interface`). *Choice* names one entry of references/architecture-styles.md. The checker warns when the section is missing, so older designs still pass.
- **Engineering sections** (*Architecture options*, *Persistence and consistency*, *Errors and observability*, *Test strategy*): the checker warns when one is missing. Write `None: <why>` when it does not apply.
- **Platforms:** one or more of `web`, `mobile`, `desktop`, `tui`, `cli`, `chat`, comma-separated, or `none` (`nenhuma`) when nobody operates the product by hand (a library, an API for other programs, a scheduled job). A command-line program has an interface: `cli`, or `tui` when it takes the whole screen. A product with a user interface goes through factory-ui-design before the tickets, and the tickets gate checks it.
- **Mode:** `new` / `existing` (`novo` / `existente`). In `existing` mode, at least one stack row cites `existing:<file>`.
- **Source:** PRD IDs (`RF-03`, `RNF-02`, `M1`, `A4`), `brief:<section>[#n]`, or `existing:<path>` for facts read from the repository (the path must exist).
- **Costly to reverse:** `yes` / `no` (`sim` / `não`). `yes` needs an ADR path that exists.
- **Alternatives:** at least one real alternative. Not `-`, not "none".
- **Serves:** PRD requirement IDs. Every FR of the PRD must appear in *Components*. Every NFR must have a row in *NFR coverage*.
- **Risks and spikes:** `None` when there are none; otherwise every column is filled.

## Portuguese aliases

Headings: `Direcionadores`, `Opções de arquitetura`, `Decisões de arquitetura`, `Stack`, `Arquitetura`, `Persistência e consistência`, `Onde as regras valem`, `Erros e observabilidade`, `Estratégia de testes`, `Componentes`, `Modelo de dados`, `Integrações`, `Cobertura dos RNF`, `Implantação`, `Riscos e spikes`, `Decisões para validar`, `Perguntas em aberto`. Header: `PRD:`, `Domínio:`, `Modo:`, `Plataformas:`. Columns of *Onde as regras valem*: `Regra`, `Onde vale`, `Como verificar`. Columns of *Modelo de dados*: `Tabela`, `Coluna`, `Tipo`, `Nulo`, `Chave`, `Origem`, `Atende`, `Notas`, `Dono`. Columns of *Decisões de arquitetura*: `Dimensão`, `Escolha`, `Direcionador`, `Alternativas`, `ADR`. Columns: `Área`, `Escolha`, `Alternativas`, `Motivo`, `Fonte`, `Difícil de reverter`, `ADR`, `Componente`, `Responsabilidade`, `Atende`, `Entidade`, `Campos principais`, `Notas`, `Sistema`, `Finalidade`, `Se falhar`, `RNF`, `Como é atendido`, `Como verificar`, `Pergunta`, `Por que importa`, `Critério de saída`, `Prazo`.
