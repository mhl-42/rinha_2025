# /// script
# requires-python = ">=3.10"
# ///
"""Quality gate for a tech design written from references/design-template.md.

Checks that every PRD functional requirement is served by a component, every NFR is covered
with a verification, stack choices have alternatives and sources, costly decisions have ADRs,
spikes are complete, and all PRD references exist. When the design links a domain model
('Domain: docs/domain/<slug>.md'), every confirmed entity must have a place in the data model and
every confirmed business rule a row in Rule enforcement, and every confirmed attribute (not calculated)
a column whose From names it ("Entity.attribute"), or a reason it is not stored. The data model is
column by column (Table, Column, Type, Null, Key, From): each table has a PK and each FK points to a
table of the model; the older per-entity format gets a warning. The engineering sections (architecture
options, persistence and consistency, errors and observability, test strategy) give a warning
when missing, so designs written before them still pass. The 'Platforms:' header (web, mobile, desktop,
tui, cli, chat, or none) says whether the product has screens, so the tickets gate can require the UI spec; it gives a
warning when missing. The 'Architecture decisions' section (one row per decision: Dimension, Choice, Driver,
Alternatives, ADR) is checked against references/architecture-catalog.json: the dimension of each pattern, its
severity (raised for a small brief), the evidence in the requirements its Driver cites, its ADR, the pattern it
needs, the Owner of each table with services (no table with two owners, no foreign key across owners), and
patterns named elsewhere in the design but not declared (a warning). Without the section, a warning.

Usage:
  python check_design.py docs/design/<slug>.md

Exit codes:
  0 = PASS
  1 = FAIL           fix the listed items
  2 = NEEDS-ANSWERS  decisions to stress-test or open questions remain
  3 = usage error
"""

from __future__ import annotations

import json
import re
import sys
import unicodedata
from pathlib import Path

SECTIONS = {
    "drivers": ("drivers", "direcionadores"),
    "stack": ("stack",),
    "architecture": ("architecture", "arquitetura"),
    "components": ("components", "componentes"),
    "data": ("data model", "modelo de dados"),
    "integrations": ("integrations", "integrações", "integracoes"),
    "nfr": ("nfr coverage", "cobertura dos rnf", "cobertura dos nfr"),
    "deployment": ("deployment", "implantação", "implantacao"),
    "spikes": ("risks and spikes", "riscos e spikes"),
    "stress_test": ("decisions to stress-test", "decisões para validar", "decisoes para validar"),
    "open_questions": ("open questions", "perguntas em aberto"),
}
# Engineering sections added in 1.3.0: a warning when missing, so older designs still pass.
OPTIONAL_SECTIONS = {
    "options": ("architecture options", "opções de arquitetura", "opcoes de arquitetura"),
    "persistence": ("persistence and consistency", "persistência e consistência", "persistencia e consistencia"),
    "rules": ("rule enforcement", "onde as regras valem"),
    "errors": ("errors and observability", "erros e observabilidade"),
    "tests": ("test strategy", "estratégia de testes", "estrategia de testes"),
}
COLUMNS = {
    "area": ("area", "área"), "choice": ("choice", "escolha"), "alternatives": ("alternatives", "alternativas"),
    "reason": ("reason", "motivo"), "source": ("source", "fonte"),
    "costly": ("costly to reverse", "difícil de reverter", "dificil de reverter"), "adr": ("adr",),
    "component": ("component", "componente"), "responsibility": ("responsibility", "responsabilidade"),
    "serves": ("serves", "atende"), "entity": ("entity", "entidade"),
    "system": ("system", "sistema"), "purpose": ("purpose", "finalidade"), "fails": ("if it fails", "se falhar"),
    "nfr": ("nfr", "rnf"), "how": ("how it is met", "como é atendido", "como e atendido"),
    "verify": ("how to verify", "como verificar"),
    "id": ("id",), "question": ("question", "pergunta"), "why": ("why it matters", "por que importa"),
    "exit": ("exit criterion", "critério de saída", "criterio de saida"), "timebox": ("timebox", "prazo"),
    "rule": ("rule", "regra"), "enforced": ("enforced in", "onde vale"),
    "table": ("table", "tabela"), "column": ("column", "coluna"), "type": ("type", "tipo"),
    "null": ("null", "nulo"), "key": ("key", "key / index", "key/index", "chave", "chave / índice", "chave/índice"),
    "from": ("from", "origem"), "owner": ("owner", "dono"),
    "dimension": ("dimension", "dimensão", "dimensao"), "driver": ("driver", "direcionador"),
}
DOMAIN_RULE_RE = re.compile(r"\b(BR|RN)-(\d+)\b", re.IGNORECASE)
CONFIRMED = {"confirmed", "confirmado", "confirmada"}


def domain_facts(text: str) -> tuple[list[str], set[str], list[tuple[str, str, str]]]:
    """Confirmed entity names, confirmed rule ids (BR-nn) and confirmed attributes (entity, attribute, kind) of a
    domain model."""
    entities: list[str] = []
    attributes: list[tuple[str, str, str]] = []
    rules: set[str] = set()
    section = ""
    header: list[str] = []
    for line in text.splitlines():
        heading = re.match(r"^##\s+(.+?)\s*$", line)
        if heading:
            section, header = heading.group(1).strip().lower(), []
            continue
        if not line.strip().startswith("|"):
            header = []
            continue
        cells = [cell.strip() for cell in line.strip().strip("|").split("|")]
        if not header:
            header = [cell.lower() for cell in cells]
            continue
        if set("".join(cells)) <= set("-: "):
            continue
        row = dict(zip(header, cells, strict=False))
        if row.get("status", "").lower() not in CONFIRMED:
            continue
        if section in ("entities", "entidades"):
            name = row.get("entity") or row.get("entidade") or ""
            if name:
                entities.append(name)
        elif section in ("business rules", "regras de negócio", "regras de negocio"):
            found = DOMAIN_RULE_RE.fullmatch(cells[0])
            if found:
                rules.add(f"BR-{int(found.group(2)):02d}")
        elif section in ("attributes", "atributos"):
            entity = row.get("entity") or row.get("entidade") or ""
            attribute = row.get("attribute") or row.get("atributo") or ""
            if entity and attribute:
                attributes.append((entity, attribute, row.get("kind") or row.get("tipo") or ""))
    return entities, rules, attributes
YES = {"yes", "sim", "y", "s"}
NO = {"no", "não", "nao", "n"}
EMPTY_ALTERNATIVES = {"", "-", "—", "none", "nenhuma", "nenhum", "n/a"}
NONE_VALUES = {"none", "nenhuma", "nenhum", "n/a"}
ADR_SECTIONS = (
    ("context", "contexto"),
    ("decision", "decisão", "decisao"),
    ("alternatives considered", "alternativas consideradas"),
    ("consequences", "consequências", "consequencias"),
)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
COMMENT_RE = re.compile(r"<!--.*?-->", re.DOTALL)
PLACEHOLDER_RE = re.compile(r"(?-i:\bTBD\b|\bTODO\b)|\?\?\?|\ba definir\b|<[^>!\n]+>", re.IGNORECASE)
REQ_RE = re.compile(r"\b(FR|RF|NFR|RNF)-(\d+)\b", re.IGNORECASE)
RANGE_RE = re.compile(r"\b(FR|RF|NFR|RNF)-(\d+)\s*(?:–|—|-|to|a|até|ate)\s*(?:FR|RF|NFR|RNF)-(\d+)\b", re.IGNORECASE)
OTHER_ID_RE = re.compile(r"\b([MA]\d+)\b")
EXISTING_RE = re.compile(r"existing:([^\s,;)|]+)", re.IGNORECASE)


def kind(prefix: str) -> str:
    return "NFR" if prefix.upper() in ("NFR", "RNF") else "FR"


def req_ids(text: str) -> set[tuple[str, int]]:
    ids = {(kind(p), int(n)) for p, n in REQ_RE.findall(text)}
    for p, start, end in RANGE_RE.findall(text):
        ids |= {(kind(p), n) for n in range(int(start), int(end) + 1)}
    return ids


def label(rid: tuple[str, int], style: dict[str, str]) -> str:
    return f"{style.get(rid[0], rid[0])}-{rid[1]:02d}"


def plain(text: str) -> str:
    """Lower case, no accents, '_' and '-' as spaces: 'Nota fiscal' matches nota_fiscal, Empréstimo matches emprestimo."""
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"[_\-\s]+", " ", stripped.lower())


def rule_ids(text: str) -> set[str]:
    return {f"BR-{int(n):02d}" for _, n in DOMAIN_RULE_RE.findall(text)}


def sections_of(text: str, spec: dict[str, tuple[str, ...]]) -> dict[str, str]:
    lookup = {alias: key for key, aliases in spec.items() for alias in aliases}
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        key = lookup.get(match.group(1).strip().lower())
        if key:
            found[key] = COMMENT_RE.sub("", text[match.end() : end]).strip()
    return found


def table_rows(body: str) -> list[dict[str, str]]:
    lines = [line.strip() for line in body.splitlines() if line.strip().startswith("|")]
    if len(lines) < 2:
        return []
    lookup = {alias: key for key, aliases in COLUMNS.items() for alias in aliases}
    keys = [lookup.get(cell.strip().lower(), cell.strip().lower()) for cell in lines[0].strip("|").split("|")]
    rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        rows.append(dict(zip(keys, cells + [""] * (len(keys) - len(cells)), strict=False)))
    return rows


# The user interfaces a product can have; each one goes through factory-ui-design.
INTERFACES = {"web", "mobile", "desktop", "tui", "cli", "chat"}


DATA_COLUMNS = ("table", "column", "type", "null", "key", "from")
FK_RE = re.compile(r"\bFK\b\s*(?:→|->|to|para)?\s*([\w.]+)", re.IGNORECASE)
CALCULATED_RE = re.compile(r"calculated|calculado|derived|derivado", re.IGNORECASE)


def check_data_model(body: str) -> tuple[list[str], list[str]]:
    """The data model, column by column: every table has a primary key, every foreign key points to a table of
    the model, every column says whether it can be null and where it comes from (a domain attribute, a rule, or
    technical). A data model in the older per-entity format gets a warning."""
    rows = table_rows(body)
    if not rows:
        return [], []
    if "column" not in rows[0]:
        return [], [("data model lists fields per entity; write it column by column (Table, Column, Type, Null, "
                     "Key, From) so every attribute of the domain has its column (recommended since 1.6.0)")]
    missing = [c for c in DATA_COLUMNS if c not in rows[0]]
    if missing:
        return [f"data model table is missing column(s): {', '.join(missing)}"], []
    failures: list[str] = []
    tables: dict[str, list[dict[str, str]]] = {}
    current = ""
    for row in rows:
        current = row.get("table", "").strip() or current
        if not current:
            failures.append("data model: a row has no table")
            continue
        tables.setdefault(plain(current), []).append(row)
        where = f"data model {current}.{row.get('column', '?') or '?'}"
        if not row.get("column", "").strip():
            failures.append(f"data model {current}: a row has no column name")
        if not row.get("type", "").strip():
            failures.append(f"{where}: no type")
        if row.get("null", "").strip().lower() not in YES | NO:
            failures.append(f"{where}: Null must be yes or no")
        if not row.get("from", "").strip():
            failures.append(f"{where}: From must name the domain attribute (Entity.attribute), the rule (BR-nn), "
                            "or say 'technical'")
    for name, table_rows_ in tables.items():
        if not any(re.search(r"\bPK\b", row.get("key", ""), re.IGNORECASE) for row in table_rows_):
            failures.append(f"data model table '{name}' has no primary key (PK in Key)")
        for row in table_rows_:
            for target in FK_RE.findall(row.get("key", "")):
                if plain(target.split(".")[0]) not in tables:
                    failures.append(f"data model {name}.{row.get('column', '?')}: FK to '{target}', which is not "
                                    "a table of the data model")
    return failures, []


def unmapped_attributes(attributes: list[tuple[str, str, str]], data: str, persistence: str) -> list[str]:
    """Each confirmed domain attribute has a column (named in From) or a reason it is not stored. A calculated
    attribute may be derived instead."""
    text = plain(data + "\n" + persistence)
    return [
        f"domain attribute '{entity}.{attribute}' has no column; name it in From (\"{entity}.{attribute}\"), or say in "
        "Persistence and consistency why it is not stored"
        for entity, attribute, kind in attributes
        if not CALCULATED_RE.search(kind) and plain(f"{entity}.{attribute}") not in text
    ]


def header(text: str, *labels: str) -> str:
    for name in labels:
        match = re.search(rf"^\s*{name}\s*:\s*(.*)$", text, re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip()
    return ""


def find(path_text: str, base: Path) -> Path | None:
    for candidate in [Path(path_text), base.parent / path_text, *(p / path_text for p in base.resolve().parents)]:
        if candidate.is_file():
            return candidate
    return None


def is_none(body: str) -> bool:
    return body.strip().strip(".").lower() in NONE_VALUES


def check(path: Path) -> tuple[list[str], list[str], list[str]]:
    failures: list[str] = []
    pending: list[str] = []
    warnings: list[str] = []
    text = path.read_text(encoding="utf-8")
    sections = sections_of(text, SECTIONS)

    # PRD
    prd_fr: set[tuple[str, int]] = set()
    prd_nfr: set[tuple[str, int]] = set()
    prd_other: set[str] = set()
    style = {"FR": "FR", "NFR": "NFR"}
    prd = ""
    prd_text = header(text, "prd")
    prd_path = find(prd_text, path) if prd_text else None
    if not prd_text:
        failures.append("header: missing 'PRD: <path>'")
    elif prd_path is None:
        failures.append(f"header: PRD not found at {prd_text}")
    else:
        prd = prd_path.read_text(encoding="utf-8")
        if not re.search(r"^status:\s*(confirmed|confirmado)\b", prd, re.IGNORECASE | re.MULTILINE):
            failures.append("the PRD is not 'Status: confirmed'; confirm it (factory-prd-writer) first")
        for prefix, number in re.findall(r"^###\s+(FR|RF)-(\d+)", prd, re.IGNORECASE | re.MULTILINE):
            prd_fr.add(("FR", int(number)))
            style["FR"] = prefix.upper()
        for prefix, number in re.findall(r"^\|\s*(NFR|RNF)-(\d+)\s*\|", prd, re.IGNORECASE | re.MULTILINE):
            prd_nfr.add(("NFR", int(number)))
            style["NFR"] = prefix.upper()
        prd_other = set(re.findall(r"^\|\s*([MA]\d+)\s*\|", prd, re.MULTILINE))

    def check_refs(cell: str, where: str) -> set[tuple[str, int]]:
        ids = req_ids(cell)
        if prd_path is not None:
            for rid in sorted(ids - prd_fr - prd_nfr):
                failures.append(f"{where}: {label(rid, style)} does not exist in the PRD")
            for other in OTHER_ID_RE.findall(cell):
                if other not in prd_other:
                    failures.append(f"{where}: {other} does not exist in the PRD")
        return ids

    for key, aliases in SECTIONS.items():
        if key not in sections:
            failures.append(f"missing section '## {aliases[0].capitalize()}'")
        elif not sections[key] and key not in ("integrations",):
            failures.append(f"section '{aliases[0]}' is empty")
    optional = sections_of(text, OPTIONAL_SECTIONS)
    for key, aliases in OPTIONAL_SECTIONS.items():
        if key == "rules":
            continue  # required only with a domain model, below
        if key not in optional:
            warnings.append(f"no '## {aliases[0].capitalize()}' section (recommended since 1.3.0; see the template)")
        elif not optional[key]:
            failures.append(f"section '{aliases[0]}' is empty; write 'None: <why>' when it does not apply")

    # Domain model: entities land in the data model, confirmed rules have a place where they are enforced
    domain_text = header(text, "domain", "domínio", "dominio")
    prd_domain = header(prd_path.read_text(encoding="utf-8"), "domain", "domínio", "dominio") if prd_path else ""
    if prd_domain and not domain_text:
        failures.append("the PRD links a domain model; add 'Domain: <path>' to this design so its entities "
                        "and rules are checked against the data model")
    if domain_text:
        domain_path = find(domain_text, path)
        if domain_path is None:
            failures.append(f"header: domain model not found at {domain_text}")
        else:
            entities, rules, attributes = domain_facts(domain_path.read_text(encoding="utf-8"))
            data_rows = table_rows(sections.get("data", ""))
            if data_rows and "column" in data_rows[0]:  # the older per-entity format only gets its warning
                failures += unmapped_attributes(attributes, sections.get("data", ""), optional.get("persistence", ""))
            data_text = plain(sections.get("data", "") + "\n" + optional.get("persistence", ""))
            for name in entities:
                if plain(name) not in data_text:
                    failures.append(f"domain entity '{name}' has no place in the data model; map it, or say "
                                    "why it is not stored (a value inside another entity, derived, not kept)")
            if "rules" not in optional:
                failures.append("missing section '## Rule enforcement': where each confirmed business rule holds")
            else:
                enforced: set[str] = set()
                for row in table_rows(optional["rules"]):
                    ids = rule_ids(row.get("rule", ""))
                    enforced |= ids
                    if ids and (not row.get("enforced") or not row.get("verify")):
                        failures.append(f"rule enforcement {', '.join(sorted(ids))}: say where it holds and how to verify")
                for rid in sorted(rules - enforced):
                    failures.append(f"{rid} (confirmed in the domain model) has no row in Rule enforcement")
                for rid in sorted(enforced - rules):
                    failures.append(f"rule enforcement: {rid} is not a confirmed rule of the domain model")

    visible = COMMENT_RE.sub(lambda m: "\n" * m.group(0).count("\n"), text)
    for match in PLACEHOLDER_RE.finditer(visible):
        failures.append(f"placeholder {match.group(0)!r} on line {visible.count(chr(10), 0, match.start()) + 1}")

    platforms_text = header(text, "platforms", "plataformas").lower()
    platforms = {p.strip() for p in platforms_text.split(",") if p.strip()}
    if not platforms:
        warnings.append(
            "header: no 'Platforms:' line (web, mobile, desktop, tui, cli, chat or none); without it the UI design step is not required"
        )
    elif not platforms <= {*INTERFACES, "none", "nenhuma"} or (
        len(platforms) > 1 and platforms & {"none", "nenhuma"}
    ):
        failures.append("header: Platforms must be one or more of web, mobile, desktop, tui, cli, chat, or none (nenhuma)")

    mode = header(text, "mode", "modo").lower()
    if mode not in ("new", "existing", "novo", "existente"):
        failures.append("header: Mode must be new or existing (novo / existente)")

    # Stack
    stack = table_rows(sections.get("stack", ""))
    if "stack" in sections and not stack:
        failures.append("stack table has no rows")
    existing_sources = 0
    for row in stack:
        where = f"stack '{row.get('area') or row.get('choice') or '?'}'"
        if not row.get("choice"):
            failures.append(f"{where}: no choice")
        if row.get("alternatives", "").strip().lower() in EMPTY_ALTERNATIVES:
            failures.append(f"{where}: list at least one alternative and why it lost")
        if not row.get("reason"):
            failures.append(f"{where}: no reason")
        source = row.get("source", "")
        refs = check_refs(source, where)
        existing = EXISTING_RE.findall(source)
        for item in existing:
            if find(item, path) is None:
                failures.append(f"{where}: existing:{item} not found in the repository")
        existing_sources += len(existing)
        if not (refs or existing or OTHER_ID_RE.search(source) or "brief:" in source.lower()):
            failures.append(f"{where}: Source must cite the PRD (RF-/RNF-/M/A ids), brief:, or existing:<path>")
        costly = row.get("costly", "").strip().lower()
        if costly not in YES | NO:
            failures.append(f"{where}: 'Costly to reverse' must be yes or no")
        elif costly in YES:
            adr_text = row.get("adr", "").strip()
            if not adr_text or adr_text in ("-", "—") or find(adr_text, path) is None:
                failures.append(f"{where}: costly decision needs an ADR file (got {adr_text or 'nothing'!r})")
            else:
                failures += adr_failures(adr_text, path)
    if mode in ("existing", "existente") and stack and existing_sources == 0:
        failures.append("mode is existing but no stack row cites existing:<file> from the repository")

    # Components cover every FR
    served: set[tuple[str, int]] = set()
    components = table_rows(sections.get("components", ""))
    if "components" in sections and not components:
        failures.append("components table has no rows")
    for row in components:
        where = f"component '{row.get('component', '?')}'"
        if not row.get("responsibility"):
            failures.append(f"{where}: no responsibility")
        served |= check_refs(row.get("serves", ""), where)
    for rid in sorted(prd_fr - served):
        failures.append(f"{label(rid, style)} is not served by any component")

    data_failures, data_warnings = check_data_model(sections.get("data", ""))
    failures += data_failures
    warnings += data_warnings
    for row in table_rows(sections.get("data", "")):
        check_refs(row.get("serves", ""), f"entity '{row.get('table') or row.get('entity', '?')}'")

    integrations = sections.get("integrations", "")
    if integrations and not is_none(integrations):
        for row in table_rows(integrations):
            where = f"integration '{row.get('system', '?')}'"
            check_refs(row.get("serves", ""), where)
            if not row.get("fails"):
                failures.append(f"{where}: say what happens when it fails")

    # NFR coverage
    covered: set[tuple[str, int]] = set()
    for row in table_rows(sections.get("nfr", "")):
        ids = check_refs(row.get("nfr", ""), "NFR coverage")
        covered |= ids
        name = ", ".join(label(i, style) for i in sorted(ids)) or "?"
        if not row.get("how"):
            failures.append(f"NFR coverage {name}: how it is met is empty")
        if not row.get("verify"):
            failures.append(f"NFR coverage {name}: how to verify is empty")
    for rid in sorted(prd_nfr - covered):
        failures.append(f"{label(rid, style)} has no row in NFR coverage")

    # Spikes
    spikes = sections.get("spikes", "")
    if spikes and not is_none(spikes):
        for row in table_rows(spikes):
            for column in ("question", "exit", "timebox"):
                if not row.get(column):
                    failures.append(f"spike {row.get('id') or '?'}: missing {column}")

    # Architecture decisions, against references/architecture-catalog.json
    brief_text = ""
    brief_link = header(prd, "brief") if prd else ""
    brief_path = find(brief_link, prd_path) if brief_link and prd_path else None
    if brief_path is not None:
        brief_text = brief_path.read_text(encoding="utf-8")
    size = re.search(r"^\s*(?:size|tamanho)\s*:\s*(\w+)", brief_text, re.IGNORECASE | re.MULTILINE)
    decisions = sections_of(text, {"decisions": DECISIONS_SECTION}).get("decisions")
    catalog = load_catalog() or {"patterns": []}
    context = {
        "path": path, "check_refs": check_refs, "warnings": warnings, "platforms": platforms,
        "size": size.group(1).lower() if size else "", "brief": brief_text,
        "requirements": requirement_texts(prd) if prd else {},
        "names": {entry["id"]: entry["name"] for entry in catalog["patterns"]},
        "data_body": sections.get("data", ""),
        "data_text": plain(sections.get("data", "") + "\n" + optional.get("persistence", "")),
        "components": {plain(row.get("component", "")).strip() for row in components if row.get("component")},
    }
    architecture_failures, architecture_warnings = check_architecture(text, decisions, context)
    failures += architecture_failures
    warnings += architecture_warnings

    for key, kind_label in (("stress_test", "stress-test"), ("open_questions", "open question")):
        body = sections.get(key, "")
        if body and not is_none(body):
            pending += [f"{kind_label}: {line.strip().lstrip('-* ')}" for line in body.splitlines() if line.strip()]
    return failures, pending, warnings


# ----------------------------------------------------------------- architecture decisions

CATALOG_PATH = Path(__file__).resolve().parent.parent / "references" / "architecture-catalog.json"
DECISIONS_SECTION = ("architecture decisions", "decisões de arquitetura", "decisoes de arquitetura")
SEVERITY_RANK = {"info": 0, "advisory": 1, "review": 2, "blocking": 3}
SMALL_SIZES = {"small", "pequeno"}
# Sections where naming a pattern is a comparison, not a decision.
COMPARISON_SECTIONS = {
    *OPTIONAL_SECTIONS["options"], *DECISIONS_SECTION, *SECTIONS["stress_test"], *SECTIONS["open_questions"],
}


def load_catalog() -> dict | None:
    try:
        return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def contains(haystack: str, term: str) -> bool:
    """The plain term starts a word of the plain text: the catalog lists stems ('scal' matches 'scale')."""
    return re.search(rf"(?<![a-z0-9]){re.escape(plain(term).strip())}", haystack) is not None


def match_patterns(choice: str, patterns: list[dict]) -> list[dict]:
    """The catalog entries a Choice cell names, the longest alias first, so 'modular monolith' is not also
    'monolith' and 'event sourcing' is not also 'event-driven'."""
    text = f" {plain(choice)} "
    aliases = sorted(((plain(alias).strip(), entry) for entry in patterns for alias in entry["aliases"]),
                     key=lambda pair: -len(pair[0]))
    found: list[dict] = []
    for alias, entry in aliases:
        pattern = rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])"
        if re.search(pattern, text):
            text = re.sub(pattern, " ", text)
            if entry not in found:
                found.append(entry)
    return found


def requirement_texts(prd: str) -> dict[tuple[str, int], str]:
    """The text of each FR (its ### block) and each NFR (its table row) of the PRD."""
    texts: dict[tuple[str, int], str] = {}
    blocks = re.split(r"(?m)^(?=#{1,3}\s)", prd)
    for block in blocks:
        found = re.match(r"###\s+(FR|RF)-(\d+)", block, re.IGNORECASE)
        if found:
            texts[("FR", int(found.group(2)))] = block
    for line in prd.splitlines():
        found = re.match(r"^\|\s*(NFR|RNF)-(\d+)\s*\|", line, re.IGNORECASE)
        if found:
            texts[("NFR", int(found.group(2)))] = line
    return texts


def comparison_free(text: str) -> str:
    """The design without comments, the sections that compare options, and the Alternatives cells of any table:
    what is left is what the design says it will build."""
    text = COMMENT_RE.sub("", text)
    kept: list[str] = []
    skipping = False
    alternatives_at: int | None = None
    for line in text.splitlines():
        heading = re.match(r"^##\s+(.+?)\s*$", line)
        if heading:
            skipping = heading.group(1).strip().lower() in COMPARISON_SECTIONS
            alternatives_at = None
            continue
        if skipping:
            continue
        if line.strip().startswith("|"):
            cells = line.strip().strip("|").split("|")
            if alternatives_at is None:
                names = [cell.strip().lower() for cell in cells]
                alternatives_at = next((i for i, name in enumerate(names) if name in COLUMNS["alternatives"]), -1)
            elif alternatives_at >= 0 and alternatives_at < len(cells):
                cells[alternatives_at] = ""
            kept.append("|".join(cells))
        else:
            alternatives_at = None
            kept.append(line)
    return plain("\n".join(kept))


def owners_of(data_rows: list[dict[str, str]]) -> dict[str, list[str]]:
    """Owner cells of each table of the column-by-column data model (the table cell may be empty after the first row)."""
    owners: dict[str, list[str]] = {}
    current = ""
    for row in data_rows:
        current = row.get("table", "").strip() or current
        owner = row.get("owner", "").strip()
        if current and owner:
            owners.setdefault(plain(current), [])
            for name in re.split(r",|;|/|\s+(?:and|e)\s+", owner):
                if plain(name).strip() and plain(name).strip() not in owners[plain(current)]:
                    owners[plain(current)].append(plain(name).strip())
    return owners


def check_ownership(data_body: str, component_names: set[str], deployment: str,
                    antipatterns: dict[str, dict]) -> list[str]:
    """With a distributed deployment, every table has one owner (a component), and no foreign key crosses owners."""
    rows = table_rows(data_body)
    if not rows or "column" not in rows[0]:
        return []
    if "owner" not in rows[0]:
        return [(f"architecture: with {deployment}, the Data model needs an Owner column: the component (service) "
                "that owns each table")]
    failures: list[str] = []
    owners = owners_of(rows)
    current = ""
    tables: list[str] = []
    for row in rows:
        current = row.get("table", "").strip() or current
        if current and plain(current) not in tables:
            tables.append(plain(current))
    for table in tables:
        names = owners.get(table, [])
        if not names:
            failures.append(f"data model table '{table}': no Owner")
        elif len(names) > 1:
            failures.append(f"{antipatterns['shared-database']['name']}: table '{table}' "
                            f"{antipatterns['shared-database']['message']} (owners: {', '.join(names)})")
        for name in names:
            if component_names and name not in component_names:
                failures.append(f"data model table '{table}': Owner '{name}' is not a component")
    current = ""
    for row in rows:
        current = row.get("table", "").strip() or current
        for target in FK_RE.findall(row.get("key", "")):
            target_table = plain(target.split(".")[0])
            mine, theirs = owners.get(plain(current), []), owners.get(target_table, [])
            if mine and theirs and not set(mine) & set(theirs):
                failures.append(f"{antipatterns['distributed-monolith']['name']}: {plain(current)}.{row.get('column', '?')} "
                                f"→ {target_table} {antipatterns['distributed-monolith']['message']}")
    return failures


def check_architecture(text: str, decisions_body: str | None, context: dict) -> tuple[list[str], list[str]]:
    """The Architecture decisions section against the catalog: one row per decision and dimension, the severity of
    each pattern (raised for a small project), the evidence in the requirements its Driver cites, the ADR of a costly
    pattern, what a pattern needs, the antipatterns the document shows, and patterns named elsewhere in the design
    but never declared."""
    failures: list[str] = []
    warnings: list[str] = []
    catalog = load_catalog()
    if catalog is None:
        return [], [f"architecture catalog not found at {CATALOG_PATH}; architecture decisions not checked"]
    patterns: list[dict] = catalog["patterns"]
    by_id = {entry["id"]: entry for entry in patterns}
    antipatterns = {entry["id"]: entry for entry in catalog["antipatterns"]}
    dimensions: dict[str, dict] = catalog["dimensions"]
    dimension_of = {plain(alias).strip(): key for key, spec in dimensions.items() for alias in spec["aliases"]}
    none_values = {plain(value).strip() for value in catalog["none_values"]}
    small = context["size"] in SMALL_SIZES
    declared: list[str] = []

    if decisions_body is None:
        warnings.append("no '## Architecture decisions' section: one row per dimension (deployment, code organization, "
                        "data and integration, interface) checked against references/architecture-catalog.json "
                        "(recommended since 1.7.0)")
    elif not decisions_body:
        failures.append("section 'architecture decisions' is empty")
    else:
        seen_dimensions: set[str] = set()
        rows = table_rows(decisions_body)
        if not rows:
            failures.append("architecture decisions: no table (Dimension | Choice | Driver | Alternatives | ADR)")
        for row in rows:
            dimension_text = row.get("dimension", "").strip()
            dimension = dimension_of.get(plain(dimension_text).strip())
            choice = row.get("choice", "").strip()
            where = f"architecture decision '{choice or '?'}'"
            if dimension is None:
                failures.append(f"{where}: Dimension must be one of "
                                f"{', '.join(spec['name'].lower() for spec in dimensions.values())} (got {dimension_text!r})")
                continue
            seen_dimensions.add(dimension)
            if not choice:
                failures.append(f"architecture decision ({dimensions[dimension]['name']}): no choice")
                continue
            if plain(choice).strip(" .") in none_values:
                if dimensions[dimension]["required"]:
                    failures.append(f"{where}: {dimensions[dimension]['name']} needs a choice")
                continue
            if dimension == "interface" and context["platforms"] <= {"none", "nenhuma"} and context["platforms"]:
                failures.append(f"{antipatterns['interface-without-ui']['name']}: '{choice}' "
                                f"{antipatterns['interface-without-ui']['message']}")
                continue
            matched = match_patterns(choice, patterns)
            if len(matched) > 1:
                failures.append(f"{where}: names {len(matched)} patterns ({', '.join(e['name'] for e in matched)}); "
                                "write one per row")
                continue
            entry = matched[0] if matched else None
            if entry is not None and entry["dimension"] != dimension:
                failures.append(f"{where}: {entry['name']} is a {dimensions[entry['dimension']]['name'].lower()} "
                                f"decision, not {dimensions[dimension]['name'].lower()}; move it to its own row")
                continue
            if entry is not None:
                declared.append(entry["id"])
            severity = "review" if entry is None else (
                entry.get("severity_small", entry["severity"]) if small else entry["severity"])
            name = entry["name"] if entry else choice
            failures += check_decision(row, entry, name, severity, context, where)
        for key, spec in dimensions.items():
            if spec["required"] and key not in seen_dimensions:
                failures.append(f"architecture decisions: no row for {spec['name'].lower()}")

        for pattern_id in declared:
            entry = by_id[pattern_id]
            needs = entry.get("needs")
            if needs and not set(needs["any_of"]) & set(declared):
                failures.append(f"architecture decision '{entry['name']}': {needs['message']}")
            terms = entry.get("design_evidence")
            if terms and not any(contains(context["data_text"], term) for term in terms):
                failures.append(f"architecture decision '{entry['name']}': the Data model or Persistence and "
                                "consistency does not show it (no read model, projection or materialized view)")
            if entry.get("min_platforms") and len(context["platforms"] & INTERFACES) < entry["min_platforms"]:
                warnings.append(f"architecture decision '{entry['name']}': it pays off with {entry['min_platforms']} or "
                                "more client platforms; Platforms names fewer")
            if small and entry.get("severity_small") and entry["id"] in antipattern_small_ids(catalog):
                warnings.append(f"{antipatterns['premature-abstraction']['name']}: '{entry['name']}' "
                                f"{antipatterns['premature-abstraction']['message']}")
        distributed = [by_id[i]["name"] for i in declared if by_id[i].get("distributed")]
        if distributed:
            failures += check_ownership(context["data_body"], context["components"], distributed[0], antipatterns)

    scan = comparison_free(text)
    for entry in patterns:
        if entry["id"] not in declared and any(contains(scan, term) for term in entry.get("mentions", [])):
            warnings.append(f"mentions {entry['name']} outside Architecture options and decisions; declare it in "
                            "Architecture decisions with the requirement that needs it, or remove it")
    for technology in catalog["technologies"]:
        named = [term for term in technology["terms"] if contains(scan, term)]
        if named and not set(technology["implies"]) & set(declared):
            warnings.append(f"{technology['message']} ({', '.join(named)}), but Architecture decisions declares none of "
                            f"{', '.join(by_id[i]['name'] for i in technology['implies'])}; make sure an NFR requires it")
    return failures, warnings


def antipattern_small_ids(catalog: dict) -> set[str]:
    """Patterns whose stricter severity for a small project is about premature abstraction (code organization)."""
    return {entry["id"] for entry in catalog["patterns"] if entry["dimension"] == "code" and entry.get("severity_small")}


def check_decision(row: dict[str, str], entry: dict | None, name: str, severity: str, context: dict,
                   where: str) -> list[str]:
    """Driver, evidence, alternatives and ADR of one decision, by its severity."""
    rank = SEVERITY_RANK.get(severity, 0)
    if rank == 0:
        return []
    failures: list[str] = []
    driver = row.get("driver", "")
    refs = context["check_refs"](driver, where)
    existing = [item for item in EXISTING_RE.findall(driver) if find(item, context["path"]) is not None]
    cites_brief = "brief:" in driver.lower()
    cited = bool(refs or existing or cites_brief or OTHER_ID_RE.search(driver))
    if rank == 1:
        if not cited:
            context["warnings"].append(f"{where}: {name} is {severity}; cite in Driver the requirement that justifies "
                                       "it (RF-/RNF-, brief: or existing:)")
        return []
    if not cited:
        failures.append(f"{where}: {name} needs a Driver that cites the requirement that justifies it "
                        "(RF-/RNF-, brief: or existing:)")
    elif entry is not None and entry.get("evidence") and not existing:
        source = "\n".join(context["requirements"].get(rid, "") for rid in refs)
        if cites_brief:
            source += "\n" + context["brief"]
        if not any(contains(plain(source), term) for term in entry["evidence"]):
            options = [context["names"].get(i, i) for i in entry.get("alternatives", [])]
            failures.append(f"{where}: the requirements its Driver cites say nothing that needs {name} "
                            f"(expected words like {', '.join(entry['evidence'][:4])}); cite the one that does"
                            + (f", or choose {' / '.join(options)}" if options else ""))
    if row.get("alternatives", "").strip().lower() in EMPTY_ALTERNATIVES:
        failures.append(f"{where}: list at least one alternative and why it lost")
    adr_text = row.get("adr", "").strip()
    if not adr_text or adr_text in ("-", "—"):
        failures.append(f"{where}: {name} is costly to reverse; write an ADR and put its path in the ADR column")
    else:
        failures += adr_failures(adr_text, context["path"])
    return failures


def adr_failures(adr_text: str, path: Path) -> list[str]:
    adr = find(adr_text, path)
    if adr is None:
        return [f"ADR not found at {adr_text}"]
    adr_sections = {m.lower() for m in re.findall(r"^##\s+(.+?)\s*$", adr.read_text(encoding="utf-8"), re.MULTILINE)}
    return [f"{adr_text}: missing section '## {aliases[0].title()}'"
            for aliases in ADR_SECTIONS if not adr_sections & set(aliases)]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]  # Windows consoles default to cp1252
    if len(sys.argv) != 2 or not Path(sys.argv[1]).is_file():
        print(__doc__, file=sys.stderr)
        return 3
    failures, pending, warnings = check(Path(sys.argv[1]))
    for warning in warnings:
        print(f"warning: {warning}")
    if failures:
        print("FAIL")
        for item in dict.fromkeys(failures):
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
