# factory-ui-design

Step 4b of the flow: designs the screens, flows, states and accessibility rules of a product, from a confirmed PRD and tech design. The core of the spec does not depend on the platform. Web is in use; mobile and desktop are added as platform sections.

```
3 factory-prd-writer → 4 factory-tech-design → 4b factory-ui-design → 5 factory-prd-to-tickets
```

## Files

```
factory-ui-design/
├── SKILL.md
├── scripts/
│   └── check_ux.py              # Gate: PASS / FAIL / NEEDS-ANSWERS
├── references/
│   ├── ui-spec-template.md      # The spec's headings and table columns
│   └── platforms.md             # What web, mobile and desktop add to the spec
└── evals/
    ├── evals.json               # Draft from PRD, broken spec, platform change, platform already decided
    └── trigger_queries.json
```

Fixtures (in `evals/fixtures/docs/ux/`):
- `autoagendamento-fisioterapia.md`: a complete web spec for the clinic PRD. It passes the gate.
- `autoagendamento-fisioterapia-broken.md`: the same spec with three known defects (a missing error state, an FR with no screen, a flow that names an unknown screen). It fails the gate.

## Run the gate

```bash
python skills/factory-ui-design/scripts/check_ux.py docs/ux/<slug>.md
```

The gate checks:
- the spec is confirmed, and its PRD exists;
- each FR has a screen or a No-interface reason;
- each screen lists `loading`, `empty` and `error`;
- each flow step names an existing screen;
- each platform in the header has a `### <platform>` note;
- each accessibility NFR of the PRD is covered;
- no placeholders; open questions block with NEEDS-ANSWERS.

## Adding mobile or desktop

Add the platform to `PLATFORMS` in `check_ux.py`, write its subsection following [references/platforms.md](references/platforms.md), and add it to the header. The core stays as it is. Do this when a project chooses that platform in its design, not before.
