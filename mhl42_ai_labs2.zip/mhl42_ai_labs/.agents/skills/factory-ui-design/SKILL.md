---
name: factory-ui-design
description: Use this skill to design the user interface of a product from a confirmed PRD and tech design — the screens and their states (loading, empty, error, edge states), how each kind of record is listed, created, edited and deleted, the flows, shared components and accessibility rules — as a platform-neutral spec with notes for web, mobile, desktop, TUI, CLI or chat, checked by a quality gate before the tickets are cut. Triggers on "design the screens", "desenha as telas", "design the CLI commands", "telas do TUI", "fluxo do bot", "fluxo do usuário", "user flows", "wireframes in text", "UI spec", "how should the screens work", "tela de agendamento". Not for choosing the platform or framework (use factory-tech-design), writing the PRD (use factory-prd-writer), breaking work into tickets (use factory-prd-to-tickets), building the screens (use factory-implement), or visual branding.
license: MIT
compatibility: scripts/check_ux.py needs Python 3.10+ (no dependencies). Expects the PRD format of factory-prd-writer and, for the platform decision, the design format of factory-tech-design.
metadata:
  author: mhl42
  version: "1.3.0"
---

# UI Design

Design the screens a user sees and how they connect, so that the tickets for each screen say what to build, including the states nobody remembers to design: the empty list, the failed request, the slot someone else just took.

This is step 4b of the flow, after the technical design and before the tickets. It is not optional for a product with a user interface: when the design's `Platforms:` header names a user interface (`web`, `mobile`, `desktop`, `tui`, `cli` or `chat`), the tickets gate (check_tickets.py) fails until this spec is confirmed.

```
3 factory-prd-writer → 4 factory-tech-design → 4b factory-ui-design → 5 factory-prd-to-tickets → build
```

Write the spec in the user's language. Keep the screen ids and the column names as the template has them.

## Before you start

- **PRD:** `docs/prd/<slug>.md` with `Status: confirmed`. If it is missing or a draft, stop and send the user to factory-prd-writer. Read every FR and every NFR that is about use, access or accessibility.
- **Design:** `docs/design/<slug>.md` with `Status: confirmed`, for the platform in its `Platforms:` header and its *Stack* and *Interface* rows. If the design does not name a platform, stop and send the user to factory-tech-design.
- **Domain model** (when the PRD links one): its *Attributes* give each form its fields, and which are required, editable or shown only; its lifecycles and rules give each screen its own states (an open sale, a closed invoice, a lot that expired) and its refusals; its alternative flows give the branches of each flow.
- **Depth:** when the brief's *Depth* skips this step (a product nobody operates by hand: a library, an API for other programs, a scheduled job), do not write a spec. A command line is not such a product: it is the `cli` platform.
- **Platforms:** the header of the spec lists them: what the design chose, nothing more. On a terminal or a chat, a "screen" is a TUI view, a CLI command or prompt, or a step of the conversation; [references/platforms.md](references/platforms.md) says how screens, states and records read on each platform.

## Workflow

```
- [ ] 1. Inputs checked (PRD and design confirmed, platform known)
- [ ] 2. Requirements mapped: every FR is a screen, a flow step, or "No interface" with a reason
- [ ] 3. Screens drafted from the template, with their states
- [ ] 3b. Records: list, create, edit and delete of each kind of record the user keeps
- [ ] 4. Flows written: what the user does, in order, per FR group
- [ ] 5. Components named once, used by several screens
- [ ] 6. Accessibility rules from the PRD applied to the screens
- [ ] 7. Platform notes for each platform in the header
- [ ] 8. check_ux.py → PASS
- [ ] 9. User confirms; status set to confirmed
```

### 2. Map the requirements
Go through the PRD's FRs in order. For each one, decide where it lives:
- a screen (add it to `Serves`);
- a step in a flow (the screen it belongs to still must exist);
- **No interface**, with a reason: a scheduled job, a command run by a developer, an e-mail. "Not designed yet" is not a reason.

### 3. Screens and states
One row per screen. For each one, write:
- the **action** (the single main thing the user does here);
- the **states**. Every screen has `loading`, `empty` and `error`. Write `empty (n/a)` when a screen cannot be empty, not a blank. Add the screen's own states from the business rules: a slot taken meanwhile, a duplicate e-mail, a room conflict, a link already used.

Each state's text and next step are part of the spec: what the user reads and where they go. "Show an error" is not a state; "Slot just taken. Back to the free slots, same day" is.

### 3b. Records
Every kind of record a user keeps on a screen (a patient, a product, a room: usually an entity of the domain model) gets a row in *Records*, with four cells:
- **List:** the screen where the records are found (search, filter, order).
- **Create:** the screen and how it opens (a "New" button on the list), and the fields open to typing: the entity's attributes in the domain model's *Attributes*, minus the calculated ones, with the required ones marked.
- **Edit:** the screen and how it opens (a row of the list), the fields that can change, and the ones that stay locked and why: the attribute's *Changes* (`no`, `once`, `until <state>`, `by <actor>`) decides it, so the spec and the domain never disagree.
- **Delete:** the screen, how the user confirms it (a dialog naming the record, an undo window), and when it is refused. An archive or deactivate is written here.

A cell that does not apply says `n/a: <reason>` with the rule behind it ("a patient is never deleted: past sessions keep the name"). A screen that only shows a record and a single "Save" button is the gap this section exists to catch: without these cells, the tickets build a read-only page. The form screens also name an `invalid` state, with what the user sees next to each refused field. When no screen keeps records, write `None: <reason>`.

### 4. Flows
Write each user path as numbered steps through the screen ids: entry, the happy path, and the branches that lead to another screen. Keep one flow per group of FRs. A flow is not a diagram of every click: it is the path a user takes to finish a task.

### 5. Components
Name a component when two or more screens use it (a slot button, a session card, an inline error). Say which screens use it. Do not name components that appear once.

### 6. Accessibility
Copy the PRD's accessibility NFRs into the *Accessibility* section by their ids (for example RNF-06). Apply them to the screens: text size, contrast, focus order, labels, error messages that do not rely on colour alone, touch target size, and a limit on taps for the main action. The gate looks for the NFR ids; a NFR you leave out fails it.

### 7. Platform notes
Write one `### <platform>` subsection for each platform in the header, using [references/platforms.md](references/platforms.md). For `web`: the rendering model, the breakpoints, the browsers, and what works without JavaScript.

### 8. Check
```bash
python <this-skill-dir>/scripts/check_ux.py docs/ux/<slug>.md
```

On Windows, `python` can be the Microsoft Store shortcut and fail with an install message. If it does not answer, use `py -3` in its place.

| Result | Exit code | Next step |
|--------|-----------|-----------|
| `FAIL` | 1 | Fix the listed items: an FR with no screen and no reason, a screen missing a state, a record without its list, create, edit or delete (or a reason), an edit without its fields, a delete without its confirmation, a flow that names an unknown screen, a platform without notes, an accessibility NFR not covered, a placeholder. |
| `NEEDS-ANSWERS` | 2 | *Open questions* is not empty. Ask them in one numbered round, each with a recommended answer, and update the file. |
| `PASS` | 0 | Confirm. |

The gate checks structure and coverage. It cannot judge whether a flow is pleasant to use. Read the flows once as the patient, the receptionist and the owner, and check each step against the PRD's user story.

### 9. Confirm
Show the screens table, the records table and the flows, one line per flow. Ask for explicit confirmation, then set `Status: confirmed`. Then offer the next step: breaking the PRD, the design and this spec into tickets (factory-prd-to-tickets). The tickets cut one ticket per screen or per flow step group, and each ticket copies the states it must build and the create, edit and delete of its records as criteria.

## Document store (factory-tickets MCP)

When the `factory-tickets` tools are connected, the database is the source of this project's documents and the server writes `docs/` on every change, from the first document on. Start with `project_manifest(<slug>)`: a new project (`exists` is false) is created with `project_open(<slug>, name=...)` before the first `doc_write`; files listed in `untracked` were written outside the database, so bring them in with `doc_import(<slug>)` before writing and tell the user. A hook may refuse a direct edit of those files; even without it, the server refuses its next write after one. Without the server, write the files as described above. When this step is confirmed, call `factory_next(<slug>)` and offer the skill it names (it reads every document's state, so no step is skipped), instead of choosing the next step yourself.

- Read the inputs with `doc_read`, or single ids with `item_get` (the definition and everything that cites it), instead of opening the files.
- Write with `doc_write(project, "ux", <slug>, markdown, expected_revision)`, the whole document each time, `expected_revision` from your last `doc_read`. It is stored as a draft, exported, and its gate runs: the result is the gate step's output, so there is no separate run.
- Confirm with `doc_confirm(project, "ux", <slug>, revision, user_answer)` after the user's yes, passing their reply verbatim, instead of editing the Status line. Show them the revision you confirm. It refuses while an input is not confirmed, the document cites an item that changed after it (`stale` in the manifest: rewrite the citing text, or `stale_resolve` with a note when it still holds), or the gate fails on the confirmed text; read the refusal to the user.

## Gotchas

- A "registry" screen with one action. Keeping records means listing, creating, editing and deleting them; each needs its screen, its fields and its confirmation, or a reason it does not exist.
- Designing only the happy path. The empty, loading and error states are where most of the work is, and where the PRD's rules show up (a taken slot, an expired link).
- Covering a platform the design did not choose, because it "would be nice". Add it when the design adds it.
- Writing the look (colours, fonts, spacing) into the spec. This skill decides what the user sees and does; visual design is a separate step. Only the PRD's measurable rules (minimum text size, touch targets, contrast) belong here.
- Putting a screen id in *Serves* that the PRD does not have. The gate catches it, but the screen is then not traceable.
- Treating accessibility as a final check. Each screen row should already respect the rules.
