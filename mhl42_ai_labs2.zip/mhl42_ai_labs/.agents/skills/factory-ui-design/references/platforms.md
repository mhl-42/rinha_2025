# Platforms

The spec's core (screens, records, flows, states, components, accessibility) does not depend on the platform. Only the **Platform notes** section and the header's `Platforms:` value change. The platform decision belongs to factory-tech-design (its `Platforms:` header); this file says what each platform adds to the spec.

Any product a person uses directly has a user interface and goes through this step: a site, an app, a desktop window, a full-screen terminal program, a command line, a bot. Only a product nobody operates by hand (a library, an API for other programs, a scheduled job) has `Platforms: none`.

| Platform | What a "screen" (S-NN) is | `loading` / `empty` / `error` | Records |
|---|---|---|---|
| `web`, `mobile`, `desktop` | a page, a view, a window or a dialog | spinner or skeleton / empty list with its next step / message next to what failed | list, form opened by "New" or by a row, delete with a confirmation dialog |
| `tui` | a full-screen view or panel of a terminal program | status line or progress bar / empty table with the key that adds one / message in the status line | list view, form with tab between fields, delete with a confirmation prompt |
| `cli` | a command or subcommand (`app patient add`), or an interactive prompt | progress output on stderr / "no patients found" and exit 0 / message on stderr and a non-zero exit code | `list`, `add` (flags or prompts for the fields), `edit` (flags for the fields that can change), `delete` with `[y/N]` or `--yes` |
| `chat` | a step of the conversation (a message the bot sends and the replies it accepts) | "typing" or a wait message / a reply saying there is nothing and what to send / a message saying what failed and what to send now | a "list" command, a guided add, an edit by field, a delete that asks for an explicit "yes" |

## web (in use)

- Pages and their URLs, server-rendered or client-rendered, and what works without JavaScript.
- Breakpoints from the smallest phone up, and the layout change at each one.
- Browsers and versions. Keyboard navigation and focus order.
- Text size, zoom to 200 % without loss of content (WCAG 1.4.4), and touch targets (44 px minimum, WCAG 2.5.5 AAA; 24 px is the AA floor).

## mobile

When a project chooses a mobile app (native or cross-platform), add a `### mobile` subsection and `mobile` to the header. Cover:

- Navigation model (tabs, stack, modal) and the back behaviour.
- Offline behaviour per flow: what works without a connection and what the screen shows.
- Platform guidelines the team follows (iOS Human Interface Guidelines, Material Design), and where the app deviates.
- Permissions requested and when (camera, notifications, location), with the screen that explains each one.
- Accessibility: dynamic type or font scaling, screen reader labels, reduced motion.

Then add `mobile` to the screens' `Platforms` column where the screen exists on mobile.

## desktop

When a project chooses a desktop window (for example a native or an Electron-style window), add a `### desktop` subsection and `desktop` to the header. Cover:

- Window model: single window or multiple windows, minimum size, what is resizable.
- Menus, keyboard shortcuts and the shortcut conflicts with the operating system.
- Data location and saving behaviour (autosave, explicit save, unsaved-changes prompt on close).
- Accessibility: keyboard-only use of every action, high-contrast themes, screen reader support for the platform (UI Automation on Windows, NSAccessibility on macOS).

## tui

A terminal program that takes the whole screen (panels, lists, forms; for example built with Textual, Bubble Tea or curses). Add a `### tui` subsection and `tui` to the header. Cover:

- Layout: the panels, the minimum terminal size (columns × rows) and what happens below it.
- Keys: the key map of each view, how the user discovers it (a footer, `?` for help), and quitting with unsaved changes.
- Forms: moving between fields, which fields are editable, where field errors appear.
- Terminals and fonts supported (Windows Terminal, the macOS terminal, SSH sessions), colours with a monochrome fallback.
- Accessibility: every action by keyboard, no meaning carried by colour alone, works with a screen reader reading the terminal.

## cli

Commands and prompts in a terminal, without a full-screen view. Add a `### cli` subsection and `cli` to the header. Each command or interactive prompt is a screen (S-NN). Cover:

- The command tree: each command, its arguments and flags, its defaults, and `--help` text.
- Output: human-readable by default, and a machine-readable option (`--json`) when other programs read it; what goes to stdout and to stderr.
- Exit codes: 0 for success, and one code per kind of failure the PRD or design names.
- Confirmation of destructive commands: a `[y/N]` prompt, `--yes` to skip it in scripts, and what happens when stdin is not a terminal.
- Accessibility: no meaning carried by colour alone, `NO_COLOR` respected, output that reads well in a screen reader.

## chat

A conversation: a messaging bot (WhatsApp, Telegram, Slack, Teams) or a voice assistant. Add a `### chat` subsection and `chat` to the header. Each step of the conversation is a screen (S-NN). Cover:

- The channel and its limits: message length, buttons or quick replies, attachments, the time window to answer.
- What the bot accepts at each step (free text, a button, a number), and what it says when it does not understand.
- How the user goes back, cancels and starts over; how a conversation left in the middle resumes.
- Confirmation before anything that changes or deletes data, with an explicit "yes".
- Accessibility: every button also works as typed text; for voice, the options read aloud and repeated on request.

## Other interfaces

Use the closest platform, and write the differences in its notes:

- A kiosk, a point-of-sale terminal or a TV app: `desktop` (or `web` when it runs in a browser), with the input device (touch, remote, barcode reader) in the notes.
- A smartwatch or a car screen: `mobile`, with the screen size and the input limits in the notes.
- A browser extension or a web view inside another app: `web`.
- An e-mail or an SMS the user answers: `chat`.

## Adding a platform

1. Add the platform to `PLATFORMS` in `scripts/check_ux.py`, to `INTERFACES` in factory-tech-design's `scripts/check_design.py` and to the set in factory-prd-to-tickets' `check_ui_spec`.
2. Add its subsection here, with its notes and its accessibility rules.
3. Add a row for it in `README.md` and in `SKILL.md`, if its rules change the workflow.
4. Add one fixture spec for it under `evals/fixtures/docs/ux/` and one eval case.

Do not add a platform before a project needs it.
