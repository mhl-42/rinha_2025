# UI Spec Template

Save as `docs/ux/<slug>.md`. Keep the headings, the table column names and the `Platforms:` values as they are, because `scripts/check_ux.py` reads them. Write the content in the user's language.

````markdown
# UI spec: <name>

PRD: docs/prd/<slug>.md
Platforms: web
Status: draft
Date: YYYY-MM-DD

## Screens

| id | Screen | Serves | Platforms | Action | States |
|----|--------|--------|-----------|--------|--------|
| S-01 | Request access link | RF-01 | web | Send link | loading, empty (form not filled), error |
| S-02 | Free slots | RF-02 | web | Choose slot | loading, empty (no free slots), error, slot-taken |
| S-07 | Patients (reception) | RF-08 | web | Find a patient | loading, empty (no patients yet), error |
| S-08 | Patient form (reception) | RF-08, RF-09 | web | Save patient | loading, empty (n/a), error, invalid (field errors), duplicate-email, saved |

Rules:
- One row per screen (or per distinct view of a screen). The id is `S-NN` and is unique.
- `Serves` lists the PRD requirements the screen delivers. Every FR must appear here or under *No interface*.
- `Platforms` is a subset of the header's `Platforms`.
- `States` must name `loading`, `empty` and `error`. Write `empty (n/a)` when the screen cannot be empty. Add screen-specific states (`slot-taken`, `duplicate-email`).
- A screen that creates or edits a record (see *Records*) also names `invalid`: what the user sees next to each field that was refused.

## Records

| Entity | List | Create | Edit | Delete |
|--------|------|--------|------|--------|
| Patient | S-07: search by name or e-mail, newest first | S-08 "New patient" button on S-07; open fields: name, e-mail, phone | S-08 from a row of S-07; editable: e-mail, phone; locked: name (BR-03) | S-07 row action; confirm dialog naming the patient; refused while the patient has a future session (BR-07) |
| Session | S-05 | S-02 (by choosing a slot) | n/a: a session is not edited, it is cancelled and booked again (BR-04) | S-05 "Cancel" with a confirmation step; allowed up to 24 h before (BR-05) |

Rules:
- One row per kind of record the user keeps on a screen (usually an entity of the domain model). When no screen keeps records, write `None: <reason>` instead of the table.
- Each of *List*, *Create*, *Edit* and *Delete* names the screen (S-NN) where it happens, or says `n/a: <reason>`. "Not needed" is not a reason; a business rule or the PRD is.
- *Create* lists the fields open to typing. *Edit* lists the fields that can change, and the ones that stay locked and why. Without them, the screens get built as read-only views. Take both from the domain model's *Attributes*, by the attribute's name: *Required* says which create fields are mandatory, *Changes* says which edit fields are open (`no` and `once` are locked after creation, `by <actor>` is open only to that actor), and a `calculated` attribute is shown, never typed.
- *Delete* says how the user confirms it (a dialog, typing the name, an undo window), and when it is refused. A soft delete (archive, deactivate) is written here too.

## Flows

- F-1 <name>: S-01 → S-02 → S-05
- F-2 <name>: S-05 → S-03 (if the slot was taken: S-03 shows "slot just taken")

Each step names a screen id from the table. The flow is what the user does, in order; one flow per FR group.

## No interface

| id | Reason |
|----|--------|
| RF-06 | The reminder e-mail is sent by a scheduled job; no screen is involved. |

## Components

- Slot button (free, taken, selected). Used by S-02, S-04.

Components that repeat across screens. Name them once, here, and say which screens use them.

## Accessibility

- RNF-06: text is 16 px or larger on patient screens; the patient flow meets WCAG 2.1 AA.

Every accessibility-related NFR of the PRD must be mentioned here by its id (the gate finds them by keywords such as WCAG, px, tap, contrast, text, screen reader, keyboard).

## Platform notes

### web

- Rendering model, breakpoints, supported browsers, what works without JavaScript.

Add one `### <platform>` subsection for each platform in the header. A platform with no notes fails the gate.

## Open questions

None
````

## Field values

- **Platforms:** `web`, `mobile`, `desktop`, `tui`, `cli` or `chat`, comma-separated, as the design chose. On `tui`, `cli` and `chat` a screen is a terminal view, a command or prompt, or a step of the conversation (see references/platforms.md).
- **States:** free text, with the three required states named.
- **Serves:** PRD ids only (`RF-03`); the gate fails unknown ids.
- **Reason** (No interface): why the requirement has no screen. "Not yet designed" is not a reason.
- **Records:** `n/a` (or `não se aplica`) followed by a reason; the delete cell mentions the confirmation (`confirm`, `confirmação`).

## Portuguese aliases

Headings: `Telas`, `Fluxos`, `Registros` (or `Cadastros`), `Sem interface`, `Acessibilidade`, `Notas por plataforma`, `Perguntas em aberto`. Column names stay in English. The checker reads the English column names only.
