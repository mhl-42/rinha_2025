#!/usr/bin/env python3
"""Quality gate for a UI spec written from references/ui-spec-template.md.

Checks that the spec is confirmed, every PRD functional requirement has a screen or is listed
under "No interface" with a reason, every screen lists its states, every flow step points to a
known screen, every declared platform has its platform notes, and the accessibility section covers
each accessibility NFR of the PRD. The Records section says, for each kind of record the user keeps,
where it is listed, created (fields open to typing), edited (which fields can change) and deleted
(with a confirmation), or why one of these does not apply; when the PRD links a domain model with
Attributes, the fields a create or edit cell lists are attributes of that entity. Open questions block the spec with NEEDS-ANSWERS.

Usage:
  python check_ux.py docs/ux/<slug>.md

Exit codes: 0 = PASS, 1 = FAIL, 2 = NEEDS-ANSWERS.
"""

from __future__ import annotations

import re
import sys
import unicodedata
from pathlib import Path

# Every kind of user interface: a browser, a phone, a desktop window, a full-screen terminal (TUI), commands and
# prompts in a terminal (CLI), and a conversation (a messaging bot or a voice assistant).
PLATFORMS = {"web", "mobile", "desktop", "tui", "cli", "chat"}
REQUIRED_STATES = ("loading", "empty", "error")
REQUIRED_COLUMNS = ("id", "screen", "serves", "platforms", "action", "states")
SECTION_ALIASES = {
    "screens": ("screens", "telas"),
    "flows": ("flows", "fluxos"),
    "no interface": ("no interface", "sem interface"),
    "records": ("records", "registros", "cadastros"),
    "accessibility": ("accessibility", "acessibilidade"),
    "platform notes": ("platform notes", "notas por plataforma"),
    "open questions": ("open questions", "perguntas em aberto"),
}
A11Y_RE = re.compile(r"WCAG|acessib|accessib|\bpx\b|toque|\btap|contrast|texto|text size|leitor|screen reader|teclado|keyboard", re.IGNORECASE)
PLACEHOLDER_RE = re.compile(r"\bTBD\b|\bTODO\b|\?\?\?", re.IGNORECASE)
SCREEN_ID_RE = re.compile(r"\bS-\d+\b")
FR_RE = re.compile(r"^###\s+(RF-\d+)\s*:", re.MULTILINE)
NFR_ROW_RE = re.compile(r"^\|\s*(RNF-\d+)\s*\|(.*)$", re.MULTILINE)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.MULTILINE)
RECORD_COLUMNS = ("entity", "list", "create", "edit", "delete")
NOT_APPLICABLE_RE = re.compile(r"^\s*(n/a|não se aplica|nao se aplica)\b[\s:—–-]*(.*)$", re.IGNORECASE)
NONE_RE = re.compile(r"^\s*(none|nenhum|nenhuma)\b[\s:—–-]*(.*)$", re.IGNORECASE | re.DOTALL)
CONFIRM_RE = re.compile(r"confirm|--yes|--force|\[[sy]/n\]", re.IGNORECASE)


def normalise_section(heading: str) -> str:
    name = re.sub(r"\(.*?\)", "", heading).strip().lower()
    for canonical, aliases in SECTION_ALIASES.items():
        if name in aliases:
            return canonical
    return name


def sections(text: str) -> dict[str, str]:
    found: dict[str, str] = {}
    matches = list(HEADING_RE.finditer(text))
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        found[normalise_section(match.group(1))] = text[match.end() : end]
    return found


def table_rows(body: str) -> list[dict[str, str]]:
    lines = [ln.strip() for ln in body.splitlines() if ln.strip().startswith("|")]
    if len(lines) < 2:
        return []
    header = [cell.strip().lower() for cell in lines[0].strip("|").split("|")]
    rows = []
    for line in lines[2:]:
        cells = [cell.strip() for cell in line.strip("|").split("|")]
        if len(cells) == len(header):
            rows.append(dict(zip(header, cells)))
    return rows


def resolve(ref: str, spec: Path) -> Path | None:
    """Resolve a repository-relative path from the spec file, the way the other gates do."""
    for parent in [spec.parent, *spec.parents]:
        candidate = parent / ref
        if candidate.is_file():
            return candidate
    return None


FIELDS_RE = re.compile(
    r"(?:open fields|editable|campos abertos|editáveis|editaveis|fields|campos)\s*:\s*([^;()]+)", re.IGNORECASE
)


def plain(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text)
    stripped = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", " ", stripped.lower()).strip()


def domain_attributes(prd_text: str, prd_path: Path | None) -> dict[str, set[str]]:
    """The attributes of each entity in the domain model the PRD links (its Attributes section), in plain form."""
    found = re.search(r"^(?:Domain|Domínio|Dominio)\s*:\s*(.+?)\s*$", prd_text, re.IGNORECASE | re.MULTILINE)
    domain_path = resolve(found.group(1), prd_path) if found and prd_path else None
    if domain_path is None:
        return {}
    attributes: dict[str, set[str]] = {}
    inside = False
    for row in domain_path.read_text(encoding="utf-8").splitlines():
        heading = re.match(r"^##\s+(.+?)\s*$", row)
        if heading:
            inside = heading.group(1).strip().lower() in ("attributes", "atributos")
            continue
        cells = [cell.strip() for cell in row.strip().strip("|").split("|")] if row.strip().startswith("|") else []
        if inside and len(cells) >= 2 and cells[0] and not set("".join(cells)) <= set("-: ") \
                and cells[0].lower() not in ("entity", "entidade"):
            attributes.setdefault(plain(cells[0]), set()).add(plain(cells[1]))
    return attributes


def check_record_fields(entity: str, column: str, cell: str, attributes: dict[str, set[str]]) -> list[str]:
    """The fields a Create or Edit cell lists are attributes of the entity in the domain model."""
    known = attributes.get(plain(entity))
    if not known:
        return []
    failures = []
    for listed in FIELDS_RE.findall(cell):
        for name in re.split(r",|\s+and\s+|\s+e\s+", listed):
            field = plain(name)
            if field and field not in known:
                failures.append(f"Records {entity}: '{column}' names the field '{name.strip()}', which is not an "
                                f"attribute of {entity} in the domain model's Attributes")
    return failures


def check_records(body: dict[str, str], screen_ids: list[str],
                  attributes: dict[str, set[str]] | None = None) -> list[str]:
    """Each kind of record the user keeps: where it is listed, created, edited and deleted, or why not."""
    if "records" not in body:
        return ["missing section '## Records': list each kind of record the user keeps, or 'None: <reason>'"]
    section = body["records"].strip()
    rows = table_rows(section)
    if not rows:
        none = NONE_RE.match(section)
        if none and len(none.group(2).strip()) >= 10:
            return []
        return ["Records: write the table, or 'None: <reason>' when no screen keeps records"]
    failures: list[str] = []
    missing = [c for c in RECORD_COLUMNS if c not in rows[0]]
    if missing:
        return [f"Records table is missing column(s): {', '.join(missing)}"]
    for row in rows:
        entity = row["entity"] or "?"
        for column in RECORD_COLUMNS[1:]:
            cell = row[column]
            not_applicable = NOT_APPLICABLE_RE.match(cell)
            if not_applicable:
                if len(not_applicable.group(2).strip()) < 10:
                    failures.append(f"Records {entity}: '{column}' is n/a without a reason")
                continue
            refs = SCREEN_ID_RE.findall(cell)
            if not refs:
                failures.append(f"Records {entity}: '{column}' must name the screen (S-NN) or be 'n/a: <reason>'")
                continue
            for ref in refs:
                if ref not in screen_ids:
                    failures.append(f"Records {entity}: '{column}' names {ref}, which is not in the Screens table")
            detail = re.sub(r"[^\w]", "", SCREEN_ID_RE.sub("", cell))
            if column in ("create", "edit") and len(detail) < 3:
                what = "the fields the user types" if column == "create" else "the fields that can change"
                failures.append(f"Records {entity}: '{column}' must list {what}")
            if column in ("create", "edit"):
                failures += check_record_fields(entity, column, cell, attributes or {})
            if column == "delete" and not CONFIRM_RE.search(cell):
                failures.append(f"Records {entity}: 'delete' must say how the user confirms it")
    return failures


def check(path: Path) -> tuple[list[str], list[str]]:
    failures: list[str] = []
    pending: list[str] = []
    text = path.read_text(encoding="utf-8")

    header = dict(re.findall(r"^(PRD|Status|Platforms):\s*(.+?)\s*$", text, re.MULTILINE))
    if "PRD" not in header:
        failures.append("header: missing 'PRD: <path>'")
    if not re.search(r"^status:\s*confirmed\b", text, re.IGNORECASE | re.MULTILINE):
        failures.append("the spec is not 'Status: confirmed'; confirm it with the user first")

    platforms = {p.strip().lower() for p in header.get("Platforms", "").split(",") if p.strip()}
    if not platforms:
        failures.append("header: missing 'Platforms: web' (comma list of web, mobile, desktop, tui, cli, chat)")
    for unknown in sorted(platforms - PLATFORMS):
        failures.append(f"header: unknown platform '{unknown}' (use web, mobile, desktop, tui, cli, chat)")

    prd_path = resolve(header["PRD"], path) if "PRD" in header else None
    if "PRD" in header and prd_path is None:
        failures.append(f"header: PRD not found at {header['PRD']}")
    prd_text = prd_path.read_text(encoding="utf-8") if prd_path else ""
    frs = FR_RE.findall(prd_text)
    a11y_nfrs = [
        rid for rid, rest in NFR_ROW_RE.findall(prd_text) if A11Y_RE.search(rest)
    ]

    body = sections(text)
    screens = table_rows(body.get("screens", ""))
    screen_ids = [row.get("id", "") for row in screens]
    served: set[str] = set()

    if not body.get("screens", "").strip():
        failures.append("missing section '## Screens'")
    for row in screens:
        missing = [c for c in REQUIRED_COLUMNS if c not in row]
        if missing:
            failures.append(f"Screens table is missing column(s): {', '.join(missing)}")
            break

    for row in screens:
        sid = row.get("id", "?")
        if not SCREEN_ID_RE.fullmatch(sid):
            failures.append(f"screen id '{sid}' must look like S-01")
        if screen_ids.count(sid) > 1:
            failures.append(f"screen {sid} is listed more than once")
        for rid in re.findall(r"RF-\d+", row.get("serves", "")):
            served.add(rid)
            if prd_text and rid not in frs:
                failures.append(f"{sid}: {rid} does not exist in the PRD")
        screen_platforms = {p.strip().lower() for p in row.get("platforms", "").split(",") if p.strip()}
        if not screen_platforms or not screen_platforms <= platforms:
            failures.append(f"{sid}: Platforms must be a subset of the spec's platforms ({', '.join(sorted(platforms))})")
        states = row.get("states", "").lower()
        for state in REQUIRED_STATES:
            if state not in states:
                failures.append(f"{sid}: states must include '{state}' (write it, even as 'empty (n/a)')")

    flows = body.get("flows", "")
    for ref in set(SCREEN_ID_RE.findall(flows)):
        if ref not in screen_ids:
            failures.append(f"flows: {ref} is not in the Screens table")

    no_interface = table_rows(body.get("no interface", ""))
    listed = set()
    for row in no_interface:
        rid = row.get("id", "")
        listed.add(rid)
        if not row.get("reason", "").strip():
            failures.append(f"{rid}: 'No interface' row needs a reason")
    for rid in frs:
        if rid not in served and rid not in listed:
            failures.append(f"{rid} has no screen and is not listed under 'No interface'")

    failures += check_records(body, screen_ids, domain_attributes(prd_text, prd_path))

    notes = body.get("platform notes", "")
    for platform in sorted(platforms):
        if not re.search(rf"^###\s+{platform}\b", notes, re.IGNORECASE | re.MULTILINE):
            failures.append(f"'Platform notes' needs a '### {platform}' subsection")

    accessibility = body.get("accessibility", "")
    if not accessibility.strip():
        failures.append("missing section '## Accessibility'")
    for rid in a11y_nfrs:
        if rid not in accessibility:
            failures.append(f"{rid} is an accessibility requirement in the PRD but is not covered in 'Accessibility'")

    if PLACEHOLDER_RE.search(text):
        failures.append("the spec still has placeholders (TBD, TODO or ???)")

    open_questions = body.get("open questions", "").strip()
    if open_questions and open_questions.lower() not in ("none", "nenhuma", "nenhum", "-"):
        pending.append("open questions remain; ask them in one numbered round with recommended answers")

    return failures, pending


def main() -> int:
    if len(sys.argv) != 2:
        print(__doc__, file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    if not path.is_file():
        print(f"Error: {path} not found", file=sys.stderr)
        return 1
    failures, pending = check(path)
    if failures:
        print("FAIL")
        for item in failures:
            print(f"  - {item}")
        return 1
    if pending:
        print("NEEDS-ANSWERS")
        for item in pending:
            print(f"  - {item}")
        return 2
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
