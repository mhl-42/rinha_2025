# Go Coding Standards

Rules for AI agents writing Go: errors with context, no panics for control flow, context propagation, goroutine lifecycles and shared state, HTTP clients and servers with deadlines, untrusted input, secure randomness, slog and package layout.

## Overview

This skill provides 11 rules across 7 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Errors | `err-` | CRITICAL | 2 |
| Context | `ctx-` | CRITICAL | 1 |
| Concurrency | `conc-` | CRITICAL | 2 |
| HTTP | `http-` | HIGH | 2 |
| Security | `sec-` | HIGH | 2 |
| Logging | `log-` | MEDIUM | 1 |
| Packages | `pkg-` | MEDIUM | 1 |

## Structure

```
skills/go-coding-standards/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from `go-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files; framework-specific rules (Gin, zerolog) replaced by the standard library (net/http, log/slog), and goroutine lifecycles, os.Root and server timeouts expanded.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
