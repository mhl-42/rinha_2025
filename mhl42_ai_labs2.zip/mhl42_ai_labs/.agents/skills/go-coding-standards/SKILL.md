---
name: go-coding-standards
description: Use this skill when writing, reviewing, or refactoring Go code — error handling and wrapping, context propagation and cancellation, goroutines, channels, mutexes and shutdown, HTTP clients and servers (timeouts, response bodies), package layout and interfaces, structured logging with log/slog, file paths, subprocesses, crypto and random tokens — even if the user only says "add a handler", "this service leaks goroutines", or "clean up this package". Not for tests (use go-testing), SQL and schema design (use postgres-database), or code in other languages.
license: MIT
compatibility: Go 1.22+ (log/slog, math/rand/v2, range over integers, per-iteration loop variables); os.Root needs Go 1.24+. Examples use only the standard library plus golang.org/x/sync/errgroup.
metadata:
  author: mhl42 (adapted from 0xMassi/Codex-skills, MIT)
  version: "1.1.0"
---

# Go Coding Standards

Rules for AI agents writing Go services, CLIs and libraries. The Quick Reference covers the common case; open a rule file when its trigger appears in the code you write or review.

## How to Use

- **Writing code**: return errors with context, pass `ctx` everywhere work can block, give every goroutine an owner and an exit, and put a deadline on every network call. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `return err` with no context, `_ = f()`, `err.Error() == "..."`, `if err != nil { log...; }` and continue | [err-wrap-and-inspect](rules/err-wrap-and-inspect.md) |
| `panic` for an expected failure; `recover` used for control flow; `log.Fatal` outside `main` | [err-no-panic](rules/err-no-panic.md) |
| A blocking function without `ctx context.Context`; `context.Background()` deep in the code; ctx stored in a struct | [ctx-propagate](rules/ctx-propagate.md) |
| `go func()` with no way to stop or wait for it; a channel nobody closes; `time.Sleep` loops | [conc-goroutine-lifecycle](rules/conc-goroutine-lifecycle.md) |
| A map or counter written by several goroutines; a struct with a mutex passed by value | [conc-shared-state](rules/conc-shared-state.md) |
| `http.Get`, `http.DefaultClient`, `&http.Client{}` without `Timeout`; a body not closed | [http-client](rules/http-client.md) |
| `http.ListenAndServe` with the default server; no shutdown on SIGTERM; `net/http/pprof` imported | [http-server](rules/http-server.md) |
| A user-supplied path joined to a directory; `exec.Command("sh", "-c", ...)`; `text/template` for HTML | [sec-untrusted-input](rules/sec-untrusted-input.md) |
| `math/rand` for tokens, ids or codes; `==` or `bytes.Equal` on secrets and signatures | [sec-crypto-random](rules/sec-crypto-random.md) |
| `log.Printf`, third-party loggers in new code, secrets or whole requests in log fields | [log-slog](rules/log-slog.md) |
| Interfaces declared next to their only implementation; `pkg/util`; a fat `main.go` | [pkg-layout](rules/pkg-layout.md) |

### Review Checklist

- [ ] `go vet ./...` and `gofmt -l .` are clean; `go test -race ./...` passes
- [ ] Every error is handled once: wrapped with context and returned, or logged and handled
- [ ] Every blocking call receives a `ctx`; every network call has a deadline
- [ ] Every goroutine has an owner that waits for it and a way to stop it
- [ ] Response bodies are closed; servers have timeouts and shut down gracefully
- [ ] No secret in source or logs; tokens from `crypto/rand`
- [ ] `govulncheck ./...` reports nothing reachable

## Gotchas

- A nil pointer of a concrete type stored in an `error` interface is not `nil`: `var e *MyErr; var err error = e; err != nil` is true. Return a literal `nil`.
- `defer resp.Body.Close()` before checking `err` panics when `resp` is nil; check `err` first.
- `defer` in a loop runs when the function returns, not at the end of each iteration; files opened in a long loop stay open.
- Writing to a nil map panics; reading from it returns the zero value.
- `time.After` in a `select` inside a loop allocates a timer per iteration; use one `time.NewTimer` or a ticker.
- `sync.Mutex` and structs containing one must not be copied after first use; `go vet` (copylocks) reports it.
- `append` may reuse the backing array: two slices appended from the same parent can overwrite each other.
- Since Go 1.22 each loop iteration has its own variable, so capturing `v` in a goroutine inside `for _, v := range` is safe; code for older Go is not.
- `json.Unmarshal` into a struct ignores unknown fields and leaves missing ones at zero; use a `Decoder` with `DisallowUnknownFields` and validate required fields.

## Categories

### Errors [CRITICAL]
Every failure is handled once, with context.

| Rule | Description |
|------|-------------|
| [err-wrap-and-inspect](rules/err-wrap-and-inspect.md) | Wrap with %w and context; inspect with errors.Is and errors.As |
| [err-no-panic](rules/err-no-panic.md) | Return errors; panic only for programmer bugs |

### Context and Concurrency [CRITICAL]
Work that can be cancelled and goroutines that end.

| Rule | Description |
|------|-------------|
| [ctx-propagate](rules/ctx-propagate.md) | ctx is the first parameter of anything that blocks |
| [conc-goroutine-lifecycle](rules/conc-goroutine-lifecycle.md) | Every goroutine has an owner, an exit and a waiter |
| [conc-shared-state](rules/conc-shared-state.md) | Guard shared state with one owner or a mutex; run the race detector |

### HTTP [HIGH]
Deadlines and clean shutdown on both sides.

| Rule | Description |
|------|-------------|
| [http-client](rules/http-client.md) | One client with timeouts; close and drain every body |
| [http-server](rules/http-server.md) | Server timeouts, graceful shutdown, private debug endpoints |

### Security [HIGH]
Untrusted input stays data; secrets stay secret.

| Rule | Description |
|------|-------------|
| [sec-untrusted-input](rules/sec-untrusted-input.md) | Confine paths with os.Root, run programs without a shell, escape HTML |
| [sec-crypto-random](rules/sec-crypto-random.md) | Tokens from crypto/rand; compare secrets in constant time |

### Structure [MEDIUM]
Readable packages and logs.

| Rule | Description |
|------|-------------|
| [log-slog](rules/log-slog.md) | Structured logging with log/slog, no secrets |
| [pkg-layout](rules/pkg-layout.md) | internal/ packages, consumer-side interfaces, thin main |

## Quick Reference

The model already applies the common rules of this skill unprompted (wrapping errors with %w, errors.Is, context first, http.Client timeouts). The examples below are the ones it tends to miss.

```go
// Shared state: the mutex lives with the data it guards; cleanup stops with ctx.
type Limiter struct {
	mu     sync.Mutex
	hits   map[string][]time.Time
	limit  int
	window time.Duration
	now    func() time.Time // injected so tests control time
}

func (l *Limiter) Allow(key string) bool {
	l.mu.Lock()
	defer l.mu.Unlock()
	cutoff := l.now().Add(-l.window)
	recent := slices.DeleteFunc(l.hits[key], func(t time.Time) bool { return t.Before(cutoff) })
	if len(recent) >= l.limit {
		l.hits[key] = recent
		return false
	}
	l.hits[key] = append(recent, l.now())
	return true
}

func (l *Limiter) Sweep(ctx context.Context) error {
	ticker := time.NewTicker(l.window)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			l.mu.Lock()
			maps.DeleteFunc(l.hits, func(_ string, ts []time.Time) bool { return len(ts) == 0 || ts[len(ts)-1].Before(l.now().Add(-l.window)) })
			l.mu.Unlock()
		}
	}
}

// Bounded concurrency with the first error returned and the rest cancelled.
g, ctx := errgroup.WithContext(ctx)
g.SetLimit(8)
for _, id := range ids {
	g.Go(func() error { return syncOne(ctx, id) })
}
err := g.Wait()

// A server without these timeouts is open to slow clients.
srv := &http.Server{Addr: ":8080", Handler: mux, ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 30 * time.Second, WriteTimeout: 30 * time.Second, IdleTimeout: 120 * time.Second}
```

## See Also

These are separate skills; use them if installed.

- `go-testing` - Table tests, fakes, httptest, race detector, fuzzing
- `postgres-database` - Parameterized queries, transactions and migrations
