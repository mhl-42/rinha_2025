# Section Definitions

## Errors (err)
**Impact:** CRITICAL

Every failure is handled once, with context.

**Rules:**
- `err-wrap-and-inspect` - Wrap with %w and context; inspect with errors.Is and errors.As
- `err-no-panic` - Return errors; panic only for programmer bugs

## Context (ctx)
**Impact:** CRITICAL

Work that can be cancelled.

**Rules:**
- `ctx-propagate` - ctx is the first parameter of anything that blocks

## Concurrency (conc)
**Impact:** CRITICAL

Goroutines that end and state that is not raced.

**Rules:**
- `conc-goroutine-lifecycle` - Every goroutine has an owner, an exit and a waiter
- `conc-shared-state` - Guard shared state with one owner or a mutex; run the race detector

## HTTP (http)
**Impact:** HIGH

Deadlines and clean shutdown on both sides.

**Rules:**
- `http-client` - One client with timeouts; close and drain every body
- `http-server` - Server timeouts, graceful shutdown, private debug endpoints

## Security (sec)
**Impact:** HIGH

Untrusted input stays data; secrets stay secret.

**Rules:**
- `sec-untrusted-input` - Confine paths with os.Root, run programs without a shell, escape HTML
- `sec-crypto-random` - Tokens from crypto/rand; compare secrets in constant time

## Logging (log)
**Impact:** MEDIUM

Structured logs without secrets.

**Rules:**
- `log-slog` - Structured logging with log/slog, no secrets

## Packages (pkg)
**Impact:** MEDIUM

Readable package boundaries.

**Rules:**
- `pkg-layout` - internal/ packages, consumer-side interfaces, thin main
