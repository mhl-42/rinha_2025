---
title: Every Goroutine Has an Owner, an Exit and a Waiter
impact: CRITICAL
impactDescription: No goroutine leaks, no lost errors, no work cut off at shutdown
tags: [concurrency, goroutines, errgroup, leaks, shutdown]
---

# Every Goroutine Has an Owner, an Exit and a Waiter [CRITICAL]

## Description
A `go func()` with no way to stop and nobody waiting for it leaks: it keeps running (and holding memory, connections, a blocked channel send) after the request or the test that started it. Its error has nowhere to go.

Before writing `go`, answer three questions: who waits for it (`errgroup`, `sync.WaitGroup`), how it stops (a cancelled `ctx`, a closed channel), and where its error goes. `errgroup.WithContext` answers all three for a batch of work: it waits, cancels the rest on the first error, and returns that error; `SetLimit` bounds the concurrency.

## Bad Example
```go
func (s *Server) Start() {
	go func() {
		for {
			s.refreshCache()
			time.Sleep(time.Minute) // runs forever, cannot be stopped or tested
		}
	}()
}

for _, id := range ids {
	go process(id) // errors lost; caller returns before any finishes
}
```

## Good Example
```go
func (s *Server) RefreshLoop(ctx context.Context) error {
	ticker := time.NewTicker(time.Minute)
	defer ticker.Stop()
	for {
		if err := s.refreshCache(ctx); err != nil {
			slog.ErrorContext(ctx, "refresh cache", "err", err)
		}
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
		}
	}
}

g, ctx := errgroup.WithContext(ctx)
g.SetLimit(10)
for _, id := range ids {
	g.Go(func() error { return process(ctx, id) })
}
if err := g.Wait(); err != nil {
	return fmt.Errorf("process batch: %w", err)
}
```

## Notes
- The goroutine that sends on a channel closes it; a receiver never closes.
- An unbuffered send with no receiver blocks forever: give a result channel a buffer of 1 when the receiver may have left.
- `sync.WaitGroup.Go` (Go 1.25+) starts and counts a goroutine in one call.

## References
- [errgroup package](https://pkg.go.dev/golang.org/x/sync/errgroup)
- [Go blog: Pipelines and cancellation](https://go.dev/blog/pipelines)
