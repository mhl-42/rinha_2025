---
title: Guard Shared State with One Owner or a Mutex; Run the Race Detector
impact: CRITICAL
impactDescription: No data races, which corrupt memory silently and crash maps
tags: [concurrency, mutex, race-detector, atomics, maps]
---

# Guard Shared State with One Owner or a Mutex; Run the Race Detector [CRITICAL]

## Description
Two goroutines touching the same variable with at least one writing is a data race: results are undefined, and concurrent map writes crash the process. Either give the data one owning goroutine that others talk to through channels, or guard every access with a `sync.Mutex` (`RWMutex` when reads dominate and are not trivial). Use `sync/atomic` types for single counters and flags.

Keep the lock and the data it guards in the same struct, lock for the shortest time, and never hold a lock across I/O or a channel operation. Run tests with `-race`: it finds races only on paths the tests execute, so it complements review, not replaces it.

## Bad Example
```go
var hits = map[string]int{}

func Track(path string) {
	hits[path]++ // called from every request goroutine: fatal error on concurrent map writes
}

type Cache struct {
	mu   sync.Mutex
	data map[string][]byte
}

func (c Cache) Get(k string) []byte { // value receiver copies the mutex
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.data[k]
}
```

## Good Example
```go
type Hits struct {
	mu     sync.Mutex
	counts map[string]int
}

func (h *Hits) Track(path string) {
	h.mu.Lock()
	h.counts[path]++
	h.mu.Unlock()
}

type Stats struct {
	requests atomic.Int64
}

func (s *Stats) Inc() { s.requests.Add(1) }
```

## Notes
- `sync.Map` fits caches written once and read many times, or keys disjoint per goroutine; a mutex and a map is clearer elsewhere.
- Do not return a slice or map that the lock guards; return a copy (`maps.Clone`, `slices.Clone`).

## References
- [The Go memory model](https://go.dev/ref/mem)
- [Data race detector](https://go.dev/doc/articles/race_detector)
