---
title: ctx Is the First Parameter of Anything That Blocks
impact: CRITICAL
impactDescription: Cancelled requests stop their work; deadlines reach every call
tags: [context, cancellation, deadlines, timeouts]
---

# ctx Is the First Parameter of Anything That Blocks [CRITICAL]

## Description
A request that the client abandoned, or that hit its deadline, should stop its database queries and outgoing calls. That only happens when the request's `context.Context` is passed down to them. Any function that does I/O, waits, or calls something that does takes `ctx context.Context` as its first parameter, and passes it on.

`context.Background()` belongs in `main`, in tests and at the top of a background job, not in the middle of a call chain, where it cuts the chain. Do not store a context in a struct: it ties the struct to one request.

## Bad Example
```go
type Repo struct{ ctx context.Context; db *sql.DB }

func (r *Repo) Orders(customerID string) ([]Order, error) {
	rows, err := r.db.QueryContext(context.Background(), query, customerID) // ignores the request
	// ...
}
```

## Good Example
```go
type Repo struct{ db *sql.DB }

func (r *Repo) Orders(ctx context.Context, customerID string) ([]Order, error) {
	rows, err := r.db.QueryContext(ctx, query, customerID)
	if err != nil {
		return nil, fmt.Errorf("orders of %s: %w", customerID, err)
	}
	defer rows.Close()
	// ...
}

func (h *Handler) ListOrders(w http.ResponseWriter, r *http.Request) {
	ctx, cancel := context.WithTimeout(r.Context(), 3*time.Second)
	defer cancel()
	orders, err := h.repo.Orders(ctx, r.PathValue("customer"))
	// ...
}
```

## Notes
- Always `defer cancel()` after `WithTimeout`, `WithDeadline` and `WithCancel`; `go vet` (lostcancel) reports a missing one.
- Context values are for request-scoped data that crosses APIs (a trace id), not for optional parameters.
- `context.WithoutCancel` (Go 1.21+) keeps values but drops cancellation, for work that must finish after the response (an audit write).

## References
- [context package](https://pkg.go.dev/context)
- [Go blog: Contexts and structs](https://go.dev/blog/context-and-structs)
