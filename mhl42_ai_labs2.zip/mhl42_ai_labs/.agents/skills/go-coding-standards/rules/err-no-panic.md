---
title: Return Errors; Panic Only for Programmer Bugs
impact: CRITICAL
impactDescription: An expected failure cannot crash the process or skip its cleanup
tags: [errors, panic, recover, log.Fatal]
---

# Return Errors; Panic Only for Programmer Bugs [CRITICAL]

## Description
`panic` unwinds the stack and, unless recovered, kills the whole process with every in-flight request. Use it only for states that mean the program itself is wrong (an impossible switch case, a broken invariant at init). Anything that can happen in production (bad input, a missing file, a failed call) returns an `error`.

`log.Fatal` and `os.Exit` skip deferred functions: files are not flushed, transactions not rolled back. Call them only in `main`, after returning the error up to it.

## Bad Example
```go
func ParseAmount(s string) int64 {
	n, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		panic(err) // a user typo crashes the server
	}
	return n
}

func loadConfig(path string) Config {
	data, err := os.ReadFile(path)
	if err != nil {
		log.Fatal(err) // deep inside a package
	}
	// ...
}
```

## Good Example
```go
func ParseAmount(s string) (int64, error) {
	n, err := strconv.ParseInt(s, 10, 64)
	if err != nil {
		return 0, fmt.Errorf("parse amount %q: %w", s, err)
	}
	return n, nil
}

func main() {
	if err := run(context.Background(), os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
```

## Notes
- `Must...` helpers (`regexp.MustCompile`, `template.Must`) are fine for values fixed at compile time, at package init.
- `net/http` recovers panics per request, but the handler's state may be left half-updated; do not rely on it.

## References
- [Effective Go: panic](https://go.dev/doc/effective_go#panic)
