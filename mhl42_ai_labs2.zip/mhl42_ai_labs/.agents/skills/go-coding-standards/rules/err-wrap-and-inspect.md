---
title: Wrap with %w and Context; Inspect with errors.Is and errors.As
impact: CRITICAL
impactDescription: Every error says where it happened and callers can still react to its cause
tags: [errors, wrapping, errors.Is, errors.As, sentinel]
---

# Wrap with %w and Context; Inspect with errors.Is and errors.As [CRITICAL]

## Description
A bare `return err` from five levels down produces `no rows in result set` with no hint of which query or which id. Add what this function was doing as the error goes up: `fmt.Errorf("load invoice %s: %w", id, err)`. `%w` keeps the original in the chain, so callers can still test it with `errors.Is` (a sentinel value) or `errors.As` (an error type). `%v` flattens it to text and breaks those checks.

Handle an error once: either return it (wrapped) or log it and recover, never both, or the same failure is logged at every level. Never discard an error with `_` unless the function's documentation says it cannot fail, and then say so.

## Bad Example
```go
func LoadInvoice(ctx context.Context, db *sql.DB, id string) (Invoice, error) {
	var inv Invoice
	err := db.QueryRowContext(ctx, query, id).Scan(&inv.ID, &inv.Total)
	if err != nil {
		log.Printf("error: %v", err)
		return inv, err
	}
	return inv, nil
}

if err.Error() == "sql: no rows in result set" { /* ... */ }
```

## Good Example
```go
var ErrInvoiceNotFound = errors.New("invoice not found")

func LoadInvoice(ctx context.Context, db *sql.DB, id string) (Invoice, error) {
	var inv Invoice
	err := db.QueryRowContext(ctx, query, id).Scan(&inv.ID, &inv.Total)
	if errors.Is(err, sql.ErrNoRows) {
		return Invoice{}, fmt.Errorf("load invoice %s: %w", id, ErrInvoiceNotFound)
	}
	if err != nil {
		return Invoice{}, fmt.Errorf("load invoice %s: %w", id, err)
	}
	return inv, nil
}

var pathErr *fs.PathError
if errors.As(err, &pathErr) {
	slog.Warn("cannot read file", "path", pathErr.Path)
}
```

## Notes
- Messages are lower case, without punctuation, and read as a chain: `charge order 42: load invoice 7: invoice not found`.
- Define a sentinel (`ErrX = errors.New(...)`) when callers branch on the condition; a type with fields when they need details.
- `errors.Join` combines several errors (from closing many resources) and still supports `errors.Is`.

## References
- [Go blog: Working with errors in Go 1.13](https://go.dev/blog/go1.13-errors)
- [errors package](https://pkg.go.dev/errors)
