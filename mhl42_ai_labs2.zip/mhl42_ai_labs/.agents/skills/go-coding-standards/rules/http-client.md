---
title: One Client with Timeouts; Close and Drain Every Body
impact: HIGH
impactDescription: Slow servers cannot hang callers; connections are reused instead of leaking
tags: [http, client, timeouts, response-body, connections]
---

# One Client with Timeouts; Close and Drain Every Body [HIGH]

## Description
`http.Get` and `http.DefaultClient` have no timeout: a server that accepts and never answers holds the goroutine forever. Create one `http.Client` per destination (or per application) with a `Timeout`, reuse it, and pass `ctx` with `http.NewRequestWithContext` for per-call deadlines and cancellation.

A response body that is not closed leaks the connection; one that is closed without being read to the end cannot be reused for the next request. Close it always, after checking `err`, and drain what you did not read.

## Bad Example
```go
func Rates() (Rates, error) {
	resp, err := http.Get("https://rates.example/latest")
	defer resp.Body.Close() // panics when err != nil
	var r Rates
	err = json.NewDecoder(resp.Body).Decode(&r) // 500 page decoded as rates
	return r, err
}
```

## Good Example
```go
var ratesClient = &http.Client{Timeout: 10 * time.Second}

func Rates(ctx context.Context) (Rates, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, "https://rates.example/latest", nil)
	if err != nil {
		return Rates{}, fmt.Errorf("rates request: %w", err)
	}
	resp, err := ratesClient.Do(req)
	if err != nil {
		return Rates{}, fmt.Errorf("get rates: %w", err)
	}
	defer func() {
		_, _ = io.Copy(io.Discard, resp.Body)
		resp.Body.Close()
	}()
	if resp.StatusCode != http.StatusOK {
		return Rates{}, fmt.Errorf("get rates: status %d", resp.StatusCode)
	}
	var r Rates
	if err := json.NewDecoder(io.LimitReader(resp.Body, 1<<20)).Decode(&r); err != nil {
		return Rates{}, fmt.Errorf("decode rates: %w", err)
	}
	return r, nil
}
```

## Notes
- Limit what you read from a body you do not control (`io.LimitReader`).
- Use the `http.Status...` and `http.Method...` constants rather than literals.
- Retry only idempotent requests and transient failures (timeouts, 502, 503, 504, 429 with `Retry-After`), with backoff and a limit.

## References
- [net/http: Client](https://pkg.go.dev/net/http#Client)
