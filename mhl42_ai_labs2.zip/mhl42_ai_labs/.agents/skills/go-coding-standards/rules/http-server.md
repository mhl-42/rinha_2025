---
title: Server Timeouts, Graceful Shutdown, Private Debug Endpoints
impact: HIGH
impactDescription: Slow clients cannot exhaust the server; deploys do not cut requests; profiles are not public
tags: [http, server, timeouts, shutdown, pprof]
---

# Server Timeouts, Graceful Shutdown, Private Debug Endpoints [HIGH]

## Description
`http.ListenAndServe` uses a server with no timeouts: a client that sends headers one byte a minute (Slowloris) holds a connection and a goroutine indefinitely. Build an `http.Server` with `ReadHeaderTimeout` at least, and read, write and idle timeouts that fit the endpoints.

On SIGTERM (every deploy), stop accepting connections and let in-flight requests finish with `Shutdown`, bounded by a deadline. Then close the database pool and flush logs.

Importing `net/http/pprof` registers `/debug/pprof` on `http.DefaultServeMux`; on a public server it exposes memory contents and lets anyone run CPU profiles. Serve it on a separate, internal listener, or not at all.

## Bad Example
```go
import _ "net/http/pprof"

func main() {
	http.HandleFunc("/orders", ordersHandler)
	log.Fatal(http.ListenAndServe(":8080", nil)) // default mux, pprof exposed, no timeouts
}
```

## Good Example
```go
func run(ctx context.Context) error {
	ctx, stop := signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)
	defer stop()

	mux := http.NewServeMux()
	mux.HandleFunc("GET /orders/{id}", h.GetOrder)

	srv := &http.Server{
		Addr:              ":8080",
		Handler:           mux,
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       30 * time.Second,
		WriteTimeout:      30 * time.Second,
		IdleTimeout:       120 * time.Second,
	}
	errCh := make(chan error, 1)
	go func() { errCh <- srv.ListenAndServe() }()

	select {
	case err := <-errCh:
		return fmt.Errorf("listen: %w", err)
	case <-ctx.Done():
	}
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	return srv.Shutdown(shutdownCtx)
}
```

## Notes
- Method and path patterns in `ServeMux` (`"GET /orders/{id}"`, `r.PathValue("id")`) need Go 1.22+.
- Limit request bodies with `http.MaxBytesReader`.
- Streaming endpoints need their own write deadline (`http.ResponseController.SetWriteDeadline`) instead of a short global one.

## References
- [net/http: Server](https://pkg.go.dev/net/http#Server)
- [net/http: Server.Shutdown](https://pkg.go.dev/net/http#Server.Shutdown)
