---
title: Structured Logging with log/slog, No Secrets
impact: MEDIUM
impactDescription: Logs can be searched by field and never leak credentials
tags: [logging, slog, observability, secrets]
---

# Structured Logging with log/slog, No Secrets [MEDIUM]

## Description
`log.Printf("user %s failed: %v", id, err)` produces text that has to be parsed again to be searched. `log/slog` (Go 1.21+) writes key-value records, as JSON in production, and is the standard choice for new code: no dependency, and handlers for other backends exist. Follow the logger the project already uses when it has one.

Configure the handler once in `main`, attach request-scoped fields with `With`, and pass `ctx` (`InfoContext`) so handlers can add trace ids. Never log secrets, tokens, passwords or whole requests; a `LogValuer` on sensitive types makes them redact themselves.

## Bad Example
```go
log.Printf("login failed for %s with password %s: %v", email, password, err)
log.Printf("request: %+v", r)
```

## Good Example
```go
logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: slog.LevelInfo}))
slog.SetDefault(logger)

reqLog := logger.With("request_id", requestID, "route", "POST /login")
reqLog.WarnContext(ctx, "login failed", "user_id", userID, "err", err)

type Token string

func (Token) LogValue() slog.Value { return slog.StringValue("[redacted]") }
```

## Notes
- Use consistent keys across the code (`user_id`, `err`, `duration_ms`).
- Log an error where it is handled, not at every level that returns it.

## References
- [log/slog](https://pkg.go.dev/log/slog)
- [Go blog: Structured logging with slog](https://go.dev/blog/slog)
