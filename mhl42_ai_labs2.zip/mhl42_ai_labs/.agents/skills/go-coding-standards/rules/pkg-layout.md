---
title: internal/ Packages, Consumer-Side Interfaces, Thin main
impact: MEDIUM
impactDescription: Packages can change without breaking importers; dependencies are easy to fake
tags: [packages, interfaces, layout, internal, main]
---

# internal/ Packages, Consumer-Side Interfaces, Thin main [MEDIUM]

## Description
- **internal/:** code under `internal/` can only be imported by its parent tree, so it can change freely. Application code lives there; a `pkg/` directory is only for code other modules really import.
- **Packages by what they provide** (`billing`, `orders`), not by kind (`models`, `utils`, `helpers`), which every package ends up importing.
- **Interfaces belong to the consumer:** a package returns concrete types; the code that needs to swap or fake a dependency declares the small interface it uses. An interface declared next to its only implementation is ceremony.
- **Thin main:** `main` parses flags and environment, wires dependencies, and calls `run(ctx) error`, so the program's logic is testable.

## Bad Example
```go
// internal/orders/repository.go
type OrderRepository interface { // declared by the producer, 12 methods, one implementation
	Get(ctx context.Context, id string) (Order, error)
	// ...
}
type orderRepository struct{ db *sql.DB }
func NewOrderRepository(db *sql.DB) OrderRepository { return &orderRepository{db} }
```

## Good Example
```go
// internal/orders/store.go
type Store struct{ db *sql.DB }
func NewStore(db *sql.DB) *Store { return &Store{db: db} }
func (s *Store) Get(ctx context.Context, id string) (Order, error) { /* ... */ }

// internal/billing/service.go
type orderGetter interface {
	Get(ctx context.Context, id string) (orders.Order, error)
}

type Service struct{ orders orderGetter }
```

## Notes
- Accept interfaces, return structs: callers get the full concrete API, and tests pass a fake for the one method used.
- Exported identifiers have doc comments that start with their name.
- Use the project's existing layout when it has one; do not reorganize packages in a change that does something else.

## References
- [Go: Organizing a Go module](https://go.dev/doc/modules/layout)
- [Go Code Review Comments: interfaces](https://go.dev/wiki/CodeReviewComments#interfaces)
