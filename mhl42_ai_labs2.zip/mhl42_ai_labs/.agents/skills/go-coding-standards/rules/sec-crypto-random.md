---
title: Tokens from crypto/rand; Compare Secrets in Constant Time
impact: HIGH
impactDescription: Session ids and reset tokens cannot be guessed or timed
tags: [security, crypto, random, tokens, timing]
---

# Tokens from crypto/rand; Compare Secrets in Constant Time [HIGH]

## Description
`math/rand` and `math/rand/v2` are fast and predictable: fine for jitter, sampling and shuffling test data, never for anything that grants access. Tokens, session ids, API keys and one-time codes come from `crypto/rand`. Compare secrets and signatures with `crypto/subtle.ConstantTimeCompare` or `hmac.Equal`, which do not stop at the first differing byte.

Secrets are read from the environment or a secret manager, never written in source.

## Bad Example
```go
token := fmt.Sprintf("%d", rand.Int63())

if r.Header.Get("X-Signature") == expected {
	accept()
}

const apiKey = "sk_live_51H..."
```

## Good Example
```go
func NewToken() string {
	return rand.Text() // crypto/rand, Go 1.24+: 26 base32 characters, 128+ bits
}

func validSignature(body []byte, header string, secret []byte) bool {
	mac := hmac.New(sha256.New, secret)
	mac.Write(body)
	received, err := hex.DecodeString(header)
	return err == nil && hmac.Equal(received, mac.Sum(nil))
}

apiKey := os.Getenv("PAYMENTS_API_KEY")
if apiKey == "" {
	return errors.New("PAYMENTS_API_KEY is not set")
}
```

## Notes
- Before Go 1.24: `b := make([]byte, 32); rand.Read(b); base64.RawURLEncoding.EncodeToString(b)` with `crypto/rand`.
- Passwords are hashed with `golang.org/x/crypto/argon2` or `bcrypt`, never with a plain SHA.

## References
- [crypto/rand](https://pkg.go.dev/crypto/rand)
- [crypto/subtle](https://pkg.go.dev/crypto/subtle)
