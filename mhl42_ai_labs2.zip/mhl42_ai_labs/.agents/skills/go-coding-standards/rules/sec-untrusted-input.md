---
title: Confine Paths with os.Root, Run Programs Without a Shell, Escape HTML
impact: HIGH
impactDescription: Prevents path traversal, command injection and cross-site scripting
tags: [security, path-traversal, os.Root, exec, html-template, sql]
---

# Confine Paths with os.Root, Run Programs Without a Shell, Escape HTML [HIGH]

## Description
- **Paths:** `filepath.Join(base, userPath)` with `../../etc/passwd` leaves `base`. `os.Root` (Go 1.24+) opens files relative to a directory and refuses any path, `..` or symlink that escapes it.
- **Programs:** `exec.Command("sh", "-c", "convert " + name)` runs a shell, so `name` can be a command. `exec.Command("convert", name, out)` passes arguments without one.
- **HTML:** `text/template` does not escape; `html/template` escapes by context (HTML, attributes, JavaScript, URLs).
- **SQL:** placeholders (`$1`, `?`), never `fmt.Sprintf` into a query.

## Bad Example
```go
data, err := os.ReadFile(filepath.Join("/srv/uploads", r.URL.Query().Get("name")))

out, err := exec.Command("sh", "-c", "convert "+name+" thumb.png").Output()

tmpl := texttemplate.Must(texttemplate.New("p").Parse(`<p>{{.Comment}}</p>`))

rows, err := db.QueryContext(ctx, fmt.Sprintf("SELECT id FROM users WHERE email = '%s'", email))
```

## Good Example
```go
root, err := os.OpenRoot("/srv/uploads")
if err != nil {
	return fmt.Errorf("open uploads: %w", err)
}
defer root.Close()
f, err := root.Open(r.URL.Query().Get("name")) // fails for paths outside /srv/uploads

cmd := exec.CommandContext(ctx, "convert", "--", name, "thumb.png")

tmpl := template.Must(template.New("p").Parse(`<p>{{.Comment}}</p>`)) // html/template

rows, err := db.QueryContext(ctx, "SELECT id FROM users WHERE email = $1", email)
```

## Notes
- Before Go 1.24, use `filepath.IsLocal` on the user part and check the cleaned result is under the base.
- Decode JSON with `DisallowUnknownFields` and a size limit, and validate the values before using them.

## References
- [Go blog: Traversal-resistant file APIs](https://go.dev/blog/osroot)
- [html/template](https://pkg.go.dev/html/template)
