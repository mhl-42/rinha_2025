# Go Testing

Rules for AI agents writing Go tests: table-driven subtests, helpers and cleanup, readable diffs and error checks, fakes and httptest, controlled time, the race detector and test order, and native fuzzing.

## Overview

This skill provides 7 rules across 6 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Structure | `struct-` | CRITICAL | 2 |
| Assertions | `assert-` | CRITICAL | 1 |
| Isolation | `iso-` | HIGH | 1 |
| Time | `time-` | HIGH | 1 |
| Races | `race-` | HIGH | 1 |
| Fuzzing | `fuzz-` | MEDIUM | 1 |

## Structure

```
skills/go-testing/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from the Go part of `testing-patterns` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT), split into rule files, with rules on helpers, synctest, test order and fuzzing.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
