# Section Definitions

## Structure (struct)
**Impact:** CRITICAL

Named cases and clean setup.

**Rules:**
- `struct-table-driven` - Table-driven tests with named subtests
- `struct-helpers-and-cleanup` - t.Helper, t.Cleanup, t.TempDir and t.Context instead of manual setup

## Assertions (assert)
**Impact:** CRITICAL

Failures that explain themselves.

**Rules:**
- `assert-diffs-and-errors` - Show got and want with cmp.Diff; check errors by kind

## Isolation (iso)
**Impact:** HIGH

Control what the code does not own.

**Rules:**
- `iso-fakes-and-httptest` - Hand-written fakes for small interfaces; httptest for HTTP

## Time (time)
**Impact:** HIGH

Deterministic time without sleeping.

**Rules:**
- `time-control` - Inject the clock or use testing/synctest instead of sleeping

## Races (race)
**Impact:** HIGH

Tests independent of each other and of scheduling.

**Rules:**
- `race-and-order` - Run with -race and -shuffle; no shared mutable state

## Fuzzing (fuzz)
**Impact:** MEDIUM

Inputs nobody thought of.

**Rules:**
- `fuzz-native` - Fuzz parsers and decoders with go test -fuzz
