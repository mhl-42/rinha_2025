---
title: Show Got and Want with cmp.Diff; Check Errors by Kind
impact: CRITICAL
impactDescription: A failure explains itself; tests do not break when an error message is reworded
tags: [assertions, cmp, errors, diff]
---

# Show Got and Want with cmp.Diff; Check Errors by Kind [CRITICAL]

## Description
`t.Errorf("not equal")` forces whoever reads the failure to rerun it with prints. Report the call, what it returned and what was expected: `Parse(%q) = %v, want %v`. For structs and slices, `cmp.Diff(want, got)` prints only the fields that differ.

Check errors by kind with `errors.Is` (sentinel) or `errors.As` (type), not by comparing `err.Error()` strings, which break on rewording. A test that expects success should also check the result, not only `err == nil`.

## Bad Example
```go
got, err := LoadOrder(ctx, "42")
if err != nil {
	t.Fatal(err)
}
if !reflect.DeepEqual(got, want) {
	t.Error("orders differ")
}

_, err = LoadOrder(ctx, "missing")
if err.Error() != "load order missing: order not found" {
	t.Error("wrong error")
}
```

## Good Example
```go
got, err := LoadOrder(ctx, "42")
if err != nil {
	t.Fatalf("LoadOrder(42) unexpected error: %v", err)
}
if diff := cmp.Diff(want, got); diff != "" {
	t.Errorf("LoadOrder(42) mismatch (-want +got):\n%s", diff)
}

_, err = LoadOrder(ctx, "missing")
if !errors.Is(err, ErrOrderNotFound) {
	t.Errorf("LoadOrder(missing) error = %v, want ErrOrderNotFound", err)
}
```

## Notes
- Use `t.Fatalf` when the rest of the test cannot run (a nil result), `t.Errorf` to report and continue.
- Without go-cmp, compare field by field with clear messages; avoid adding an assertion library only for this.

## References
- [go-cmp](https://pkg.go.dev/github.com/google/go-cmp/cmp)
- [Go Code Review Comments: useful test failures](https://go.dev/wiki/CodeReviewComments#useful-test-failures)
