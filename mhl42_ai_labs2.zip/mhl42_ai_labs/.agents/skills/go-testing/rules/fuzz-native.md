---
title: Fuzz Parsers and Decoders with go test -fuzz
impact: MEDIUM
impactDescription: Finds panics and wrong results on inputs nobody wrote down
tags: [fuzzing, parsers, robustness, testing]
---

# Fuzz Parsers and Decoders with go test -fuzz [MEDIUM]

## Description
Code that reads untrusted input (parsers, decoders, validators, protocol handlers) must not panic and should keep its invariants for any input. Go's native fuzzing generates inputs from a seed corpus, and saves any failing input under `testdata/fuzz` so it becomes a regular test case.

Check a property, not a fixed output: no panic, a round trip (`Parse(Format(x)) == x`), or agreement with a simpler reference.

## Bad Example
```go
func TestParseAmount(t *testing.T) {
	if _, err := ParseAmount("12,34"); err != nil {
		t.Fatal(err)
	}
}
```

## Good Example
```go
func FuzzParseAmount(f *testing.F) {
	for _, seed := range []string{"0", "12,34", "1.234,56", "-1", "", "9999999999999999999"} {
		f.Add(seed)
	}
	f.Fuzz(func(t *testing.T, in string) {
		cents, err := ParseAmount(in)
		if err != nil {
			return // refusing is fine; panicking is not
		}
		if cents < 0 {
			t.Fatalf("ParseAmount(%q) = %d, negative amounts must be refused", in, cents)
		}
		if again, err := ParseAmount(FormatAmount(cents)); err != nil || again != cents {
			t.Fatalf("round trip of %d gave %d, %v", cents, again, err)
		}
	})
}
```

## Notes
- Without `-fuzz`, `go test` runs only the seeds and the saved corpus, so the fuzz test is cheap in CI; run the fuzzer itself on a schedule or before a release.
- Commit `testdata/fuzz` entries the fuzzer found.

## References
- [Go fuzzing](https://go.dev/doc/security/fuzz/)
