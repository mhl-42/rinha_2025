---
title: Hand-Written Fakes for Small Interfaces; httptest for HTTP
impact: HIGH
impactDescription: Tests run offline, fast, and read as plain Go
tags: [isolation, fakes, httptest, interfaces, mocks]
---

# Hand-Written Fakes for Small Interfaces; httptest for HTTP [HIGH]

## Description
When the code depends on a small interface declared by the consumer (see go-coding-standards), a fake is a few lines of Go: a struct with the fields the test sets and reads. It is easier to read than a generated mock with expectations on call order, and it does not break when the implementation changes how often it calls.

For outgoing HTTP, point the client at an `httptest.Server` that answers like the real service, including its errors. For handlers, call them with `httptest.NewRequest` and `httptest.NewRecorder`, through the same router and middleware as production.

## Bad Example
```go
func TestRates(t *testing.T) {
	r, err := Rates(context.Background()) // calls the real API: slow, flaky, needs network
	// ...
}
```

## Good Example
```go
type fakeMailer struct{ sent []Message }

func (f *fakeMailer) Send(_ context.Context, m Message) error {
	f.sent = append(f.sent, m)
	return nil
}

func TestRatesUnavailable(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.WriteHeader(http.StatusServiceUnavailable)
	}))
	t.Cleanup(srv.Close)

	client := NewRatesClient(srv.URL, srv.Client())
	_, err := client.Latest(t.Context())
	if !errors.Is(err, ErrRatesUnavailable) {
		t.Fatalf("Latest() error = %v, want ErrRatesUnavailable", err)
	}
}

func TestGetOrderNotFound(t *testing.T) {
	mux := NewRouter(&Handler{orders: emptyStore{}})
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, httptest.NewRequest(http.MethodGet, "/orders/99", nil))
	if rec.Code != http.StatusNotFound {
		t.Errorf("GET /orders/99 status = %d, want 404", rec.Code)
	}
}
```

## Notes
- Integration tests against a real database belong in their own files, skipped with `testing.Short()` or a build tag, and run in CI.
- Make base URLs and clients injectable in the code so tests can point them at `httptest`.

## References
- [net/http/httptest](https://pkg.go.dev/net/http/httptest)
