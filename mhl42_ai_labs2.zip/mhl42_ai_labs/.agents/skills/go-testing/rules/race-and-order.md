---
title: Run with -race and -shuffle; No Shared Mutable State
impact: HIGH
impactDescription: Races and order dependencies show up in CI, not in production
tags: [race-detector, shuffle, parallel, isolation]
---

# Run with -race and -shuffle; No Shared Mutable State [HIGH]

## Description
The race detector reports concurrent unsynchronized access while tests run; without `-race` in CI, races reach production. `-shuffle=on` runs tests in random order and prints the seed, exposing tests that pass only after another one has set something up.

Package-level variables that tests modify (a global config, a default client, a fixture slice) couple tests to each other and make `t.Parallel` unsafe. Build what each test needs inside it.

## Bad Example
```go
var store = NewMemoryStore() // shared by every test in the package

func TestCreate(t *testing.T) { store.Add(Item{ID: "1"}) }
func TestList(t *testing.T) {
	if len(store.List()) != 1 { // passes only after TestCreate
		t.Fatal("expected one item")
	}
}
```

## Good Example
```go
func TestList(t *testing.T) {
	t.Parallel()
	store := NewMemoryStore()
	store.Add(Item{ID: "1"})
	if got := len(store.List()); got != 1 {
		t.Fatalf("List() returned %d items, want 1", got)
	}
}
```

```bash
go test -race -shuffle=on ./...
go test -race -shuffle=1712345678 -run TestList ./internal/store
```

## Notes
- `-race` needs cgo; on platforms without it, run the race job on Linux in CI.
- `-count=10` on a suspected flaky test reproduces timing problems.

## References
- [Data race detector](https://go.dev/doc/articles/race_detector)
- [go test flags](https://pkg.go.dev/cmd/go#hdr-Testing_flags)
