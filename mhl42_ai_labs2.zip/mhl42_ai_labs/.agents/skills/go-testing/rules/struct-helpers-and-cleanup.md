---
title: t.Helper, t.Cleanup, t.TempDir and t.Context Instead of Manual Setup
impact: CRITICAL
impactDescription: Setup is reusable, failures point at the test line, and nothing is left behind
tags: [structure, helpers, cleanup, tempdir, context]
---

# t.Helper, t.Cleanup, t.TempDir and t.Context Instead of Manual Setup [CRITICAL]

## Description
Setup code repeated in every test, and cleanup written at the end of the test body, are skipped when the test fails early. Move setup into helpers that take `t`, call `t.Helper()` (so a failure is reported at the caller's line), and register teardown with `t.Cleanup`, which runs even after `t.Fatal`.

`t.TempDir()` gives a directory removed after the test; `t.Setenv` restores the variable; `t.Context()` (Go 1.24+) is cancelled when the test ends, so goroutines started with it stop.

## Bad Example
```go
func TestImport(t *testing.T) {
	os.Mkdir("tmp", 0o755)
	db, _ := sql.Open("sqlite", "tmp/test.db")
	// ... the test ...
	db.Close()
	os.RemoveAll("tmp") // skipped when the test fails above
}
```

## Good Example
```go
func newTestDB(t *testing.T) *sql.DB {
	t.Helper()
	db, err := sql.Open("sqlite", filepath.Join(t.TempDir(), "test.db"))
	if err != nil {
		t.Fatalf("open test db: %v", err)
	}
	t.Cleanup(func() { db.Close() })
	if err := migrate(t.Context(), db); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	return db
}

func TestImport(t *testing.T) {
	db := newTestDB(t)
	t.Setenv("IMPORT_BATCH_SIZE", "2")
	// ... the test ...
}
```

## Notes
- `TestMain` is for setup shared by the whole package (starting one database container); prefer per-test helpers otherwise.
- `t.Setenv` cannot be combined with `t.Parallel` in the same test.

## References
- [testing package](https://pkg.go.dev/testing)
