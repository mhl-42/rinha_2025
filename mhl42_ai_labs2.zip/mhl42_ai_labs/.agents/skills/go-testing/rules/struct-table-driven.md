---
title: Table-Driven Tests with Named Subtests
impact: CRITICAL
impactDescription: Adding a case is one line, and a failure names the case
tags: [structure, table-driven, subtests, t.Run]
---

# Table-Driven Tests with Named Subtests [CRITICAL]

## Description
Several test functions that differ only in inputs repeat the logic and drift apart. Put the cases in a slice of structs, each with a `name` that describes the situation, and run each with `t.Run(tt.name, ...)`. A failure then reads `TestParseAmount/negative_is_refused`, and `go test -run 'TestParseAmount/negative'` reruns just that case.

Keep one table per behaviour. A table whose struct grows flags that switch the test's logic (`setupMock bool`, `checkHeader bool`) is several tests forced into one; split it.

## Bad Example
```go
func TestDiscount(t *testing.T) {
	for _, c := range []struct{ total, want int }{{100, 100}, {1000, 900}, {5000, 4000}} {
		if got := Discount(c.total); got != c.want {
			t.Errorf("wrong discount") // which case? what was got?
		}
	}
}
```

## Good Example
```go
func TestDiscount(t *testing.T) {
	tests := []struct {
		name  string
		total int
		want  int
	}{
		{name: "below the first tier pays full price", total: 100, want: 100},
		{name: "first tier gets 10% off", total: 1000, want: 900},
		{name: "second tier gets 20% off", total: 5000, want: 4000},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := Discount(tt.total); got != tt.want {
				t.Errorf("Discount(%d) = %d, want %d", tt.total, got, tt.want)
			}
		})
	}
}
```

## Notes
- Include the edge values in the table: zero, the exact tier boundary, the maximum.
- `t.Parallel()` in subtests is safe in Go 1.22+ without copying `tt`; with older Go add `tt := tt`.

## References
- [Go wiki: TableDrivenTests](https://go.dev/wiki/TableDrivenTests)
