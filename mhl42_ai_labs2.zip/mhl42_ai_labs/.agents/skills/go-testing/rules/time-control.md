---
title: Inject the Clock or Use testing/synctest Instead of Sleeping
impact: HIGH
impactDescription: Timing tests are instant and never flaky
tags: [time, synctest, clock, flaky, concurrency]
---

# Inject the Clock or Use testing/synctest Instead of Sleeping [HIGH]

## Description
`time.Sleep` in a test is either too long (slow suite) or too short on a loaded CI machine (flaky). Code that calls `time.Now()` directly gives different results depending on when it runs.

Two ways out:
- **Inject time:** the code takes a `now func() time.Time` (or a small clock interface); the test passes a fixed one.
- **testing/synctest** (Go 1.25+): code inside `synctest.Test` runs in a bubble with a fake clock that advances only when every goroutine in it is blocked, so timeouts, tickers and `time.Sleep` complete instantly and deterministically.

## Bad Example
```go
func TestSessionExpires(t *testing.T) {
	s := NewSession(100 * time.Millisecond)
	time.Sleep(150 * time.Millisecond)
	if !s.Expired() {
		t.Error("session should be expired")
	}
}
```

## Good Example
```go
func TestSessionExpires(t *testing.T) {
	synctest.Test(t, func(t *testing.T) {
		s := NewSession(30 * time.Minute)
		time.Sleep(30*time.Minute + time.Second) // instant inside the bubble
		if !s.Expired() {
			t.Error("session not expired 30 minutes after creation")
		}
	})
}

func TestOverdue(t *testing.T) {
	now := func() time.Time { return time.Date(2026, 1, 11, 9, 0, 0, 0, time.UTC) }
	inv := Invoice{DueAt: time.Date(2026, 1, 10, 23, 59, 0, 0, time.UTC)}
	if !inv.Overdue(now) {
		t.Error("invoice due yesterday is not overdue")
	}
}
```

## Notes
- `synctest.Wait()` blocks until every goroutine in the bubble is blocked, which replaces "sleep a bit and hope the goroutine ran".
- Use explicit time zones in test dates; `time.Local` differs between machines.

## References
- [testing/synctest](https://pkg.go.dev/testing/synctest)
- [Go blog: Testing concurrent code with testing/synctest](https://go.dev/blog/synctest)
