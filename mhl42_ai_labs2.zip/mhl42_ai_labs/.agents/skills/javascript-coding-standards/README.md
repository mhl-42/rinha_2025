# JavaScript Coding Standards

Rules for AI agents writing JavaScript, mostly Node.js: injection-free code, secure randomness, secrets, errors, deadlines and cancellation, non-blocking I/O, streams, ES modules, the platform before dependencies, JSDoc type checking and cheap performance wins.

## Overview

This skill provides 11 rules across 8 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Security | `sec-` | CRITICAL | 3 |
| Errors | `err-` | HIGH | 1 |
| Async | `async-` | HIGH | 2 |
| I/O | `io-` | MEDIUM | 1 |
| Modules | `mod-` | MEDIUM | 1 |
| Runtime | `runtime-` | MEDIUM | 1 |
| Types | `types-` | MEDIUM | 1 |
| Performance | `perf-` | LOW | 1 |

## Structure

```
skills/javascript-coding-standards/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Usage

The agent loads this skill for JavaScript and for the Node runtime parts of TypeScript code. Tests use `typescript-testing`.

## Origin

Adapted from `javascript-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files; CommonJS replaced by ES modules, `Promise.race` timeouts replaced by `AbortSignal`, and JSDoc type checking added.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
