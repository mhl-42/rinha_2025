---
name: javascript-coding-standards
description: Use this skill when writing, reviewing, or refactoring JavaScript (.js, .mjs, .cjs), especially Node.js services, scripts and CLIs — modules (ESM or CommonJS), error handling, async code, timeouts and cancellation with AbortController, file and stream I/O, child processes, crypto and tokens, secrets in env and logs, and dependencies Node already ships — even if the user only says "add an endpoint", "write a script that processes this file", or "this service leaks memory". Also applies to the Node runtime parts of TypeScript code. Not for TypeScript types and tsconfig (use typescript-coding-standards), tests (use typescript-testing), SQL (use postgres-database), or code in other languages.
license: MIT
compatibility: Node.js 22 LTS or later (fetch, AbortSignal.timeout and AbortSignal.any, --env-file, node:test, util.parseArgs); the browser rules hold in any current browser. Type checking of plain JavaScript uses JSDoc with the TypeScript compiler (checkJs).
metadata:
  author: mhl42 (adapted from 0xMassi/claude-skills, MIT)
  version: "1.1.0"
---

# JavaScript Coding Standards

Rules for AI agents writing JavaScript, mostly on Node.js. The Quick Reference covers the common case; open a rule file when its trigger appears in the code you write or review.

## How to Use

- **Writing code**: use the platform first (ESM, `fetch`, `AbortController`, streams, `node:crypto`), give every outside call a deadline, and never let an error or a promise disappear. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `eval`, `new Function`, `innerHTML` with data, `child_process.exec` with a built string | [sec-no-code-injection](rules/sec-no-code-injection.md) |
| `Math.random()` for ids, tokens or codes; `===` comparing secrets or signatures | [sec-secure-random](rules/sec-secure-random.md) |
| Keys or passwords as literals; whole config or request objects logged; `NODE_TLS_REJECT_UNAUTHORIZED=0` | [sec-secrets](rules/sec-secrets.md) |
| `catch (e) {}`, `.catch(() => {})`, `console.log(e)` and continue, `throw "message"` | [err-never-swallow](rules/err-never-swallow.md) |
| `fetch` or a client call without a timeout; `Promise.race` with `setTimeout` as a timeout | [async-deadlines](rules/async-deadlines.md) |
| `readFileSync`, `execSync`, `JSON.parse` of a large body inside a request handler | [async-no-blocking](rules/async-no-blocking.md) |
| `readFile` of a large or uploaded file; building a big string or array before writing it | [io-streams](rules/io-streams.md) |
| `require(...)` in new code; imports without the `node:` prefix; modules that import each other | [mod-esm](rules/mod-esm.md) |
| A new dependency for something Node has (`node-fetch`, `dotenv`, `uuid`, `minimist`, `lodash.clonedeep`) | [runtime-platform-first](rules/runtime-platform-first.md) |
| A JavaScript project with no type checking; public functions without JSDoc types | [types-checkjs](rules/types-checkjs.md) |
| `array.includes`/`find` inside a loop over another array; repeated parsing per request | [perf-lookups](rules/perf-lookups.md) |

### Review Checklist

- [ ] No user data reaches `eval`, markup, or a shell; child processes get argument arrays
- [ ] Tokens and ids come from `node:crypto`; secrets are compared with `timingSafeEqual`
- [ ] No secret in code, logs or error messages; TLS verification is on
- [ ] Every outside call has a deadline and can be cancelled with an `AbortSignal`
- [ ] No synchronous I/O on a request path; large data is streamed with `pipeline`
- [ ] Every error is handled with context or propagated; every promise is awaited or handled
- [ ] `npm audit` (or the package manager's equivalent) shows nothing new at high severity

## Gotchas

- `Promise.race([work, timeout])` rejects on time but leaves `work` running, holding sockets and memory; pass an `AbortSignal` so the work itself stops.
- `fetch` has no default timeout; a server that accepts and never answers hangs the call until the socket dies.
- `fetch` resolves on 404 and 500; check `response.ok` before reading the body.
- `child_process.exec` runs through a shell: a filename with `; rm -rf ~` in it is a command. `execFile` and `spawn` with an argument array are not.
- `JSON.parse` of a 50 MB body blocks the event loop for every user; limit body sizes at the server.
- `crypto.randomUUID()` is fine for ids; tokens need more entropy than an id implies: `randomBytes(32).toString("base64url")`.
- A `.mjs` file is always ESM and `.cjs` always CommonJS; `.js` follows `"type"` in the nearest `package.json`.
- Node 22.12+ can `require()` an ES module that has no top-level `await`; older Node cannot.
- `--env-file=.env` loads variables without `dotenv`; the file must still stay out of git.

## Categories

### Security [CRITICAL]
Keep input from becoming code and secrets from leaking.

| Rule | Description |
|------|-------------|
| [sec-no-code-injection](rules/sec-no-code-injection.md) | No eval, no markup from data, no shell strings |
| [sec-secure-random](rules/sec-secure-random.md) | Tokens from node:crypto; compare secrets in constant time |
| [sec-secrets](rules/sec-secrets.md) | Secrets from the environment, masked in logs, TLS on |

### Errors and Async [HIGH]
Never lose an error; never wait forever.

| Rule | Description |
|------|-------------|
| [err-never-swallow](rules/err-never-swallow.md) | Handle with context or propagate with cause |
| [async-deadlines](rules/async-deadlines.md) | Give every outside call a deadline with AbortSignal |
| [async-no-blocking](rules/async-no-blocking.md) | No synchronous I/O or heavy work on the event loop |

### Runtime and Modules [MEDIUM]
Use the platform and keep modules explicit.

| Rule | Description |
|------|-------------|
| [io-streams](rules/io-streams.md) | Stream large data with pipeline |
| [mod-esm](rules/mod-esm.md) | ES modules, node: imports, no import cycles |
| [runtime-platform-first](rules/runtime-platform-first.md) | Use what Node ships before adding a dependency |
| [types-checkjs](rules/types-checkjs.md) | Type-check JavaScript with JSDoc and checkJs |

### Performance [LOW]
Cheap wins on hot paths.

| Rule | Description |
|------|-------------|
| [perf-lookups](rules/perf-lookups.md) | Index with Map and Set; parse once, not per request |

## Quick Reference

The model already applies the common rules of this skill unprompted (execFile with arguments, crypto tokens, timingSafeEqual, streams). The examples below are the ones it tends to miss.

```javascript
import { pbkdf2 } from "node:crypto";
import { readFile } from "node:fs/promises";
import { promisify } from "node:util";

// One deadline for the call AND the caller's cancellation, not Promise.race (which leaves the request running).
export async function getQuote(sku, { signal } = {}) {
  const response = await fetch(`https://quotes.example/v1/${encodeURIComponent(sku)}`, {
    signal: AbortSignal.any([AbortSignal.timeout(5_000), ...(signal ? [signal] : [])]),
  });
  if (!response.ok) throw new Error(`quote ${sku}: HTTP ${response.status}`);
  return response.json();
}

// Nothing synchronous on a request path: read once at startup, hash on the thread pool.
const template = await readFile(new URL("./templates/report.html", import.meta.url), "utf8");
const hashPin = promisify(pbkdf2);

app.post("/reports", express.json({ limit: "100kb" }), async (req, res, next) => {
  try {
    const digest = await hashPin(req.body.pin, salt, 600_000, 32, "sha256");
    res.send(render(template, { digest: digest.toString("hex") }));
  } catch (err) {
    next(new Error("rendering report", { cause: err }));
  }
});
```

## See Also

These are separate skills; use them if installed.

- `typescript-coding-standards` - Types, validation of input with schemas, tsconfig
- `typescript-testing` - Tests for JavaScript and TypeScript (Vitest, node:test)
- `postgres-database` - Parameterized queries, transactions and migrations
