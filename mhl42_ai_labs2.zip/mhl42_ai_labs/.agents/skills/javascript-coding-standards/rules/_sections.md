# Section Definitions

## Security (sec)
**Impact:** CRITICAL

Keep input from becoming code and secrets from leaking.

**Rules:**
- `sec-no-code-injection` - No eval, no markup from data, no shell strings
- `sec-secure-random` - Tokens from node:crypto; compare secrets in constant time
- `sec-secrets` - Secrets from the environment, masked in logs, TLS on

## Errors (err)
**Impact:** HIGH

Never lose an error.

**Rules:**
- `err-never-swallow` - Handle with context or propagate with cause

## Async (async)
**Impact:** HIGH

Never wait forever; never block everyone.

**Rules:**
- `async-deadlines` - Give every outside call a deadline with AbortSignal
- `async-no-blocking` - No synchronous I/O or heavy work on the event loop

## I/O (io)
**Impact:** MEDIUM

Constant memory for any input size.

**Rules:**
- `io-streams` - Stream large data with pipeline

## Modules (mod)
**Impact:** MEDIUM

Explicit, acyclic module graphs.

**Rules:**
- `mod-esm` - ES modules, node: imports, no import cycles

## Runtime (runtime)
**Impact:** MEDIUM

The platform before a dependency.

**Rules:**
- `runtime-platform-first` - Use what Node ships before adding a dependency

## Types (types)
**Impact:** MEDIUM

Type checking without a build step.

**Rules:**
- `types-checkjs` - Type-check JavaScript with JSDoc and checkJs

## Performance (perf)
**Impact:** LOW

Cheap wins on hot paths.

**Rules:**
- `perf-lookups` - Index with Map and Set; parse once, not per request
