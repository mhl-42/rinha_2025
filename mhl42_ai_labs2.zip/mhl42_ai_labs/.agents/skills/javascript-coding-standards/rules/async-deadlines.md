---
title: Give Every Outside Call a Deadline with AbortSignal
impact: HIGH
impactDescription: A slow dependency cannot hang requests or pile up open sockets
tags: [async, timeouts, abortcontroller, fetch, cancellation]
---

# Give Every Outside Call a Deadline with AbortSignal [HIGH]

## Description
`fetch`, database drivers and most clients wait as long as the other side keeps the connection open. Every call that leaves the process needs a deadline. `AbortSignal.timeout(ms)` gives one; `AbortSignal.any([...])` combines it with the caller's signal, so a request that the client abandoned also stops the work it started.

A `Promise.race` against a timer only stops waiting: the request keeps running, holding a socket and memory, and its result is discarded. Abort the work itself.

## Bad Example
```javascript
function withTimeout(promise, ms) {
  return Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error("timeout")), ms))]);
}

const rates = await withTimeout(fetch(RATES_URL).then((r) => r.json()), 3000);
```

## Good Example
```javascript
export async function getRates({ signal } = {}) {
  const response = await fetch(RATES_URL, {
    signal: AbortSignal.any([AbortSignal.timeout(3_000), ...(signal ? [signal] : [])]),
  });
  if (!response.ok) throw new Error(`rates: HTTP ${response.status}`);
  return response.json();
}

app.get("/quote", async (req, res) => {
  const controller = new AbortController();
  req.on("close", () => controller.abort()); // the client left: stop the work
  res.json(await getRates({ signal: controller.signal }));
});
```

## Notes
- An aborted `fetch` rejects with a `DOMException` named `AbortError` or `TimeoutError`; treat them apart from other failures.
- Choose the deadline per dependency from its normal latency; retries go inside the deadline, not around it.
- Pass the signal down: `fs.promises.readFile`, `setTimeout` from `node:timers/promises`, `events.once` and many clients accept `{ signal }`.

## References
- [MDN: AbortSignal.timeout](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal/timeout_static)
- [MDN: AbortSignal.any](https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal/any_static)
