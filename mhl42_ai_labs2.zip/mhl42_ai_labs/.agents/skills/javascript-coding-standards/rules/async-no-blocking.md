---
title: No Synchronous I/O or Heavy Work on the Event Loop
impact: HIGH
impactDescription: One slow request cannot stall every other request on the process
tags: [async, event-loop, sync-io, performance, worker-threads]
---

# No Synchronous I/O or Heavy Work on the Event Loop [HIGH]

## Description
Node runs JavaScript on one thread. `readFileSync`, `execSync`, a synchronous hash of a large buffer or a tight loop over a million items blocks that thread: every other request waits. Synchronous calls are fine at startup and in CLIs; on a request path use the async API, and move CPU-heavy work to a worker thread or a job queue.

## Bad Example
```javascript
app.get("/report/:id", (req, res) => {
  const template = fs.readFileSync("templates/report.html", "utf8"); // every request, blocking
  const hash = crypto.pbkdf2Sync(req.query.pin, salt, 600_000, 32, "sha256");
  res.send(render(template, hash));
});
```

## Good Example
```javascript
const template = await fs.promises.readFile("templates/report.html", "utf8"); // once, at startup
const pbkdf2 = promisify(crypto.pbkdf2);

app.get("/report/:id", async (req, res) => {
  const hash = await pbkdf2(req.query.pin, salt, 600_000, 32, "sha256"); // runs on the thread pool
  res.send(render(template, hash));
});
```

## Notes
- Measure with `perf_hooks.monitorEventLoopDelay()`; a p99 delay above a few tens of milliseconds means something blocks.
- `piscina` or `node:worker_threads` run CPU work in parallel; a queue (BullMQ, a database job table) moves it out of the request entirely.

## References
- [Node.js: Don't block the event loop](https://nodejs.org/en/learn/asynchronous-work/dont-block-the-event-loop)
