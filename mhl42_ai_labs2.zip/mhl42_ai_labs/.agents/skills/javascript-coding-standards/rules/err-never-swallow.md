---
title: Handle with Context or Propagate with cause
impact: HIGH
impactDescription: Every failure is visible and traceable to where it started
tags: [errors, catch, cause, logging, promises]
---

# Handle with Context or Propagate with cause [HIGH]

## Description
An empty `catch`, a `.catch(() => {})`, or a `catch` that logs and carries on turns a failure into wrong data or a silent no-op that someone discovers weeks later. Catch only where you can act: retry, translate to a domain error, return a fallback the caller expects, or report. Otherwise let it propagate, adding context with `new Error(message, { cause })` so the original stack survives.

Throw `Error` objects (or subclasses), never strings: a string has no stack.

## Bad Example
```javascript
try {
  await saveOrder(order);
} catch (e) {
  console.log(e);
}

loadConfig().catch(() => {});

if (!user) throw "user not found";
```

## Good Example
```javascript
class NotFound extends Error {
  name = "NotFound";
}

try {
  await saveOrder(order);
} catch (err) {
  throw new Error(`saving order ${order.id}`, { cause: err });
}

const config = await loadConfig().catch((err) => {
  if (err.code === "ENOENT") return DEFAULT_CONFIG; // a missing file is expected; anything else is not
  throw err;
});

if (!user) throw new NotFound(`user ${id}`);
```

## Notes
- Log an error once, where it is handled, with its context; logging at every level that rethrows repeats it.
- `process.on("unhandledRejection")` is for logging and exiting, not for recovering.

## References
- [MDN: Error cause](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error/cause)
