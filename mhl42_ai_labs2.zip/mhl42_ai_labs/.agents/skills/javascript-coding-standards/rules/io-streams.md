---
title: Stream Large Data with pipeline
impact: MEDIUM
impactDescription: Constant memory regardless of file size, with backpressure and cleanup on errors
tags: [streams, pipeline, memory, files, uploads]
---

# Stream Large Data with pipeline [MEDIUM]

## Description
Reading a whole file or response into memory works in development and fails in production when someone uploads 2 GB. Streams process data in chunks. `pipeline` from `node:stream/promises` connects them, applies backpressure (a slow writer slows the reader) and destroys every stream when one fails; `a.pipe(b)` does neither of the last two.

## Bad Example
```javascript
const csv = await fs.promises.readFile(upload.path, "utf8");
const rows = csv.split("\n").map(parseRow);
await fs.promises.writeFile(out, JSON.stringify(rows));

source.pipe(gzip).pipe(destination); // an error leaves the others open
```

## Good Example
```javascript
import { createReadStream, createWriteStream } from "node:fs";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";

await pipeline(
  createReadStream(upload.path),
  csvParser(),
  new Transform({
    objectMode: true,
    transform(row, _encoding, callback) {
      callback(null, `${JSON.stringify(toRecord(row))}\n`);
    },
  }),
  createWriteStream(out),
  { signal: AbortSignal.timeout(10 * 60_000) },
);
```

## Notes
- Async iteration (`for await (const chunk of stream)`) is the simplest consumer when there is no output stream.
- Limit upload sizes at the HTTP layer as well; streaming bounds memory, not disk.

## References
- [Node.js: stream.pipeline](https://nodejs.org/api/stream.html#streampipelinesource-transforms-destination-options)
