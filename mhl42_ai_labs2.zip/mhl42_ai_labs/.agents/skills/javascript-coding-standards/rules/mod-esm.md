---
title: "ES Modules, node: Imports, No Import Cycles"
impact: MEDIUM
impactDescription: One module system, clear built-in imports, no half-initialized modules
tags: [modules, esm, commonjs, imports, cycles]
---

# ES Modules, node: Imports, No Import Cycles [MEDIUM]

## Description
New code uses ES modules (`"type": "module"` in `package.json`, `import`/`export`): static imports that tools can analyze, top-level `await`, and the format browsers and every current runtime share. An existing CommonJS project stays CommonJS until it migrates as a whole; do not mix the two in one package.

Import built-ins with the `node:` prefix so they cannot be confused with an npm package of the same name.

Two modules that import each other see each other half-initialized: an imported value is `undefined` (CommonJS) or throws on access (ESM) depending on load order. Move the shared part to a third module.

## Bad Example
```javascript
const fs = require("fs");
const { formatUser } = require("./users");
module.exports = { renderOrder };

// users.js
const { renderOrder } = require("./orders"); // orders.js requires users.js too
```

## Good Example
```javascript
// package.json: { "type": "module" }
import { readFile } from "node:fs/promises";
import { formatUser } from "./format.js"; // shared code moved out of both modules

export function renderOrder(order) {
  return `${formatUser(order.user)}: ${order.total}`;
}
```

## Notes
- ESM imports need the file extension (`./format.js`).
- `madge --circular src` or eslint's `import/no-cycle` find cycles.
- `__dirname` is `import.meta.dirname` in ESM (Node 20.11+).

## References
- [Node.js: ECMAScript modules](https://nodejs.org/api/esm.html)
