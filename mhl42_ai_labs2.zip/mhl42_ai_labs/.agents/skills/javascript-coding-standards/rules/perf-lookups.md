---
title: Index with Map and Set; Parse Once, Not per Request
impact: LOW
impactDescription: Quadratic loops become linear; repeated work moves to startup
tags: [performance, map, set, caching, hot-path]
---

# Index with Map and Set; Parse Once, Not per Request [LOW]

## Description
`array.includes` or `array.find` inside a loop over another array is O(n·m): fine for ten items, minutes for a hundred thousand. Build a `Set` or a `Map` once and look up in constant time. Likewise, work that gives the same result on every request (compiling a regex or a schema, reading a template, building a client) belongs at startup, not in the handler.

Optimise only measured hot paths; readable code comes first elsewhere.

## Bad Example
```javascript
const active = orders.filter((order) => customers.find((c) => c.id === order.customerId)?.active);

app.get("/search", (req, res) => {
  const pattern = new RegExp(buildPattern(config.keywords), "i"); // same regex every request
  res.json(items.filter((item) => pattern.test(item.title)));
});
```

## Good Example
```javascript
const activeIds = new Set(customers.filter((c) => c.active).map((c) => c.id));
const active = orders.filter((order) => activeIds.has(order.customerId));

const pattern = new RegExp(buildPattern(config.keywords), "i");
app.get("/search", (req, res) => {
  res.json(items.filter((item) => pattern.test(item.title)));
});
```

## Notes
- `Object.groupBy` and `Map.groupBy` (Node 21+) index a list by a key in one pass.
- Profile with `node --cpu-prof` before rewriting code for speed.

## References
- [MDN: Map](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map)
