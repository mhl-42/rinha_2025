---
title: Use What Node Ships Before Adding a Dependency
impact: MEDIUM
impactDescription: Fewer packages to audit, update and trust
tags: [dependencies, supply-chain, stdlib, node]
---

# Use What Node Ships Before Adding a Dependency [MEDIUM]

## Description
Every dependency is code you run with your credentials, and its own dependencies come with it. Node 22+ ships much of what used to need a package. Check the platform first; add a dependency when it does something the platform does not, and then prefer a maintained, widely used one.

| Instead of | Use |
|------------|-----|
| `node-fetch`, `axios` for simple calls | global `fetch` |
| `dotenv` | `node --env-file=.env` or `process.loadEnvFile()` |
| `uuid` (v4) | `crypto.randomUUID()` |
| `minimist`, `yargs` for small CLIs | `util.parseArgs` |
| `lodash.clonedeep` | `structuredClone` |
| `chalk` for simple colours | `util.styleText` |
| `mocha` or `jest` for a library without a DOM | `node:test` |

## Bad Example
```javascript
import fetch from "node-fetch";
import { v4 as uuid } from "uuid";
import minimist from "minimist";

const args = minimist(process.argv.slice(2));
```

## Good Example
```javascript
import { parseArgs } from "node:util";

const { values } = parseArgs({
  options: { input: { type: "string", short: "i" }, dryRun: { type: "boolean", default: false } },
});
const id = crypto.randomUUID();
const response = await fetch(url, { signal: AbortSignal.timeout(5_000) });
```

## Notes
- Commit the lockfile and install with `npm ci` (or the equivalent) in CI.
- Check a package before adding it: maintenance, downloads, install scripts, and what it pulls in.

## References
- [Node.js: util.parseArgs](https://nodejs.org/api/util.html#utilparseargsconfig)
- [Node.js: test runner](https://nodejs.org/api/test.html)
