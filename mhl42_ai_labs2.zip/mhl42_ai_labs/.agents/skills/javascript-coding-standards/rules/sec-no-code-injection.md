---
title: No eval, No Markup from Data, No Shell Strings
impact: CRITICAL
impactDescription: Prevents remote code execution, command injection and cross-site scripting
tags: [security, eval, xss, command-injection, child_process]
---

# No eval, No Markup from Data, No Shell Strings [CRITICAL]

## Description
Three ways text becomes code: `eval`, `new Function` and `setTimeout("string")` run it as JavaScript; `innerHTML`, `outerHTML`, `insertAdjacentHTML` and `document.write` run it as markup (and its scripts); `child_process.exec` and `execSync` run it through a shell. With user data in any of them, the user runs code on your server or in other users' browsers.

Use data-only alternatives: `JSON.parse` for data, `textContent` and DOM methods for text, `execFile` or `spawn` with an argument array (no shell) for programs.

## Bad Example
```javascript
const rule = eval(`(${req.body.rule})`);

list.innerHTML += `<li>${comment.text}</li>`;

exec(`convert ${req.file.path} -resize 200x200 ${out}`, done);
```

## Good Example
```javascript
const rule = RuleSchema.parse(JSON.parse(req.body.rule));

const item = document.createElement("li");
item.textContent = comment.text;
list.append(item);

await run("convert", [req.file.path, "-resize", "200x200", out], { timeout: 30_000 });
```

## Notes
- `spawn(cmd, args, { shell: true })` is `exec` again; leave `shell` off.
- An argument that starts with `-` can still be read as an option by the program; put `--` before user-supplied file names when the program supports it.
- `vm` is not a sandbox for untrusted code; run untrusted code in a separate process with the permission model or a container.

## References
- [Node.js: child_process.execFile](https://nodejs.org/api/child_process.html#child_processexecfilefile-args-options-callback)
- [OWASP: DOM based XSS prevention](https://cheatsheetseries.owasp.org/cheatsheets/DOM_based_XSS_Prevention_Cheat_Sheet.html)
