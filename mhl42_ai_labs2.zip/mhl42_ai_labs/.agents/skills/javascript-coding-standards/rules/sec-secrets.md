---
title: Secrets from the Environment, Masked in Logs, TLS On
impact: CRITICAL
impactDescription: Credentials stay out of the repository, the logs and the hands of an interceptor
tags: [security, secrets, environment, logging, tls]
---

# Secrets from the Environment, Masked in Logs, TLS On [CRITICAL]

## Description
A key in the source is in every clone, fork and backup of the repository, forever. Read secrets from the environment (or a secret manager) at startup, check they are present, and fail fast when they are not.

Logs travel further than the code: to log services, support tickets and screenshots. Never log whole config objects, request headers or bodies that can carry credentials; log the keys you need and redact the rest.

`NODE_TLS_REJECT_UNAUTHORIZED=0` (or `rejectUnauthorized: false`) turns off certificate checks for every outgoing request of the process. Fix the trust store instead (`NODE_EXTRA_CA_CERTS` for an internal CA).

## Bad Example
```javascript
const stripe = new Stripe("sk_live_51H...");

logger.info({ config }, "starting");
logger.error({ headers: req.headers }, "request failed");

process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"; // "fixes" the self-signed cert error
```

## Good Example
```javascript
function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`missing environment variable ${name}`);
  return value;
}

const stripe = new Stripe(required("STRIPE_SECRET_KEY"));

const logger = pino({ redact: ["req.headers.authorization", "req.headers.cookie", "*.password", "*.token"] });
logger.info({ port, region }, "starting");
```

## Notes
- `node --env-file=.env` loads a local file in development; keep `.env` in `.gitignore` and commit a `.env.example` without values.
- A secret that was committed is compromised: rotate it, then remove it from history.

## References
- [Node.js: --env-file](https://nodejs.org/api/cli.html#--env-fileconfig)
- [Node.js: NODE_EXTRA_CA_CERTS](https://nodejs.org/api/cli.html#node_extra_ca_certsfile)
