---
title: Tokens from node:crypto; Compare Secrets in Constant Time
impact: CRITICAL
impactDescription: Reset links, session ids and API keys cannot be predicted or timed
tags: [security, crypto, random, tokens, timing]
---

# Tokens from node:crypto; Compare Secrets in Constant Time [CRITICAL]

## Description
`Math.random()` is predictable: after observing a few outputs an attacker can compute the next ones. Anything that grants access (a password reset token, a session id, an invite code, an API key) must come from a cryptographically secure source: `crypto.randomBytes`, `crypto.randomInt`, `crypto.randomUUID`, or `crypto.getRandomValues` in browsers.

Comparing a secret with `===` returns as soon as a character differs, which leaks how many leading characters were right. Compare HMAC signatures and tokens with `timingSafeEqual` on equal-length buffers.

## Bad Example
```javascript
const resetToken = Math.random().toString(36).slice(2);
const code = Math.floor(Math.random() * 1_000_000);

if (req.headers["x-signature"] === expectedSignature) accept();
```

## Good Example
```javascript
import { createHmac, randomBytes, randomInt, timingSafeEqual } from "node:crypto";

const resetToken = randomBytes(32).toString("base64url");
const code = String(randomInt(0, 1_000_000)).padStart(6, "0");

const expected = createHmac("sha256", secret).update(rawBody).digest();
const received = Buffer.from(req.headers["x-signature"] ?? "", "hex");
if (received.length !== expected.length || !timingSafeEqual(received, expected)) {
  throw new InvalidSignature();
}
```

## Notes
- Store a hash of a reset token, not the token, and give it an expiry and single use.
- Passwords are hashed with a password hash (`crypto.scrypt`, or argon2 through a maintained package), never with a fast digest.

## References
- [Node.js: crypto.randomBytes](https://nodejs.org/api/crypto.html#cryptorandombytessize-callback)
- [Node.js: crypto.timingSafeEqual](https://nodejs.org/api/crypto.html#cryptotimingsafeequala-b)
