---
title: Type-Check JavaScript with JSDoc and checkJs
impact: MEDIUM
impactDescription: Wrong arguments and missing properties are caught before running, without a build step
tags: [types, jsdoc, checkjs, typescript]
---

# Type-Check JavaScript with JSDoc and checkJs [MEDIUM]

## Description
Plain JavaScript can be type-checked by the TypeScript compiler without converting files: JSDoc comments declare the types and `checkJs` makes the compiler check them. Public functions get `@param` and `@returns` types; shapes get `@typedef`. Run `tsc --noEmit` in CI like any other gate.

## Bad Example
```javascript
// What is options? What does it return?
export function schedule(job, options) {
  return queue.add(job.name, job.data, { delay: options.delayMs });
}
```

## Good Example
```javascript
/**
 * @typedef {{ name: string, data: Record<string, unknown> }} Job
 * @typedef {{ delayMs?: number }} ScheduleOptions
 */

/**
 * Adds a job to the queue.
 * @param {Job} job
 * @param {ScheduleOptions} [options]
 * @returns {Promise<string>} the queued job id
 */
export async function schedule(job, options = {}) {
  const added = await queue.add(job.name, job.data, { delay: options.delayMs ?? 0 });
  return added.id;
}
```

```json
{
  "compilerOptions": {
    "allowJs": true,
    "checkJs": true,
    "noEmit": true,
    "strict": true,
    "module": "NodeNext"
  },
  "include": ["src"]
}
```

## Notes
- `// @ts-check` at the top of one file checks just that file, a way to start in a large codebase.
- When most of the code needs types, converting to TypeScript is usually the better move; follow typescript-coding-standards then.

## References
- [TypeScript: JSDoc reference](https://www.typescriptlang.org/docs/handbook/jsdoc-supported-types.html)
