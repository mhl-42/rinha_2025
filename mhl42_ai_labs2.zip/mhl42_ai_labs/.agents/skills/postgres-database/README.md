# PostgreSQL

Rules for AI agents working with PostgreSQL from any language: migrations that do not lock live tables, types and keys that hold business rules, indexes proven with EXPLAIN, parameterized and bounded queries, atomic upserts, short transactions with row locks, pools and timeouts, roles, TLS, row-level security and query statistics.

## Overview

This skill provides 11 rules across 8 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Migrations | `mig-` | CRITICAL | 3 |
| Schema | `schema-` | CRITICAL | 1 |
| Indexes | `idx-` | HIGH | 1 |
| Queries | `query-` | HIGH | 2 |
| Transactions | `tx-` | HIGH | 1 |
| Connections | `conn-` | HIGH | 1 |
| Security | `sec-` | HIGH | 1 |
| Observability | `obs-` | MEDIUM | 1 |

## Structure

```
skills/postgres-database/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Usage

The skill is language-neutral: it applies with any language skill when the design's database is PostgreSQL. Python driver code (psycopg, pools, migrations tooling) stays in `python-database`.

## Origin

Adapted from `postgres-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files, with keyset pagination, job queues with SKIP LOCKED and the NOT NULL-through-CHECK migration added, and version-specific features marked.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
