---
name: postgres-database
description: Use this skill when writing, reviewing, or changing anything that runs on PostgreSQL, from any language — schema design and column types, migrations on live tables (indexes, NOT NULL, constraints, locks), indexes and EXPLAIN, queries (parameters, pagination, upserts), transactions, row locks and isolation, connection pools, running out of connections and timeouts, roles, TLS and row-level security, and pg_stat_statements — even if the user only says "add a column", "this query is slow", or "the migration locked the table". Not for language-specific driver code in Python (use python-database), ORMs' own APIs, or other databases (MySQL, SQLite, Oracle).
license: MIT
compatibility: PostgreSQL 14+; features from later versions are marked where used (MERGE 15+, MERGE ... RETURNING 17+, uuidv7() 18+). Pooling notes cover PgBouncer 1.21+.
metadata:
  author: mhl42 (adapted from 0xMassi/claude-skills, MIT)
  version: "1.0.1"
---

# PostgreSQL

Rules for AI agents designing schemas, writing migrations and queries for PostgreSQL, whatever language the application uses. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing**: choose types that hold the business rule, change live tables without long locks, index for the queries you actually run, and keep transactions short. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the change contains... | Read |
|-----------------------------|------|
| `CREATE INDEX` on an existing table; `REINDEX`; dropping an index | [mig-index-concurrently](rules/mig-index-concurrently.md) |
| `ADD COLUMN ... NOT NULL`, `ADD CONSTRAINT`, `ALTER COLUMN TYPE`, `SET NOT NULL` on a table with data | [mig-constraints-in-steps](rules/mig-constraints-in-steps.md) |
| A migration with no `lock_timeout`; DDL mixed with large data updates | [mig-lock-timeouts](rules/mig-lock-timeouts.md) |
| `timestamp`, `float`/`real` for money, `serial`, `varchar(255)` everywhere, FKs without indexes | [schema-types-and-keys](rules/schema-types-and-keys.md) |
| A slow query; `WHERE`/`ORDER BY` columns without an index; JSONB filters; "it's fast on my machine" | [idx-match-the-query](rules/idx-match-the-query.md) |
| SQL built by string concatenation; `SELECT *`; `OFFSET` pagination on large tables; no `LIMIT` | [query-parameterized-and-bounded](rules/query-parameterized-and-bounded.md) |
| Read-then-insert to "create if missing"; check-then-update races | [query-upserts](rules/query-upserts.md) |
| Long transactions; HTTP calls inside a transaction; lost updates; job queues on a table | [tx-short-and-locked](rules/tx-short-and-locked.md) |
| A connection per request; no pool limits; `idle in transaction` sessions; prepared statements behind PgBouncer | [conn-pool-and-timeouts](rules/conn-pool-and-timeouts.md) |
| The application connecting as `postgres` or the owner; `md5` passwords; `sslmode=disable`; tenants in shared tables | [sec-roles-tls-rls](rules/sec-roles-tls-rls.md) |
| No visibility into which queries are slow | [obs-query-stats](rules/obs-query-stats.md) |

### Review Checklist

- [ ] Every migration on an existing table sets `lock_timeout` and takes no long `ACCESS EXCLUSIVE` lock
- [ ] Indexes on populated tables are built `CONCURRENTLY`; constraints are added `NOT VALID` then validated
- [ ] Money is `numeric` or integer cents; instants are `timestamptz`; keys are identity or UUID
- [ ] Every query is parameterized, selects named columns, and is bounded
- [ ] Each slow query was checked with `EXPLAIN (ANALYZE, BUFFERS)` on realistic data
- [ ] Transactions contain no network calls; concurrent updates use row locks or atomic statements
- [ ] The application role owns nothing and is not a superuser; connections use TLS

## Gotchas

- `CREATE INDEX` without `CONCURRENTLY` blocks every write to the table until it finishes; `CONCURRENTLY` cannot run inside a transaction block, so most migration tools need it in its own non-transactional migration.
- A failed `CREATE INDEX CONCURRENTLY` leaves an `INVALID` index behind that still slows writes; drop it and retry.
- `ALTER TABLE` waits for its lock behind any long-running query, and every query that arrives after it waits behind the `ALTER`: a one-millisecond DDL can stop the table for minutes without `lock_timeout`.
- Foreign keys do not create an index on the referencing column; deletes on the parent then scan the child table.
- `timestamp` (without time zone) stores a wall-clock reading with no zone; two servers in different zones disagree on what it means.
- `NOT IN (subquery)` returns no rows when the subquery yields a `NULL`; use `NOT EXISTS`.
- `READ COMMITTED` (the default) lets two transactions read the same balance and both write their update: one is lost unless the statement is atomic or the row is locked.
- `OFFSET 100000` reads and discards 100,000 rows; keyset pagination (`WHERE (created_at, id) < ($1, $2)`) does not.
- PgBouncer in transaction mode breaks session state: `SET`, advisory session locks, `LISTEN`, and (before PgBouncer 1.21) named prepared statements.

## Categories

### Migrations [CRITICAL]
Change live tables without stopping them.

| Rule | Description |
|------|-------------|
| [mig-index-concurrently](rules/mig-index-concurrently.md) | Build and drop indexes concurrently on tables with traffic |
| [mig-constraints-in-steps](rules/mig-constraints-in-steps.md) | Add NOT NULL and constraints in steps: NOT VALID, backfill, VALIDATE |
| [mig-lock-timeouts](rules/mig-lock-timeouts.md) | Set lock_timeout and statement_timeout in every migration |

### Schema [CRITICAL]
Types and keys that hold the rules.

| Rule | Description |
|------|-------------|
| [schema-types-and-keys](rules/schema-types-and-keys.md) | timestamptz, exact money, identity or UUID keys, indexed FKs, CHECKs |

### Queries and Indexes [HIGH]
Fast, safe, bounded queries.

| Rule | Description |
|------|-------------|
| [idx-match-the-query](rules/idx-match-the-query.md) | Index for real queries; prove it with EXPLAIN ANALYZE |
| [query-parameterized-and-bounded](rules/query-parameterized-and-bounded.md) | Parameters always, named columns, LIMIT and keyset pagination |
| [query-upserts](rules/query-upserts.md) | Atomic upserts with ON CONFLICT or MERGE, not read-then-write |

### Transactions and Connections [HIGH]
Short transactions, explicit locks, bounded pools.

| Rule | Description |
|------|-------------|
| [tx-short-and-locked](rules/tx-short-and-locked.md) | Short transactions, row locks for read-modify-write, SKIP LOCKED queues |
| [conn-pool-and-timeouts](rules/conn-pool-and-timeouts.md) | A bounded pool, server-side timeouts, PgBouncer caveats |

### Security and Operations [HIGH]
Least privilege and visibility.

| Rule | Description |
|------|-------------|
| [sec-roles-tls-rls](rules/sec-roles-tls-rls.md) | Least-privilege roles, scram-sha-256, TLS, RLS for tenants |
| [obs-query-stats](rules/obs-query-stats.md) | pg_stat_statements on, slow queries tracked |

## Quick Reference

```sql
-- migration 0042, run outside a transaction block
SET lock_timeout = '3s';
CREATE INDEX CONCURRENTLY IF NOT EXISTS orders_customer_created_idx
    ON orders (customer_id, created_at DESC);

-- migration 0043
SET lock_timeout = '3s';
ALTER TABLE orders ADD COLUMN channel text;                         -- nullable: instant
ALTER TABLE orders ADD CONSTRAINT orders_channel_not_null
    CHECK (channel IS NOT NULL) NOT VALID;                          -- new rows checked now
-- backfill in batches (application job), then:
ALTER TABLE orders VALIDATE CONSTRAINT orders_channel_not_null;     -- no write lock
ALTER TABLE orders ALTER COLUMN channel SET NOT NULL;               -- uses the validated check (PG 12+)
ALTER TABLE orders DROP CONSTRAINT orders_channel_not_null;

CREATE TABLE payments (
    id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    order_id    bigint NOT NULL REFERENCES orders (id),
    amount      numeric(12, 2) NOT NULL CHECK (amount > 0),
    status      text NOT NULL CHECK (status IN ('pending', 'paid', 'refunded')),
    paid_at     timestamptz,
    created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX payments_order_id_idx ON payments (order_id);

-- keyset pagination
SELECT id, total, created_at
FROM orders
WHERE customer_id = $1 AND (created_at, id) < ($2, $3)
ORDER BY created_at DESC, id DESC
LIMIT 50;

-- job queue
WITH next AS (
    SELECT id FROM jobs WHERE status = 'queued' ORDER BY id LIMIT 10 FOR UPDATE SKIP LOCKED
)
UPDATE jobs SET status = 'running', started_at = now()
FROM next WHERE jobs.id = next.id
RETURNING jobs.id, jobs.payload;
```

## See Also

These are separate skills; use them if installed.

- `python-database` - psycopg and python-oracledb driver code, pools and migrations in Python
- `typescript-coding-standards`, `go-coding-standards`, `rust-coding-standards` - the application side
