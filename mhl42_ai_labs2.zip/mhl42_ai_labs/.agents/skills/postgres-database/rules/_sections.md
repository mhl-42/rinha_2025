# Section Definitions

## Migrations (mig)
**Impact:** CRITICAL

Change live tables without stopping them.

**Rules:**
- `mig-index-concurrently` - Build and drop indexes concurrently on tables with traffic
- `mig-constraints-in-steps` - Add NOT NULL and constraints in steps: NOT VALID, backfill, VALIDATE
- `mig-lock-timeouts` - Set lock_timeout and statement_timeout in every migration

## Schema (schema)
**Impact:** CRITICAL

Types and keys that hold the rules.

**Rules:**
- `schema-types-and-keys` - timestamptz, exact money, identity or UUID keys, indexed FKs, CHECKs

## Indexes (idx)
**Impact:** HIGH

Indexes that serve real queries.

**Rules:**
- `idx-match-the-query` - Index for real queries; prove it with EXPLAIN ANALYZE

## Queries (query)
**Impact:** HIGH

Fast, safe, bounded queries.

**Rules:**
- `query-parameterized-and-bounded` - Parameters always, named columns, LIMIT and keyset pagination
- `query-upserts` - Atomic upserts with ON CONFLICT or MERGE, not read-then-write

## Transactions (tx)
**Impact:** HIGH

Short transactions with explicit locks.

**Rules:**
- `tx-short-and-locked` - Short transactions, row locks for read-modify-write, SKIP LOCKED queues

## Connections (conn)
**Impact:** HIGH

Bounded pools and server-side timeouts.

**Rules:**
- `conn-pool-and-timeouts` - A bounded pool, server-side timeouts, PgBouncer caveats

## Security (sec)
**Impact:** HIGH

Least privilege, encrypted connections, tenant isolation.

**Rules:**
- `sec-roles-tls-rls` - Least-privilege roles, scram-sha-256, TLS, RLS for tenants

## Observability (obs)
**Impact:** MEDIUM

Know which queries cost the most.

**Rules:**
- `obs-query-stats` - pg_stat_statements on, slow queries tracked
