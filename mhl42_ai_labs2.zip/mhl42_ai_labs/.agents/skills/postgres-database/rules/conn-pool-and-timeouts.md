---
title: A Bounded Pool, Server-Side Timeouts, PgBouncer Caveats
impact: HIGH
impactDescription: The database is not exhausted by connections, and stuck sessions end on their own
tags: [connections, pooling, pgbouncer, timeouts]
---

# A Bounded Pool, Server-Side Timeouts, PgBouncer Caveats [HIGH]

## Description
Each PostgreSQL connection is a process with its own memory; a few hundred of them degrade the server. Use one pool per application process with a maximum size, and make the sum over all processes fit `max_connections` with room for migrations and admin. Many processes (serverless functions, many pods) go through a pooler such as PgBouncer in transaction mode.

Set timeouts on the application's role so a bug cannot hold resources forever: `statement_timeout` for runaway queries, `idle_in_transaction_session_timeout` for transactions left open, and a connect timeout in the client.

Transaction pooling hands the server connection to another client after each transaction, so session state does not survive: `SET` (use `SET LOCAL`), session advisory locks, `LISTEN`, temporary tables. Named prepared statements work through PgBouncer 1.21+ with `max_prepared_statements` set; with older versions disable them in the driver.

## Bad Example
```sql
-- every request opens a new connection; 300 pods × 20 connections against max_connections = 200
SET search_path = tenant_42;  -- through transaction pooling, leaks to another client's transaction
```

## Good Example
```sql
ALTER ROLE app SET statement_timeout = '30s';
ALTER ROLE app SET idle_in_transaction_session_timeout = '60s';
ALTER ROLE app CONNECTION LIMIT 150;

BEGIN;
SET LOCAL search_path = tenant_42;  -- ends with the transaction
-- ...
COMMIT;
```

## Notes
- A pool of roughly `2 × CPU cores` of the database server per busy application is a common starting point; measure wait time on the pool before raising it.
- Reports and migrations can use a separate role with longer timeouts.

## References
- [PostgreSQL: client connection defaults](https://www.postgresql.org/docs/current/runtime-config-client.html)
- [PgBouncer: features by pool mode](https://www.pgbouncer.org/features.html)
