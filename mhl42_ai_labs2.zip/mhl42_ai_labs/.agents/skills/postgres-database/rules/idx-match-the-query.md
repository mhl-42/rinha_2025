---
title: Index for Real Queries; Prove It with EXPLAIN ANALYZE
impact: HIGH
impactDescription: Queries use the index you added, measured on realistic data
tags: [indexes, explain, performance, composite, partial, gin]
---

# Index for Real Queries; Prove It with EXPLAIN ANALYZE [HIGH]

## Description
An index helps only the queries whose `WHERE`, `JOIN` and `ORDER BY` it matches. For a composite index, put the columns compared with equality first and the range or sort column last: `(customer_id, created_at)` serves `WHERE customer_id = $1 ORDER BY created_at DESC`; `(created_at, customer_id)` does not.

- **Partial indexes** cover the rows queries touch (`WHERE status = 'queued'`) and stay small.
- **GIN** indexes serve `jsonb` containment (`@>`), arrays and full-text search; B-tree does not.
- **Expression indexes** serve queries on an expression (`lower(email)`).

Check with `EXPLAIN (ANALYZE, BUFFERS)` on a copy with production-like volume: a plan on ten rows says nothing. Every index slows writes and takes space; drop the ones `pg_stat_user_indexes` shows are never used.

## Bad Example
```sql
CREATE INDEX orders_created_idx ON orders (created_at);
CREATE INDEX orders_customer_idx ON orders (customer_id);
-- the query filters by customer and sorts by date: neither index serves both

SELECT id FROM users WHERE lower(email) = lower($1);  -- index on email is not used
```

## Good Example
```sql
CREATE INDEX CONCURRENTLY orders_customer_created_idx ON orders (customer_id, created_at DESC);

CREATE INDEX CONCURRENTLY jobs_queued_idx ON jobs (id) WHERE status = 'queued';

CREATE UNIQUE INDEX CONCURRENTLY users_email_lower_key ON users (lower(email));

EXPLAIN (ANALYZE, BUFFERS)
SELECT id, total FROM orders WHERE customer_id = 42 ORDER BY created_at DESC LIMIT 20;
```

## Notes
- Read the plan for `Seq Scan` on large tables, row estimates far from actual rows (run `ANALYZE`), and high `shared read` buffers.
- For pgvector, HNSW indexes give better recall and speed than IVFFlat for most workloads.

## References
- [PostgreSQL: indexes](https://www.postgresql.org/docs/current/indexes.html)
- [PostgreSQL: using EXPLAIN](https://www.postgresql.org/docs/current/using-explain.html)
