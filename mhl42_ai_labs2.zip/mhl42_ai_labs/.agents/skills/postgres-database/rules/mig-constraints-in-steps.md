---
title: "Add NOT NULL and Constraints in Steps: NOT VALID, Backfill, VALIDATE"
impact: CRITICAL
impactDescription: Constraints reach existing data without a table rewrite or a long write lock
tags: [migrations, not-null, constraints, not-valid, backfill]
---

# Add NOT NULL and Constraints in Steps: NOT VALID, Backfill, VALIDATE [CRITICAL]

## Description
Adding a `CHECK` or a `FOREIGN KEY` scans the whole table while holding a lock that blocks writes. Adding it `NOT VALID` takes the lock only for an instant and enforces it for new rows; `VALIDATE CONSTRAINT` later checks existing rows under a lock that allows reads and writes.

`SET NOT NULL` also scans the table under a write-blocking lock, unless a validated `CHECK (col IS NOT NULL)` already proves it (PG 12+). So: add the column nullable, add the check `NOT VALID`, backfill in batches, validate, set `NOT NULL`, drop the check.

Changing a column's type usually rewrites the table; add a new column, write both, backfill, switch reads, then drop the old one.

## Bad Example
```sql
ALTER TABLE orders ADD COLUMN channel text NOT NULL DEFAULT 'web';  -- fine on PG 11+ for a constant default...
UPDATE orders SET channel = legacy_source;                           -- ...but this rewrites every row in one transaction
ALTER TABLE orders ALTER COLUMN amount TYPE numeric(12, 2);          -- full rewrite under ACCESS EXCLUSIVE
ALTER TABLE order_items ADD CONSTRAINT order_items_order_fk
    FOREIGN KEY (order_id) REFERENCES orders (id);                   -- scans order_items with writes blocked
```

## Good Example
```sql
SET lock_timeout = '3s';
ALTER TABLE orders ADD COLUMN channel text;
ALTER TABLE orders ADD CONSTRAINT orders_channel_not_null CHECK (channel IS NOT NULL) NOT VALID;

-- backfill in batches from a job, each batch its own transaction:
UPDATE orders SET channel = coalesce(legacy_source, 'web')
WHERE id IN (SELECT id FROM orders WHERE channel IS NULL ORDER BY id LIMIT 5000);

ALTER TABLE orders VALIDATE CONSTRAINT orders_channel_not_null;
ALTER TABLE orders ALTER COLUMN channel SET NOT NULL;
ALTER TABLE orders DROP CONSTRAINT orders_channel_not_null;

ALTER TABLE order_items ADD CONSTRAINT order_items_order_fk
    FOREIGN KEY (order_id) REFERENCES orders (id) NOT VALID;
ALTER TABLE order_items VALIDATE CONSTRAINT order_items_order_fk;
```

## Notes
- `ADD COLUMN ... DEFAULT <constant>` is instant since PG 11; a volatile default (`DEFAULT now()` is fine, `DEFAULT gen_random_uuid()` is not) rewrites the table.
- Deploy code that writes the new column before the backfill, so no new row arrives without it.

## References
- [PostgreSQL: ALTER TABLE](https://www.postgresql.org/docs/current/sql-altertable.html)
