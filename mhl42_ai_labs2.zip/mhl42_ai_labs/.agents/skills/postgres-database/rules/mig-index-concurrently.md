---
title: Build and Drop Indexes Concurrently on Tables with Traffic
impact: CRITICAL
impactDescription: Adding an index does not block writes to a production table
tags: [migrations, indexes, concurrently, locks]
---

# Build and Drop Indexes Concurrently on Tables with Traffic [CRITICAL]

## Description
A plain `CREATE INDEX` takes a lock that blocks every `INSERT`, `UPDATE` and `DELETE` on the table until the index is built: minutes on a large table, during which the application's writes queue up and time out. `CREATE INDEX CONCURRENTLY` builds it while writes continue, at the cost of a slower build. `DROP INDEX CONCURRENTLY` and `REINDEX INDEX CONCURRENTLY` (PG 12+) do the same for removal and rebuilding.

`CONCURRENTLY` cannot run inside a transaction block. Put it in its own migration, marked non-transactional in the migration tool, with `IF NOT EXISTS` so a retry is safe. If it fails, it leaves an `INVALID` index that must be dropped before retrying.

## Bad Example
```sql
BEGIN;
ALTER TABLE orders ADD COLUMN channel text;
CREATE INDEX orders_status_idx ON orders (status);  -- blocks writes for the whole build
COMMIT;
```

## Good Example
```sql
-- 0041_orders_status_idx.sql (non-transactional migration)
SET lock_timeout = '3s';
CREATE INDEX CONCURRENTLY IF NOT EXISTS orders_status_idx ON orders (status);

-- after a failed build:
SELECT indexrelid::regclass FROM pg_index WHERE NOT indisvalid;
DROP INDEX CONCURRENTLY IF EXISTS orders_status_idx;
```

## Notes
- A new, empty table does not need `CONCURRENTLY`; create its indexes in the same migration as the table.
- Unique indexes built concurrently fail if duplicates exist; find and fix them first.
- Tools: `-- atlas:txmode none`, Flyway `executeInTransaction=false`, Django `AddIndexConcurrently` with `atomic = False`, golang-migrate one statement per file.

## References
- [PostgreSQL: CREATE INDEX, building indexes concurrently](https://www.postgresql.org/docs/current/sql-createindex.html#SQL-CREATEINDEX-CONCURRENTLY)
