---
title: Set lock_timeout and statement_timeout in Every Migration
impact: CRITICAL
impactDescription: A migration that cannot get its lock fails fast instead of stalling all traffic
tags: [migrations, locks, lock-timeout, deploys]
---

# Set lock_timeout and statement_timeout in Every Migration [CRITICAL]

## Description
Even an instant DDL (`ADD COLUMN` without a default, `ADD CONSTRAINT ... NOT VALID`) needs an `ACCESS EXCLUSIVE` lock for a moment. If a long query or an idle-in-transaction session holds a conflicting lock, the `ALTER` waits, and every query that arrives after it queues behind the `ALTER`. The table is effectively down until the old query ends.

Set `lock_timeout` (a few seconds) so the migration gives up and can be retried, and a `statement_timeout` so a statement that turns out slow does not run for an hour. Keep data backfills out of schema migrations: they belong in batched jobs.

## Bad Example
```sql
ALTER TABLE orders ADD COLUMN channel text;  -- waits forever behind a long report query, blocking everyone
UPDATE orders SET channel = 'web';           -- 40 million rows in one transaction
```

## Good Example
```sql
SET lock_timeout = '3s';
SET statement_timeout = '15min';
ALTER TABLE orders ADD COLUMN channel text;
```

## Notes
- Retry a migration that hit `lock_timeout` a few times with a pause; if it keeps failing, find the blocker in `pg_stat_activity`.
- `idle_in_transaction_session_timeout` on the application role stops forgotten transactions from holding locks (see conn-pool-and-timeouts).
- Many teams lint migrations with a tool (squawk, strong_migrations) that flags unsafe operations.

## References
- [PostgreSQL: lock_timeout](https://www.postgresql.org/docs/current/runtime-config-client.html#GUC-LOCK-TIMEOUT)
- [PostgreSQL: explicit locking](https://www.postgresql.org/docs/current/explicit-locking.html)
