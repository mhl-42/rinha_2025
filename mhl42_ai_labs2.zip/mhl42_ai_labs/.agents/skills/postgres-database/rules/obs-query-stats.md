---
title: pg_stat_statements On, Slow Queries Tracked
impact: MEDIUM
impactDescription: The queries that cost the most time are known before users complain
tags: [observability, pg_stat_statements, slow-queries, monitoring]
---

# pg_stat_statements On, Slow Queries Tracked [MEDIUM]

## Description
`pg_stat_statements` aggregates execution statistics per normalized query: calls, total and mean time, rows, buffer reads. It answers "what should we optimise" with data instead of guesses. Enable it on every environment, and log statements slower than a threshold with `log_min_duration_statement`.

Watch a few baseline numbers: connections in use and waiting, transaction age (`pg_stat_activity`), replication lag, dead tuples and the last autovacuum per table, and cache hit ratio.

## Bad Example
```sql
-- no extension, no slow query log: "the database is slow" with nothing to look at
```

## Good Example
```sql
-- postgresql.conf: shared_preload_libraries = 'pg_stat_statements'
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
ALTER SYSTEM SET log_min_duration_statement = '500ms';

SELECT query, calls, round(total_exec_time) AS total_ms, round(mean_exec_time, 1) AS mean_ms, rows
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 20;

SELECT pid, now() - xact_start AS age, state, left(query, 80)
FROM pg_stat_activity
WHERE xact_start IS NOT NULL
ORDER BY age DESC;
```

## Notes
- Managed services (RDS, Cloud SQL, Azure) enable the extension through their parameter groups.
- `auto_explain` logs plans of slow queries, which explains a regression after the fact.

## References
- [PostgreSQL: pg_stat_statements](https://www.postgresql.org/docs/current/pgstatstatements.html)
