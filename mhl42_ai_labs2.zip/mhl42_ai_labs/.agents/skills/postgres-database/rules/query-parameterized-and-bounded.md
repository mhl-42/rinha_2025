---
title: Parameters Always, Named Columns, LIMIT and Keyset Pagination
impact: HIGH
impactDescription: No SQL injection, no surprise columns, no unbounded result sets
tags: [queries, sql-injection, parameters, pagination, limit]
---

# Parameters Always, Named Columns, LIMIT and Keyset Pagination [HIGH]

## Description
Values go into queries as bind parameters (`$1`, or the driver's placeholder), never by string concatenation or formatting: a quote in the value then cannot change the query. Identifiers that must vary (a sort column chosen by the user) come from an allow-list, quoted with `quote_ident`/`format('%I')` or the driver's identifier helper.

Select the columns the code uses: `SELECT *` sends columns nobody reads, breaks code that maps by position when a column is added, and can leak new sensitive columns. Every query that returns a list has a `LIMIT`. Page large lists with keyset pagination (the last row's sort key), not `OFFSET`, which reads and throws away every earlier row.

## Bad Example
```sql
-- built in code: "SELECT * FROM orders WHERE customer = '" + name + "' ORDER BY " + sort
SELECT * FROM orders WHERE customer = 'O''Brien' OR 1=1 --' ORDER BY created_at;

SELECT id, total FROM orders ORDER BY created_at DESC OFFSET 200000 LIMIT 50;
```

## Good Example
```sql
SELECT id, total, created_at
FROM orders
WHERE customer_id = $1
ORDER BY created_at DESC, id DESC
LIMIT 50;

-- next page: the last row's (created_at, id) from the previous page
SELECT id, total, created_at
FROM orders
WHERE customer_id = $1 AND (created_at, id) < ($2, $3)
ORDER BY created_at DESC, id DESC
LIMIT 50;
```

## Notes
- `IN` lists with a variable number of values: pass an array (`WHERE id = ANY($1)`) instead of building placeholders.
- Keyset pagination needs a unique sort key; add the primary key as the tie-breaker.

## References
- [PostgreSQL: LIMIT and OFFSET](https://www.postgresql.org/docs/current/queries-limit.html)
- [OWASP: Query Parameterization Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Query_Parameterization_Cheat_Sheet.html)
