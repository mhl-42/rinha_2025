---
title: Atomic Upserts with ON CONFLICT or MERGE, Not Read-Then-Write
impact: HIGH
impactDescription: No duplicate rows or unique-violation errors under concurrent requests
tags: [queries, upsert, on-conflict, merge, race-conditions]
---

# Atomic Upserts with ON CONFLICT or MERGE, Not Read-Then-Write [HIGH]

## Description
"Select; if not found, insert" races: two requests both find nothing and both insert, creating a duplicate or failing on the unique index. Let one statement decide: `INSERT ... ON CONFLICT (key) DO UPDATE` (or `DO NOTHING`) is atomic and backed by a unique index. The same applies to counters: `UPDATE ... SET n = n + 1` instead of reading `n` and writing `n + 1`.

`MERGE` (PG 15+, `RETURNING` from PG 17) fits synchronizing a table from a source set with insert, update and delete branches. It is not safe against concurrent inserts the way `ON CONFLICT` is; prefer `ON CONFLICT` for single-row upserts under concurrency.

## Bad Example
```sql
SELECT id FROM customers WHERE email = $1;
-- application: if no row, then
INSERT INTO customers (email, name) VALUES ($1, $2);

SELECT stock FROM products WHERE id = $1;
-- application computes stock - 1, then
UPDATE products SET stock = $2 WHERE id = $1;
```

## Good Example
```sql
INSERT INTO customers (email, name)
VALUES ($1, $2)
ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name
RETURNING id;

UPDATE products
SET stock = stock - $2
WHERE id = $1 AND stock >= $2
RETURNING stock;  -- no row returned: not enough stock
```

## Notes
- `ON CONFLICT` needs a unique index or constraint on exactly the conflict columns.
- `DO NOTHING` returns no row for the existing one; follow it with a `SELECT` when the id is needed.

## References
- [PostgreSQL: INSERT ... ON CONFLICT](https://www.postgresql.org/docs/current/sql-insert.html#SQL-ON-CONFLICT)
- [PostgreSQL: MERGE](https://www.postgresql.org/docs/current/sql-merge.html)
