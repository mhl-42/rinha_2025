---
title: Least-Privilege Roles, scram-sha-256, TLS, RLS for Tenants
impact: HIGH
impactDescription: A compromised application cannot drop tables, read other tenants, or be sniffed on the wire
tags: [security, roles, privileges, tls, row-level-security, multi-tenant]
---

# Least-Privilege Roles, scram-sha-256, TLS, RLS for Tenants [HIGH]

## Description
- **Roles:** the application connects with a role that can read and write the tables it needs and nothing else; it does not own the schema and is never a superuser. Migrations run with a separate owner role.
- **Passwords:** `scram-sha-256` authentication (`password_encryption = 'scram-sha-256'`, the default since PG 14); `md5` is deprecated.
- **TLS:** every connection that leaves the host uses TLS with certificate verification (`sslmode=verify-full`), not `require` (encrypts without checking who answers) or `disable`.
- **Tenants:** in shared tables with a `tenant_id`, row-level security makes the database enforce the filter, so a missing `WHERE` in one query does not leak another tenant's rows.

## Bad Example
```sql
-- application connection string: postgres://postgres:postgres@db:5432/app?sslmode=disable
SELECT * FROM invoices WHERE id = $1;  -- any tenant's invoice, if the id is guessed
```

## Good Example
```sql
CREATE ROLE app LOGIN PASSWORD :'app_password';
GRANT USAGE ON SCHEMA public TO app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app;
ALTER DEFAULT PRIVILEGES FOR ROLE migrator IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app;

ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON invoices
    USING (tenant_id = current_setting('app.tenant_id')::bigint);

BEGIN;
SELECT set_config('app.tenant_id', $1, true);  -- local to this transaction
SELECT id, total FROM invoices WHERE id = $2;
COMMIT;
```

## Notes
- Table owners and roles with `BYPASSRLS` skip policies; the application role must have neither.
- Grant `TRUNCATE`, `REFERENCES` and `TRIGGER` only when needed; revoke `CREATE` on `public` for the app role.

## References
- [PostgreSQL: row security policies](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)
- [PostgreSQL: SSL support (libpq)](https://www.postgresql.org/docs/current/libpq-ssl.html)
