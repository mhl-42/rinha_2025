---
title: Short Transactions, Row Locks for Read-Modify-Write, SKIP LOCKED Queues
impact: HIGH
impactDescription: No lost updates, no long-held locks, and job queues without double processing
tags: [transactions, locking, for-update, skip-locked, isolation]
---

# Short Transactions, Row Locks for Read-Modify-Write, SKIP LOCKED Queues [HIGH]

## Description
A transaction holds its locks and keeps old row versions alive (blocking vacuum) until it ends. Keep it to the database work: no HTTP calls, no e-mail, no waiting on a user inside it. Call the outside world before or after, and record its result in a short transaction (with an outbox row when the call must happen after commit).

Under the default `READ COMMITTED`, reading a row and writing a value computed from it loses concurrent updates. Lock the row with `SELECT ... FOR UPDATE`, use an atomic statement, or raise the isolation to `SERIALIZABLE` and retry on serialization failures (SQLSTATE `40001`).

For job queues stored in a table, `FOR UPDATE SKIP LOCKED` lets several workers take different rows without waiting for or duplicating each other.

## Bad Example
```sql
BEGIN;
SELECT balance FROM accounts WHERE id = $1;          -- 100
-- application calls the payment provider (2 seconds), then computes 100 - 30
UPDATE accounts SET balance = 70 WHERE id = $1;      -- overwrites a concurrent deposit
COMMIT;
```

## Good Example
```sql
BEGIN;
SELECT balance FROM accounts WHERE id = $1 FOR UPDATE;
UPDATE accounts SET balance = balance - $2 WHERE id = $1 AND balance >= $2;
INSERT INTO outbox (topic, payload) VALUES ('charge.requested', $3);  -- the provider is called after commit
COMMIT;

WITH next AS (
    SELECT id FROM jobs
    WHERE status = 'queued'
    ORDER BY id
    LIMIT 10
    FOR UPDATE SKIP LOCKED
)
UPDATE jobs SET status = 'running', started_at = now()
FROM next WHERE jobs.id = next.id
RETURNING jobs.id, jobs.payload;
```

## Notes
- Lock rows in a consistent order (by id) across code paths to avoid deadlocks.
- `SERIALIZABLE` needs every transaction to be retryable; wrap it in a retry loop in the application.

## References
- [PostgreSQL: transaction isolation](https://www.postgresql.org/docs/current/transaction-iso.html)
- [PostgreSQL: SELECT, the locking clause](https://www.postgresql.org/docs/current/sql-select.html#SQL-FOR-UPDATE-SHARE)
