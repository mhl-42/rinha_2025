---
name: python-coding-standards
description: Use this skill when writing, reviewing, or refactoring application Python code — exception handling, asyncio concurrency, class and module design (SOLID, dependency injection, dataclasses, Protocols), docstrings and type hints, and Pydantic validation of external input — even if the user only asks to "clean up", "fix", or "add a feature to" a .py file. Not for test code (use python-testing), project/linter configuration (use python-tooling), NumPy/pandas code (use python-data-science), SQL and database access (use python-database), subprocesses, secrets, password hashing, file uploads, and outbound HTTP calls (use python-security), or code in other languages.
license: MIT
metadata:
  author: Python Best Practices
  version: "2.0.0"
---

# Python Coding Standards

Python coding standards for AI agents. The Quick Reference below covers the common case; open a rule file only when its trigger appears in the code you are writing or reviewing.

## How to Use

- **Writing code**: follow the Quick Reference and Gotchas. Open a rule file when you are about to use the pattern it covers.
- **Reviewing code**: work through the checklist below in order (highest impact first) and open the matching rule when a trigger appears.

| When the code contains... | Read |
|---------------------------|------|
| `except:`, `except Exception`, `pass`/`continue`/`return None` in a handler, log-and-continue | [error-no-silent-exceptions](rules/error-no-silent-exceptions.md) |
| `asyncio.create_task(...)` whose result is not stored | [async-create-task](rules/async-create-task.md) |
| `asyncio.gather(...)`, especially with `return_exceptions=True` | [async-gather](rules/async-gather.md) |
| An unbounded fan-out of requests or a `Semaphore` | [async-semaphore](rules/async-semaphore.md) |
| `time.sleep`, `requests`, sync DB drivers, `open()`, or CPU-heavy calls inside `async def` | [async-no-blocking-calls](rules/async-no-blocking-calls.md) |
| Module-level clients/connections, `global`, `get_x()` accessors | [design-no-global-singleton](rules/design-no-global-singleton.md), [design-dependency-injection](rules/design-dependency-injection.md) |
| A growing `if/elif` or `match` on types/kinds | [solid-ocp](rules/solid-ocp.md) |
| Subclasses that raise `NotImplementedError` or reject parent inputs | [solid-lsp](rules/solid-lsp.md), [solid-isp](rules/solid-isp.md) |
| JSON, form data, env vars, or third-party responses entering the code | [validation-pydantic](rules/validation-pydantic.md) |
| A class that only holds fields, or `get_x()`/`set_x()` methods | [oop-dataclass](rules/oop-dataclass.md), [oop-property](rules/oop-property.md) |

### Review Checklist

- [ ] Errors: no swallowed exceptions; translations use `raise ... from exc`
- [ ] Async: no blocking calls inside `async def`; background tasks are referenced; `gather` failures are inspected; concurrency is bounded
- [ ] Design: dependencies are injected, not fetched from globals
- [ ] Contracts: public functions have type hints and docstrings; external input is validated once at the boundary
- [ ] Run `ruff check .` and `mypy .` if the project configures them, and fix what they report before finishing

Performance and OOP rules (`perf-*`, `oop-*`) are style-level: apply them to code you are writing, but do not rewrite working code for them unless asked.

## Gotchas

- `asyncio.create_task()` without a stored reference: the event loop keeps only a weak reference, so the task can be garbage-collected mid-run. Keep tasks in a `set` and discard them in a done callback.
- `asyncio.gather()` does **not** cancel the remaining coroutines when one fails; they keep running. Use `asyncio.TaskGroup` (3.11+) for all-or-nothing semantics.
- `gather(..., return_exceptions=True)` turns failures into return values: every result must be checked, and `asyncio.CancelledError` is a `BaseException`, so `isinstance(r, Exception)` misses it.
- Logging is not recovery: `except Exception: logger.exception(...)` inside domain code still swallows the failure. Suppress only at a process or task boundary that reports a non-success outcome.
- Never swallow `asyncio.CancelledError`, `KeyboardInterrupt`, or `SystemExit`; re-raise after cleanup.
- A `Semaphore` created at import time can bind to the first event loop that waits on it and raise `RuntimeError` from another loop. Create it per client or per loop.
- `@dataclass` with a mutable default (`items: list = []`) raises at class definition; use `field(default_factory=list)`.
- `@cached_property` needs `__dict__`, so it fails on `slots=True` classes, and it is not thread-safe.
- `@runtime_checkable` `isinstance()` checks only that method names exist, not signatures.
- Pydantic `field_validator` runs after `Field()` constraints by default; use `mode="before"` to normalize input (e.g. strip whitespace) before length or pattern checks.

## Categories

### Error Handling [CRITICAL]
Prevent failures from being hidden or reported as successful outcomes.

| Rule | Description |
|------|-------------|
| [error-no-silent-exceptions](rules/error-no-silent-exceptions.md) | Never swallow exceptions |

### Performance Optimization [CRITICAL]
Apply Python optimization patterns to improve processing speed and memory efficiency.

| Rule | Description |
|------|-------------|
| [perf-list-comprehension](rules/perf-list-comprehension.md) | Prefer list comprehensions over loops (1.5-2x faster) |
| [perf-generator-expression](rules/perf-generator-expression.md) | Use generators for large datasets (O(1) memory) |
| [perf-dict-get](rules/perf-dict-get.md) | Use dict.get() for efficient default values |
| [perf-set-lookup](rules/perf-set-lookup.md) | Use set for fast lookups (O(1) vs O(n)) |
| [perf-str-join](rules/perf-str-join.md) | Use join for string concatenation (O(n) vs O(n²)) |

### Async Processing [HIGH]
Efficient asynchronous programming patterns using asyncio.

| Rule | Description |
|------|-------------|
| [async-gather](rules/async-gather.md) | Use asyncio.gather for independent tasks |
| [async-create-task](rules/async-create-task.md) | Proper background task creation |
| [async-context-manager](rules/async-context-manager.md) | Resource management with async with |
| [async-semaphore](rules/async-semaphore.md) | Limit concurrency with semaphores |
| [async-no-blocking-calls](rules/async-no-blocking-calls.md) | Never block the event loop with sync I/O or CPU work |

### Design Principles [HIGH]
Software design principles for maintainability and extensibility.

| Rule | Description |
|------|-------------|
| [design-philosophy](rules/design-philosophy.md) | DRY, YAGNI, KISS principles |
| [design-single-responsibility](rules/design-single-responsibility.md) | Single Responsibility Principle |
| [design-dependency-injection](rules/design-dependency-injection.md) | Loose coupling with dependency injection |
| [design-no-global-singleton](rules/design-no-global-singleton.md) | Avoid global singletons and module-level shared instances |
| [solid-ocp](rules/solid-ocp.md) | Open/Closed Principle |
| [solid-lsp](rules/solid-lsp.md) | Liskov Substitution Principle |
| [solid-isp](rules/solid-isp.md) | Interface Segregation Principle |
| [design-pure-functions](rules/design-pure-functions.md) | Prefer pure functions without side effects |
| [design-early-return](rules/design-early-return.md) | Reduce nesting with early returns |

### Documentation [HIGH]
Documentation standards for public API clarity and machine-checkable contracts.

| Rule | Description |
|------|-------------|
| [doc-docstring](rules/doc-docstring.md) | Document public APIs with Google style docstrings |
| [doc-type-hints](rules/doc-type-hints.md) | Require type hints for public APIs |

### Data Validation [HIGH]
Validation patterns for data crossing trust boundaries.

| Rule | Description |
|------|-------------|
| [validation-pydantic](rules/validation-pydantic.md) | Use Pydantic for boundary data validation |

### Object-Oriented Programming [MEDIUM]
Best practices for Pythonic object-oriented programming.

| Rule | Description |
|------|-------------|
| [oop-composition-over-inheritance](rules/oop-composition-over-inheritance.md) | Prefer composition over inheritance |
| [oop-dataclass](rules/oop-dataclass.md) | Use dataclass for data containers |
| [oop-protocol](rules/oop-protocol.md) | Prefer Protocol over abstract base classes |
| [oop-property](rules/oop-property.md) | Use property instead of getters |

## Quick Reference

### Error Handling
```python
try:
    config = parse_config(path)
except ConfigParseError as exc:
    raise StartupError(f"Invalid configuration: {path}") from exc


def main() -> int:
    try:
        start_application()
    except StartupError:
        logger.exception("Application startup failed")
        return 1  # explicit non-success outcome at the process boundary
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
```

### Performance Patterns
```python
# List comprehension (not loops)
result = [x * 2 for x in items]

# Generator for large data
total = sum(x * x for x in range(1_000_000))

# dict.get() with default
value = config.get("key", default_value)

# Set for fast lookup
valid_ids: set[int] = {1, 2, 3}
if item_id in valid_ids: ...

# join for strings
result = ",".join(values)
```

### Async Patterns
```python
# Concurrent execution
results = await asyncio.gather(task1(), task2(), task3())

# Resource management
async with aiohttp.ClientSession() as session:
    async with session.get(url) as response:
        data = await response.json()

# Concurrency limit
semaphore = asyncio.Semaphore(10)
async with semaphore:
    await do_work()
```

### Design Patterns
```python
# Dependency injection (not module-level singletons)
class Service:
    def __init__(self, repository: Repository) -> None:
        self.repository = repository

# Composition root builds the graph once
def create_app(settings: Settings) -> Service:
    return Service(repository=PostgresRepository(settings.dsn))

# Open/Closed: extend via new types, not edits
class JsonFormat:
    def export(self, invoice: Invoice) -> str: ...

# Interface Segregation: small Protocols
class Workable(Protocol):
    def work(self) -> None: ...

# Early return
def process(data: Data | None) -> Result:
    if data is None:
        return Result.empty()
    # main logic here
```

### Documentation Patterns
```python
def create_user(email: str, name: str) -> User:
    """Create a user account.

    Args:
        email: Unique email address for the account.
        name: Display name for the user.

    Returns:
        The created user.
    """
    return user_repository.create(email=email, name=name)
```

### Validation Patterns
```python
from pydantic import BaseModel, EmailStr, Field

class CreateUserRequest(BaseModel):
    email: EmailStr
    age: int = Field(ge=0, le=150)
```

### OOP Patterns
```python
# Dataclass
@dataclass
class User:
    name: str
    email: str

# Protocol for interfaces
class Repository(Protocol):
    def get(self, id: str) -> Entity: ...

# Property
@property
def full_name(self) -> str:
    return f"{self.first} {self.last}"
```

## See Also

- The `python-tooling` skill, if installed, configures ruff, mypy, pytest, pyscn, and uv to enforce these standards automatically.
