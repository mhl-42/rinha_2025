---
title: Never Block the Event Loop
impact: HIGH
impactDescription: One blocking call stalls every concurrent task
tags: [async, asyncio, blocking, event-loop, to_thread]
---

# Never Block the Event Loop [HIGH]

## Description
An asyncio event loop runs every task on one thread. A synchronous call that waits on I/O or burns CPU inside an `async def` (`time.sleep`, `requests.get`, a sync database driver, reading a large file, hashing a password) freezes *all* other tasks until it returns: a web server stops answering every request, not just the slow one. Nothing raises; the service just gets slow under load.

Inside `async def`:
- Use the async version of the library (`asyncio.sleep`, `httpx.AsyncClient`, `psycopg.AsyncConnection`, `aiofiles`).
- When only a sync library exists, run the call in a thread with `await asyncio.to_thread(func, *args)`.
- For CPU-heavy work, use a process pool (`loop.run_in_executor(process_pool, func, *args)`).

## Bad Example
```python
async def get_profile(user_id: int) -> Profile:
    time.sleep(0.5)  # blocks every request handled by this worker
    response = requests.get(f"{API}/users/{user_id}", timeout=10)  # sync HTTP
    with open(f"/data/avatars/{user_id}.png", "rb") as f:  # sync file I/O
        avatar = f.read()
    return Profile(**response.json(), avatar=avatar)


async def register(email: str, password: str) -> None:
    password_hash = hasher.hash(password)  # ~100 ms of CPU on the event loop
    await users.insert(email, password_hash)
```

## Good Example
```python
async def get_profile(client: httpx.AsyncClient, user_id: int) -> Profile:
    await asyncio.sleep(0.5)
    response = await client.get(f"/users/{user_id}")
    avatar = await asyncio.to_thread(Path(f"/data/avatars/{user_id}.png").read_bytes)
    return Profile(**response.json(), avatar=avatar)


async def register(email: str, password: str) -> None:
    password_hash = await asyncio.to_thread(hasher.hash, password)
    await users.insert(email, password_hash)
```

## Notes
- Common blocking calls that slip in: `time.sleep`, `requests`/`urllib`, `psycopg.connect` (sync), `sqlite3`, `subprocess.run`, `open().read()` on large files, `json.loads` on huge payloads, bcrypt/argon2 hashing, pandas operations.
- `asyncio.to_thread` uses the default thread pool (a few dozen threads). It suits occasional sync calls, not a hot path that should use an async library.
- Threads do not speed up pure-Python CPU work because of the GIL; use a `ProcessPoolExecutor` for that.
- In FastAPI, a plain `def` endpoint already runs in a thread pool; the problem is sync calls inside `async def` endpoints.
- `asyncio.get_running_loop().set_debug(True)` (or `PYTHONASYNCIODEBUG=1`) logs callbacks that take longer than 100 ms, which points at blocking calls.
- Ruff's `ASYNC` rules flag many of these (`ASYNC210` blocking HTTP, `ASYNC251` `time.sleep`, `ASYNC230` sync file open).

## References
- [asyncio - Running in threads](https://docs.python.org/3/library/asyncio-task.html#running-in-threads)
- [asyncio - Developing with asyncio (debug mode)](https://docs.python.org/3/library/asyncio-dev.html)
- [Ruff - flake8-async rules](https://docs.astral.sh/ruff/rules/#flake8-async-async)
