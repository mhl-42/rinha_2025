# Python Database Access

Relational database practices for AI agents writing Python data-access code with plain SQL through the driver (psycopg 3 by default, python-oracledb for Oracle), without an ORM.

## Overview

This skill provides 21 rules across 8 categories:

| Category | Prefix | Impact | Rules |
|----------|--------|--------|-------|
| Security | `sec-` | CRITICAL | 2 |
| Transactions | `tx-` | CRITICAL | 2 |
| Connections | `conn-` | HIGH | 1 |
| Queries | `query-` | HIGH | 4 |
| Migrations | `migration-` | HIGH | 2 |
| Code Organization | `repo-` | MEDIUM | 1 |
| Testing | `test-` | MEDIUM | 1 |
| Oracle | `oracle-` | HIGH | 8 |

## Why No ORM

Agents write SQL fluently, and explicit SQL is what reviewers, `EXPLAIN`, and the database logs see. ORMs hide the real queries (lazy loading creates N+1 queries nobody wrote), keep a second schema definition that drifts from the migrations, and turn performance work into fighting the abstraction. Projects that already use an ORM keep it: the skill tells the agent to follow existing conventions and not migrate unless asked.

## Structure

```
skills/python-database/
├── SKILL.md                  # Skill overview with quick reference
├── metadata.json             # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md                 # This file
├── evals/
│   ├── evals.json            # Output-quality test cases (prompt, expected output, assertions)
│   └── trigger_queries.json  # Should/should-not trigger queries for the description
└── rules/
    ├── _sections.md          # Section definitions
    ├── _template.md          # Rule template
    ├── sec-*.md              # SQL injection and dynamic SQL
    ├── tx-*.md               # Transactions and concurrency
    ├── conn-*.md             # Connection pools
    ├── query-*.md            # Query patterns
    ├── migration-*.md        # Schema migrations
    ├── repo-*.md             # Data-access layer
    ├── test-*.md             # Database tests
    └── oracle-*.md           # Oracle Database with python-oracledb (Thin/Thick)
```

## Rules

### Security (CRITICAL)
- `sec-parameterized-queries` - Pass values as bound parameters, never by string formatting
- `sec-dynamic-sql` - Compose identifiers and optional clauses with psycopg.sql and allowlists

### Transactions (CRITICAL)
- `tx-explicit-boundaries` - One explicit transaction per unit of work, owned by the caller
- `tx-atomic-writes` - Do read-modify-write in one statement or under a row lock

### Connections (HIGH)
- `conn-pool` - Use one injected connection pool per process

### Queries (HIGH)
- `query-no-n-plus-one` - Fetch related rows in one query, not one per item
- `query-batch-writes` - Write many rows with executemany, unnest, or COPY
- `query-explicit-columns` - Select named columns into typed rows
- `query-keyset-pagination` - Paginate with keyset conditions instead of large OFFSETs

### Migrations (HIGH)
- `migration-versioned-sql` - Keep schema changes in versioned SQL migration files
- `migration-zero-downtime` - Change live tables without long locks or breaking running code

### Code Organization (MEDIUM)
- `repo-sql-in-repositories` - Keep SQL in repository functions that take the connection

### Testing (MEDIUM)
- `test-real-database` - Run data-access tests against real PostgreSQL with per-test rollback

### Oracle (HIGH)
- `oracle-bind-variables` - Use `:name` bind variables, and bind IN lists as one collection
- `oracle-transactions` - Commit explicitly; `with` blocks roll back and DDL commits implicitly
- `oracle-driver-modes` - Use python-oracledb; Thin mode by default, Thick mode only for Thick-only features
- `oracle-pool` - One python-oracledb connection pool per process
- `oracle-bulk-and-fetch` - executemany with batcherrors, MERGE, fetch tuning, Decimal and LOB defaults
- `oracle-sql-dialect` - Oracle equivalents of LIMIT, RETURNING, ON CONFLICT; empty string is NULL
- `oracle-migrations` - One DDL per migration, online DDL, and DDL_LOCK_TIMEOUT
- `oracle-testing` - Test against Oracle Database Free with per-test rollback

## Usage

The agent loads this skill when its `description` matches the task (SQL, connections, transactions, migrations, data-access code).

## Contributing

To add a new rule:
1. Copy `rules/_template.md`
2. Use the appropriate prefix (`sec-`, `tx-`, `conn-`, `query-`, `migration-`, `repo-`, `test-`, `oracle-`)
3. Follow the existing format; keep examples in plain SQL with psycopg 3 (python-oracledb in `oracle-` rules)
4. Update `_sections.md`, `SKILL.md` (category table, and the "How to Use" trigger table if the rule has a clear trigger), and `metadata.json`
5. Run `uv run scripts/validate_skills.py` from the repository root
