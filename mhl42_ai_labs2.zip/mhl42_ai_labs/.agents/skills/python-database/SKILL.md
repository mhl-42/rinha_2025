---
name: python-database
description: Use this skill when writing, reviewing, or changing Python code that talks to a relational database — SQL queries, psycopg/asyncpg/sqlite3 or Oracle with python-oracledb (Thin or Thick mode, including migrating off cx_Oracle) connections and pools, transactions, bulk inserts, pagination, schema migrations, repository/data-access layers, and database tests — even if the user only says "save this to the DB", "this endpoint is slow", or "add a column". Works with plain SQL through the driver, without an ORM. Not for DataFrame analysis with read_sql (use python-data-science), general Python style (use python-coding-standards), or database code in other languages.
license: MIT
compatibility: Examples target PostgreSQL with psycopg 3 and psycopg_pool (sync and async). Oracle uses python-oracledb 2+ (oracle-* rules) in Thin mode by default (Oracle Database 12.1+, no Oracle Client), Thick mode when Oracle Client 19+ libraries are installed. The principles apply to asyncpg and sqlite3 with their own placeholder styles.
metadata:
  author: Python Best Practices
  version: "2.0.0"
---

# Python Database Access

Database practices for AI agents writing Python data-access code with plain SQL.

## Approach: SQL Through the Driver, No ORM

Write SQL directly and execute it with the database driver (psycopg 3 by default; python-oracledb for Oracle). Do not introduce an ORM (SQLAlchemy ORM, Django ORM, SQLModel, Peewee, Tortoise) or a query builder in new code.

Why: agents write correct SQL fluently, and explicit SQL is what reviewers, `EXPLAIN`, and the database logs see. ORMs hide the actual queries (lazy loading produces N+1 queries no one wrote), add a second schema definition that drifts from the migrations, and make performance work a matter of fighting the abstraction.

If the project already uses an ORM, follow the existing code and conventions; do not mix styles or migrate away from it unless the user asks.

## How to Use

- **Writing data-access code**: follow the Quick Reference and Gotchas; put the SQL in a repository module (see [repo-sql-in-repositories](rules/repo-sql-in-repositories.md)).
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| f-strings, `%`, `.format()` or `+` building SQL text | [sec-parameterized-queries](rules/sec-parameterized-queries.md) |
| Table/column names, `ORDER BY`, or optional `WHERE` filters chosen at runtime | [sec-dynamic-sql](rules/sec-dynamic-sql.md) |
| Several writes that must succeed or fail together; `commit()` calls scattered around | [tx-explicit-boundaries](rules/tx-explicit-boundaries.md) |
| `SELECT` a value, change it in Python, `UPDATE` it back; check-then-insert | [tx-atomic-writes](rules/tx-atomic-writes.md) |
| `psycopg.connect(...)` per request or a module-level connection | [conn-pool](rules/conn-pool.md) |
| A query inside a `for` loop | [query-no-n-plus-one](rules/query-no-n-plus-one.md) |
| `INSERT` in a loop, row-by-row loads | [query-batch-writes](rules/query-batch-writes.md) |
| `SELECT *`, rows handled as tuples or dicts in business logic | [query-explicit-columns](rules/query-explicit-columns.md) |
| `OFFSET` on large tables or infinite scroll | [query-keyset-pagination](rules/query-keyset-pagination.md) |
| `CREATE TABLE`/`ALTER TABLE` run by app code or by hand | [migration-versioned-sql](rules/migration-versioned-sql.md) |
| `CREATE INDEX`, `NOT NULL`, foreign keys, renames on existing tables | [migration-zero-downtime](rules/migration-zero-downtime.md) |
| Tests that mock the cursor or swap PostgreSQL for SQLite | [test-real-database](rules/test-real-database.md) |

### Oracle

The rules above apply to Oracle too, but their examples are psycopg. Oracle code uses **python-oracledb** (`import oracledb`); when the project uses it, or still uses `cx_Oracle`, also open the Oracle rule for the topic:

| When the Oracle code contains... | Read |
|----------------------------------|------|
| `%s` placeholders, SQL built with values, `IN (...)` lists | [oracle-bind-variables](rules/oracle-bind-variables.md) |
| Writes without `commit()`, commits in repositories, read-modify-write | [oracle-transactions](rules/oracle-transactions.md) |
| `cx_Oracle`, `init_oracle_client`, Instant Client, Thin vs Thick mode, NNE/Kerberos | [oracle-driver-modes](rules/oracle-driver-modes.md) |
| `oracledb.connect` per request, `SessionPool`, async pools | [oracle-pool](rules/oracle-pool.md) |
| `execute` in a loop, money columns, large fetches, CLOBs | [oracle-bulk-and-fetch](rules/oracle-bulk-and-fetch.md) |
| `LIMIT`, `ON CONFLICT`, `RETURNING id`, `''` comparisons, `SERIAL`, `BOOLEAN` | [oracle-sql-dialect](rules/oracle-sql-dialect.md) |
| Migration files with several DDLs, indexes or NOT NULL on live tables | [oracle-migrations](rules/oracle-migrations.md) |
| Oracle repository tests on SQLite or mocks | [oracle-testing](rules/oracle-testing.md) |

### Review Checklist

- [ ] Every value reaches the database as a bound parameter; identifiers go through `psycopg.sql`
- [ ] Each unit of work has one explicit transaction, owned by the service layer, with no network calls inside
- [ ] Read-modify-write is a single SQL statement or uses row locks
- [ ] No queries in loops; bulk writes use `executemany` or `COPY`
- [ ] Schema changes live in versioned migration files and are safe to run on a live table
- [ ] When a database is available, run the queries (or the tests) and check `EXPLAIN` for new queries on large tables

## Gotchas

- Install `psycopg[binary]` (plus `psycopg-pool` for pools). Plain `psycopg` needs a system libpq and fails at import with "no pq wrapper available" when it is missing.
- psycopg 3 does not support `WHERE id IN %s` with a tuple (psycopg 2 did). Use `WHERE id = ANY(%s)` with a Python list.
- psycopg 3 binds parameters on the server, so placeholders do not work in statements without parameters such as `SET`, `NOTIFY`, or DDL. Use `psycopg.sql.Literal` or `SELECT set_config(...)` there.
- With parameters, a literal `%` in the query text must be written `%%` (e.g. `LIKE 'a%%'`). Better: pass the whole pattern as a parameter.
- psycopg connections start a transaction on the first statement unless `autocommit=True`. A connection that only reads and never commits stays "idle in transaction", holding locks and blocking `VACUUM`.
- `with psycopg.connect(...) as conn:` commits and **closes** the connection; `with pool.connection() as conn:` commits and returns it to the pool. sqlite3's `with conn:` commits but does **not** close.
- `INSERT ... ON CONFLICT` needs a unique index or constraint on exactly the conflict columns.
- `CREATE INDEX CONCURRENTLY` cannot run inside a transaction block, and most migration tools wrap each migration in one (in yoyo, add `-- transactional: false` to that file).
- yoyo reads a plain `postgresql://` URL as psycopg 2; with psycopg 3 use `postgresql+psycopg://`.
- SQLite does not enforce foreign keys unless `PRAGMA foreign_keys = ON` is run on every connection.
- `cursor.rowcount` after `executemany` or `COPY` is not a reliable count of affected rows; use `RETURNING` when you need the rows.

### Oracle (python-oracledb)

- Use `python-oracledb` (`pip install oracledb`, `import oracledb`); `cx_Oracle` is its unmaintained predecessor. It runs in **Thin mode** by default (pure Python, no Oracle Client, Oracle Database 12.1+, the only mode with asyncio) or in **Thick mode** after `oracledb.init_oracle_client()` (needs Oracle Instant Client 19+; required for NNE, Kerberos, `sqlnet.ora`, Application Continuity, or databases older than 12.1). Stay in Thin mode unless a Thick-only feature is needed.
- The mode is fixed per process: `init_oracle_client()` must run at startup before any connection or pool exists, otherwise it fails (DPY-2019).
- Nothing autocommits, and leaving `with oracledb.connect()` or `with pool.acquire()` **rolls back** uncommitted work, the opposite of psycopg. Call `conn.commit()` at the end of the unit of work.
- Placeholders are `:name`; `%s` fails. `IN` lists are capped at 1000 items (ORA-01795): bind a `SYS.ODCINUMBERLIST` and use `IN (SELECT column_value FROM TABLE(:ids))`.
- `''` is stored as `NULL`: compare with `IS NULL`, and expect `None` back for empty strings.
- `NUMBER` columns come back as `float` unless `oracledb.defaults.fetch_decimals = True`; set it before handling money.
- DDL commits implicitly, so migrations cannot be rolled back: one DDL change per migration file.
- No `LIMIT` and no row-value comparison: use `FETCH FIRST n ROWS ONLY` and expand `(a, b) < (x, y)` into `a < x OR (a = x AND b < y)`.

## Categories

### Security [CRITICAL]
Keep untrusted input out of SQL text.

| Rule | Description |
|------|-------------|
| [sec-parameterized-queries](rules/sec-parameterized-queries.md) | Pass values as bound parameters, never by string formatting |
| [sec-dynamic-sql](rules/sec-dynamic-sql.md) | Compose identifiers and optional clauses with psycopg.sql and allowlists |

### Transactions [CRITICAL]
Make units of work atomic and free of race conditions.

| Rule | Description |
|------|-------------|
| [tx-explicit-boundaries](rules/tx-explicit-boundaries.md) | One explicit transaction per unit of work, owned by the caller |
| [tx-atomic-writes](rules/tx-atomic-writes.md) | Do read-modify-write in one statement or under a row lock |

### Connections [HIGH]
Share and release connections correctly.

| Rule | Description |
|------|-------------|
| [conn-pool](rules/conn-pool.md) | Use one injected connection pool per process |

### Queries [HIGH]
Fetch and write data with the fewest round trips and explicit shapes.

| Rule | Description |
|------|-------------|
| [query-no-n-plus-one](rules/query-no-n-plus-one.md) | Fetch related rows in one query, not one per item |
| [query-batch-writes](rules/query-batch-writes.md) | Write many rows with executemany, unnest, or COPY |
| [query-explicit-columns](rules/query-explicit-columns.md) | Select named columns into typed rows |
| [query-keyset-pagination](rules/query-keyset-pagination.md) | Paginate with keyset conditions instead of large OFFSETs |

### Migrations [HIGH]
Change the schema in reviewable, repeatable, non-blocking steps.

| Rule | Description |
|------|-------------|
| [migration-versioned-sql](rules/migration-versioned-sql.md) | Keep schema changes in versioned SQL migration files |
| [migration-zero-downtime](rules/migration-zero-downtime.md) | Change live tables without long locks or breaking running code |

### Code Organization [MEDIUM]
Keep SQL in one layer with typed inputs and outputs.

| Rule | Description |
|------|-------------|
| [repo-sql-in-repositories](rules/repo-sql-in-repositories.md) | Keep SQL in repository functions that take the connection |

### Testing [MEDIUM]
Test SQL against the real database engine.

| Rule | Description |
|------|-------------|
| [test-real-database](rules/test-real-database.md) | Run data-access tests against real PostgreSQL with per-test rollback |

### Oracle [HIGH]
Apply the rules above to Oracle Database with python-oracledb.

| Rule | Description |
|------|-------------|
| [oracle-bind-variables](rules/oracle-bind-variables.md) | Use `:name` bind variables, and bind IN lists as one collection |
| [oracle-transactions](rules/oracle-transactions.md) | Commit explicitly; `with` blocks roll back and DDL commits implicitly |
| [oracle-driver-modes](rules/oracle-driver-modes.md) | Use python-oracledb; Thin mode by default, Thick mode only for Thick-only features |
| [oracle-pool](rules/oracle-pool.md) | One python-oracledb connection pool per process |
| [oracle-bulk-and-fetch](rules/oracle-bulk-and-fetch.md) | executemany with batcherrors, MERGE, fetch tuning, Decimal and LOB defaults |
| [oracle-sql-dialect](rules/oracle-sql-dialect.md) | Oracle equivalents of LIMIT, RETURNING, ON CONFLICT; empty string is NULL |
| [oracle-migrations](rules/oracle-migrations.md) | One DDL per migration, online DDL, and DDL_LOCK_TIMEOUT |
| [oracle-testing](rules/oracle-testing.md) | Test against Oracle Database Free with per-test rollback |

## Quick Reference

### Pool and Transactions
```python
from psycopg_pool import ConnectionPool

# Composition root: one pool per process, autocommit + explicit transactions
pool = ConnectionPool(settings.database_url, min_size=1, max_size=10,
                      kwargs={"autocommit": True}, open=False)
pool.open()

def place_order(pool: ConnectionPool, cmd: PlaceOrder) -> int:
    with pool.connection() as conn, conn.transaction():
        order_id = orders_repo.insert(conn, cmd)
        stock_repo.reserve(conn, cmd.items)
    return order_id  # side effects (emails, HTTP) after the transaction commits
```

### Parameters and Dynamic SQL
```python
conn.execute("SELECT id, email FROM users WHERE email = %s", (email,))
conn.execute("SELECT id FROM users WHERE id = ANY(%s)", (user_ids,))  # list → array

from psycopg import sql
query = sql.SQL("SELECT id, name FROM {} ORDER BY {}").format(
    sql.Identifier(table), sql.Identifier(sort_column)  # validated against an allowlist first
)
```

### Typed Rows
```python
from psycopg.rows import class_row

@dataclass(frozen=True)
class User:
    id: int
    email: str

with conn.cursor(row_factory=class_row(User)) as cur:
    user = cur.execute("SELECT id, email FROM users WHERE id = %s", (user_id,)).fetchone()
```

### Atomic Writes and Bulk Loads
```python
# Read-modify-write in one statement
conn.execute(
    "UPDATE accounts SET balance = balance - %s WHERE id = %s AND balance >= %s RETURNING balance",
    (amount, account_id, amount),
)

# Upsert many rows in one round trip
conn.execute(
    """
    INSERT INTO stock (sku, qty)
    SELECT * FROM unnest(%s::text[], %s::int[])
    ON CONFLICT (sku) DO UPDATE SET qty = EXCLUDED.qty
    """,
    (skus, quantities),
)

# Large loads
with conn.cursor() as cur, cur.copy("COPY events (user_id, kind, at) FROM STDIN") as copy:
    for event in events:
        copy.write_row((event.user_id, event.kind, event.at))
```

### Async
```python
from psycopg_pool import AsyncConnectionPool

async with AsyncConnectionPool(url, kwargs={"autocommit": True}, open=False) as pool:
    async with pool.connection() as conn, conn.transaction():
        await conn.execute("UPDATE jobs SET status = 'done' WHERE id = %s", (job_id,))
```

## See Also

These are separate skills; use them if installed.

- `python-coding-standards` - Dependency injection and dataclasses used by the repository pattern here
- `python-testing` - Fixture scope and structure for the database test fixtures
- `python-tooling` - Adding psycopg, psycopg_pool, oracledb, and the migration tool as dependencies with uv
