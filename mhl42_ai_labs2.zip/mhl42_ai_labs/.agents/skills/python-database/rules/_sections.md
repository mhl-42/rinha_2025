# Section Definitions

## Security (sec)
**Impact:** CRITICAL

Keep untrusted input out of SQL text.
Covers bound parameters, identifier quoting with `psycopg.sql`, and allowlists for runtime-chosen columns and filters.

**Rules:**
- `sec-parameterized-queries` - Pass values as bound parameters, never by string formatting
- `sec-dynamic-sql` - Compose identifiers and optional clauses with psycopg.sql and allowlists

## Transactions (tx)
**Impact:** CRITICAL

Make units of work atomic and free of race conditions.
Covers explicit transaction boundaries owned by the service layer, autocommit setup, single-statement updates, upserts, and row locks.

**Rules:**
- `tx-explicit-boundaries` - One explicit transaction per unit of work, owned by the caller
- `tx-atomic-writes` - Do read-modify-write in one statement or under a row lock

## Connections (conn)
**Impact:** HIGH

Share and release connections correctly.
Covers connection pools, their lifecycle at the composition root, sizing, and async pools.

**Rules:**
- `conn-pool` - Use one injected connection pool per process

## Queries (query)
**Impact:** HIGH

Fetch and write data with the fewest round trips and explicit shapes.
Covers N+1 queries, bulk writes, typed rows, and pagination.

**Rules:**
- `query-no-n-plus-one` - Fetch related rows in one query, not one per item
- `query-batch-writes` - Write many rows with executemany, unnest, or COPY
- `query-explicit-columns` - Select named columns into typed rows
- `query-keyset-pagination` - Paginate with keyset conditions instead of large OFFSETs

## Migrations (migration)
**Impact:** HIGH

Change the schema in reviewable, repeatable, non-blocking steps.
Covers versioned SQL migration files and lock-safe changes to live tables.

**Rules:**
- `migration-versioned-sql` - Keep schema changes in versioned SQL migration files
- `migration-zero-downtime` - Change live tables without long locks or breaking running code

## Code Organization (repo)
**Impact:** MEDIUM

Keep SQL in one layer with typed inputs and outputs.
Covers repository modules that receive the connection from the caller.

**Rules:**
- `repo-sql-in-repositories` - Keep SQL in repository functions that take the connection

## Testing (test)
**Impact:** MEDIUM

Test SQL against the real database engine.
Covers disposable PostgreSQL instances, migrations in fixtures, and per-test rollback.

**Rules:**
- `test-real-database` - Run data-access tests against real PostgreSQL with per-test rollback

## Oracle (oracle)
**Impact:** HIGH

Apply the rules above to Oracle Database with python-oracledb.
Covers python-oracledb Thin and Thick modes, bind variables and IN lists, explicit commits, pools and asyncio, executemany and MERGE, fetch defaults, SQL dialect differences, non-transactional DDL in migrations, and tests on Oracle Database Free.

**Rules:**
- `oracle-bind-variables` - Use `:name` bind variables, and bind IN lists as one collection
- `oracle-transactions` - Commit explicitly; `with` blocks roll back and DDL commits implicitly
- `oracle-driver-modes` - Use python-oracledb; Thin mode by default, Thick mode only for Thick-only features
- `oracle-pool` - One python-oracledb connection pool per process
- `oracle-bulk-and-fetch` - executemany with batcherrors, MERGE, fetch tuning, Decimal and LOB defaults
- `oracle-sql-dialect` - Oracle equivalents of LIMIT, RETURNING, ON CONFLICT; empty string is NULL
- `oracle-migrations` - One DDL per migration, online DDL, and DDL_LOCK_TIMEOUT
- `oracle-testing` - Test against Oracle Database Free with per-test rollback
