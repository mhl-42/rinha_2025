---
title: Use One Injected Connection Pool per Process
impact: HIGH
impactDescription: Avoids connection setup per request and connection exhaustion
tags: [connections, pool, psycopg_pool, lifecycle, dependency-injection]
---

# Use One Injected Connection Pool per Process [HIGH]

## Description
Opening a PostgreSQL connection costs a network round trip, authentication, and a server process; doing it per request adds latency and, under load, exhausts `max_connections`. A single long-lived module-level connection is worse: it is shared between threads or tasks, breaks after a network blip, and cannot be replaced in tests.

Create one `psycopg_pool.ConnectionPool` (or `AsyncConnectionPool`) per process at the composition root, open it at startup, close it at shutdown, and pass it to the code that needs it. Borrow connections with `with pool.connection() as conn:`, which always returns them to the pool.

## Bad Example
```python
# Module-level connection shared by every request and thread
conn = psycopg.connect(os.environ["DATABASE_URL"])


def get_user(user_id: int) -> User | None:
    ...


def list_orders(user_id: int) -> list[Order]:
    conn2 = psycopg.connect(os.environ["DATABASE_URL"])  # new connection per call
    rows = conn2.execute("SELECT ...", (user_id,)).fetchall()
    return [Order(*r) for r in rows]  # conn2 never closed: leaks under errors
```

## Good Example
```python
from psycopg_pool import ConnectionPool


def create_pool(settings: Settings) -> ConnectionPool:
    pool = ConnectionPool(
        settings.database_url,
        min_size=2,
        max_size=10,
        kwargs={"autocommit": True},  # explicit transactions, see tx-explicit-boundaries
        open=False,
    )
    pool.open(wait=True, timeout=10)  # fail fast at startup if the database is unreachable
    return pool


# FastAPI: open in the lifespan, inject into handlers
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    async with AsyncConnectionPool(
        settings.database_url, kwargs={"autocommit": True}, open=False
    ) as pool:
        app.state.pool = pool
        yield


async def get_pool(request: Request) -> AsyncConnectionPool:
    return request.app.state.pool
```

## Notes
- Size the pool from the database side: the sum of `max_size` across all processes and replicas must stay below the server's `max_connections` (or the pgbouncer pool). More connections than CPU cores rarely makes queries faster.
- Pass `open=False` and open explicitly (or use the pool as a context manager); opening in the constructor is deprecated in recent psycopg_pool versions.
- Keep the `with pool.connection()` block around the database work only; holding a connection while waiting on HTTP calls starves other requests.
- Use `AsyncConnectionPool` with asyncio code; never call the sync pool from an `async def`, which blocks the event loop.
- Behind pgbouncer in transaction mode, disable prepared statements (`kwargs={"prepare_threshold": None}`) because consecutive statements may run on different server connections.
- Scripts and one-off jobs can use `with psycopg.connect(url, autocommit=True) as conn:` directly; the pool is for long-running processes.

## References
- [psycopg - Connection pools](https://www.psycopg.org/psycopg3/docs/advanced/pool.html)
- [psycopg_pool API](https://www.psycopg.org/psycopg3/docs/api/pool.html)
