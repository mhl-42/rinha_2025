---
title: Keep Schema Changes in Versioned SQL Migration Files
impact: HIGH
impactDescription: Reproducible schema in every environment
tags: [migrations, schema, ddl, yoyo, version-control]
---

# Keep Schema Changes in Versioned SQL Migration Files [HIGH]

## Description
The schema is part of the code. Every change (tables, columns, indexes, constraints, data backfills) goes into a new, numbered `.sql` file in the repository and is applied by a migration tool that records which files already ran. Do not create tables at application startup, run DDL from request handlers, or apply changes by hand in a database console: environments drift and nobody can tell which schema production has.

If the project has no migration tool, use [yoyo-migrations](https://ollycope.com/software/yoyo/latest/), which runs plain SQL files and is installed as a dev dependency. Keep using whatever tool the project already has (dbmate, Flyway, Sqitch...).

## Bad Example
```python
def init_db(conn: Connection[TupleRow]) -> None:
    # Runs at every startup; ALTERs added later are never applied to existing databases
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id serial PRIMARY KEY,
            email text
        )
    """)
    conn.execute("ALTER TABLE users ADD COLUMN IF NOT EXISTS name text")
```

## Good Example
```
migrations/
├── 0001.create-users.sql
├── 0001.create-users.rollback.sql
├── 0002.add-users-name.sql
└── 0003.create-orders.sql
```

```sql
-- migrations/0001.create-users.sql
CREATE TABLE users (
    id         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    email      text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT users_email_key UNIQUE (email)
);
```

```bash
uv add --dev yoyo-migrations
# yoyo selects the driver from the URL scheme: postgresql+psycopg:// = psycopg 3
uv run yoyo apply --batch --database "postgresql+psycopg://app@db.internal/app" ./migrations
uv run yoyo list --database "postgresql+psycopg://app@db.internal/app" ./migrations
```

## Notes
- yoyo treats a plain `postgresql://` URL as psycopg 2, which a psycopg 3 project does not have installed. Use `postgresql+psycopg://`.
- Declare ordering explicitly when migrations depend on each other: `-- depends: 0001.create-users` at the top of the file.
- Never edit a migration that has already run in a shared environment; write a new one that corrects it.
- One logical change per file, named after what it does. Data backfills on large tables go in their own migration (see [migration-zero-downtime](migration-zero-downtime.md)).
- Run migrations as a separate deploy step before the new application version starts, not from the application's own startup code where several replicas would race.
- Run the full migration set against an empty database in CI (the test database fixture can do this, see [test-real-database](test-real-database.md)), so a broken migration fails before deploy.
- Prefer `bigint GENERATED ALWAYS AS IDENTITY` over `serial`, `timestamptz` over `timestamp`, and `text` with a `CHECK` over `varchar(n)` in new tables.
- Name constraints and indexes explicitly; later migrations must refer to them by name.
- Rollback files are useful in development; in production, recovering forward with a new migration is usually safer than running a rollback that drops data.

## References
- [yoyo-migrations documentation](https://ollycope.com/software/yoyo/latest/)
- [PostgreSQL - Don't Do This](https://wiki.postgresql.org/wiki/Don%27t_Do_This)
