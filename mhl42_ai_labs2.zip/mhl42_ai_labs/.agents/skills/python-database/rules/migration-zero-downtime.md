---
title: Change Live Tables Without Long Locks or Breaking Running Code
impact: HIGH
impactDescription: Avoids outages from table locks and incompatible deploys
tags: [migrations, zero-downtime, locks, index, expand-contract]
---

# Change Live Tables Without Long Locks or Breaking Running Code [HIGH]

## Description
Many `ALTER TABLE` forms take an `ACCESS EXCLUSIVE` lock that blocks every read and write on the table; while a statement waits for that lock, all queries queue behind it. On a large or busy table a "simple" migration becomes an outage. Separately, the old version of the application keeps running during a deploy, so the schema must work for both versions at once.

Rules of thumb for PostgreSQL:
- Set `lock_timeout` in migrations so a blocked DDL fails fast instead of stalling traffic.
- Build indexes with `CREATE INDEX CONCURRENTLY`.
- Add constraints as `NOT VALID`, then `VALIDATE CONSTRAINT` in a separate step.
- Rename or drop in phases (expand, migrate, contract), never in one deploy.

## Bad Example
```sql
-- Blocks writes to orders for the whole index build
CREATE INDEX orders_customer_id_idx ON orders (customer_id);

-- Scans the table under an exclusive lock
ALTER TABLE orders ALTER COLUMN customer_id SET NOT NULL;
ALTER TABLE orders ADD CONSTRAINT orders_customer_fk
    FOREIGN KEY (customer_id) REFERENCES customers (id);

-- Old app version still reads "total": it breaks the moment this runs
ALTER TABLE orders RENAME COLUMN total TO total_amount;

-- Backfill of 50M rows in one transaction: long locks, huge WAL
UPDATE orders SET status_v2 = status;
```

## Good Example
```sql
-- 0010.orders-customer-index.sql
-- transactional: false
-- (yoyo header: CONCURRENTLY cannot run inside a transaction block;
--  other tools have their own flag for this)
CREATE INDEX CONCURRENTLY IF NOT EXISTS orders_customer_id_idx ON orders (customer_id);

-- 0011.orders-customer-fk.sql
SET lock_timeout = '5s';
ALTER TABLE orders ADD CONSTRAINT orders_customer_fk
    FOREIGN KEY (customer_id) REFERENCES customers (id) NOT VALID;  -- brief lock
ALTER TABLE orders VALIDATE CONSTRAINT orders_customer_fk;           -- no write lock

-- 0012.orders-customer-not-null.sql  (PostgreSQL 12+: the valid CHECK lets
-- SET NOT NULL skip the full-table scan)
SET lock_timeout = '5s';
ALTER TABLE orders ADD CONSTRAINT orders_customer_id_not_null
    CHECK (customer_id IS NOT NULL) NOT VALID;
ALTER TABLE orders VALIDATE CONSTRAINT orders_customer_id_not_null;
ALTER TABLE orders ALTER COLUMN customer_id SET NOT NULL;
ALTER TABLE orders DROP CONSTRAINT orders_customer_id_not_null;
```

Renaming `total` to `total_amount` across deploys (expand/contract):
1. Migration: add `total_amount` (nullable). Deploy code that writes both columns.
2. Backfill `total_amount` in batches (`UPDATE ... WHERE id BETWEEN ...`, a few thousand rows per transaction).
3. Deploy code that reads `total_amount` only.
4. Migration: drop `total`.

## Notes
- If `CREATE INDEX CONCURRENTLY` fails it leaves an `INVALID` index; drop it (`DROP INDEX CONCURRENTLY`) and retry.
- Adding a column with a constant `DEFAULT` is instant since PostgreSQL 11; a volatile default (`DEFAULT random()`, `clock_timestamp()`) rewrites the table.
- Changing a column type usually rewrites the table; add a new column and migrate instead. Widening `varchar(n)` or dropping the limit is the common cheap exception.
- `DROP COLUMN` is fast, but deploy the code that stops using the column first.
- Test lock behavior on a production-sized copy when in doubt; `EXPLAIN` does not show locks, but `pg_locks` during a dry run does.

## References
- [PostgreSQL - ALTER TABLE (lock levels and notes)](https://www.postgresql.org/docs/current/sql-altertable.html)
- [PostgreSQL - CREATE INDEX CONCURRENTLY](https://www.postgresql.org/docs/current/sql-createindex.html#SQL-CREATEINDEX-CONCURRENTLY)
