---
title: Use Oracle Bind Variables, Including for IN Lists
impact: CRITICAL
impactDescription: Prevents SQL injection, ORA-01795 failures, and shared-pool hard-parse storms
tags: [oracle, oracledb, security, sql-injection, bind-variables, in-list]
---

# Use Oracle Bind Variables, Including for IN Lists [CRITICAL]

## Description
python-oracledb uses `:name` (or `:1`, `:2`) placeholders, not `%s`. Every value goes in as a bind variable, for the same injection reasons as in [sec-parameterized-queries](sec-parameterized-queries.md). On Oracle there is a second cost: each distinct SQL text is hard-parsed and cached in the shared pool, so literals built into the text (`WHERE id = 42`, `WHERE id = 43`, ...) flood it, burn CPU on parsing, and slow down the whole instance, not just your application.

Lists are the usual leak. Oracle has no `= ANY(array)`, and an `IN` list is limited to 1000 expressions (ORA-01795). Bind the whole list as one collection and read it with `TABLE(...)`.

## Bad Example
```python
# Injection, a new SQL text per call, and ORA-01795 above 1000 ids
ids = ", ".join(str(i) for i in order_ids)
cur.execute(f"SELECT id, status FROM orders WHERE customer_id = {customer_id} AND id IN ({ids})")

# psycopg style placeholders: ORA-01036 / DPY-4010 errors
cur.execute("SELECT id FROM users WHERE email = %s", (email,))
```

## Good Example
```python
cur.execute(
    "SELECT id, email FROM users WHERE email = :email AND status = :status",
    {"email": email, "status": "active"},
)

# Any number of ids, one SQL text, one round trip
id_list = conn.gettype("SYS.ODCINUMBERLIST").newobject(order_ids)
cur.execute(
    """
    SELECT id, status FROM orders
    WHERE customer_id = :customer_id
      AND id IN (SELECT column_value FROM TABLE(:ids))
    """,
    {"customer_id": customer_id, "ids": id_list},
)
```

## Notes
- Use `SYS.ODCIVARCHAR2LIST` for strings and `SYS.ODCIDATELIST` for dates. Fetch the type once per connection rather than per call when it is used in a loop.
- Named binds are clearer than positional ones; do not mix both styles in one statement. Bind names cannot be reserved words: `:date`, `:level`, or `:uid` raise ORA-01745, so use `:start_date`.
- Identifiers (table, column, sort direction) cannot be bound. Choose them from an allowlist exactly as in [sec-dynamic-sql](sec-dynamic-sql.md); python-oracledb has no equivalent of `psycopg.sql`.
- In PL/SQL blocks called with `cur.callproc` or `cur.execute("BEGIN ... END;")`, dynamic SQL inside the procedure (`EXECUTE IMMEDIATE`) must also use `USING` binds; the Python side being safe does not protect the procedure.

## References
- [python-oracledb - Using bind variables](https://python-oracledb.readthedocs.io/en/latest/user_guide/bind.html)
- [python-oracledb - Binding multiple values to a SQL WHERE IN clause](https://python-oracledb.readthedocs.io/en/latest/user_guide/bind.html#binding-multiple-values-to-a-sql-where-in-clause)
