---
title: Batch Oracle Writes with executemany and Tune Fetches
impact: HIGH
impactDescription: 10-100x faster loads and large reads; exact NUMBER values
tags: [oracle, oracledb, executemany, batcherrors, arraysize, decimal, lob]
---

# Batch Oracle Writes with executemany and Tune Fetches [HIGH]

## Description
Each `execute` is a network round trip. Inserting rows in a loop is the classic slow load; `cursor.executemany` sends the whole batch in one array bind. With `batcherrors=True`, bad rows are reported individually instead of aborting the batch, so one constraint violation does not lose the other 9,999 rows.

On the read side, python-oracledb fetches 100 rows per round trip by default (`arraysize`), and it returns `NUMBER` columns with decimals as Python `float`, which silently rounds money. Set the defaults once at startup.

## Bad Example
```python
for row in rows:  # one round trip per row
    cur.execute(
        "INSERT INTO payments (id, account_id, amount) VALUES (:1, :2, :3)",
        (row.id, row.account_id, row.amount),
    )

total = cur.execute("SELECT SUM(amount) FROM payments").fetchone()[0]  # float: 0.30000000000000004
```

## Good Example
```python
import oracledb

oracledb.defaults.fetch_decimals = True  # NUMBER -> decimal.Decimal instead of float
oracledb.defaults.fetch_lobs = False     # CLOB/BLOB up to 1 GB -> str/bytes, no LOB round trips

cur.executemany(
    "INSERT INTO payments (id, account_id, amount) VALUES (:id, :account_id, :amount)",
    [{"id": r.id, "account_id": r.account_id, "amount": r.amount} for r in rows],
    batcherrors=True,
)
failed = [(e.offset, e.message) for e in cur.getbatcherrors()]
if failed:
    conn.rollback()  # or log the rejected rows and commit the rest, per business rule
    raise ImportRejected(failed)
conn.commit()

# Upsert many rows: MERGE with executemany
cur.executemany(
    """
    MERGE INTO stock t
    USING (SELECT :sku AS sku, :qty AS qty FROM dual) s
    ON (t.sku = s.sku)
    WHEN MATCHED THEN UPDATE SET t.qty = s.qty
    WHEN NOT MATCHED THEN INSERT (sku, qty) VALUES (s.sku, s.qty)
    """,
    [{"sku": sku, "qty": qty} for sku, qty in items],
)

# Large reads: bigger fetch batches, streamed
with conn.cursor() as cur:
    cur.arraysize = 5_000
    cur.prefetchrows = 5_001
    for row in cur.execute("SELECT id, kind, created_at FROM events WHERE day = :day", {"day": day}):
        handle(row)
```

## Notes
- Send very large loads in chunks of 10k-100k rows per `executemany` call to bound memory; recent versions also accept a `batch_size` argument.
- If the first rows of a batch contain `None` or short strings, call `cur.setinputsizes(...)` with the real types and sizes to avoid re-binding and "ORA-01438"/truncation surprises in later rows.
- Concurrent `MERGE` statements inserting the same new key can both hit ORA-00001 (unique constraint); catch it and retry the statement once.
- Name rows explicitly (`SELECT id, kind, ...`) and map them with `cur.rowfactory = Event` (positional dataclass) instead of passing tuples around (see [query-explicit-columns](query-explicit-columns.md)). Column names in `cur.description` come back upper case.

## References
- [python-oracledb - Batch statement and bulk copy operations](https://python-oracledb.readthedocs.io/en/latest/user_guide/batch_statement.html)
- [python-oracledb - Tuning fetch performance](https://python-oracledb.readthedocs.io/en/latest/user_guide/tuning.html)
- [python-oracledb - Fetching NUMBER as Decimal](https://python-oracledb.readthedocs.io/en/latest/user_guide/sql_execution.html#fetched-number-precision)
