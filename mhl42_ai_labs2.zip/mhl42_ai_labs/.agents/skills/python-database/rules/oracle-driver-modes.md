---
title: Use python-oracledb and Choose Thin or Thick Mode Deliberately
impact: HIGH
impactDescription: Avoids unsupported drivers, needless native dependencies, and DPY-2019 startup failures
tags: [oracle, oracledb, python-oracledb, thin-mode, thick-mode, instant-client, cx_oracle]
---

# Use python-oracledb and Choose Thin or Thick Mode Deliberately [HIGH]

## Description
**python-oracledb** (`pip install oracledb`, `import oracledb`) is Oracle's supported Python driver. It replaces `cx_Oracle`, which is no longer maintained; do not add `cx_Oracle` to new code, and migrate existing code (the API is largely the same, mostly a rename of the import).

The driver runs in one of two modes, chosen once per process:

| | **Thin mode** (default) | **Thick mode** |
|---|---|---|
| Oracle Client libraries | Not needed: pure Python, plain `pip install` | Required: Oracle Instant Client (or a full client/`ORACLE_HOME`), version 19 or later |
| How to enable | Nothing to do | Call `oracledb.init_oracle_client()` before the first connection or pool |
| Database versions | Oracle Database 12.1 and later | Also older databases (11.2 and earlier) |
| Only here | asyncio (`connect_async`, `create_pool_async`), direct path loads, pipelining (23ai+) | Native Network Encryption (NNE), Kerberos/RADIUS external auth, `sqlnet.ora`/`oraaccess.xml`, Secure External Password Store wallets, Application Continuity/TAC, FAN, TAF, client result cache, SODA, heterogeneous pools and session tagging |
| Config files | Reads only `tnsnames.ora` (from `config_dir`) | Full Oracle Net configuration |

**Default to Thin mode.** It needs no native libraries in the Docker image or on developer machines and supports asyncio. Switch to Thick mode only when the project needs one of the Thick-only features above, for example a DBA-mandated NNE, Kerberos, a database older than 12.1, or Application Continuity. Write down the reason next to the call.

## Bad Example
```python
import cx_Oracle  # unmaintained driver
import oracledb

# Thick mode "just in case": every image and laptop now needs Instant Client
cx_Oracle.init_oracle_client(lib_dir="/opt/oracle/instantclient_19_8")


def handler() -> None:
    conn = oracledb.connect(user=..., password=..., dsn=...)  # first connection: Thin mode is locked in
    oracledb.init_oracle_client()  # DPY-2019: too late, the process is already in Thin mode
```

## Good Example
```python
import oracledb

# Thin mode (default): nothing to initialize
pool = oracledb.create_pool(user=..., password=..., dsn="db.example.com:1521/APP", min=4, max=4)


# Thick mode, only when a Thick-only feature is required. Called once, at startup,
# before any connection or pool is created.
def init_oracle(settings: Settings) -> None:
    if settings.oracle_thick_mode:  # e.g. the database enforces Native Network Encryption
        oracledb.init_oracle_client(
            lib_dir=settings.oracle_client_lib_dir,  # Windows/macOS; None on Linux (see notes)
            config_dir=settings.oracle_config_dir,   # tnsnames.ora, sqlnet.ora
        )
```

## Notes
- The mode is per process and cannot change: once the first connection or pool exists in Thin mode, `init_oracle_client()` fails, and once Thick mode is enabled there is no way back. Call it in the composition root, never inside request code or a library.
- Linux: `lib_dir` only works if the client was built with `RPATH=$ORIGIN`; otherwise put Instant Client on the system library path (`ldconfig`, or `LD_LIBRARY_PATH` set before Python starts) and call `init_oracle_client()` without `lib_dir`. Windows paths need raw strings (`r"C:\oracle\instantclient_23_5"`).
- In Docker, Thick mode means installing Instant Client (and `libaio`) in the image; Thin mode keeps the image a plain Python one.
- Check the mode at runtime with `conn.thin` / `pool.thin` (or `oracledb.is_thin_mode()`), and log it at startup.
- Multi-threaded apps that never use Thick mode can call `oracledb.enable_thin_mode()` at startup to lock Thin mode explicitly.
- asyncio is Thin-only: an async service cannot use Thick-only features, so check this before choosing asyncio for an Oracle project.
- In Thin mode `sqlnet.ora` is not read; pass equivalent settings (timeouts, TLS, `expire_time`) as connect or pool parameters.
- Migrating from cx_Oracle: replace `import cx_Oracle` with `import oracledb`, drop `init_oracle_client()` unless a Thick-only feature is used, and replace `SessionPool(...)` with `create_pool(...)`.

## References
- [python-oracledb - Initializing python-oracledb (Thin and Thick modes)](https://python-oracledb.readthedocs.io/en/latest/user_guide/initialization.html)
- [python-oracledb - Feature comparison of Thin and Thick modes](https://python-oracledb.readthedocs.io/en/latest/user_guide/appendix_a.html)
- [python-oracledb - Upgrading from cx_Oracle](https://python-oracledb.readthedocs.io/en/latest/user_guide/appendix_c.html)
