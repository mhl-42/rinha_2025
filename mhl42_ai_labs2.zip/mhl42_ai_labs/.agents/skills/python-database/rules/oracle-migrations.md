---
title: Write Oracle Migrations for Non-Transactional DDL
impact: HIGH
impactDescription: Avoids half-applied migrations and blocking DDL on live tables
tags: [oracle, migrations, ddl, online, flyway, liquibase]
---

# Write Oracle Migrations for Non-Transactional DDL [HIGH]

## Description
Keep Oracle schema changes in versioned SQL files, as in [migration-versioned-sql](migration-versioned-sql.md), but remember that **Oracle DDL is not transactional**: each `CREATE`/`ALTER`/`DROP` commits on its own. A migration file with five statements that fails on the fourth leaves three applied and cannot be rolled back. Write one DDL change per migration (or make each statement re-runnable), so a failed migration can be fixed and re-run.

Use a migration tool with real Oracle support and plain `.sql` files, such as Flyway or Liquibase (formatted SQL). yoyo-migrations' Oracle backend imports the old `cx_Oracle` driver, not python-oracledb.

On live tables, use the online forms so DML is not blocked, and set `DDL_LOCK_TIMEOUT` so a DDL waits briefly for locks instead of failing at once with ORA-00054.

## Bad Example
```sql
-- V12__orders_region.sql: several DDLs plus a full-table update in one file
ALTER TABLE orders ADD region VARCHAR2(2 CHAR);
UPDATE orders SET region = 'BR';  -- rewrites 80M rows in one transaction, huge undo
ALTER TABLE orders MODIFY region NOT NULL;
CREATE INDEX orders_region_ix ON orders (region);  -- blocks DML on orders while it builds
```

## Good Example
```sql
-- V12__orders_add_region.sql
-- With a DEFAULT, adding a NOT NULL column is a metadata-only change (11g+): no rewrite, instant
ALTER SESSION SET DDL_LOCK_TIMEOUT = 10;
ALTER TABLE orders ADD (region VARCHAR2(2 CHAR) DEFAULT 'BR' NOT NULL);

-- V13__orders_region_index.sql
ALTER SESSION SET DDL_LOCK_TIMEOUT = 10;
CREATE INDEX orders_region_ix ON orders (region) ONLINE;
```

## Notes
- Making an existing column `NOT NULL` without a long validation lock: `ALTER TABLE t MODIFY (col CONSTRAINT t_col_nn NOT NULL ENABLE NOVALIDATE)` (blocks new NULLs), backfill in batches with commits, then `ALTER TABLE t MODIFY CONSTRAINT t_col_nn VALIDATE`.
- Add foreign keys as `ENABLE NOVALIDATE` and validate in a later migration; also index the child column, or deletes on the parent lock the whole child table.
- Backfill large tables in batches (`UPDATE ... WHERE region IS NULL AND ROWNUM <= 10000`, commit, repeat) from a script, not in a DDL migration.
- `CREATE OR REPLACE` for views, packages, and procedures is re-runnable; keep those in repeatable migrations (Flyway `R__` files).
- Renames break the code that is still running; use expand/contract as in [migration-zero-downtime](migration-zero-downtime.md).

## References
- [Oracle - ALTER TABLE](https://docs.oracle.com/en/database/oracle/oracle-database/23/sqlrf/ALTER-TABLE.html)
- [Oracle - Managing indexes online](https://docs.oracle.com/en/database/oracle/oracle-database/23/admin/managing-indexes.html)
- [Flyway - Oracle database](https://documentation.red-gate.com/flyway/reference/database-driver-reference/oracle-database)
