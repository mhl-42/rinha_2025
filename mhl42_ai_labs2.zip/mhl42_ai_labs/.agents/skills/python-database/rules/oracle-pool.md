---
title: Use One python-oracledb Connection Pool per Process
impact: HIGH
impactDescription: Avoids slow Oracle logons per request and connection storms
tags: [oracle, oracledb, python-oracledb, pool, connections, async]
---

# Use One python-oracledb Connection Pool per Process [HIGH]

## Description
An Oracle logon is expensive (authentication, session creation, often TLS), so a connection per request adds tens to hundreds of milliseconds and, under load, overwhelms the listener. Create one pool per process with `oracledb.create_pool` (or `oracledb.create_pool_async` for asyncio) at the composition root and inject it, as in [conn-pool](conn-pool.md).

The pool works the same in Thin and Thick mode; choose the mode first (see [oracle-driver-modes](oracle-driver-modes.md)). `create_pool_async` requires Thin mode.

## Bad Example
```python
import oracledb


def get_user(user_id: int) -> User | None:
    # New logon on every call, password in code, connection leaked on errors
    conn = oracledb.connect(user="app", password="secret", dsn="db:1521/APP")
    ...


pool = oracledb.SessionPool(...)  # cx_Oracle-era name; use create_pool
```

## Good Example
```python
import oracledb


def init_session(conn: oracledb.Connection, requested_tag: str | None) -> None:
    # Runs once per new session, not per acquire
    conn.cursor().execute("ALTER SESSION SET TIME_ZONE = 'UTC'")


def create_pool(settings: Settings) -> oracledb.ConnectionPool:
    return oracledb.create_pool(
        user=settings.db_user,
        password=settings.db_password.get_secret_value(),
        dsn=settings.db_dsn,  # "host:1521/service_name" or a tnsnames alias
        min=4,
        max=4,  # fixed size: Oracle recommends min == max to avoid connection storms
        session_callback=init_session,
        ping_interval=60,
    )


# asyncio (Thin mode only)
pool = oracledb.create_pool_async(user=..., password=..., dsn=..., min=4, max=4)
async with pool.acquire() as conn:
    rows = await conn.fetchall("SELECT id, name FROM products WHERE category = :c", {"c": category})
```

## Notes
- `with pool.acquire() as conn:` returns the connection to the pool and rolls back uncommitted work; commit explicitly (see [oracle-transactions](oracle-transactions.md)).
- Close the pool at shutdown with `pool.close()` (or `await pool.close()` for the async pool).
- Keep `min`, `max` and the number of processes within the database's `PROCESSES`/`SESSIONS` limits, and coordinate with DRCP or a proxy if the DBA provides one.
- `oracledb.defaults` (for example `fetch_decimals`, `fetch_lobs`, `arraysize`) are process-wide; set them once at startup next to the pool creation.
- Never call the sync pool from `async def`; it blocks the event loop.

## References
- [python-oracledb - Connection pooling](https://python-oracledb.readthedocs.io/en/latest/user_guide/connection_handling.html#connection-pooling)
- [python-oracledb - Concurrent programming with asyncio](https://python-oracledb.readthedocs.io/en/latest/user_guide/asyncio.html)
