---
title: Write Oracle SQL, Not PostgreSQL SQL
impact: HIGH
impactDescription: Avoids ORA- syntax errors and silent NULL and pagination bugs
tags: [oracle, sql, dialect, pagination, returning, null, identity]
---

# Write Oracle SQL, Not PostgreSQL SQL [HIGH]

## Description
Agents default to PostgreSQL syntax. On Oracle several of those constructs fail outright, and a few run but behave differently. Check new queries against this list before running them.

| PostgreSQL habit | Oracle |
|------------------|--------|
| `LIMIT 20 OFFSET 40` | `OFFSET 40 ROWS FETCH NEXT 20 ROWS ONLY` (12c+) |
| `WHERE (created_at, id) < (%s, %s)` | Row-value `<` is not supported: `created_at < :c OR (created_at = :c AND id < :id)` |
| `INSERT ... RETURNING id` | `RETURNING id INTO :new_id` with an output bind (`cur.var(...)`) |
| `ON CONFLICT DO UPDATE` | `MERGE INTO ... USING ... ON (...)` |
| `SERIAL` / `BIGSERIAL` | `NUMBER GENERATED ALWAYS AS IDENTITY` (12c+) |
| `BOOLEAN` | `BOOLEAN` only from 23ai; before that `NUMBER(1)` with a `CHECK (col IN (0, 1))` |
| `TEXT`, `now()`, `ILIKE` | `VARCHAR2(n)`/`CLOB`, `SYSTIMESTAMP`, `UPPER(col) LIKE UPPER(:pattern)` |
| `SELECT 1` | `SELECT 1 FROM dual` (the `FROM` is optional only from 23ai) |

The silent one: **Oracle stores the empty string `''` as `NULL`**. `WHERE middle_name = ''` never matches, `NOT NULL` columns reject `''`, and `''` round-trips as `None`.

## Bad Example
```python
cur.execute(
    "SELECT id, created_at FROM events WHERE (created_at, id) < (:c, :id) "
    "ORDER BY created_at DESC, id DESC LIMIT 50",  # ORA-00920 / ORA-00933
    {"c": cursor_at, "id": cursor_id},
)
cur.execute("SELECT id FROM users WHERE nickname = ''")  # always empty
```

## Good Example
```python
cur.execute(
    """
    SELECT id, created_at FROM events
    WHERE created_at < :c OR (created_at = :c AND id < :id)
    ORDER BY created_at DESC, id DESC
    FETCH FIRST :page_size ROWS ONLY
    """,
    {"c": cursor_at, "id": cursor_id, "page_size": 50},
)

cur.execute("SELECT id FROM users WHERE nickname IS NULL")

new_id = cur.var(oracledb.DB_TYPE_NUMBER)
cur.execute(
    "INSERT INTO orders (customer_id, total) VALUES (:customer_id, :total) RETURNING id INTO :new_id",
    {"customer_id": customer_id, "total": total, "new_id": new_id},
)
order_id = int(new_id.getvalue()[0])
```

## Notes
- `DATE` always includes a time of day; `WHERE created = DATE '2026-01-31'` misses rows after midnight. Use a half-open range `>= :day AND < :day + 1`. Prefer `TIMESTAMP WITH TIME ZONE` for events.
- Unquoted identifiers are stored upper case. Never quote identifiers in DDL (`"userId"`), or every query must quote them too.
- `VARCHAR2(100)` counts bytes unless the database uses `NLS_LENGTH_SEMANTICS=CHAR`; declare `VARCHAR2(100 CHAR)` for user text with accents.
- Keyset pagination needs an index matching the `ORDER BY` (here `(created_at, id)`); check the plan with `EXPLAIN PLAN FOR ...` and `DBMS_XPLAN.DISPLAY`.

## References
- [Oracle SQL Language Reference - SELECT (row limiting clause)](https://docs.oracle.com/en/database/oracle/oracle-database/23/sqlrf/SELECT.html)
- [Oracle SQL Language Reference - Nulls](https://docs.oracle.com/en/database/oracle/oracle-database/23/sqlrf/Nulls.html)
- [python-oracledb - DML RETURNING bind variables](https://python-oracledb.readthedocs.io/en/latest/user_guide/bind.html#dml-returning-bind-variables)
