---
title: Test Oracle Data Access Against Oracle Database Free
impact: MEDIUM
impactDescription: Tests catch Oracle syntax, NULL, and type differences that other engines hide
tags: [oracle, testing, pytest, testcontainers, rollback]
---

# Test Oracle Data Access Against Oracle Database Free [MEDIUM]

## Description
Oracle SQL differs enough from PostgreSQL and SQLite (empty string is `NULL`, no `LIMIT`, `MERGE`, `RETURNING INTO`, DDL commits) that tests on another engine prove little. Run repository tests against Oracle Database Free in a container (`gvenzl/oracle-free`), as in [test-real-database](test-real-database.md), and roll back after each test.

python-oracledb has no savepoint-based `transaction()` block, so the per-test fixture simply hands out a connection with autocommit off and calls `rollback()` afterwards. This works as long as repositories never commit (see [oracle-transactions](oracle-transactions.md)).

## Bad Example
```python
@pytest.fixture
def conn() -> Iterator[sqlite3.Connection]:
    conn = sqlite3.connect(":memory:")  # passes LIMIT, ON CONFLICT and '' that fail on Oracle
    conn.executescript(Path("schema_sqlite.sql").read_text())  # a second, drifting schema
    yield conn
```

## Good Example
```python
# tests/conftest.py
import oracledb
import pytest
from testcontainers.community.oracle import OracleDbContainer


@pytest.fixture(scope="session")
def oracle_pool() -> Iterator[oracledb.ConnectionPool]:
    with OracleDbContainer("gvenzl/oracle-free:slim-faststart", username="app", password="app") as db:
        dsn = f"{db.get_container_host_ip()}:{db.get_exposed_port(1521)}/FREEPDB1"
        apply_migrations(dsn, user="app", password="app")  # the same SQL files as production
        pool = oracledb.create_pool(user="app", password="app", dsn=dsn, min=1, max=2)
        yield pool
        pool.close()


@pytest.fixture
def conn(oracle_pool: oracledb.ConnectionPool) -> Iterator[oracledb.Connection]:
    with oracle_pool.acquire() as conn:
        yield conn
        conn.rollback()  # undo everything the test wrote


def test_blank_nickname_is_stored_as_null(conn: oracledb.Connection) -> None:
    user_id = users.insert(conn, email="a@example.com", nickname="")

    assert users.get(conn, user_id).nickname is None
```

## Notes
- The Oracle Free image takes tens of seconds to start; keep the container session-scoped, and use a `faststart` tag locally.
- Tests that need real commits (service functions, `MERGE` concurrency, DDL) cannot rely on rollback; give them a fixture that deletes or truncates the touched tables afterwards.
- testcontainers needs Docker. In CI without it, run `gvenzl/oracle-free` as a service container and read the DSN from an environment variable.
- `pip install "testcontainers[oracle-free]"` pulls SQLAlchemy for the container's helper URL; that is a test-only dependency and does not mean the application uses an ORM.

## References
- [testcontainers-python - Oracle Free](https://testcontainers-python.readthedocs.io/en/latest/modules/oracle-free/README.html)
- [gvenzl/oracle-free images](https://hub.docker.com/r/gvenzl/oracle-free)
