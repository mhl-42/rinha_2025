---
title: Commit Oracle Transactions Explicitly
impact: CRITICAL
impactDescription: Prevents silently lost writes and partial units of work
tags: [oracle, oracledb, transactions, commit, rollback, locking]
---

# Commit Oracle Transactions Explicitly [CRITICAL]

## Description
Oracle is always in a transaction and python-oracledb does not autocommit. Unlike psycopg, it has no `conn.transaction()` block, and **leaving `with oracledb.connect(...)` or `with pool.acquire()` rolls back** anything not committed. Code ported from psycopg or sqlite3, where the `with` block commits, therefore loses every write without an error.

Keep the rule from [tx-explicit-boundaries](tx-explicit-boundaries.md): the service layer owns one transaction per unit of work and calls `commit()` once at the end; repositories never commit. A small context manager makes the boundary visible. Read-modify-write still belongs in one statement or under `SELECT ... FOR UPDATE` (see [tx-atomic-writes](tx-atomic-writes.md)).

## Bad Example
```python
def place_order(pool: oracledb.ConnectionPool, cmd: PlaceOrder) -> None:
    with pool.acquire() as conn:
        orders_repo.insert(conn, cmd)
        stock_repo.reserve(conn, cmd.items)
    # no commit: both writes are rolled back when the connection returns to the pool


def insert(conn: oracledb.Connection, cmd: PlaceOrder) -> None:
    conn.cursor().execute("INSERT INTO orders ...", {...})
    conn.commit()  # repository commits: the stock reservation can fail after the order is saved
```

## Good Example
```python
from collections.abc import Iterator
from contextlib import contextmanager


@contextmanager
def transaction(pool: oracledb.ConnectionPool) -> Iterator[oracledb.Connection]:
    with pool.acquire() as conn:
        try:
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise


def place_order(pool: oracledb.ConnectionPool, cmd: PlaceOrder) -> int:
    with transaction(pool) as conn:
        order_id = orders_repo.insert(conn, cmd)
        stock_repo.reserve(conn, cmd.items)
    return order_id  # emails and HTTP calls after the commit


def debit(conn: oracledb.Connection, wallet_id: int, amount: Decimal) -> Decimal:
    cur = conn.cursor()
    new_balance = cur.var(oracledb.DB_TYPE_NUMBER)
    cur.execute(
        """
        UPDATE wallets SET balance = balance - :amount
        WHERE id = :wallet_id AND balance >= :amount
        RETURNING balance INTO :new_balance
        """,
        {"amount": amount, "wallet_id": wallet_id, "new_balance": new_balance},
    )
    if cur.rowcount == 0:
        raise InsufficientFunds(wallet_id)
    return new_balance.getvalue()[0]  # DML RETURNING gives a list, one value per row
```

## Notes
- DDL (`CREATE`, `ALTER`, `TRUNCATE`, `GRANT`) commits the open transaction implicitly before and after it runs. Never mix DDL into a unit of work; pending DML is committed even if the next step fails.
- `conn.autocommit = True` is fine for scripts and read-only workers, but then each statement is its own transaction; do not turn it on to "fix" missing commits in services.
- Queue workers can claim rows with `SELECT ... FOR UPDATE SKIP LOCKED`; use `FOR UPDATE NOWAIT` (ORA-00054) or `WAIT n` instead of blocking forever on a locked row.
- Oracle reads are consistent at statement level by default (`READ COMMITTED`); use `SET TRANSACTION ISOLATION LEVEL SERIALIZABLE` only when needed, and be ready to retry ORA-08177.

## References
- [python-oracledb - Managing transactions](https://python-oracledb.readthedocs.io/en/latest/user_guide/txn_management.html)
- [Oracle - Transactions](https://docs.oracle.com/en/database/oracle/oracle-database/23/cncpt/transactions.html)
