---
title: Write Many Rows with executemany, unnest, or COPY
impact: HIGH
impactDescription: 10-100x faster bulk writes
tags: [queries, bulk-insert, executemany, copy, unnest, performance]
---

# Write Many Rows with executemany, unnest, or COPY [HIGH]

## Description
Calling `execute` once per row pays a round trip per row and, outside a transaction, a commit per row. Pick the bulk path by size:

| Rows | Use |
|------|-----|
| Up to a few thousand, or needs `RETURNING`/`ON CONFLICT` | One statement with `unnest(%s::type[], ...)` |
| Same, simplest code | `cursor.executemany(...)` (psycopg 3.1+ pipelines it into few round trips) |
| Tens of thousands or more | `COPY ... FROM STDIN` |

Wrap the batch in one transaction so it is all-or-nothing.

## Bad Example
```python
def save_readings(conn: Connection[TupleRow], readings: list[Reading]) -> None:
    for r in readings:  # one round trip and one commit per row
        conn.execute(
            "INSERT INTO readings (sensor_id, value, at) VALUES (%s, %s, %s)",
            (r.sensor_id, r.value, r.at),
        )
```

## Good Example
```python
def save_readings(conn: Connection[TupleRow], readings: Sequence[Reading]) -> None:
    with conn.transaction(), conn.cursor() as cur:
        cur.executemany(
            "INSERT INTO readings (sensor_id, value, at) VALUES (%s, %s, %s)",
            [(r.sensor_id, r.value, r.at) for r in readings],
        )


def upsert_prices(conn: Connection[TupleRow], prices: Mapping[str, Decimal]) -> None:
    # One statement, one round trip, works with ON CONFLICT and RETURNING
    conn.execute(
        """
        INSERT INTO prices (sku, price)
        SELECT * FROM unnest(%s::text[], %s::numeric[])
        ON CONFLICT (sku) DO UPDATE SET price = EXCLUDED.price
        """,
        (list(prices.keys()), list(prices.values())),
    )


def load_events(conn: Connection[TupleRow], events: Iterable[Event]) -> None:
    # Large loads: COPY streams rows without per-row statement overhead
    with conn.transaction(), conn.cursor() as cur:
        with cur.copy("COPY events (user_id, kind, at) FROM STDIN") as copy:
            for e in events:
                copy.write_row((e.user_id, e.kind, e.at))
```

## Notes
- `unnest` with several arrays must be in the `FROM` clause (`SELECT * FROM unnest(a, b)`), and every array needs an explicit cast so PostgreSQL knows the element types.
- `executemany(..., returning=True)` (psycopg 3.1+) keeps one result set per input row; read them by fetching and calling `cur.nextset()`. When you need the generated ids of many rows, the `unnest ... RETURNING` form is simpler.
- `COPY` does not support `ON CONFLICT`. For bulk upserts of large data, `COPY` into a temporary table, then `INSERT ... SELECT ... ON CONFLICT` from it.
- Feed `COPY` from a generator to keep memory flat; split very large loads into batches of e.g. 50k rows per transaction to bound lock time and WAL growth.
- For bulk updates, use `UPDATE t SET col = v.col FROM unnest(%s::int[], %s::text[]) AS v(id, col) WHERE t.id = v.id`.

## References
- [psycopg - executemany and pipeline mode](https://www.psycopg.org/psycopg3/docs/advanced/pipeline.html)
- [psycopg - Using COPY TO and COPY FROM](https://www.psycopg.org/psycopg3/docs/basic/copy.html)
- [PostgreSQL - Populating a database](https://www.postgresql.org/docs/current/populate.html)
