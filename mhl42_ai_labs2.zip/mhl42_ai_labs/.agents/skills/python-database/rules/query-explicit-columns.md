---
title: Select Named Columns into Typed Rows
impact: HIGH
impactDescription: Schema changes fail loudly instead of shifting tuple positions
tags: [queries, select-star, row-factory, dataclass, typing]
---

# Select Named Columns into Typed Rows [HIGH]

## Description
`SELECT *` couples the code to the current column order of the table. When a migration adds or reorders a column, tuple unpacking silently assigns values to the wrong fields, and the query transfers columns nobody uses (including large `text`/`jsonb` ones). Raw tuples and dicts in business code also lose type checking.

List the columns the code needs, and map rows to a frozen dataclass with psycopg's `class_row` row factory. A renamed or missing column then raises at the query, and mypy checks every use of the row.

## Bad Example
```python
def get_user(conn: Connection[TupleRow], user_id: int) -> tuple[Any, ...] | None:
    return conn.execute("SELECT * FROM users WHERE id = %s", (user_id,)).fetchone()


row = get_user(conn, 42)
user_id, email, name, created_at = row  # breaks or mislabels when a column is added
send_welcome(row[1])                    # which column is 1?
```

## Good Example
```python
from dataclasses import dataclass
from datetime import datetime

from psycopg.rows import class_row


@dataclass(frozen=True, slots=True)
class User:
    id: int
    email: str
    name: str
    created_at: datetime


def get_user(conn: Connection[TupleRow], user_id: int) -> User | None:
    with conn.cursor(row_factory=class_row(User)) as cur:
        return cur.execute(
            "SELECT id, email, name, created_at FROM users WHERE id = %s", (user_id,)
        ).fetchone()
```

## Notes
- `class_row` passes columns as keyword arguments, so column names (or `AS` aliases) must match the dataclass fields exactly.
- Use `dict_row` for ad-hoc scripts and `scalar_row` (psycopg 3.2+) for single-value queries such as `SELECT count(*)`.
- Map database types once: `numeric` → `Decimal`, `timestamptz` → aware `datetime`, `jsonb` → `dict` (or a Pydantic model validated in the repository).
- Use a dataclass for rows the code owns; reserve Pydantic for validating data that crosses a trust boundary (see the `python-coding-standards` skill, `validation-pydantic`).
- `SELECT *` is acceptable in interactive exploration and in `EXISTS (SELECT * ...)`, where no columns are returned.

## References
- [psycopg - Row factories](https://www.psycopg.org/psycopg3/docs/advanced/rows.html)
