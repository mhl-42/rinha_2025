---
title: Paginate with Keyset Conditions Instead of Large OFFSETs
impact: MEDIUM
impactDescription: Constant time per page instead of O(offset)
tags: [queries, pagination, keyset, cursor, offset, performance]
---

# Paginate with Keyset Conditions Instead of Large OFFSETs [MEDIUM]

## Description
`LIMIT 50 OFFSET 100000` makes PostgreSQL read and discard 100,000 rows before returning 50, so deep pages get slower linearly. When rows are inserted or deleted between requests, offsets also shift and pages skip or repeat rows.

Keyset (cursor) pagination remembers the sort key of the last row returned and asks for rows after it. With an index matching the `ORDER BY`, every page costs the same. Include a unique column (usually `id`) as a tie-breaker so the order is total.

## Bad Example
```python
def list_events(conn: Connection[TupleRow], page: int, size: int = 50) -> list[Event]:
    with conn.cursor(row_factory=class_row(Event)) as cur:
        return cur.execute(
            "SELECT id, kind, created_at FROM events ORDER BY created_at DESC "
            "LIMIT %s OFFSET %s",
            (size, page * size),  # page 2000 scans 100k rows
        ).fetchall()
```

## Good Example
```python
@dataclass(frozen=True)
class PageCursor:
    created_at: datetime
    id: int


def list_events(
    conn: Connection[TupleRow], after: PageCursor | None, size: int = 50
) -> tuple[list[Event], PageCursor | None]:
    with conn.cursor(row_factory=class_row(Event)) as cur:
        if after is None:
            cur.execute(
                "SELECT id, kind, created_at FROM events "
                "ORDER BY created_at DESC, id DESC LIMIT %s",
                (size,),
            )
        else:
            cur.execute(
                "SELECT id, kind, created_at FROM events "
                "WHERE (created_at, id) < (%s, %s) "
                "ORDER BY created_at DESC, id DESC LIMIT %s",
                (after.created_at, after.id, size),
            )
        rows = cur.fetchall()
    next_cursor = PageCursor(rows[-1].created_at, rows[-1].id) if len(rows) == size else None
    return rows, next_cursor

# Migration: CREATE INDEX CONCURRENTLY events_created_at_id_idx ON events (created_at DESC, id DESC);
```

## Notes
- The row comparison `(a, b) < (x, y)` uses the composite index only when the `ORDER BY` directions match the comparison (both `DESC` with `<`, both `ASC` with `>`).
- Encode the cursor for APIs (e.g. base64 of JSON) and treat it as opaque; validate it when decoding.
- Keyset pagination cannot jump to "page 37". If the UI needs page numbers, keep `OFFSET` but cap the maximum page, or paginate keyset-style and show "next/previous".
- `OFFSET` is fine for small, bounded result sets (admin lists of a few hundred rows).
- Avoid `SELECT count(*)` on every page of a large table just to show totals; use an estimate or omit it.

## References
- [PostgreSQL - LIMIT and OFFSET](https://www.postgresql.org/docs/current/queries-limit.html)
- [Use The Index, Luke - Paging Through Results](https://use-the-index-luke.com/no-offset)
