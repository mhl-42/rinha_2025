---
title: Fetch Related Rows in One Query
impact: HIGH
impactDescription: 1 round trip instead of N+1 (10-100x faster on lists)
tags: [queries, n-plus-one, performance, join, any]
---

# Fetch Related Rows in One Query [HIGH]

## Description
Running a query inside a loop over the results of another query (one query for the orders, then one per order for its items) costs one network round trip per row. With 200 orders that is 201 queries, and latency grows linearly with the page size. Fetch the related rows in a single query with a `JOIN`, or with `= ANY(%s)` on the collected ids, and group them in Python.

## Bad Example
```python
def list_orders_with_items(conn: Connection[TupleRow], customer_id: int) -> list[OrderView]:
    orders = orders_repo.list_by_customer(conn, customer_id)
    result = []
    for order in orders:
        items = conn.execute(  # one query per order
            "SELECT sku, qty, price FROM order_items WHERE order_id = %s", (order.id,)
        ).fetchall()
        result.append(OrderView(order=order, items=[Item(*row) for row in items]))
    return result
```

## Good Example
```python
def list_orders_with_items(conn: Connection[TupleRow], customer_id: int) -> list[OrderView]:
    orders = orders_repo.list_by_customer(conn, customer_id)
    with conn.cursor(row_factory=class_row(OrderItem)) as cur:
        items = cur.execute(
            "SELECT order_id, sku, qty, price FROM order_items WHERE order_id = ANY(%s)",
            ([order.id for order in orders],),
        ).fetchall()

    items_by_order: defaultdict[int, list[OrderItem]] = defaultdict(list)
    for item in items:
        items_by_order[item.order_id].append(item)
    return [OrderView(order=o, items=items_by_order[o.id]) for o in orders]


# Or let PostgreSQL build the nested shape in one query
ORDERS_WITH_ITEMS = """
    SELECT o.id, o.created_at,
           coalesce(json_agg(json_build_object('sku', i.sku, 'qty', i.qty))
                    FILTER (WHERE i.order_id IS NOT NULL), '[]') AS items
    FROM orders o
    LEFT JOIN order_items i ON i.order_id = o.id
    WHERE o.customer_id = %s
    GROUP BY o.id
    ORDER BY o.created_at DESC
"""
```

## Notes
- The same applies to calling a repository function inside a loop; add a batch variant (`get_many(conn, ids)`) instead.
- `= ANY(%s)` with a Python list is the psycopg 3 replacement for `IN %s`; an empty list is valid and matches nothing.
- Make sure the foreign key column used for the lookup (`order_items.order_id`) is indexed; PostgreSQL does not index foreign keys automatically.
- `json_agg` is convenient for read models sent straight to an API; for domain objects, the two-query version keeps rows typed.
- Spot N+1 in production with `pg_stat_statements` (a cheap query with a very high `calls` count) or by counting queries per request in tests.

## References
- [PostgreSQL - Array comparisons (ANY)](https://www.postgresql.org/docs/current/functions-comparisons.html#FUNCTIONS-COMPARISONS-ANY-SOME)
- [PostgreSQL - Aggregate functions (json_agg)](https://www.postgresql.org/docs/current/functions-aggregate.html)
