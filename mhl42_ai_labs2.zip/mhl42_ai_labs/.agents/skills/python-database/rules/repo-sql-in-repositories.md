---
title: Keep SQL in Repository Functions That Take the Connection
impact: MEDIUM
impactDescription: One place to read, review, and test every query
tags: [architecture, repository, data-access, dependency-injection]
---

# Keep SQL in Repository Functions That Take the Connection [MEDIUM]

## Description
Without an ORM, SQL needs a home. Put every query for an aggregate (orders, users) in one repository module whose functions take the connection as their first argument and return typed rows. Handlers and services call these functions and never contain SQL text.

Passing the connection in (instead of the repository opening its own) lets the service decide the transaction boundary and lets several repositories share one transaction (see [tx-explicit-boundaries](tx-explicit-boundaries.md)).

## Bad Example
```python
@app.post("/orders")
def create_order(payload: CreateOrder) -> dict[str, int]:
    with pool.connection() as conn:  # global pool, SQL in the HTTP handler
        conn.execute(f"INSERT INTO orders (customer_id) VALUES ({payload.customer_id})")
        order_id = conn.execute("SELECT max(id) FROM orders").fetchone()[0]  # race
        for item in payload.items:
            conn.execute("INSERT INTO order_items VALUES (%s, %s, %s)", (order_id, item.sku, item.qty))
    return {"id": order_id}
```

## Good Example
```python
# app/orders/repository.py
INSERT_ORDER = """
    INSERT INTO orders (customer_id, total)
    VALUES (%(customer_id)s, %(total)s)
    RETURNING id
"""


def insert(conn: Connection[TupleRow], customer_id: int, total: Decimal) -> int:
    row = conn.execute(INSERT_ORDER, {"customer_id": customer_id, "total": total}).fetchone()
    assert row is not None
    return row[0]


def insert_items(conn: Connection[TupleRow], order_id: int, items: Sequence[NewItem]) -> None:
    conn.execute(
        """
        INSERT INTO order_items (order_id, sku, qty)
        SELECT %s, * FROM unnest(%s::text[], %s::int[])
        """,
        (order_id, [i.sku for i in items], [i.qty for i in items]),
    )


# app/orders/service.py
def create_order(pool: ConnectionPool, cmd: CreateOrder) -> int:
    with pool.connection() as conn, conn.transaction():
        order_id = repository.insert(conn, cmd.customer_id, cmd.total)
        repository.insert_items(conn, order_id, cmd.items)
    return order_id


# app/api.py: the handler only translates HTTP <-> service
@app.post("/orders")
def post_order(payload: CreateOrder, pool: ConnectionPool = Depends(get_pool)) -> OrderCreated:
    return OrderCreated(id=create_order(pool, payload))
```

## Notes
- Plain module-level functions are enough; a class is useful only when the repository holds configuration (a schema name, a clock).
- Keep queries as module constants or in `.sql` files next to the module when they grow long; either way they stay greppable and reviewable.
- Repositories return domain dataclasses (see [query-explicit-columns](query-explicit-columns.md)), never cursors or raw tuples.
- Repositories do not commit, retry, or catch database errors to return defaults; translate specific errors (e.g. `psycopg.errors.UniqueViolation` → `EmailAlreadyRegistered`) and let the rest propagate.
- Test repositories against a real database (see [test-real-database](test-real-database.md)); test services with fakes of the repository functions when the database is not the subject of the test.

## References
- [Martin Fowler - Repository](https://martinfowler.com/eaaCatalog/repository.html)
- [psycopg - Basic module usage](https://www.psycopg.org/psycopg3/docs/basic/usage.html)
