---
title: Compose Dynamic SQL with psycopg.sql and Allowlists
impact: CRITICAL
impactDescription: Prevents injection through identifiers, sort keys, and filters
tags: [security, sql-injection, dynamic-sql, psycopg-sql, filters]
---

# Compose Dynamic SQL with psycopg.sql and Allowlists [CRITICAL]

## Description
Parameters can carry values only. When a table name, a column name, a sort direction, or the set of `WHERE` conditions is chosen at runtime, the structure of the SQL changes, and agents often fall back to f-strings. Instead:

1. Validate the runtime choice against an allowlist of known names (map API field names to columns).
2. Build the statement with `psycopg.sql`: `sql.Identifier` quotes names, `sql.SQL` holds trusted fragments, and values stay as `%s` parameters.

## Bad Example
```python
def search_products(conn: Connection[TupleRow], filters: dict[str, str], sort: str, desc: bool):
    query = "SELECT id, name, price FROM products WHERE 1=1"
    for column, value in filters.items():
        query += f" AND {column} = '{value}'"  # injection through keys and values
    query += f" ORDER BY {sort} {'DESC' if desc else 'ASC'}"  # injection through sort
    return conn.execute(query).fetchall()
```

## Good Example
```python
from psycopg import sql

FILTERABLE = {"category": "category", "brand": "brand_name"}  # API field -> column
SORTABLE = {"name": "name", "price": "price", "newest": "created_at"}


def search_products(
    conn: Connection[TupleRow], filters: Mapping[str, str], sort: str, desc: bool
) -> list[Product]:
    if sort not in SORTABLE:
        raise ValueError(f"cannot sort by {sort!r}; options: {sorted(SORTABLE)}")
    unknown = set(filters) - FILTERABLE.keys()
    if unknown:
        raise ValueError(f"cannot filter by {sorted(unknown)}")

    conditions = [
        sql.SQL("{} = %s").format(sql.Identifier(FILTERABLE[field])) for field in filters
    ]
    where = sql.SQL(" AND ").join(conditions) if conditions else sql.SQL("TRUE")
    query = sql.SQL(
        "SELECT id, name, price FROM products WHERE {where} ORDER BY {sort} {direction}"
    ).format(
        where=where,
        sort=sql.Identifier(SORTABLE[sort]),
        direction=sql.SQL("DESC" if desc else "ASC"),
    )
    with conn.cursor(row_factory=class_row(Product)) as cur:
        return cur.execute(query, list(filters.values())).fetchall()
```

## Notes
- `sql.Identifier` quotes names correctly but does not make an arbitrary name safe to expose; the allowlist decides *which* tables and columns a caller may reach.
- Keep the order of parameters aligned with the order of placeholders; for many optional filters, named placeholders (`%(category)s`) are less error-prone.
- `sql.Literal` embeds a value in the text; use it only where server-side parameters are not allowed (DDL, `SET`), never as a substitute for `%s`.
- `query.as_string(conn)` shows the final SQL for logging and debugging.
- Prefer one static query with optional predicates (`WHERE (%(brand)s::text IS NULL OR brand_name = %(brand)s)`) when there are only two or three filters; it keeps a single, reviewable statement.

## References
- [psycopg - sql module](https://www.psycopg.org/psycopg3/docs/api/sql.html)
