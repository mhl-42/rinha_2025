---
title: Pass Values as Bound Parameters
impact: CRITICAL
impactDescription: Prevents SQL injection and type/quoting bugs
tags: [security, sql-injection, parameters, psycopg]
---

# Pass Values as Bound Parameters [CRITICAL]

## Description
Every value that comes from outside the SQL text (user input, API payloads, file contents, even values from your own database) must reach the driver as a parameter, never be interpolated into the query string. With parameters, the driver sends the query and the values separately, so a value can never change the structure of the statement. String formatting also breaks on quotes, `None`, dates, and decimals, which parameters handle by type.

psycopg uses `%s` (positional) or `%(name)s` (named) placeholders for every type. They are not Python `%` formatting: the values go in the second argument to `execute`.

## Bad Example
```python
# SQL injection: email = "x' OR '1'='1" returns every user
conn.execute(f"SELECT id, email FROM users WHERE email = '{email}'")

# Same problem with %, .format(), and concatenation
conn.execute("SELECT id FROM users WHERE name = '%s'" % name)
conn.execute("DELETE FROM sessions WHERE user_id = " + str(user_id))

# Quoted placeholder: the driver adds the quotes itself
conn.execute("SELECT id FROM users WHERE email = '%s'", (email,))
```

## Good Example
```python
conn.execute("SELECT id, email FROM users WHERE email = %s", (email,))

conn.execute(
    "UPDATE users SET name = %(name)s, updated_at = now() WHERE id = %(id)s",
    {"name": name, "id": user_id},
)

# Lists become PostgreSQL arrays
conn.execute("SELECT id, email FROM users WHERE id = ANY(%s)", (user_ids,))

# LIKE: build the whole pattern in Python and pass it as one parameter
conn.execute("SELECT id FROM products WHERE name ILIKE %s", (f"%{term}%",))
```

## Notes
- The parameters argument is a sequence or mapping: a single value still needs a tuple, `(email,)`, not `(email)`.
- In a `LIKE` pattern, `%` and `_` inside user input act as wildcards; escape them (`term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")`) when the user means them literally.
- When the query has parameters, a literal `%` in the SQL text must be doubled (`%%`).
- Placeholders replace values only, never identifiers or keywords; for table/column names and `ORDER BY` direction see [sec-dynamic-sql](sec-dynamic-sql.md).
- Other drivers use other placeholder styles: asyncpg uses `$1, $2`; sqlite3 uses `?` or `:name`. The rule is the same.
- Ruff's `S608` flags string-built SQL; enable it with the rest of the `S` rules.

## References
- [psycopg - Passing parameters to SQL queries](https://www.psycopg.org/psycopg3/docs/basic/params.html)
- [OWASP - SQL Injection Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html)
