---
title: Test Data Access Against Real PostgreSQL with Per-Test Rollback
impact: MEDIUM
impactDescription: Tests catch SQL errors, constraint violations, and dialect differences
tags: [testing, pytest, testcontainers, fixtures, rollback]
---

# Test Data Access Against Real PostgreSQL with Per-Test Rollback [MEDIUM]

## Description
The SQL is the logic of a repository. Mocking the connection or cursor only checks that some string was sent, and swapping PostgreSQL for SQLite tests a different dialect (no `ANY(array)`, no `ON CONFLICT ... RETURNING` parity, different types and locking). Run repository tests against the same PostgreSQL major version as production.

Pattern: start one disposable PostgreSQL per test session (testcontainers, or a CI service container), apply the real migrations once, and give each test a connection inside a transaction that is always rolled back. Tests stay isolated and fast.

## Bad Example
```python
def test_insert_order(mocker: MockerFixture) -> None:
    conn = mocker.MagicMock()
    conn.execute.return_value.fetchone.return_value = (1,)

    order_id = repository.insert(conn, customer_id=7, total=Decimal("10.00"))

    assert order_id == 1  # passes even if the SQL has a typo or the column does not exist
```

## Good Example
```python
# tests/conftest.py
import psycopg
import pytest
from testcontainers.community.postgres import PostgresContainer  # testcontainers 4.15+
from yoyo import get_backend, read_migrations


@pytest.fixture(scope="session")
def database_url() -> Iterator[str]:
    with PostgresContainer("postgres:16-alpine") as pg:
        location = (
            f"{pg.username}:{pg.password}@"
            f"{pg.get_container_host_ip()}:{pg.get_exposed_port(5432)}/{pg.dbname}"
        )
        url = f"postgresql://{location}"
        backend = get_backend(f"postgresql+psycopg://{location}")  # yoyo: psycopg 3 driver
        with backend.lock():
            backend.apply_migrations(backend.to_apply(read_migrations("migrations")))
        yield url


@pytest.fixture
def conn(database_url: str) -> Iterator[psycopg.Connection[TupleRow]]:
    with psycopg.connect(database_url, autocommit=True) as conn:
        with conn.transaction(force_rollback=True):  # undo everything the test wrote
            yield conn


# tests/orders/test_repository.py
def test_insert_returns_id_of_persisted_order(conn: psycopg.Connection[TupleRow]) -> None:
    customer_id = make_customer(conn)

    order_id = repository.insert(conn, customer_id, Decimal("10.00"))

    assert repository.get(conn, order_id).total == Decimal("10.00")


def test_duplicate_email_raises_domain_error(conn: psycopg.Connection[TupleRow]) -> None:
    users.insert(conn, email="a@example.com")

    with pytest.raises(EmailAlreadyRegistered):
        users.insert(conn, email="a@example.com")
```

## Notes
- Code under test that opens its own `conn.transaction()` still works: inside the test transaction it becomes a savepoint, and everything is rolled back at the end.
- This requires the code under test to receive the connection (see [repo-sql-in-repositories](repo-sql-in-repositories.md)); code that grabs a global pool cannot share the test transaction.
- Older testcontainers versions expose the class as `testcontainers.postgres.PostgresContainer` (deprecated in 4.15); match the import to the installed version.
- testcontainers needs Docker. In CI without Docker-in-Docker, start PostgreSQL as a service container and read the URL from an environment variable in the `database_url` fixture.
- Running migrations in the session fixture doubles as a test that the migration set applies cleanly to an empty database.
- Tests that exercise concurrency, `COMMIT`-dependent behavior, or `CREATE INDEX CONCURRENTLY` cannot run inside a rolled-back transaction; give them a separate fixture that truncates the tables afterwards.
- Use factory helpers (`make_customer(conn, **overrides)`) for test data instead of shared seed files (see the `python-testing` skill, `fixture-factory`).

## References
- [testcontainers-python - PostgreSQL](https://testcontainers-python.readthedocs.io/en/latest/modules/postgres/README.html)
- [psycopg - Transaction contexts (force_rollback)](https://www.psycopg.org/psycopg3/docs/basic/transactions.html#transaction-contexts)
- [yoyo-migrations - Using yoyo from Python code](https://ollycope.com/software/yoyo/latest/#using-yoyo-from-python-code)
