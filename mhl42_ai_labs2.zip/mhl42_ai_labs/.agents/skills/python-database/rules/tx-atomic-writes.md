---
title: Do Read-Modify-Write in One Statement or Under a Row Lock
impact: CRITICAL
impactDescription: Prevents lost updates and duplicate rows under concurrency
tags: [transactions, concurrency, race-condition, upsert, locking]
---

# Do Read-Modify-Write in One Statement or Under a Row Lock [CRITICAL]

## Description
Reading a value, changing it in Python, and writing it back loses updates when two requests run at the same time: both read `balance = 100`, both write `90`, and one withdrawal disappears. "Check if it exists, then insert" has the same race and produces duplicates or unique-violation errors. A transaction alone does not prevent this at PostgreSQL's default `READ COMMITTED` isolation.

In order of preference:
1. Express the change as one SQL statement (`SET x = x - %s`, `INSERT ... ON CONFLICT`), with the business condition in the `WHERE` clause and `RETURNING` to get the result.
2. When the logic cannot be expressed in SQL, lock the rows first with `SELECT ... FOR UPDATE` inside a transaction.

## Bad Example
```python
def withdraw(conn: Connection[TupleRow], account_id: int, amount: Decimal) -> Decimal:
    with conn.transaction():
        (balance,) = conn.execute(
            "SELECT balance FROM accounts WHERE id = %s", (account_id,)
        ).fetchone()
        if balance < amount:
            raise InsufficientFunds(account_id)
        new_balance = balance - amount  # another request may have changed it already
        conn.execute("UPDATE accounts SET balance = %s WHERE id = %s", (new_balance, account_id))
        return new_balance


def add_tag(conn: Connection[TupleRow], name: str) -> int:
    row = conn.execute("SELECT id FROM tags WHERE name = %s", (name,)).fetchone()
    if row:
        return row[0]
    # two requests reach this line at once: duplicate or UniqueViolation
    return conn.execute("INSERT INTO tags (name) VALUES (%s) RETURNING id", (name,)).fetchone()[0]
```

## Good Example
```python
def withdraw(conn: Connection[TupleRow], account_id: int, amount: Decimal) -> Decimal:
    row = conn.execute(
        """
        UPDATE accounts SET balance = balance - %(amount)s
        WHERE id = %(id)s AND balance >= %(amount)s
        RETURNING balance
        """,
        {"amount": amount, "id": account_id},
    ).fetchone()
    if row is None:
        raise InsufficientFunds(account_id)  # or the account does not exist
    return row[0]


def add_tag(conn: Connection[TupleRow], name: str) -> int:
    row = conn.execute(
        """
        INSERT INTO tags (name) VALUES (%s)
        ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name
        RETURNING id
        """,
        (name,),
    ).fetchone()
    assert row is not None
    return row[0]


def apply_discount_rules(conn: Connection[TupleRow], order_id: int) -> None:
    # Complex Python logic: lock the row for the duration of the transaction
    with conn.transaction():
        order = orders_repo.get_for_update(conn, order_id)  # SELECT ... FOR UPDATE
        orders_repo.save_total(conn, order_id, pricing.apply_rules(order))
```

## Notes
- `ON CONFLICT DO NOTHING` returns no row when the row already exists; the `DO UPDATE SET name = EXCLUDED.name` form above always returns the id (at the cost of a no-op update).
- `ON CONFLICT (col)` requires a unique index or constraint on exactly those columns; add it in a migration. A unique constraint is also the only real guarantee against duplicates.
- Lock rows in a consistent order (e.g. `ORDER BY id ... FOR UPDATE`) when a transaction locks several, to avoid deadlocks.
- For job queues, `SELECT ... FOR UPDATE SKIP LOCKED LIMIT n` lets several workers claim different rows without blocking each other.
- `SERIALIZABLE` isolation also prevents these anomalies but requires retrying the whole transaction on `SerializationFailure`.

## References
- [PostgreSQL - INSERT ... ON CONFLICT](https://www.postgresql.org/docs/current/sql-insert.html#SQL-ON-CONFLICT)
- [PostgreSQL - Explicit Locking](https://www.postgresql.org/docs/current/explicit-locking.html)
