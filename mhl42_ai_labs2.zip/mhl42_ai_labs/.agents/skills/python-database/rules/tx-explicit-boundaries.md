---
title: One Explicit Transaction per Unit of Work
impact: CRITICAL
impactDescription: Prevents partial writes and long-held locks
tags: [transactions, atomicity, psycopg, autocommit, unit-of-work]
---

# One Explicit Transaction per Unit of Work [CRITICAL]

## Description
A business operation that writes more than one row or table (create an order *and* reserve stock) must commit or roll back as a whole. Make that boundary explicit and put it in the layer that knows what the unit of work is (the service or use case), not in each repository function.

Recommended setup with psycopg 3: open connections with `autocommit=True`, so single statements commit on their own and nothing stays "idle in transaction", and wrap every multi-statement unit of work in `with conn.transaction():`. The block commits on success and rolls back on any exception.

Keep transactions short: no HTTP calls, message publishing, or user waits inside. Locks taken by the writes are held until commit.

## Bad Example
```python
def place_order(conn: Connection[TupleRow], cmd: PlaceOrder) -> int:
    order_id = orders_repo.insert(conn, cmd)
    conn.commit()                       # order committed...
    stock_repo.reserve(conn, cmd.items)  # ...this fails: order exists without stock
    conn.commit()
    payment = payments_client.charge(cmd.card, cmd.total)  # HTTP call while holding locks
    orders_repo.mark_paid(conn, order_id, payment.id)
    conn.commit()
    return order_id


def insert(conn: Connection[TupleRow], cmd: PlaceOrder) -> int:
    row = conn.execute("INSERT INTO orders ... RETURNING id", ...).fetchone()
    conn.commit()  # repository decides transaction boundaries it cannot know about
    return row[0]
```

## Good Example
```python
def place_order(pool: ConnectionPool, payments: PaymentsClient, cmd: PlaceOrder) -> int:
    with pool.connection() as conn:
        with conn.transaction():
            order_id = orders_repo.insert(conn, cmd)
            stock_repo.reserve(conn, cmd.items)

        payment = payments.charge(cmd.card, cmd.total)  # outside: no locks held

        orders_repo.mark_paid(conn, order_id, payment.id)  # single statement, autocommit
    return order_id


def insert(conn: Connection[TupleRow], cmd: PlaceOrder) -> int:
    row = conn.execute(
        "INSERT INTO orders (customer_id, total) VALUES (%s, %s) RETURNING id",
        (cmd.customer_id, cmd.total),
    ).fetchone()
    assert row is not None
    return row[0]  # no commit: the caller owns the transaction
```

## Notes
- Create the pool with `kwargs={"autocommit": True}` (see [conn-pool](conn-pool.md)). Without autocommit, the first statement opens an implicit transaction and `conn.transaction()` inside it only creates a savepoint; the outer transaction still has to be committed.
- Nested `conn.transaction()` blocks become savepoints: an inner failure rolls back only the inner block if you catch the exception.
- When an external side effect must follow a commit reliably (send an email, publish an event), write it to an outbox table inside the same transaction and deliver it from a worker.
- Retry a whole unit of work, never a single statement in the middle of it, on serialization failures (`psycopg.errors.SerializationFailure`) and deadlocks (`psycopg.errors.DeadlockDetected`).
- For sqlite3 on Python 3.12+, connect with `autocommit=False` and use `with conn:` as the transaction block; it commits or rolls back but does not close the connection.

## References
- [psycopg - Transactions management](https://www.psycopg.org/psycopg3/docs/basic/transactions.html)
- [PostgreSQL - Transactions](https://www.postgresql.org/docs/current/tutorial-transactions.html)
