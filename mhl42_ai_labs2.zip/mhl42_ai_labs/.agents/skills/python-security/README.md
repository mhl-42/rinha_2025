# Python Security

Security practices for AI agents writing Python that handles untrusted input, secrets, files, subprocesses, and outbound HTTP calls.

## Overview

This skill provides 10 rules across 5 categories:

| Category | Prefix | Impact | Rules |
|----------|--------|--------|-------|
| Injection | `inj-` | CRITICAL | 2 |
| Secrets | `secret-` | CRITICAL | 1 |
| Cryptography | `crypto-` | CRITICAL | 2 |
| Files | `file-` | HIGH | 1 |
| HTTP Clients | `http-` | HIGH | 4 |

SQL injection is covered by the `python-database` skill.

## Structure

```
skills/python-security/
├── SKILL.md                  # Skill overview with quick reference
├── metadata.json             # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md                 # This file
├── evals/
│   ├── evals.json            # Output-quality test cases (prompt, expected output, assertions)
│   └── trigger_queries.json  # Should/should-not trigger queries for the description
└── rules/
    ├── _sections.md          # Section definitions
    ├── _template.md          # Rule template
    ├── inj-*.md              # Command injection and unsafe deserialization
    ├── secret-*.md           # Secrets management
    ├── crypto-*.md           # Password hashing and secure tokens
    ├── file-*.md             # Path traversal, uploads, archives
    └── http-*.md             # Outbound HTTP clients
```

## Rules

### Injection (CRITICAL)
- `inj-subprocess-no-shell` - Run subprocesses with argument lists, never through a shell
- `inj-unsafe-deserialization` - Never deserialize or evaluate untrusted data with code-executing formats

### Secrets (CRITICAL)
- `secret-no-hardcoding` - Load secrets from the environment into typed settings

### Cryptography (CRITICAL)
- `crypto-password-hashing` - Hash passwords with argon2, never with a plain digest
- `crypto-secure-random` - Generate tokens with secrets and compare them in constant time

### Files (HIGH)
- `file-path-traversal` - Resolve and confine user-supplied paths, uploads, and archives

### HTTP Clients (HIGH)
- `http-timeouts` - Set explicit timeouts and keep TLS verification on
- `http-client-reuse` - Reuse one configured client per service
- `http-retry-transient` - Retry only transient failures, with backoff and a limit
- `http-user-supplied-urls` - Validate user-supplied URLs before fetching them (SSRF)

## Usage

The agent loads this skill when its `description` matches the task (subprocesses, deserialization, secrets, passwords, tokens, file paths, uploads, outbound HTTP). Security issues often hide in tasks that never say "security", so the description lists those everyday tasks explicitly.

Many rules map to ruff's `S` (flake8-bandit) checks; enable them as described in the `python-tooling` skill.

## Contributing

To add a new rule:
1. Copy `rules/_template.md`
2. Use the appropriate prefix (`inj-`, `secret-`, `crypto-`, `file-`, `http-`)
3. Follow the existing format; name the matching ruff rule in Notes when one exists
4. Update `_sections.md`, `SKILL.md` (category table, and the "How to Use" trigger table if the rule has a clear trigger), and `metadata.json`
5. Run `uv run scripts/validate_skills.py` from the repository root
