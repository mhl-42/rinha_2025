---
name: python-security
description: Use this skill when writing or reviewing Python code that handles untrusted input, secrets, or calls to other systems — running subprocesses, deserializing data (pickle, YAML, XML), loading API keys and config, hashing passwords, generating tokens, handling file paths, uploads and archives, and calling HTTP APIs (timeouts, retries, client reuse, user-supplied URLs) — even if the user never mentions security, e.g. "call the payment API", "add a file upload endpoint", "store the API key", "run ffmpeg on the file". For SQL injection and database access use python-database. Not for code in other languages.
license: MIT
compatibility: Examples use the standard library plus httpx, tenacity, argon2-cffi, pydantic-settings, and defusedxml. Python 3.11+.
metadata:
  author: Python Best Practices
  version: "2.0.0"
---

# Python Security

Security practices for AI agents writing Python that touches untrusted input, secrets, the filesystem, subprocesses, and network services. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing code**: treat every value from a request, file, message, environment, or third-party API as untrusted until it is validated. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `subprocess.*(..., shell=True)`, `os.system`, `os.popen`, command strings built with f-strings | [inj-subprocess-no-shell](rules/inj-subprocess-no-shell.md) |
| `pickle.load(s)`, `yaml.load`, `eval`, `exec`, `xml.etree` on external data, `torch.load` | [inj-unsafe-deserialization](rules/inj-unsafe-deserialization.md) |
| API keys, passwords, or tokens as string literals; `os.environ[...]` scattered in code | [secret-no-hardcoding](rules/secret-no-hardcoding.md) |
| `hashlib.md5/sha1/sha256` applied to passwords | [crypto-password-hashing](rules/crypto-password-hashing.md) |
| `random` used for tokens, codes, or IDs; `==` comparing secrets or signatures | [crypto-secure-random](rules/crypto-secure-random.md) |
| A user-supplied filename or path joined to a directory; `extractall` | [file-path-traversal](rules/file-path-traversal.md) |
| `requests.*` / `httpx.*` without `timeout=`; `verify=False` | [http-timeouts](rules/http-timeouts.md) |
| `requests.get(...)` / `httpx.get(...)` at module level in a loop or per request | [http-client-reuse](rules/http-client-reuse.md) |
| Retry loops, `while True` around HTTP calls, retrying on every exception | [http-retry-transient](rules/http-retry-transient.md) |
| Fetching a URL that came from a user (webhooks, previews, imports) | [http-user-supplied-urls](rules/http-user-supplied-urls.md) |

### Review Checklist

- [ ] No shell strings, `eval`, or unsafe deserializers reach external input
- [ ] Secrets come from settings (`SecretStr`), never from literals, and never appear in logs, errors, or URLs
- [ ] Passwords use argon2; tokens use `secrets`; secret comparisons use `hmac.compare_digest`
- [ ] Every path built from input is resolved and checked against its base directory
- [ ] Every outbound HTTP call has a timeout, reuses a client, and retries only transient failures
- [ ] Run `ruff check --select S .` (flake8-bandit) and review every finding before finishing

## Gotchas

- `requests` has **no default timeout**: a call can hang forever. `httpx` defaults to 5 seconds, which is often too short for slow APIs and too long for health checks; set it explicitly.
- `yaml.load(data)` without `Loader=` and `yaml.load(data, Loader=yaml.Loader)` can execute arbitrary code; use `yaml.safe_load`.
- `pickle`, `shelve`, `marshal`, `joblib.load`, and `torch.load(..., weights_only=False)` execute code from the file; never use them on data an attacker could have touched.
- `Path(base) / user_input` with an absolute `user_input` discards `base` entirely: `Path("/srv/uploads") / "/etc/passwd"` is `/etc/passwd`.
- `tarfile.extractall()` without `filter="data"` can write outside the target directory (and create device files or symlinks); the safe default only arrives in Python 3.14.
- `random` is predictable; anything security-relevant (tokens, reset codes, session IDs) must use `secrets`.
- `a == b` on tokens or HMAC signatures leaks timing; use `hmac.compare_digest(a, b)`.
- `subprocess.run(["sh", "-c", cmd])` is `shell=True` in disguise.
- `pydantic.SecretStr` prints as `**********` in `str`, `repr`, and logs; the raw value comes only from `.get_secret_value()`. Call it at the point of use (building a header), never to log or store the value.
- An exception message or `logger.exception` that includes a request object can leak `Authorization` headers and cookies into logs.

## Categories

### Injection [CRITICAL]
Keep untrusted input from becoming code or commands.

| Rule | Description |
|------|-------------|
| [inj-subprocess-no-shell](rules/inj-subprocess-no-shell.md) | Run subprocesses with argument lists, never through a shell |
| [inj-unsafe-deserialization](rules/inj-unsafe-deserialization.md) | Never deserialize or evaluate untrusted data with code-executing formats |

### Secrets [CRITICAL]
Keep credentials out of code, logs, and errors.

| Rule | Description |
|------|-------------|
| [secret-no-hardcoding](rules/secret-no-hardcoding.md) | Load secrets from the environment into typed settings |

### Cryptography [CRITICAL]
Use purpose-built primitives instead of generic ones.

| Rule | Description |
|------|-------------|
| [crypto-password-hashing](rules/crypto-password-hashing.md) | Hash passwords with argon2, never with a plain digest |
| [crypto-secure-random](rules/crypto-secure-random.md) | Generate tokens with secrets and compare them in constant time |

### Files [HIGH]
Keep user-controlled paths inside their intended directory.

| Rule | Description |
|------|-------------|
| [file-path-traversal](rules/file-path-traversal.md) | Resolve and confine user-supplied paths, uploads, and archives |

### HTTP Clients [HIGH]
Call other services without hanging, leaking, or amplifying failures.

| Rule | Description |
|------|-------------|
| [http-timeouts](rules/http-timeouts.md) | Set explicit timeouts and keep TLS verification on |
| [http-client-reuse](rules/http-client-reuse.md) | Reuse one configured client per service |
| [http-retry-transient](rules/http-retry-transient.md) | Retry only transient failures, with backoff and a limit |
| [http-user-supplied-urls](rules/http-user-supplied-urls.md) | Validate user-supplied URLs before fetching them (SSRF) |

## Quick Reference

### Subprocesses and Deserialization
```python
subprocess.run(["ffmpeg", "-i", str(src), str(dst)], check=True, timeout=300)  # list, no shell

config = yaml.safe_load(text)
value = ast.literal_eval(user_text)  # literals only, never eval()
root = defusedxml.ElementTree.fromstring(xml_bytes)
```

### Secrets and Cryptography
```python
class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env")
    stripe_api_key: SecretStr

password_hash = PasswordHasher().hash(password)            # argon2id
reset_token = secrets.token_urlsafe(32)
if not hmac.compare_digest(received_signature, expected_signature):
    raise InvalidSignature()
```

### Paths
```python
def safe_path(base: Path, user_path: str) -> Path:
    base = base.resolve()
    target = (base / user_path).resolve()
    if not target.is_relative_to(base):
        raise PathTraversalError(user_path)
    return target

with tarfile.open(archive) as tar:
    tar.extractall(dest, filter="data")
```

### HTTP
```python
client = httpx.Client(
    base_url="https://api.payments.example",
    timeout=httpx.Timeout(10.0, connect=3.0),
    headers={"Authorization": f"Bearer {settings.payments_token.get_secret_value()}"},
)

@retry(
    retry=retry_if_exception(is_transient),
    stop=stop_after_attempt(4),
    wait=wait_exponential_jitter(initial=0.5, max=8),
    reraise=True,
)
def fetch_invoice(client: httpx.Client, invoice_id: str) -> Invoice:
    response = client.get(f"/invoices/{invoice_id}")
    response.raise_for_status()
    return Invoice.model_validate_json(response.content)
```

## See Also

These are separate skills; use them if installed.

- `python-database` - SQL injection, parameters, and dynamic SQL
- `python-coding-standards` - Pydantic validation at trust boundaries and exception handling
- `python-tooling` - Enabling ruff's `S` (bandit) rules in CI
