# Section Definitions

## Injection (inj)
**Impact:** CRITICAL

Keep untrusted input from becoming code or commands.
Covers subprocess calls without a shell and data-only deserialization (pickle, YAML, eval, XML, model files).

**Rules:**
- `inj-subprocess-no-shell` - Run subprocesses with argument lists, never through a shell
- `inj-unsafe-deserialization` - Never deserialize or evaluate untrusted data with code-executing formats

## Secrets (secret)
**Impact:** CRITICAL

Keep credentials out of code, logs, and errors.
Covers typed settings with `SecretStr`, `.env` handling, and keeping secrets out of URLs and logs.

**Rules:**
- `secret-no-hardcoding` - Load secrets from the environment into typed settings

## Cryptography (crypto)
**Impact:** CRITICAL

Use purpose-built primitives instead of generic ones.
Covers password hashing with argon2, token generation with `secrets`, and constant-time comparison.

**Rules:**
- `crypto-password-hashing` - Hash passwords with argon2, never with a plain digest
- `crypto-secure-random` - Generate tokens with secrets and compare them in constant time

## Files (file)
**Impact:** HIGH

Keep user-controlled paths inside their intended directory.
Covers path confinement, upload naming, and safe archive extraction.

**Rules:**
- `file-path-traversal` - Resolve and confine user-supplied paths, uploads, and archives

## HTTP Clients (http)
**Impact:** HIGH

Call other services without hanging, leaking, or amplifying failures.
Covers timeouts and TLS, client reuse, retries for transient failures, and SSRF.

**Rules:**
- `http-timeouts` - Set explicit timeouts and keep TLS verification on
- `http-client-reuse` - Reuse one configured client per service
- `http-retry-transient` - Retry only transient failures, with backoff and a limit
- `http-user-supplied-urls` - Validate user-supplied URLs before fetching them (SSRF)
