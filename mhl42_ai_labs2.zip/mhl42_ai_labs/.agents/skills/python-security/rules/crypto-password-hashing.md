---
title: Hash Passwords with argon2, Never with a Plain Digest
impact: CRITICAL
impactDescription: Leaked hashes cannot be cracked in bulk
tags: [security, passwords, argon2, hashing, authentication]
---

# Hash Passwords with argon2, Never with a Plain Digest [CRITICAL]

## Description
`hashlib.sha256(password)` (or md5/sha1, with or without a salt) is designed to be fast; a GPU tries billions of guesses per second, so a leaked table of such hashes is cracked within hours. Password hashing needs a deliberately slow, memory-hard algorithm with a per-password salt. Use argon2id via `argon2-cffi`: its `PasswordHasher` generates the salt, encodes the parameters into the hash string, and verifies in constant time.

## Bad Example
```python
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()  # fast, unsalted


def check_password(password: str, stored: str) -> bool:
    return hash_password(password) == stored  # timing leak, crackable hashes
```

## Good Example
```python
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError

_hasher = PasswordHasher()  # argon2id with the library's current recommended parameters


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(stored_hash: str, password: str) -> bool:
    try:
        return _hasher.verify(stored_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


def login(users: UserRepository, email: str, password: str) -> User:
    user = users.get_by_email(email)
    if user is None or not verify_password(user.password_hash, password):
        raise InvalidCredentials()  # same error for unknown email and wrong password
    if _hasher.check_needs_rehash(user.password_hash):
        users.update_password_hash(user.id, hash_password(password))  # upgrade parameters
    return user
```

## Notes
- `verify(hash, password)` takes the stored hash first; it raises on mismatch rather than returning `False`.
- `check_needs_rehash` lets you raise the cost parameters later and upgrade hashes on the next successful login.
- Hashing takes tens of milliseconds by design; in async code run it with `asyncio.to_thread` (see the `python-coding-standards` skill, `async-no-blocking-calls`).
- When the user does not exist, still spend comparable time (e.g. verify against a dummy hash) if account enumeration through timing matters for the product.
- Existing bcrypt or scrypt hashes are acceptable; migrate them to argon2 on login rather than forcing resets.
- Never log, return, or email passwords, and do not impose low maximum lengths (allow at least 64 characters).
- Ruff: `S324` flags md5/sha1; it does not catch `sha256` used for passwords, so review hashing of credentials manually.

## References
- [argon2-cffi documentation](https://argon2-cffi.readthedocs.io/)
- [OWASP - Password Storage Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html)
