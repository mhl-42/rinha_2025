---
title: Generate Tokens with secrets and Compare Them in Constant Time
impact: CRITICAL
impactDescription: Prevents guessable tokens and timing attacks
tags: [security, tokens, secrets, hmac, random]
---

# Generate Tokens with secrets and Compare Them in Constant Time [CRITICAL]

## Description
The `random` module is a Mersenne Twister: after observing enough outputs, an attacker can predict the next ones. Password reset tokens, session IDs, API keys, invite codes, and one-time codes generated with `random` (or `uuid1`, timestamps, or hashes of user data) can be guessed.

Use the `secrets` module for anything security-relevant, and compare secret values with `hmac.compare_digest`, which takes the same time whether the first or last character differs. Plain `==` returns early and leaks how many leading characters matched.

## Bad Example
```python
def make_reset_token() -> str:
    return "".join(random.choices(string.ascii_letters, k=20))  # predictable


def make_otp() -> str:
    return str(random.randint(100000, 999999))


def verify_webhook(body: bytes, signature: str) -> bool:
    expected = hmac.new(WEBHOOK_SECRET, body, hashlib.sha256).hexdigest()
    return expected == signature  # timing leak
```

## Good Example
```python
import hashlib
import hmac
import secrets


def make_reset_token() -> str:
    return secrets.token_urlsafe(32)  # 256 bits, URL-safe


def make_otp() -> str:
    return f"{secrets.randbelow(1_000_000):06d}"


def verify_webhook(secret: bytes, body: bytes, signature: str) -> bool:
    expected = hmac.new(secret, body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)
```

## Notes
- Store only a hash of long-lived tokens (API keys, reset tokens): `hashlib.sha256(token.encode()).hexdigest()` is fine here because the token is already high-entropy, unlike a password. Look up by hash, then show the raw token to the user once.
- Give tokens an expiry and make one-time tokens single-use (delete or mark used in the same transaction that consumes them).
- Short codes (6-digit OTPs) need rate limiting and attempt limits; their entropy is low by design.
- `uuid.uuid4()` uses `os.urandom` and is fine as an unguessable ID; `uuid1` (time + MAC address) is not.
- `random` remains correct for simulations, sampling, and tests (see the `python-data-science` skill for seeded generators).
- Ruff: `S311` flags `random` in security-sensitive contexts.

## References
- [secrets - Generate secure random numbers](https://docs.python.org/3/library/secrets.html)
- [hmac.compare_digest](https://docs.python.org/3/library/hmac.html#hmac.compare_digest)
