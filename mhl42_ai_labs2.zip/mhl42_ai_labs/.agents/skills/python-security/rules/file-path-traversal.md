---
title: Resolve and Confine User-Supplied Paths, Uploads, and Archives
impact: HIGH
impactDescription: Prevents reading or overwriting files outside the intended directory
tags: [security, path-traversal, uploads, tarfile, zipfile, pathlib]
---

# Resolve and Confine User-Supplied Paths, Uploads, and Archives [HIGH]

## Description
A filename from a request, form upload, or archive entry can contain `../`, an absolute path, or a symlink. Joined naively to a base directory, it reads `/etc/passwd` or overwrites application files. `Path(base) / name` does not protect you: an absolute `name` replaces `base` entirely.

Resolve the final path (which collapses `..` and follows symlinks) and check that it is still inside the resolved base directory. For uploads, do not reuse the client's filename at all: generate a name and keep the original only as metadata. For tar archives, always pass `filter="data"`.

## Bad Example
```python
@app.get("/files/{name}")
def download(name: str) -> FileResponse:
    return FileResponse(f"/srv/files/{name}")  # name = "../../etc/passwd"


@app.post("/upload")
async def upload(file: UploadFile) -> None:
    dest = Path("/srv/uploads") / file.filename  # "/etc/cron.d/x" or "../app/main.py"
    dest.write_bytes(await file.read())


def unpack(archive: Path, dest: Path) -> None:
    with tarfile.open(archive) as tar:
        tar.extractall(dest)  # members like "../../home/app/.bashrc" or symlinks escape dest
```

## Good Example
```python
FILES_DIR = Path("/srv/files").resolve()
UPLOADS_DIR = Path("/srv/uploads").resolve()
ALLOWED_TYPES = {"image/png": ".png", "image/jpeg": ".jpg", "application/pdf": ".pdf"}


def confined(base: Path, user_path: str) -> Path:
    target = (base / user_path).resolve()
    if not target.is_relative_to(base):
        raise PathTraversalError(user_path)
    return target


@app.get("/files/{name}")
def download(name: str) -> FileResponse:
    path = confined(FILES_DIR, name)
    if not path.is_file():
        raise HTTPException(status_code=404)
    return FileResponse(path)


@app.post("/upload")
async def upload(file: UploadFile) -> StoredFile:
    suffix = ALLOWED_TYPES.get(file.content_type or "")
    if suffix is None:
        raise HTTPException(status_code=415)
    stored_name = f"{uuid.uuid4().hex}{suffix}"  # never the client's filename
    (UPLOADS_DIR / stored_name).write_bytes(await file.read())
    return StoredFile(id=stored_name, original_name=file.filename)


def unpack(archive: Path, dest: Path) -> None:
    with tarfile.open(archive) as tar:
        tar.extractall(dest, filter="data")  # rejects absolute paths, "..", links outside dest, devices
```

## Notes
- `resolve()` must happen on both sides: compare the resolved target with the resolved base, or symlinks and `..` in the base path break the check.
- `Path.is_relative_to` is a path-component check; do not use `str(target).startswith(str(base))`, which accepts `/srv/files-secret` for base `/srv/files`.
- The `content_type` of an upload is client-supplied; for anything parsed later (images, PDFs), verify the content (e.g. open it with the image library) and limit the size before reading it all into memory.
- `zipfile.ZipFile.extractall` strips absolute paths and `..` components, but a zip bomb can still fill the disk; check `sum(info.file_size for info in zf.infolist())` before extracting.
- `filter="data"` is the default only from Python 3.14; on 3.12-3.13 omitting it emits a `DeprecationWarning` and keeps the unsafe behavior.
- Serve user uploads from a separate domain or with `Content-Disposition: attachment` so uploaded HTML cannot run scripts on the main site.
- Ruff: `S202` flags `tarfile.extractall` without a safe filter.

## References
- [tarfile - Extraction filters](https://docs.python.org/3/library/tarfile.html#tarfile-extraction-filter)
- [OWASP - File Upload Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/File_Upload_Cheat_Sheet.html)
