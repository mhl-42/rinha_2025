---
title: Reuse One Configured Client per Service
impact: HIGH
impactDescription: Connection reuse and consistent config (2-10x lower latency per call)
tags: [http, httpx, connection-pooling, client, dependency-injection]
---

# Reuse One Configured Client per Service [HIGH]

## Description
Module-level helpers like `httpx.get(...)` and `requests.get(...)` create a new connection pool for every call: a fresh TCP connection and TLS handshake each time, which often costs more than the request itself, and under load exhausts sockets. They also scatter configuration (base URL, auth header, timeouts) across call sites.

Create one `httpx.Client` (or `AsyncClient`) per external service at the composition root, configured with base URL, timeouts, and auth, and inject it. Close it at shutdown. Wrap it in a small typed client class so the rest of the code calls `payments.charge(...)`, not raw HTTP.

## Bad Example
```python
def get_rate(currency: str) -> Decimal:
    # new connection + TLS handshake per call, config repeated everywhere
    response = httpx.get(
        f"https://api.rates.example/v1/rates/{currency}",
        headers={"Authorization": f"Bearer {os.environ['RATES_TOKEN']}"},
        timeout=5,
    )
    return Decimal(response.json()["rate"])
```

## Good Example
```python
class RatesClient:
    def __init__(self, http: httpx.Client) -> None:
        self._http = http

    def get_rate(self, currency: str) -> Decimal:
        response = self._http.get(f"/v1/rates/{currency}")
        response.raise_for_status()
        return RateResponse.model_validate_json(response.content).rate


def create_rates_client(settings: Settings) -> RatesClient:
    http = httpx.Client(
        base_url="https://api.rates.example",
        headers={"Authorization": f"Bearer {settings.rates_token.get_secret_value()}"},
        timeout=httpx.Timeout(5.0, connect=2.0),
        limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
    )
    return RatesClient(http)


# Async apps: create AsyncClient in the lifespan and close it on shutdown
@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    async with httpx.AsyncClient(base_url=settings.rates_url, timeout=5.0) as http:
        app.state.rates = AsyncRatesClient(http)
        yield
```

## Notes
- One client per *service*, not one global client for everything: base URL, auth, timeouts, and limits differ per dependency.
- Clients are safe to share across threads (`Client`) or tasks (`AsyncClient`); never share an `AsyncClient` across event loops.
- Validate responses with a Pydantic model at this boundary; the rest of the code receives typed values.
- In tests, inject an `httpx.Client(transport=httpx.MockTransport(handler))` to fake the remote service without patching (see the `python-testing` skill, `mock-boundaries`).
- Do not create a client inside a request handler "to be safe"; that recreates the pool per request.

## References
- [httpx - Clients](https://www.python-httpx.org/advanced/clients/)
- [httpx - Resource limits](https://www.python-httpx.org/advanced/resource-limits/)
