---
title: Retry Only Transient Failures, with Backoff and a Limit
impact: HIGH
impactDescription: Recovers from blips without hammering a struggling service or duplicating writes
tags: [http, retries, backoff, tenacity, idempotency, resilience]
---

# Retry Only Transient Failures, with Backoff and a Limit [HIGH]

## Description
Retries help with failures that are likely to succeed on the next attempt: connection errors, timeouts, `429 Too Many Requests`, `502`/`503`/`504`. Retrying anything else (a `400`, a `401`, a bug in your code) only delays the error and multiplies load. Retrying immediately and forever turns a brief outage into a self-inflicted one, as every client hammers the recovering service at once.

Use tenacity with: a predicate that selects transient errors, exponential backoff with jitter, a maximum number of attempts (and optionally a total time budget), and `reraise=True` so the original exception surfaces. Only retry requests that are safe to repeat.

## Bad Example
```python
def send_invoice(client: httpx.Client, invoice: Invoice) -> None:
    while True:  # forever, no backoff
        try:
            client.post("/invoices", json=invoice.model_dump(mode="json")).raise_for_status()
            return
        except Exception:  # retries 400s, auth errors, and bugs too
            time.sleep(1)
```

## Good Example
```python
import logging

import httpx
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception,
    stop_after_attempt,
    stop_after_delay,
    wait_exponential_jitter,
)

logger = logging.getLogger(__name__)
RETRYABLE_STATUS = {429, 502, 503, 504}


def is_transient(exc: BaseException) -> bool:
    if isinstance(exc, httpx.TransportError):  # connect/read timeouts, connection resets
        return True
    return isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code in RETRYABLE_STATUS


@retry(
    retry=retry_if_exception(is_transient),
    stop=stop_after_attempt(5) | stop_after_delay(30),
    wait=wait_exponential_jitter(initial=0.5, max=10),
    before_sleep=before_sleep_log(logger, logging.WARNING),
    reraise=True,
)
def send_invoice(client: httpx.Client, invoice: Invoice) -> None:
    response = client.post(
        "/invoices",
        json=invoice.model_dump(mode="json"),
        headers={"Idempotency-Key": str(invoice.id)},  # server deduplicates repeated POSTs
    )
    response.raise_for_status()
```

## Notes
- `GET`, `PUT`, and `DELETE` are idempotent by definition; `POST` is safe to retry only with an idempotency key the server honors, because a timeout does not tell you whether the first attempt was processed.
- Honor `Retry-After` on `429`/`503` when the API sends it (a custom `wait` callable can read it from the exception's response).
- Retry at one layer only. A retrying client inside a retrying job inside a retrying queue multiplies attempts (5 × 5 × 5 = 125 calls).
- `httpx.HTTPTransport(retries=n)` retries only failed connection attempts, which is a useful cheap layer, but it does not cover timeouts during the response or 5xx statuses.
- For async functions the same `@retry` decorator works and sleeps with `asyncio.sleep`.
- After the final attempt, let the exception propagate (or translate it with `raise ... from exc`); do not return a default value (see the `python-coding-standards` skill, `error-no-silent-exceptions`).

## References
- [tenacity documentation](https://tenacity.readthedocs.io/)
- [AWS Architecture Blog - Exponential Backoff and Jitter](https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/)
