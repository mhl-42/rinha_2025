---
title: Set Explicit Timeouts and Keep TLS Verification On
impact: HIGH
impactDescription: A slow dependency cannot hang workers; traffic cannot be intercepted
tags: [http, timeouts, httpx, requests, tls, resilience]
---

# Set Explicit Timeouts and Keep TLS Verification On [HIGH]

## Description
`requests` has no default timeout: if the remote server accepts the connection and never answers, the call blocks forever, and each stuck call holds a worker thread until the service stops responding. `httpx` defaults to 5 seconds for every phase, which is arbitrary for any real API. Choose the timeout per dependency, based on its expected latency, and set it on the client.

Disabling certificate verification (`verify=False`) to "fix" an SSL error makes every request open to interception. Fix the trust store instead.

## Bad Example
```python
response = requests.get(f"{REPORTS_API}/reports/{report_id}")  # may hang forever

response = httpx.post(
    "https://internal-billing/charge",
    json=payload,
    verify=False,  # "SSL error" silenced; man-in-the-middle possible
)
```

## Good Example
```python
billing = httpx.Client(
    base_url="https://billing.internal",
    timeout=httpx.Timeout(10.0, connect=3.0),  # 3 s to connect, 10 s for read/write/pool
    verify="/etc/ssl/certs/internal-ca.pem",   # trust the internal CA explicitly
)

reports = httpx.Client(
    base_url=settings.reports_api,
    timeout=httpx.Timeout(60.0, connect=5.0),  # slow endpoint: longer read, short connect
)

response = billing.post("/charge", json=payload)
response.raise_for_status()
```

## Notes
- Connect timeouts should be short (1-5 s): a host that does not accept a connection quickly is down. Read timeouts depend on the endpoint.
- A timeout bounds one network operation, not the whole call. To cap total time including retries, use the retry policy's overall stop condition (see [http-retry-transient](http-retry-transient.md)) or `asyncio.timeout()` around the async call.
- With `requests`, pass `timeout=(connect, read)` on every call; it cannot be set once on a `Session` without a custom adapter, which is one reason to prefer `httpx` in new code.
- Call `response.raise_for_status()` (or check `status_code`) before parsing; a 500 HTML error page passed to a JSON parser produces a confusing error far from the cause.
- For corporate proxies that re-sign TLS, point `verify=` (or `SSL_CERT_FILE`) at the corporate CA bundle instead of disabling verification.
- Ruff: `S113` (request without timeout) and `S501` (`verify=False`).

## References
- [httpx - Timeouts](https://www.python-httpx.org/advanced/timeouts/)
- [httpx - SSL](https://www.python-httpx.org/advanced/ssl/)
- [requests - Timeouts](https://requests.readthedocs.io/en/latest/user/advanced/#timeouts)
