---
title: Validate User-Supplied URLs Before Fetching Them (SSRF)
impact: HIGH
impactDescription: Prevents attackers from using your server to reach internal services
tags: [security, ssrf, http, urls, webhooks]
---

# Validate User-Supplied URLs Before Fetching Them (SSRF) [HIGH]

## Description
When the server fetches a URL the user provided (link previews, "import from URL", webhook targets, avatar URLs), an attacker can point it at addresses only the server can reach: `http://169.254.169.254/` (cloud metadata with credentials), `http://localhost:6379`, internal admin panels, or private IP ranges. The response, or even just the timing, leaks internal data. This is server-side request forgery (SSRF).

Before fetching: allow only `https` (and `http` if required), resolve the hostname, reject non-global IP addresses, connect to the IP you checked, and do not follow redirects automatically (each redirect target needs the same check). Limit response size and time.

## Bad Example
```python
@app.post("/preview")
def preview(url: str) -> Preview:
    response = requests.get(url, timeout=10, allow_redirects=True)  # any scheme/host, redirects
    return Preview.from_html(response.text)  # unbounded size
```

## Good Example
```python
import ipaddress
import socket
from urllib.parse import urlsplit

MAX_BYTES = 2_000_000


class UnsafeURLError(ValueError):
    pass


def check_public_url(url: str) -> None:
    parts = urlsplit(url)
    if parts.scheme != "https" or not parts.hostname:
        raise UnsafeURLError(f"only https URLs are allowed: {url!r}")
    infos = socket.getaddrinfo(parts.hostname, parts.port or 443, type=socket.SOCK_STREAM)
    addresses = {ipaddress.ip_address(info[4][0]) for info in infos}
    if not addresses or not all(addr.is_global for addr in addresses):
        raise UnsafeURLError(f"{parts.hostname} resolves to a non-public address")


def fetch_preview(client: httpx.Client, url: str) -> Preview:
    check_public_url(url)
    with client.stream("GET", url, follow_redirects=False) as response:
        if response.is_redirect:
            raise UnsafeURLError("redirects are not followed; submit the final URL")
        response.raise_for_status()
        body = bytearray()
        for chunk in response.iter_bytes():
            body.extend(chunk)
            if len(body) > MAX_BYTES:
                raise UnsafeURLError("response too large")
    return Preview.from_html(body.decode(response.encoding or "utf-8", errors="replace"))
```

## Notes
- Checking the IP and then letting the HTTP client resolve the name again leaves a DNS-rebinding gap (the name can resolve to a public IP for the check and a private one for the request). Close it by sending egress through a proxy that enforces the policy, or with a transport that connects to the validated IP; for high-risk features, an egress proxy is the robust fix.
- `ipaddress.ip_address(...).is_global` rejects private, loopback, link-local (`169.254.0.0/16`, the cloud metadata range), and reserved addresses for both IPv4 and IPv6.
- If you follow redirects manually, re-run the check on every `Location` and cap the number of hops.
- For webhooks, validate the target when it is registered *and* when it is called; DNS can change in between.
- Network-level controls (no route from app servers to metadata endpoints, IMDSv2 on AWS) are the second layer; keep both.

## References
- [OWASP - SSRF Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html)
- [ipaddress - is_global](https://docs.python.org/3/library/ipaddress.html#ipaddress.IPv4Address.is_global)
