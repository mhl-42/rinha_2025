---
title: Run Subprocesses with Argument Lists, Never Through a Shell
impact: CRITICAL
impactDescription: Prevents command injection
tags: [security, injection, subprocess, shell]
---

# Run Subprocesses with Argument Lists, Never Through a Shell [CRITICAL]

## Description
With `shell=True`, `os.system`, or `os.popen`, the command string is parsed by `/bin/sh` (or `cmd.exe`), so any `;`, `&&`, `|`, `$(...)`, or backtick inside a filename or user value runs as a new command. Pass the program and its arguments as a list instead: the OS receives each argument as-is, and no shell is involved.

Also set `check=True` so failures raise, and `timeout=` so a stuck process cannot hang the caller.

## Bad Example
```python
def make_thumbnail(src: str, dst: str) -> None:
    # src = "a.mp4; rm -rf ~" runs the second command
    os.system(f"ffmpeg -i {src} -vf scale=320:-1 {dst}")


def git_log(repo: str, author: str) -> str:
    return subprocess.check_output(
        f"git -C {repo} log --author='{author}'", shell=True, text=True
    )
```

## Good Example
```python
def make_thumbnail(src: Path, dst: Path) -> None:
    subprocess.run(
        ["ffmpeg", "-nostdin", "-i", str(src), "-vf", "scale=320:-1", str(dst)],
        check=True,
        timeout=300,
        capture_output=True,
    )


def git_log(repo: Path, author: str) -> str:
    result = subprocess.run(
        ["git", "-C", str(repo), "log", f"--author={author}", "--"],
        check=True,
        timeout=30,
        capture_output=True,
        text=True,
    )
    return result.stdout
```

## Notes
- An argument that starts with `-` can still be read as an option by the target program (`--upload-pack=...` in git). Put user values after `--` when the program supports it, or reject values starting with `-`.
- Use an absolute path or `shutil.which("ffmpeg")` once at startup when `PATH` may be attacker-influenced.
- If shell features are truly required (pipes), build the pipeline with two `subprocess.Popen` calls, or quote every value with `shlex.quote` and document why.
- `["sh", "-c", command]` and `["bash", "-c", ...]` reintroduce the shell; the same rule applies.
- Do not pass secrets as command-line arguments (they appear in `ps`); use environment variables via `env=` or stdin.
- In async code use `asyncio.create_subprocess_exec` (not `_shell`).
- Ruff: `S602` (`shell=True`), `S605` (`os.system`), and `S603`/`S607` (review untrusted input and partial paths).

## References
- [subprocess - Security considerations](https://docs.python.org/3/library/subprocess.html#security-considerations)
- [OWASP - OS Command Injection Defense](https://cheatsheetseries.owasp.org/cheatsheets/OS_Command_Injection_Defense_Cheat_Sheet.html)
