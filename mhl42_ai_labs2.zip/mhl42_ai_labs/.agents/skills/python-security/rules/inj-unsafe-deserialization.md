---
title: Never Deserialize or Evaluate Untrusted Data with Code-Executing Formats
impact: CRITICAL
impactDescription: Prevents remote code execution
tags: [security, deserialization, pickle, yaml, eval, xml]
---

# Never Deserialize or Evaluate Untrusted Data with Code-Executing Formats [CRITICAL]

## Description
Some Python formats can run code while loading. `pickle.loads` calls whatever `__reduce__` the payload names (for example `os.system`); `yaml.load` with the full loader constructs arbitrary Python objects; `eval`/`exec` run any expression. If an attacker can influence the bytes (an upload, a cache, a queue message, a model file from the internet), loading them is remote code execution.

Use data-only formats and loaders for anything that crosses a trust boundary:

| Instead of | Use |
|------------|-----|
| `pickle`, `shelve`, `marshal`, `joblib`, `dill` | JSON + Pydantic model validation |
| `yaml.load` / `yaml.unsafe_load` | `yaml.safe_load` |
| `eval(text)` | `ast.literal_eval(text)` or a real parser |
| `xml.etree`, `lxml` on external XML | `defusedxml` |
| `torch.load(..., weights_only=False)` | `weights_only=True` (default in PyTorch 2.6+) or `safetensors` |

## Bad Example
```python
@app.post("/import")
async def import_job(request: Request) -> None:
    job = pickle.loads(await request.body())  # attacker-controlled bytes run code
    queue.put(job)


def load_rules(path: Path) -> dict[str, Any]:
    return yaml.load(path.read_text(), Loader=yaml.Loader)  # builds arbitrary objects


def parse_filter(expr: str) -> Any:
    return eval(expr)  # "__import__('os').system('...')"
```

## Good Example
```python
class ImportJob(BaseModel):
    source: HttpUrl
    format: Literal["csv", "json"]


@app.post("/import")
async def import_job(request: Request) -> None:
    job = ImportJob.model_validate_json(await request.body())
    queue.put(job.model_dump_json())


def load_rules(path: Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text())
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected a mapping at the top level")
    return data


def parse_filter(expr: str) -> list[int]:
    value = ast.literal_eval(expr)  # literals only: numbers, strings, lists, dicts...
    if not isinstance(value, list) or not all(isinstance(v, int) for v in value):
        raise ValueError("expected a list of integers")
    return value
```

## Notes
- `pickle` is acceptable only for data your own process wrote to storage nobody else can write (a local cache file with correct permissions). Signing a pickle with HMAC helps only if the key never leaves the trusted side.
- `ast.literal_eval` is safe from code execution, but very large or deeply nested input can still exhaust memory or recursion; limit input size first.
- `defusedxml` blocks entity-expansion ("billion laughs") and external-entity attacks; it is a drop-in for `xml.etree.ElementTree` (`defusedxml.ElementTree.fromstring`).
- Templates are code too: never render user input as a Jinja2 template (`Template(user_text).render()`); pass it as a variable to a fixed template, with autoescaping on for HTML.
- Ruff: `S301` (pickle), `S506` (unsafe yaml), `S307` (eval), `S313`-`S320` (XML).

## References
- [pickle - Security warning](https://docs.python.org/3/library/pickle.html)
- [PyYAML - yaml.load deprecation](https://github.com/yaml/pyyaml/wiki/PyYAML-yaml.load(input)-Deprecation)
- [defusedxml](https://github.com/tiran/defusedxml)
