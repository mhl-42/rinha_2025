---
title: Load Secrets from the Environment into Typed Settings
impact: CRITICAL
impactDescription: Keeps credentials out of git history, logs, and error reports
tags: [security, secrets, configuration, pydantic-settings, logging]
---

# Load Secrets from the Environment into Typed Settings [CRITICAL]

## Description
A secret committed to the repository stays in git history forever and reaches every clone, CI log, and fork; rotating it is the only fix. Secrets must come from the environment (or a secret manager that injects them), be validated once at startup, and stay masked everywhere except the single place that uses them.

Default: a `pydantic-settings` `BaseSettings` class with `SecretStr` fields, instantiated once at the composition root and passed in. A missing secret fails at startup with a clear error instead of at the first request.

## Bad Example
```python
STRIPE_KEY = "sk_live_51H..."  # in git history forever

def charge(amount: int) -> None:
    api_key = os.environ.get("STRIPE_KEY", "sk_test_default")  # silent fallback in prod
    logger.info("charging with key %s", api_key)               # secret in logs
    requests.post(f"https://api.stripe.com/v1/charges?key={api_key}", timeout=10)  # in URLs/proxies
```

## Good Example
```python
from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

    database_url: SecretStr
    stripe_api_key: SecretStr
    stripe_base_url: str = "https://api.stripe.com"


def create_payments_client(settings: Settings) -> httpx.Client:
    return httpx.Client(
        base_url=settings.stripe_base_url,
        headers={"Authorization": f"Bearer {settings.stripe_api_key.get_secret_value()}"},
        timeout=10.0,
    )


settings = Settings()  # composition root only; raises ValidationError if a secret is missing
logger.info("settings loaded: %s", settings)  # stripe_api_key=SecretStr('**********')
```

```gitignore
# .gitignore
.env
.env.*
!.env.example
```

## Notes
- Commit a `.env.example` with every variable name and fake values, so new environments know what to set.
- No defaults for secrets: a default turns a missing production secret into silently using the wrong credential.
- Send secrets in headers or request bodies, never in URLs; URLs end up in access logs, proxies, and browser history.
- Error reporting tools (Sentry and similar) capture local variables and headers; configure their scrubbing for `Authorization`, cookies, and fields named like `*_key`, `*_token`, `password`.
- If a secret was committed, rotate it first; rewriting history does not un-leak it.
- Add a secret scanner to pre-commit or CI (for example `gitleaks`) to block new leaks.
- Ruff's `S105`-`S107` only flag literals assigned to password-like names (`password`, `secret`, `token`); `STRIPE_KEY = "sk_live_..."` passes unnoticed. A secret scanner is what actually catches leaked keys.

## References
- [pydantic-settings](https://docs.pydantic.dev/latest/concepts/pydantic_settings/)
- [OWASP - Secrets Management Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Secrets_Management_Cheat_Sheet.html)
