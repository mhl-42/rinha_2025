---
name: python-testing
description: Use this skill when writing, reviewing, or fixing Python tests with pytest — test structure and naming, fixtures and conftest.py, parametrize, mocking and monkeypatch — including requests like "add tests for this", "increase coverage", or "this test is flaky", even if pytest is not mentioned. Not for configuring pytest, coverage, or CI (use python-tooling), float/DataFrame assertions in numeric code (use python-data-science), or tests in other languages (Jest, JUnit, go test).
license: MIT
metadata:
  author: Python Best Practices
  version: "2.0.0"
---

# Python Testing

Test-writing practices for pytest. The Quick Reference below covers the common case; open a rule file when its trigger appears.

## How to Use

When writing tests:

1. Identify the behaviors to verify; each behavior gets one test named after it.
2. Identify the external boundaries (network, database, clock, filesystem, third-party APIs). Only these get mocked or faked.
3. Write each test as Arrange-Act-Assert; move repeated setup into fixtures in the nearest `conftest.py`.
4. Collapse tests that differ only in data into one `parametrize` with readable ids.
5. Run the new tests (`pytest path/to/test_file.py -q`) and make sure each one fails if the behavior it checks is broken.

When reviewing tests, open the matching rule:

| When the test contains... | Read |
|---------------------------|------|
| `patch(...)` of a function the project owns | [mock-boundaries](rules/mock-boundaries.md) |
| `patch(...)` or `Mock()` without `autospec`/`spec` | [mock-autospec](rules/mock-autospec.md) |
| `os.environ[...] =`, `os.chdir`, manual attribute swapping | [mock-monkeypatch](rules/mock-monkeypatch.md) |
| `if`, `for`, or `try/except` in the test body | [struct-no-logic](rules/struct-no-logic.md) |
| Several act-then-assert steps in one test | [struct-one-behavior](rules/struct-one-behavior.md) |
| `scope="session"`/`"module"` on fixtures with mutable state | [fixture-scope](rules/fixture-scope.md) |
| Near-identical test functions | [param-parametrize](rules/param-parametrize.md) |

## Gotchas

- Patch where the dependency is *looked up*, not where it is defined: `mocker.patch("app.orders.repository.save")`, not `app.db.repository.save`.
- `mocker` comes from the pytest-mock plugin; if the project does not depend on it, use `unittest.mock.patch` instead.
- A mock without `autospec=True` accepts any call, so tests keep passing after the real signature changes.
- `monkeypatch` is function-scoped; using it from a session-scoped fixture raises `ScopeMismatch`. Create `pytest.MonkeyPatch()` manually and call `undo()` in teardown.
- Fixtures in `conftest.py` are auto-discovered; do not import them into test modules, which can shadow or duplicate the fixture.
- Computing the expected value with the same formula as production code makes the test pass whenever the code is wrong in the same way; write expected values as literals.
- Wider fixture scopes share mutable state between tests and cause order-dependent failures; `pytest-randomly` exposes them.

## Categories

### Mocking [CRITICAL]
Mock external boundaries only, and keep mocks faithful to real interfaces.

| Rule | Description |
|------|-------------|
| [mock-boundaries](rules/mock-boundaries.md) | Mock external boundaries, not internal logic |
| [mock-autospec](rules/mock-autospec.md) | Use autospec to keep mocks faithful to real signatures |
| [mock-monkeypatch](rules/mock-monkeypatch.md) | Use monkeypatch for env vars and attributes |

### Test Structure [HIGH]
Structure tests so failures are easy to diagnose.

| Rule | Description |
|------|-------------|
| [struct-aaa-pattern](rules/struct-aaa-pattern.md) | Structure tests as Arrange-Act-Assert |
| [struct-test-naming](rules/struct-test-naming.md) | Name tests after the behavior they verify |
| [struct-one-behavior](rules/struct-one-behavior.md) | Test one behavior per test |
| [struct-no-logic](rules/struct-no-logic.md) | Keep conditionals and loops out of tests |

### Fixtures [HIGH]
Share setup without hiding it.

| Rule | Description |
|------|-------------|
| [fixture-scope](rules/fixture-scope.md) | Use the narrowest fixture scope that works |
| [fixture-conftest](rules/fixture-conftest.md) | Place fixtures in the nearest conftest.py |
| [fixture-factory](rules/fixture-factory.md) | Use factory fixtures for varied test data |

### Parametrization [MEDIUM]
Eliminate duplicated tests without hiding cases.

| Rule | Description |
|------|-------------|
| [param-parametrize](rules/param-parametrize.md) | Replace duplicated tests with parametrize |
| [param-ids](rules/param-ids.md) | Give parametrized cases readable ids |

## Quick Reference

### Structure Patterns
```python
def test_expired_token_is_rejected() -> None:
    # Arrange
    token = make_token(expires_at=YESTERDAY)

    # Act
    result = validate(token)

    # Assert
    assert result.valid is False
```

### Fixture Patterns
```python
# Narrow scope by default
@pytest.fixture
def user() -> User:
    return User(name="alice", email="alice@example.com")

# Factory fixture for varied data
@pytest.fixture
def make_user() -> Callable[..., User]:
    def _make(name: str = "alice", active: bool = True) -> User:
        return User(name=name, email=f"{name}@example.com", active=active)
    return _make
```

### Parametrize Patterns
```python
@pytest.mark.parametrize(
    ("email", "valid"),
    [
        pytest.param("a@example.com", True, id="simple-address"),
        pytest.param("a@sub.example.com", True, id="subdomain"),
        pytest.param("no-at-sign", False, id="missing-at"),
        pytest.param("", False, id="empty-string"),
    ],
)
def test_email_validation(email: str, valid: bool) -> None:
    assert is_valid_email(email) is valid
```

### Mocking Patterns
```python
# Mock the external boundary with a faithful interface.
# `mocker` requires the pytest-mock plugin; with stdlib only,
# use unittest.mock.patch as a decorator or context manager.
def test_notifies_on_signup(mocker: MockerFixture) -> None:
    send = mocker.patch("app.signup.email_client.send", autospec=True)

    signup(email="alice@example.com")

    send.assert_called_once_with(to="alice@example.com", template="welcome")

# monkeypatch for environment variables
def test_reads_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("API_KEY", "test-key")
    assert load_config().api_key == "test-key"
```

## See Also

- The `python-tooling` skill, if installed, covers pytest configuration, coverage, and CI setup (`test-pytest` rule).
