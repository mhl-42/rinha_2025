# Python Tooling

A comprehensive guide to Python development tools, designed for AI agents and LLMs to configure and use modern Python tooling effectively.

## Overview

This skill provides 9 rules across 7 categories:

| Category | Prefix | Impact | Rules |
|----------|--------|--------|-------|
| Analysis | `analysis-` | HIGH | 1 |
| Linting | `lint-` | CRITICAL | 1 |
| Type Checking | `type-` | HIGH | 1 |
| Formatting | `fmt-` | HIGH | 1 |
| Testing | `test-` | HIGH | 1 |
| Package Management | `pkg-` | MEDIUM | 2 |
| Continuous Integration | `ci-` | HIGH | 2 |

## Structure

```
skills/python-tooling/
├── SKILL.md              # Skill overview with quick reference
├── metadata.json         # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md             # This file
├── evals/
│   ├── evals.json        # Output-quality test cases (prompt, expected output, assertions)
│   └── trigger_queries.json # Should/should-not trigger queries for the description
└── rules/
    ├── analysis-pyscn.md # Code quality analysis
    ├── lint-ruff.md      # Linting
    ├── type-mypy.md      # Type checking
    ├── fmt-ruff.md       # Formatting
    ├── test-pytest.md    # Testing
    ├── pkg-uv.md         # Package management
    ├── pkg-pyproject.md  # Project configuration
    ├── ci-github-actions.md # CI workflow with uv
    └── ci-pre-commit.md  # pre-commit hooks
```

## Rules

### Analysis (HIGH)
- `analysis-pyscn` - Dead code, clones, dependencies, complexity with pyscn

### Linting (CRITICAL)
- `lint-ruff` - Fast, comprehensive linting with ruff

### Type Checking (HIGH)
- `type-mypy` - Static type checking with mypy

### Formatting (HIGH)
- `fmt-ruff` - Code formatting and import sorting with ruff

### Testing (HIGH)
- `test-pytest` - Testing with pytest, fixtures, and coverage

See the [python-testing skill](../python-testing/README.md) for how to write the tests themselves (structure, fixtures, parametrization, mocking).

### Package Management (MEDIUM)
- `pkg-uv` - Fast package management with uv
- `pkg-pyproject` - Project configuration with pyproject.toml

### Continuous Integration (HIGH)
- `ci-github-actions` - Run the same checks in CI with a locked environment
- `ci-pre-commit` - Run fast checks before each commit with pre-commit

## Tools Covered

| Tool | Purpose |
|------|---------|
| [pyscn](https://github.com/ludo-technologies/pyscn) | Code Quality Analysis |
| [ruff](https://docs.astral.sh/ruff/) | Linting & Formatting |
| [mypy](https://mypy.readthedocs.io/) | Type Checking |
| [pytest](https://docs.pytest.org/) | Testing |
| [uv](https://docs.astral.sh/uv/) | Package Management |

## Usage

The agent loads this skill when its `description` matches the task (project setup, dependencies, linters, type checkers, test configuration, CI).
