---
name: python-tooling
description: Use this skill when setting up or changing Python project tooling — pyproject.toml, dependencies and lock files with uv, ruff lint/format rules, mypy strictness, pytest and coverage configuration, pyscn quality gates, or CI checks — including requests like "set up a new Python project", "add a linter", or "fix the mypy errors in CI". Not for writing application code or test cases themselves (use python-coding-standards or python-testing) or for tooling in other languages (npm, Cargo, Maven).
license: MIT
compatibility: Commands assume uv is installed; tools run through the project environment (uv run) or uvx.
metadata:
  author: Python Best Practices
  version: "2.0.0"
---

# Python Tooling

A comprehensive guide to Python development tools. Configuration best practices for analysis, linters, type checkers, formatters, test frameworks, and package managers.

## Why These Tools Matter

To write high-quality Python code, we recommend adopting these tools:

- **pyscn** - Detect dead code, duplicates, and circular dependencies to prevent technical debt
- **ruff** - Catch bugs and style violations early with fast static analysis
- **mypy** - Find errors before runtime with type checking, also improves IDE completion
- **pytest** - Build confidence in changes with reliable tests
- **uv** - Improve developer experience with fast dependency management

Integrating these into CI/CD reduces code review burden and maintains consistent quality.

## How to Use

Setting up or updating a project:

- [ ] Step 1: Inspect what exists (`pyproject.toml`, `uv.lock`, `requirements*.txt`, CI workflows). Extend the existing setup instead of replacing it; keep pip/requirements projects in uv's pip mode unless asked to migrate.
- [ ] Step 2: Add dev tools as a dependency group: `uv add --dev ruff mypy pytest pytest-cov`. Pin through `uv.lock`, not by hand.
- [ ] Step 3: Configure the tools in `pyproject.toml` (see the Quick Reference); match `target-version` / `python_version` to `requires-python`.
- [ ] Step 4: Run every configured tool once: `uv run ruff check . && uv run ruff format --check . && uv run mypy . && uv run pytest`.
- [ ] Step 5: If a step fails, fix the code or narrow the config with `per-file-ignores` / mypy `overrides`, then rerun. Do not disable a rule globally to make a check pass.
- [ ] Step 6: Wire the same commands into CI ([ci-github-actions](rules/ci-github-actions.md)) and, optionally, pre-commit ([ci-pre-commit](rules/ci-pre-commit.md)).

Open a rule file for the tool you are configuring: [lint-ruff](rules/lint-ruff.md), [fmt-ruff](rules/fmt-ruff.md), [type-mypy](rules/type-mypy.md), [test-pytest](rules/test-pytest.md), [pkg-uv](rules/pkg-uv.md), [pkg-pyproject](rules/pkg-pyproject.md), [analysis-pyscn](rules/analysis-pyscn.md), [ci-github-actions](rules/ci-github-actions.md), [ci-pre-commit](rules/ci-pre-commit.md).

## Gotchas

- `uv add` / `uv sync` rewrite `uv.lock`; commit it. In CI use `uv sync --locked`, which fails on a stale lock, rather than `--frozen`, which skips the check.
- Ruff's `target-version` and mypy's `python_version` default to values unrelated to `requires-python`; set both explicitly or `UP` fixes can produce syntax the minimum Python cannot run.
- Ruff allows broad handlers that call `logging.exception`; `BLE001`, `S110`, and `S112` with `check-typed-exception = true` catch only part of swallowed exceptions.
- Use the same `line-length` for `ruff check` and `ruff format`, or the formatter and `E501` fight each other.
- Turning on `strict = true` in an existing codebase floods it with errors; enable it per module via `[[tool.mypy.overrides]]` and tighten gradually.
- Third-party libraries without inline types need stub packages (`types-requests`, `pandas-stubs`) as dev dependencies, or mypy treats them as `Any`.
- `ruff check --fix` applies only safe fixes; review `--unsafe-fixes` before applying them.
- Enabling the `S` (bandit) rules flags every `assert` with `S101`; ignore it for `tests/**` only.
- pre-commit 4.4+ renamed local-hook `language: system` to `language: unsupported`; the old name is a deprecated alias.
- In CI, run `ruff check` without `--fix` and `ruff format --check`; fixing in CI hides the problem and commits nothing.

## Categories

### Analysis [HIGH]
Structural code analysis for quality assessment.

| Rule | Description |
|------|-------------|
| [analysis-pyscn](rules/analysis-pyscn.md) | Dead code, clones, dependencies, complexity with pyscn |

### Linting [CRITICAL]
Static code analysis with ruff for consistent, high-quality code.

| Rule | Description |
|------|-------------|
| [lint-ruff](rules/lint-ruff.md) | Fast, comprehensive linting with ruff |

### Type Checking [HIGH]
Static type checking with mypy for type safety and better IDE support.

| Rule | Description |
|------|-------------|
| [type-mypy](rules/type-mypy.md) | Static type checking with mypy |

### Formatting [HIGH]
Consistent code formatting with ruff format and import sorting.

| Rule | Description |
|------|-------------|
| [fmt-ruff](rules/fmt-ruff.md) | Code formatting and import sorting with ruff |

### Testing [HIGH]
Test framework configuration with pytest for reliable testing.

| Rule | Description |
|------|-------------|
| [test-pytest](rules/test-pytest.md) | Testing with pytest, fixtures, and coverage |

### Package Management [MEDIUM]
Modern Python packaging with uv and pyproject.toml.

| Rule | Description |
|------|-------------|
| [pkg-uv](rules/pkg-uv.md) | Fast package management with uv |
| [pkg-pyproject](rules/pkg-pyproject.md) | Project configuration with pyproject.toml |

### Continuous Integration [HIGH]
Run the same checks automatically on every commit and pull request.

| Rule | Description |
|------|-------------|
| [ci-github-actions](rules/ci-github-actions.md) | Run the same checks in CI with a locked environment |
| [ci-pre-commit](rules/ci-pre-commit.md) | Run fast checks before each commit with pre-commit |

## Quick Reference

### Minimal pyproject.toml
```toml
[project]
name = "myproject"
version = "0.1.0"
requires-python = ">=3.11"
dependencies = []

[dependency-groups]  # written by `uv add --dev ...`; versions are pinned in uv.lock
dev = ["ruff", "mypy", "pytest", "pytest-cov", "pyscn"]

[tool.ruff]
target-version = "py311"
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "W", "I", "UP", "B", "BLE", "SIM", "PTH", "ASYNC", "S"]

[tool.ruff.lint.per-file-ignores]
"tests/**/*.py" = ["S101"]  # assert is how pytest tests work

[tool.ruff.lint.flake8-bandit]
check-typed-exception = true

[tool.mypy]
python_version = "3.11"
strict = true

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = ["-v", "--tb=short"]

[tool.pyscn]
max_complexity = 15
```

### Common Commands
```bash
# Package management (uv project workflow)
uv sync                         # Create/update .venv from uv.lock (includes dev group)
uv sync --locked                # CI: fail if uv.lock is stale

# Analysis
uv run pyscn analyze .          # Full quality analysis
uv run pyscn check .            # CI quality gate

# Linting
uv run ruff check .             # Check for issues
uv run ruff check . --fix       # Auto-fix issues

# Formatting
uv run ruff format .            # Format code

# Type checking
uv run mypy .                   # Type check

# Testing
uv run pytest                   # Run tests
uv run pytest --cov=src         # With coverage
```

Running through `uv run` uses the versions pinned in `uv.lock`. Outside a project, pin one-off runs explicitly (`uvx ruff@<version> check .`). For existing `requirements.txt` projects, see the pip-compatible mode in [pkg-uv](rules/pkg-uv.md).
