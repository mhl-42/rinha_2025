---
title: Run the Same Checks in CI with a Locked Environment
impact: HIGH
impactDescription: Every change is linted, type-checked, and tested with the versions in uv.lock
tags: [ci, github-actions, uv, quality-gate]
---

# Run the Same Checks in CI with a Locked Environment [HIGH]

## Description
Local checks are optional; CI checks are the gate. Run the exact commands developers run locally (`ruff check`, `ruff format --check`, `mypy`, `pytest`) on every pull request, in an environment built from `uv.lock` with `uv sync --locked`, so CI fails when the lock file is stale instead of silently resolving different versions.

Keep the workflow small: one job that installs uv, syncs, and runs the checks as separate steps so the failing step is obvious in the UI.

## Bad Example
```yaml
# .github/workflows/ci.yml
on: push
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@main          # moving ref
      - uses: actions/setup-python@v5
      - run: pip install -r requirements.txt  # unlocked, resolves new versions each run
      - run: pip install ruff mypy pytest     # tool versions differ from local
      - run: ruff check . --fix && pytest     # --fix in CI hides problems; no mypy, no format check
```

## Good Example
```yaml
# .github/workflows/ci.yml
name: CI

on:
  pull_request:
  push:
    branches: [main]

permissions:
  contents: read

concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true

jobs:
  checks:
    runs-on: ubuntu-latest
    timeout-minutes: 15
    strategy:
      matrix:
        python-version: ["3.11", "3.12", "3.13"]
    steps:
      - uses: actions/checkout@v7
      - uses: astral-sh/setup-uv@v10
        with:
          python-version: ${{ matrix.python-version }}
          enable-cache: true
      - run: uv sync --locked
      - run: uv run ruff check .
      - run: uv run ruff format --check .
      - run: uv run mypy .
      - run: uv run pytest --cov --cov-report=term-missing
```

## Notes
- `uv sync --locked` fails if `uv.lock` does not match `pyproject.toml`; never use plain `uv sync` or `--frozen` in CI unless skipping that check is intentional.
- Run checks without `--fix`; CI reports problems, developers (or pre-commit, see [ci-pre-commit](ci-pre-commit.md)) fix them.
- Test the oldest supported Python (`requires-python`) and the newest; middle versions rarely add signal. A library may need the full range, an application usually needs one version.
- Set `permissions: contents: read` at the top and widen it per job only when a step needs to write (releases, comments).
- Pin actions to a major version (`@v7`) at minimum; security-sensitive repositories pin to a full commit SHA and let Dependabot update it.
- Services such as PostgreSQL for integration tests go in `services:` on the job; pass the connection URL through `env:`.
- Fail the build on coverage drops with `fail_under` in `[tool.coverage.report]` rather than a CLI flag, so local and CI behave the same.

## References
- [uv - Using uv in GitHub Actions](https://docs.astral.sh/uv/guides/integration/github/)
- [astral-sh/setup-uv](https://github.com/astral-sh/setup-uv)
- [GitHub Actions - Security hardening](https://docs.github.com/en/actions/security-for-github-actions/security-guides/security-hardening-for-github-actions)
