---
title: Run Fast Checks Before Each Commit with pre-commit
impact: MEDIUM
impactDescription: Formatting and lint errors are fixed before they reach CI
tags: [pre-commit, git-hooks, ruff, mypy, uv]
---

# Run Fast Checks Before Each Commit with pre-commit [MEDIUM]

## Description
pre-commit runs checks on the staged files before every commit, so formatting and lint fixes happen locally in seconds instead of in a CI round trip. Run the tools through `uv run` from local hooks: the hook then uses the same versions as `uv.lock`, CI, and the editor, and there is no second version pin to keep in sync.

Keep the hooks fast (formatter, linter, and file hygiene). Slow checks like the full test suite belong in CI.

## Bad Example
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: v0.4.0          # a second ruff version, drifting from uv.lock
    hooks:
      - id: ruff
  - repo: https://github.com/pre-commit/mirrors-mypy
    rev: v1.10.0
    hooks:
      - id: mypy         # isolated env without the project's deps: imports become Any
  - repo: local
    hooks:
      - id: tests
        name: pytest
        entry: pytest    # full test suite on every commit: people start using --no-verify
        language: system
        pass_filenames: false
```

## Good Example
```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v6.0.0
    hooks:
      - id: check-yaml
      - id: check-toml
      - id: end-of-file-fixer
      - id: trailing-whitespace
      - id: check-added-large-files

  - repo: local
    hooks:
      - id: ruff-check
        name: ruff check
        entry: uv run ruff check --fix --exit-non-zero-on-fix
        language: unsupported   # pre-commit 4.4+; was `system`
        types_or: [python, pyi]
        require_serial: true
      - id: ruff-format
        name: ruff format
        entry: uv run ruff format
        language: unsupported
        types_or: [python, pyi]
        require_serial: true
      - id: mypy
        name: mypy
        entry: uv run mypy .
        language: unsupported
        types_or: [python, pyi]
        pass_filenames: false   # check the whole project, with its config
        require_serial: true
```

```bash
uv add --dev pre-commit
uv run pre-commit install           # once per clone
uv run pre-commit run --all-files   # after changing the config
```

## Notes
- `language: unsupported` is the pre-commit 4.4+ name for `system` (the old name still works as a deprecated alias). Use `system` if the team is on an older pre-commit.
- `--exit-non-zero-on-fix` makes the commit fail when ruff changed files, so the fixed files get reviewed and re-staged instead of being committed unseen.
- `pass_filenames: false` for mypy: checking only staged files misses errors in files that import them.
- Drop the mypy hook if it takes more than a few seconds on the project; CI still runs it.
- Pin `rev` for remote hook repositories and update them with `uv run pre-commit autoupdate`.
- pre-commit is a convenience, not a gate; anyone can skip it with `--no-verify`. CI must run the same checks (see [ci-github-actions](ci-github-actions.md)).

## References
- [pre-commit documentation](https://pre-commit.com/)
- [pre-commit-hooks](https://github.com/pre-commit/pre-commit-hooks)
