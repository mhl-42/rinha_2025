---
title: Project Configuration with pyproject.toml
impact: MEDIUM
impactDescription: Modern unified configuration
tags: [pyproject.toml, packaging, pep621, dependencies]
---

# Project Configuration with pyproject.toml [MEDIUM]

## Description
`pyproject.toml` is the single configuration file for modern Python projects. It consolidates project metadata, dependencies, and all tool configurations in one place, following PEP 621.

## Complete Example

```toml
[project]
name = "myproject"
version = "1.0.0"
description = "A Python project"
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.11"
authors = [
    {name = "Your Name", email = "you@example.com"},
]
classifiers = [
    "Development Status :: 4 - Beta",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]
dependencies = [
    "fastapi>=0.100.0",
    "pydantic>=2.0",
    "sqlalchemy>=2.0",
]

[project.optional-dependencies]
# User-facing extras only: `pip install myproject[postgres]`
postgres = ["psycopg[binary]>=3.1"]

[dependency-groups]
# Development-only dependencies (PEP 735), never published with the package
dev = [
    "ruff>=0.8.0",
    "mypy>=1.13.0",
    "pytest>=8.0",
    "pytest-cov>=4.0",
]
docs = [
    "mkdocs>=1.5",
]

[project.scripts]
myproject = "myproject.cli:main"

[project.urls]
Homepage = "https://github.com/you/myproject"
Documentation = "https://myproject.readthedocs.io"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

# Tool configurations
[tool.ruff]
target-version = "py311"
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "W", "I", "UP", "B", "BLE", "SIM", "ASYNC", "S"]

[tool.ruff.lint.flake8-bandit]
check-typed-exception = true

[tool.mypy]
python_version = "3.11"
strict = true

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = ["-v", "--tb=short"]

[tool.pyscn]
max_complexity = 15
```

## Dependency Groups vs Extras

- `[dependency-groups]` (PEP 735): tools for working on the project (linters, test runners, docs). Not part of the published package metadata.
- `[project.optional-dependencies]`: optional features that *users* of the package install (`myproject[postgres]`).

```bash
# Development tools go in a group (uv writes [dependency-groups] and uv.lock)
uv add --dev ruff mypy pytest pytest-cov
uv add --group docs mkdocs

# Install
uv sync                     # runtime deps + dev group
uv sync --no-dev            # production only
uv sync --group docs        # also include the docs group
uv sync --extra postgres    # include a user-facing extra
```

Projects still using pip mode can keep a `dev` extra and `uv pip install -e ".[dev]"`; see [pkg-uv](pkg-uv.md).

## Common Mistakes

```toml
# Bad: dev tools published as a user-facing extra
[project.optional-dependencies]
dev = ["ruff", "mypy", "pytest"]

# Bad: exact pins in library metadata block every downstream resolver
dependencies = ["pydantic==2.7.1"]

# Bad: tool config in separate files that drift from pyproject.toml
# setup.cfg [flake8], mypy.ini, pytest.ini, .isort.cfg ...
```

```toml
# Good
dependencies = ["pydantic>=2.0"]   # exact versions live in uv.lock

[dependency-groups]
dev = ["ruff", "mypy", "pytest"]

[tool.ruff]
[tool.mypy]
[tool.pytest.ini_options]
```

## Key Sections

| Section | Purpose |
|---------|---------|
| `[project]` | Package metadata (PEP 621) |
| `[project.optional-dependencies]` | User-facing optional features |
| `[dependency-groups]` | Development-only dependencies (PEP 735) |
| `[project.scripts]` | CLI entry points |
| `[build-system]` | Build backend |
| `[tool.*]` | Tool configurations |

## Notes
- `[project]` follows PEP 621 standard
- Use `>=` for minimum versions, not exact pins
- Put dev/test/docs tooling in `[dependency-groups]`; reserve extras for user-facing features
- All tool configs go in `[tool.xxx]` sections
- Build backends: hatchling, setuptools, flit

## References
- [PEP 621](https://peps.python.org/pep-0621/)
- [PEP 735 - Dependency Groups](https://peps.python.org/pep-0735/)
- [Python Packaging Guide](https://packaging.python.org/en/latest/guides/writing-pyproject-toml/)
