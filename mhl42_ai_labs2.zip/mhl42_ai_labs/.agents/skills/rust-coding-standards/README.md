# Rust Coding Standards

Rules for AI agents writing Rust: no panics for expected failures, typed errors with causes, audited unsafe, async code that never stalls the runtime, newtypes and checked arithmetic, secrets and untrusted input, tracing, workspace lints and dependency hygiene.

## Overview

This skill provides 11 rules across 9 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Errors | `err-` | CRITICAL | 2 |
| Unsafe | `unsafe-` | CRITICAL | 1 |
| Async | `async-` | HIGH | 1 |
| Types | `types-` | HIGH | 1 |
| Arithmetic | `arith-` | HIGH | 1 |
| Security | `sec-` | HIGH | 2 |
| Logging | `log-` | MEDIUM | 1 |
| Lints | `lint-` | MEDIUM | 1 |
| Dependencies | `deps-` | MEDIUM | 1 |

## Structure

```
skills/rust-coding-standards/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from `rust-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files; application-specific rules (Tauri commands, Keychain, string obfuscation) removed, and cancellation, overflow, `try_from` and the secrecy crate added.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
