---
name: rust-coding-standards
description: Use this skill when writing, reviewing, or refactoring Rust code — error handling (Result, ?, unwrap and expect, thiserror and anyhow), unsafe blocks and FFI, async code with tokio (locks across .await, blocking calls, cancellation), newtypes and must_use attributes, integer overflow, secrets and untrusted input, logging with tracing, clippy and workspace lints, Cargo features and dependencies — even if the user only says "add a command to the CLI", "this compiles but panics", or "clean up this crate". Not for tests (use rust-testing), SQL and schema design (use postgres-database), or code in other languages.
license: MIT
compatibility: Rust 1.85+ (edition 2024); the rules hold for edition 2021 except where marked. Async examples use tokio 1.x. Error examples use thiserror 2 and anyhow 1; secrets use the secrecy crate.
metadata:
  author: mhl42 (adapted from 0xMassi/Codex-skills, MIT)
  version: "1.0.2"
---

# Rust Coding Standards

Rules for AI agents writing Rust that does not panic on bad input, does not hide unsafety, and does not stall its async runtime. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing code**: return `Result` with typed errors, keep `unsafe` out or audited, never block or hold a lock across `.await`, and let types carry meaning (newtypes). Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `.unwrap()`, `.expect(..)` on input or I/O, `panic!` for expected failures, indexing with `[i]` on input | [err-no-unwrap](rules/err-no-unwrap.md) |
| `Box<dyn Error>` in a library API, `String` errors, `map_err(|_| ...)` dropping the cause | [err-typed-errors](rules/err-typed-errors.md) |
| `unsafe` blocks or functions, `extern "C"`, raw pointers, `transmute`, `static mut` | [unsafe-audit](rules/unsafe-audit.md) |
| `std::sync::Mutex` guard alive across `.await`; `std::fs`/`thread::sleep` in async fns; spawned tasks never joined | [async-runtime-hygiene](rules/async-runtime-hygiene.md) |
| `u64`/`String` ids and units passed around; results that are easy to ignore | [types-newtypes](rules/types-newtypes.md) |
| `+`, `-`, `*` on money, quantities or lengths from input; `as` casts between integer types | [arith-overflow](rules/arith-overflow.md) |
| Passwords, tokens or keys in `String` fields with `#[derive(Debug)]`; secrets in logs | [sec-secrets](rules/sec-secrets.md) |
| User-supplied paths joined to a directory; `Command::new("sh").arg("-c")`; deserializing untrusted data unbounded | [sec-untrusted-input](rules/sec-untrusted-input.md) |
| `println!`/`eprintln!` for diagnostics in a service; `log` + `env_logger` in new code | [log-tracing](rules/log-tracing.md) |
| A crate without `[lints]`; clippy warnings allowed crate-wide | [lint-workspace](rules/lint-workspace.md) |
| A new dependency with default features; `native-tls`; no `cargo deny`/`cargo audit` | [deps-features](rules/deps-features.md) |

### Review Checklist

- [ ] `cargo clippy --all-targets -- -D warnings` and `cargo fmt --check` pass
- [ ] No `unwrap`/`expect` on anything that can fail at runtime; errors carry their cause
- [ ] Every `unsafe` block has a `SAFETY:` comment that proves its preconditions
- [ ] No blocking call and no `std` lock guard across `.await`; spawned tasks are joined or tracked
- [ ] Arithmetic on external values is checked; casts use `try_from`
- [ ] Secrets are wrapped (`SecretString`) and never printed
- [ ] `cargo deny check` (or `cargo audit`) passes

## Gotchas

- `.expect("should never fail")` is still a panic; the message only helps after the crash. Reserve it for invariants the code itself guarantees, with the reason in the message.
- Integer overflow panics in debug builds and wraps silently in release (unless `overflow-checks = true`), so tests pass and production computes wrong totals.
- `x as u32` truncates and `-1i64 as u64` is `18446744073709551615`; use `u32::try_from(x)?`.
- A `std::sync::MutexGuard` held across `.await` makes the future `!Send` (it will not compile with `tokio::spawn`) or, on a current-thread runtime, can deadlock.
- Dropping a future cancels it at its current `.await`: code after that point never runs, so cleanup must live in `Drop` or be cancellation-safe.
- `tokio::spawn` detaches the task; if its `JoinHandle` is dropped, its panic or error is lost.
- `#[derive(Debug)]` on a struct with a password prints it in every `{:?}` and every error report that includes the struct.
- `Path::join` with an absolute path replaces the base: `Path::new("/srv").join("/etc/passwd")` is `/etc/passwd`.
- Edition 2024 requires `unsafe extern "C" { ... }` blocks and makes `unsafe_op_in_unsafe_fn` warn: an `unsafe fn` body needs its own `unsafe {}` blocks.

## Categories

### Errors [CRITICAL]
No panics for expected failures; errors that carry their cause.

| Rule | Description |
|------|-------------|
| [err-no-unwrap](rules/err-no-unwrap.md) | Propagate with ?, never unwrap what can fail |
| [err-typed-errors](rules/err-typed-errors.md) | thiserror enums in libraries, anyhow with context in applications |

### Safety [CRITICAL]
Unsafe code that is rare, small and proven.

| Rule | Description |
|------|-------------|
| [unsafe-audit](rules/unsafe-audit.md) | Deny unsafe by default; every block has a SAFETY proof |

### Async [HIGH]
Never stall the runtime.

| Rule | Description |
|------|-------------|
| [async-runtime-hygiene](rules/async-runtime-hygiene.md) | No blocking and no std locks across .await; track spawned tasks |

### Types [HIGH]
Let the compiler check meaning, not only shape.

| Rule | Description |
|------|-------------|
| [types-newtypes](rules/types-newtypes.md) | Newtypes for ids and units; parse at the boundary; #[must_use] |
| [arith-overflow](rules/arith-overflow.md) | Checked arithmetic and try_from on external values |

### Security [HIGH]
Secrets stay hidden; input stays data.

| Rule | Description |
|------|-------------|
| [sec-secrets](rules/sec-secrets.md) | Wrap secrets in SecretString; never Debug-print them |
| [sec-untrusted-input](rules/sec-untrusted-input.md) | Confine paths, no shell, bounded deserialization |

### Tooling [MEDIUM]
Lints, logs and dependencies under control.

| Rule | Description |
|------|-------------|
| [log-tracing](rules/log-tracing.md) | Structured diagnostics with tracing spans |
| [lint-workspace](rules/lint-workspace.md) | Workspace lints with clippy, inherited by every crate |
| [deps-features](rules/deps-features.md) | Minimal features, rustls, cargo-deny in CI |

## Quick Reference

```rust
#[derive(Debug, thiserror::Error)]
pub enum ImportError {
    #[error("reading {path}")]
    Read { path: PathBuf, #[source] source: std::io::Error },
    #[error("line {line}: {reason}")]
    Invalid { line: usize, reason: String },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct OrderId(u64);

pub fn total_cents(lines: &[Line]) -> Result<u64, ImportError> {
    lines.iter().try_fold(0u64, |sum, line| {
        line.unit_cents
            .checked_mul(u64::from(line.quantity))
            .and_then(|value| sum.checked_add(value))
            .ok_or(ImportError::Invalid { line: line.number, reason: "total overflows".into() })
    })
}

async fn refresh(cache: &tokio::sync::RwLock<Cache>, client: &Client) -> anyhow::Result<()> {
    let fresh = client.fetch().await.context("fetching prices")?; // no lock held while waiting
    *cache.write().await = fresh;
    Ok(())
}
```

```toml
[workspace.lints.rust]
unsafe_code = "deny"

[workspace.lints.clippy]
unwrap_used = "warn"
expect_used = "warn"
panic = "warn"
```

## See Also

These are separate skills; use them if installed.

- `rust-testing` - Unit and integration tests, async tests, proptest
- `postgres-database` - Parameterized queries, transactions and migrations
