# Section Definitions

## Errors (err)
**Impact:** CRITICAL

No panics for expected failures; errors that carry their cause.

**Rules:**
- `err-no-unwrap` - Propagate with ?, never unwrap what can fail
- `err-typed-errors` - thiserror enums in libraries, anyhow with context in applications

## Unsafe (unsafe)
**Impact:** CRITICAL

Unsafe code that is rare, small and proven.

**Rules:**
- `unsafe-audit` - Deny unsafe by default; every block has a SAFETY proof

## Async (async)
**Impact:** HIGH

Never stall the runtime.

**Rules:**
- `async-runtime-hygiene` - No blocking and no std locks across .await; track spawned tasks

## Types (types)
**Impact:** HIGH

Let the compiler check meaning, not only shape.

**Rules:**
- `types-newtypes` - Newtypes for ids and units; parse at the boundary; #[must_use]

## Arithmetic (arith)
**Impact:** HIGH

No silent wrap-around.

**Rules:**
- `arith-overflow` - Checked arithmetic and try_from on external values

## Security (sec)
**Impact:** HIGH

Secrets stay hidden; input stays data.

**Rules:**
- `sec-secrets` - Wrap secrets in SecretString; never Debug-print them
- `sec-untrusted-input` - Confine paths, no shell, bounded deserialization

## Logging (log)
**Impact:** MEDIUM

Structured diagnostics.

**Rules:**
- `log-tracing` - Structured diagnostics with tracing spans

## Lints (lint)
**Impact:** MEDIUM

One lint policy for the workspace.

**Rules:**
- `lint-workspace` - Workspace lints with clippy, inherited by every crate

## Dependencies (deps)
**Impact:** MEDIUM

Fewer, audited dependencies.

**Rules:**
- `deps-features` - Minimal features, rustls, cargo-deny in CI
