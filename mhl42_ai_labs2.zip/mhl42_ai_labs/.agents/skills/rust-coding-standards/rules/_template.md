---
title: Rule Title
impact: CRITICAL | HIGH | MEDIUM | LOW
impactDescription: Impact description (e.g., 1.5-2x faster)
tags: [tag1, tag2, tag3]
---

# Rule Title [IMPACT]

## Description
Explanation of why this rule matters and when to apply it.

## Bad Example
```rust
# Problematic code
```

## Good Example
```rust
# Recommended code
```

## Notes
- Additional tips and hints
- Edge cases and exceptions

## References
- [Link text](URL)
