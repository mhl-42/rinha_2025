---
title: Checked Arithmetic and try_from on External Values
impact: HIGH
impactDescription: Totals and lengths never wrap around silently in release builds
tags: [arithmetic, overflow, casts, try_from, money]
---

# Checked Arithmetic and try_from on External Values [HIGH]

## Description
In release builds, integer overflow wraps by default: a large quantity times a price becomes a small or negative total without any error. Tests in debug panic instead, so the difference shows up only in production. For values that come from outside (quantities, prices, sizes, offsets), use `checked_*` and handle `None`, or `saturating_*` when clamping is the right answer.

`as` between integer types truncates or reinterprets the sign. Use `u32::try_from(value)` and handle the error. Money is an integer number of cents (or a decimal type), never `f64`.

## Bad Example
```rust
let total = unit_cents * quantity as u64;     // wraps in release, truncates if quantity is negative
let index = offset as usize;                  // a negative i64 becomes a huge usize
let price: f64 = 0.1 + 0.2;                   // 0.30000000000000004
```

## Good Example
```rust
let quantity = u64::try_from(quantity).map_err(|_| OrderError::Invalid { reason: "negative quantity".into() })?;
let total = unit_cents
    .checked_mul(quantity)
    .ok_or(OrderError::Invalid { reason: "total too large".into() })?;

let index = usize::try_from(offset).map_err(|_| PageError::NegativeOffset)?;

let retries = attempts.saturating_add(1);
```

```toml
[profile.release]
overflow-checks = true
```

## Notes
- `overflow-checks = true` in release turns silent wrap-around into a panic: a safety net, not a substitute for checked arithmetic on input.
- clippy's `arithmetic_side_effects` and `cast_possible_truncation` (pedantic) find unchecked operations in sensitive modules.

## References
- [std: checked_mul](https://doc.rust-lang.org/std/primitive.u64.html#method.checked_mul)
- [Cargo: profiles](https://doc.rust-lang.org/cargo/reference/profiles.html#overflow-checks)
