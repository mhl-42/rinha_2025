---
title: No Blocking and No std Locks Across .await; Track Spawned Tasks
impact: HIGH
impactDescription: The runtime keeps serving other tasks; no deadlocks or lost task failures
tags: [async, tokio, mutex, blocking, spawn, cancellation]
---

# No Blocking and No std Locks Across .await; Track Spawned Tasks [HIGH]

## Description
An async runtime runs many tasks on a few threads. A blocking call inside an `async fn` (`std::fs`, `std::thread::sleep`, a CPU-heavy loop, a synchronous HTTP client) stops every task on that thread. Use the async equivalent (`tokio::fs`, `tokio::time::sleep`) or move the work to `spawn_blocking`.

A `std::sync::Mutex` guard held across `.await` blocks the thread while waiting and makes the future `!Send`. Either drop the guard before awaiting (copy out what you need) or use `tokio::sync::Mutex` when the lock must span an await. Keep lock scopes short either way.

`tokio::spawn` detaches a task: keep its `JoinHandle` (or use a `JoinSet`) so its panics and errors are observed, and so shutdown can wait for it.

## Bad Example
```rust
async fn handle(state: Arc<std::sync::Mutex<State>>, client: &Client) -> Result<()> {
    let mut guard = state.lock().unwrap();
    let data = client.fetch().await?; // guard held across await
    guard.update(data);
    std::thread::sleep(Duration::from_secs(1)); // blocks the runtime thread
    let report = std::fs::read_to_string("report.txt")?;
    tokio::spawn(send_report(report)); // failure is never seen
    Ok(())
}
```

## Good Example
```rust
async fn handle(state: Arc<std::sync::Mutex<State>>, client: &Client, tasks: &mut JoinSet<Result<()>>) -> Result<()> {
    let data = client.fetch().await?;
    state.lock().expect("state lock poisoned").update(data); // guard dropped at end of statement
    tokio::time::sleep(Duration::from_secs(1)).await;
    let report = tokio::fs::read_to_string("report.txt").await?;
    tasks.spawn(send_report(report));
    Ok(())
}

let digest = tokio::task::spawn_blocking(move || argon2_hash(&password)).await??;
```

## Notes
- Dropping a future cancels it at its pending `.await`. In `tokio::select!`, use branches that are cancellation-safe (see each method's docs) or move the work into its own task.
- clippy's `await_holding_lock` reports std guards held across awaits.
- Give outgoing calls a deadline with `tokio::time::timeout`.

## References
- [Tokio: shared state](https://tokio.rs/tokio/tutorial/shared-state)
- [Tokio: spawn_blocking](https://docs.rs/tokio/latest/tokio/task/fn.spawn_blocking.html)
