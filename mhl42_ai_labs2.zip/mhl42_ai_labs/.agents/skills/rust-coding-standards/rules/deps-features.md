---
title: Minimal Features, rustls, cargo-deny in CI
impact: MEDIUM
impactDescription: Smaller builds, fewer native dependencies, and known vulnerabilities blocked
tags: [dependencies, features, rustls, cargo-deny, supply-chain]
---

# Minimal Features, rustls, cargo-deny in CI [MEDIUM]

## Description
Default features pull in code (and often C libraries) you do not use: more compile time, more attack surface. Add dependencies with `default-features = false` and the features you need. Prefer `rustls` over `native-tls` for TLS: pure Rust, no OpenSSL to install or patch on each platform.

In a workspace, declare versions once in `[workspace.dependencies]` and inherit them. Check licenses, advisories and duplicate versions in CI with `cargo deny check` (or at least `cargo audit`), and commit `Cargo.lock` for binaries.

## Bad Example
```toml
[dependencies]
reqwest = "0.12"
tokio = { version = "1", features = ["full"] }
```

## Good Example
```toml
[workspace.dependencies]
reqwest = { version = "0.12", default-features = false, features = ["json", "rustls-tls"] }
tokio = { version = "1", features = ["rt-multi-thread", "macros", "net", "time"] }

[dependencies]
reqwest = { workspace = true }
tokio = { workspace = true }
```

## Notes
- Check the current major version and its feature names on docs.rs before adding a crate; feature names change between majors.
- A crate with a `build.rs` or proc-macros runs code at build time; prefer well-known ones.

## References
- [Cargo: features](https://doc.rust-lang.org/cargo/reference/features.html)
- [cargo-deny](https://embarkstudios.github.io/cargo-deny/)
