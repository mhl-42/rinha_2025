---
title: Propagate with ?, Never Unwrap What Can Fail
impact: CRITICAL
impactDescription: Bad input, a missing file or a dropped connection returns an error instead of crashing
tags: [errors, unwrap, expect, panic, question-mark]
---

# Propagate with ?, Never Unwrap What Can Fail [CRITICAL]

## Description
`unwrap()` and `expect()` turn every `Err` and `None` into a panic. On anything that depends on the outside world (input, files, the network, the environment, a lock that can be poisoned) that is a crash waiting for the first unusual case. Propagate with `?`, convert an `Option` with `ok_or`/`ok_or_else`, and decide at the top (in `main` or the request handler) what the user sees.

Slice indexing (`v[i]`), `HashMap[&key]` and division by a value from input panic the same way; use `get`, `checked_div`.

`expect` remains right for invariants the code itself guarantees (a regex literal, a value just inserted), with a message that says why it cannot fail.

## Bad Example
```rust
fn load(path: &Path) -> Config {
    let text = std::fs::read_to_string(path).unwrap();
    let port = std::env::var("PORT").unwrap().parse().unwrap();
    let first = text.lines().next().unwrap();
    toml::from_str(&text).expect("bad config")
}
```

## Good Example
```rust
fn load(path: &Path) -> anyhow::Result<Config> {
    let text = std::fs::read_to_string(path)
        .with_context(|| format!("reading config {}", path.display()))?;
    let port: u16 = std::env::var("PORT")
        .context("PORT is not set")?
        .parse()
        .context("PORT must be a number between 0 and 65535")?;
    let mut config: Config = toml::from_str(&text).context("parsing config")?;
    config.port = port;
    Ok(config)
}

static ID_PATTERN: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^[A-Z]{3}-\d{4}$").expect("ID_PATTERN is a valid literal regex"));
```

## Notes
- In tests, `unwrap` is fine: a panic is a test failure. Returning `Result` from the test is often clearer (see rust-testing).
- clippy's `unwrap_used`, `expect_used`, `indexing_slicing` and `panic` lints find these; enable them as warnings at least.

## References
- [The Rust Book: recoverable errors with Result](https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html)
