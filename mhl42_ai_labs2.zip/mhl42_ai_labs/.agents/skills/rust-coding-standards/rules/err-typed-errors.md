---
title: thiserror Enums in Libraries, anyhow with Context in Applications
impact: CRITICAL
impactDescription: Callers can react to specific failures, and every error report shows its full cause chain
tags: [errors, thiserror, anyhow, context, source]
---

# thiserror Enums in Libraries, anyhow with Context in Applications [CRITICAL]

## Description
A library's callers need to tell failures apart (not found vs. permission denied vs. corrupt data). Give its public API an error `enum`, derived with `thiserror`, with one variant per case the caller may handle, and the underlying error as `#[source]`. `Box<dyn Error>` or `String` errors force callers to parse messages.

An application usually only reports errors. `anyhow::Result` with `.context(...)` at each layer produces a readable chain (`importing orders.csv: line 12: invalid date`) without defining types nobody matches on.

Never drop the cause: `map_err(|_| MyError::Failed)` loses what actually went wrong.

## Bad Example
```rust
pub fn parse_order(line: &str) -> Result<Order, Box<dyn std::error::Error>> { /* ... */ }

pub fn save(order: &Order) -> Result<(), String> {
    db.insert(order).map_err(|_| "save failed".to_string())
}
```

## Good Example
```rust
#[derive(Debug, thiserror::Error)]
pub enum OrderError {
    #[error("order {0} not found")]
    NotFound(OrderId),
    #[error("invalid order line: {reason}")]
    Invalid { reason: String },
    #[error("database error")]
    Database(#[from] sqlx::Error),
}

pub async fn save(pool: &PgPool, order: &Order) -> Result<(), OrderError> {
    sqlx::query("INSERT INTO orders (reference, total_cents) VALUES ($1, $2)")
        .bind(&order.reference)
        .bind(order.total_cents)
        .execute(pool)
        .await?;
    Ok(())
}

fn main() -> anyhow::Result<()> {
    let orders = import(&path).with_context(|| format!("importing {}", path.display()))?;
    Ok(())
}
```

## Notes
- Keep variants about what the caller can do, not about every internal step.
- Print the whole chain at the top: `{:#}` for anyhow, or iterate `source()`.
- `#[non_exhaustive]` on a public error enum lets you add variants without a breaking release.

## References
- [thiserror](https://docs.rs/thiserror)
- [anyhow](https://docs.rs/anyhow)
