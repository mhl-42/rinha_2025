---
title: Workspace Lints with clippy, Inherited by Every Crate
impact: MEDIUM
impactDescription: One lint policy, enforced in CI, for every crate in the workspace
tags: [lints, clippy, cargo, workspace, ci]
---

# Workspace Lints with clippy, Inherited by Every Crate [MEDIUM]

## Description
Lint settings scattered as `#![allow(...)]` attributes drift apart between crates. Declare them once in the workspace `Cargo.toml` under `[workspace.lints]` and make every crate inherit them with `[lints] workspace = true`. Run `cargo clippy --all-targets -- -D warnings` in CI so a warning cannot be merged.

An exception is local and explained: `#[expect(clippy::lint_name, reason = "...")]` on the item (Rust 1.81+), which also fails when the lint stops firing, instead of a crate-wide `allow`.

## Bad Example
```rust
#![allow(clippy::all)]
#![allow(unused)]
```

## Good Example
```toml
[workspace.lints.rust]
unsafe_code = "deny"
unsafe_op_in_unsafe_fn = "deny"

[workspace.lints.clippy]
unwrap_used = "warn"
expect_used = "warn"
panic = "warn"
await_holding_lock = "deny"
undocumented_unsafe_blocks = "deny"
pedantic = { level = "warn", priority = -1 }
module_name_repetitions = "allow"
```

```rust
#[expect(clippy::cast_possible_truncation, reason = "value is checked to fit in u16 above")]
let port = value as u16;
```

## Notes
- `pedantic` is noisy on an existing codebase; adopt it on new crates, or enable its lints one by one.
- Tests may allow `unwrap_used` with `#[cfg_attr(test, allow(clippy::unwrap_used))]` in the test module.

## References
- [Cargo: the lints section](https://doc.rust-lang.org/cargo/reference/manifest.html#the-lints-section)
- [Clippy lints](https://rust-lang.github.io/rust-clippy/master/)
