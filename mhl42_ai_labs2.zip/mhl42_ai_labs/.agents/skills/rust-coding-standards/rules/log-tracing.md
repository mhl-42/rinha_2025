---
title: Structured Diagnostics with tracing Spans
impact: MEDIUM
impactDescription: Logs carry context across async tasks and can be filtered and searched
tags: [logging, tracing, spans, observability]
---

# Structured Diagnostics with tracing Spans [MEDIUM]

## Description
`println!` and `eprintln!` in a service produce unstructured lines without levels, and in async code the lines of concurrent requests interleave with no way to tell them apart. `tracing` records events with fields inside spans; a span (a request, a job) attaches its fields to everything logged within it, even across `.await` points. Configure the subscriber once in `main` (`tracing-subscriber` with `EnvFilter`, JSON in production).

`#[instrument]` creates a span per call with the arguments as fields; skip arguments that are large or secret.

## Bad Example
```rust
async fn import(path: &Path, token: &str) -> Result<()> {
    println!("importing {:?} with {}", path, token);
    // ...
    eprintln!("failed: {:?}", err);
}
```

## Good Example
```rust
#[tracing::instrument(skip(token), fields(path = %path.display()))]
async fn import(path: &Path, token: &SecretString) -> anyhow::Result<()> {
    let rows = read_rows(path).await?;
    tracing::info!(rows = rows.len(), "file parsed");
    // ...
    Ok(())
}

fn main() {
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .json()
        .init();
}
```

## Notes
- A CLI's normal output to the user still goes to stdout with `println!`; `tracing` is for diagnostics.
- Libraries emit `tracing` events and never install a subscriber.

## References
- [tracing](https://docs.rs/tracing)
- [tracing-subscriber](https://docs.rs/tracing-subscriber)
