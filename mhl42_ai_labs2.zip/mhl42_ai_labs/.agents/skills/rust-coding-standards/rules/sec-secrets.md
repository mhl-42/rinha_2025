---
title: Wrap Secrets in SecretString; Never Debug-Print Them
impact: HIGH
impactDescription: Keys and passwords do not leak through logs, panics or error reports
tags: [security, secrets, secrecy, debug, logging]
---

# Wrap Secrets in SecretString; Never Debug-Print Them [HIGH]

## Description
A token stored in a `String` field of a `#[derive(Debug)]` struct appears in every `{:?}`, every `tracing` field that records the struct, and every error report that includes it. Store secrets in `secrecy::SecretString` (or `SecretBox<T>`): its `Debug` prints a placeholder, the value is zeroed on drop, and reading it requires an explicit `expose_secret()` at the point of use.

Load secrets from the environment or a secret manager at startup; never from source. Compare tokens with a constant-time comparison (`subtle::ConstantTimeEq`).

## Bad Example
```rust
#[derive(Debug, Deserialize)]
struct Config {
    database_url: String,
    stripe_key: String,
}

tracing::info!(?config, "loaded config"); // both secrets in the logs
```

## Good Example
```rust
#[derive(Debug, Deserialize)]
struct Config {
    database_url: SecretString,
    stripe_key: SecretString,
    region: String,
}

tracing::info!(region = %config.region, "loaded config");

let client = Stripe::new(config.stripe_key.expose_secret());
```

## Notes
- Passwords are hashed with `argon2` (the RustCrypto crate), never stored or compared as plain text.
- A secret that reached a log or a commit is compromised: rotate it.

## References
- [secrecy crate](https://docs.rs/secrecy)
- [subtle crate](https://docs.rs/subtle)
