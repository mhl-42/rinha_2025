---
title: Confine Paths, No Shell, Bounded Deserialization
impact: HIGH
impactDescription: Prevents path traversal, command injection and memory exhaustion from input
tags: [security, paths, command, serde, limits]
---

# Confine Paths, No Shell, Bounded Deserialization [HIGH]

## Description
- **Paths:** a user-supplied name joined to a directory can climb out with `..` or replace the base when absolute. Accept only plain file names (one normal component), or canonicalize and check the result starts with the canonical base.
- **Programs:** `Command::new("sh").arg("-c").arg(format!(...))` runs a shell. `Command::new("convert").arg(input).arg(output)` passes arguments directly.
- **Deserialization:** limit the size of what you read before parsing (`take`, the web framework's body limit) and use `#[serde(deny_unknown_fields)]` where extra fields mean a mistake.
- **SQL:** bind parameters; never `format!` into a query.

## Bad Example
```rust
let path = Path::new("/srv/uploads").join(&params.name);
let data = std::fs::read(path)?;

Command::new("sh").arg("-c").arg(format!("convert {} thumb.png", params.name)).status()?;

let order: Order = serde_json::from_reader(request_body)?; // unbounded
```

## Good Example
```rust
fn upload_path(base: &Path, name: &str) -> Result<PathBuf, UploadError> {
    let mut components = Path::new(name).components();
    match (components.next(), components.next()) {
        (Some(Component::Normal(file)), None) => Ok(base.join(file)),
        _ => Err(UploadError::InvalidName(name.to_owned())),
    }
}

Command::new("convert").arg("--").arg(&input).arg(&output).status()?;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct NewOrder { product_id: Uuid, quantity: u32 }

let order: NewOrder = serde_json::from_reader(request_body.take(64 * 1024))?;
```

## Notes
- For archives, check each entry's path the same way before extracting.
- Regexes built from user input can be slow; the `regex` crate guarantees linear time, `fancy-regex` does not.

## References
- [std::process::Command](https://doc.rust-lang.org/std/process/struct.Command.html)
- [serde: container attributes](https://serde.rs/container-attrs.html#deny_unknown_fields)
