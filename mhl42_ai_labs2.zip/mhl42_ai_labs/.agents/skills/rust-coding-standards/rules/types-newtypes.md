---
title: Newtypes for Ids and Units; Parse at the Boundary; #[must_use]
impact: HIGH
impactDescription: Mixed-up ids and units become compile errors; validated values stay valid
tags: [types, newtype, must-use, validation, parse-dont-validate]
---

# Newtypes for Ids and Units; Parse at the Boundary; #[must_use] [HIGH]

## Description
A function taking `(u64, u64)` for a customer id and an order id accepts them swapped. A `f64` that is sometimes seconds and sometimes milliseconds passes every check. Wrap them in single-field structs (`struct CustomerId(u64)`): the compiler then refuses the mix-up at no runtime cost.

Validate once, when the value enters (`Email::parse(&str) -> Result<Email, _>`), and keep the field private so an `Email` is always valid; functions taking `Email` never re-check.

Mark functions and types whose result must not be ignored with `#[must_use]`, such as a builder method or a function returning a new value instead of mutating.

## Bad Example
```rust
fn transfer(from: u64, to: u64, amount: i64) -> Result<(), Error> { /* ... */ }

transfer(order.id, customer.id, 100)?; // arguments swapped, compiles

fn send_invite(email: &str) { /* checks the format again, or forgets to */ }
```

## Good Example
```rust
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AccountId(u64);

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct Cents(i64);

pub fn transfer(from: AccountId, to: AccountId, amount: Cents) -> Result<(), TransferError> { /* ... */ }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Email(String);

impl Email {
    pub fn parse(raw: &str) -> Result<Self, InvalidEmail> {
        let trimmed = raw.trim();
        if trimmed.len() > 254 || !trimmed.contains('@') {
            return Err(InvalidEmail(raw.to_owned()));
        }
        Ok(Self(trimmed.to_lowercase()))
    }
}

#[must_use = "with_discount returns a new price and does not change this one"]
pub fn with_discount(price: Cents, percent: u8) -> Cents { /* ... */ }
```

## Notes
- Implement `Display`, `FromStr` and serde traits on the newtype when it crosses boundaries; keep arithmetic explicit.
- `Duration` already exists for time; use it instead of numbers of seconds.

## References
- [Rust API Guidelines: newtypes](https://rust-lang.github.io/api-guidelines/type-safety.html#newtypes-provide-static-distinctions-c-newtype)
