---
title: Deny unsafe by Default; Every Block Has a SAFETY Proof
impact: CRITICAL
impactDescription: Memory-safety bugs are confined to a few audited lines
tags: [unsafe, ffi, safety, miri, edition-2024]
---

# Deny unsafe by Default; Every Block Has a SAFETY Proof [CRITICAL]

## Description
`unsafe` lets the code break the guarantees the rest of the program relies on; a mistake there causes undefined behaviour anywhere. Deny `unsafe_code` for the workspace and allow it only in the module or crate that needs it (FFI, a measured hot path).

Each `unsafe` block is as small as possible and carries a `// SAFETY:` comment that states the preconditions and why they hold here. Each `unsafe fn` documents its contract in a `# Safety` section. Wrap the unsafe part in a safe function whose signature makes misuse impossible.

Never use `unsafe` to silence the borrow checker, to share mutable state (`static mut`), or to convert types with `transmute` when `from_ne_bytes`, `bytemuck` or a cast does it.

## Bad Example
```rust
static mut COUNTER: u64 = 0;

pub fn bump() {
    unsafe { COUNTER += 1 } // data race with any other thread
}

pub fn first(values: &[u32]) -> u32 {
    unsafe { *values.get_unchecked(0) } // UB on an empty slice
}
```

## Good Example
```rust
static COUNTER: AtomicU64 = AtomicU64::new(0);

pub fn bump() {
    COUNTER.fetch_add(1, Ordering::Relaxed);
}

unsafe extern "C" {
    fn crc32_update(state: u32, data: *const u8, len: usize) -> u32;
}

pub fn crc32(data: &[u8]) -> u32 {
    // SAFETY: `data` is a valid slice, so the pointer is non-null, aligned for u8 and valid for
    // `data.len()` bytes; crc32_update only reads that range and does not keep the pointer.
    unsafe { crc32_update(0, data.as_ptr(), data.len()) }
}
```

## Notes
- clippy's `undocumented_unsafe_blocks` requires the `SAFETY:` comment.
- Run tests of unsafe code under Miri (`cargo +nightly miri test`) where it supports the operations.
- Edition 2024: `extern` blocks must be written `unsafe extern`, and calls inside an `unsafe fn` need their own `unsafe {}`.

## References
- [The Rustonomicon](https://doc.rust-lang.org/nomicon/)
- [Rust 2024: unsafe extern blocks](https://doc.rust-lang.org/edition-guide/rust-2024/unsafe-extern.html)
