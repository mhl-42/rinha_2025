# Rust Testing

Rules for AI agents writing Rust tests: unit and integration tests in the right place, Result-returning tests with matched error variants, trait fakes, paused tokio time, proptest and doc tests.

## Overview

This skill provides 6 rules across 6 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Structure | `struct-` | CRITICAL | 1 |
| Assertions | `assert-` | CRITICAL | 1 |
| Isolation | `iso-` | HIGH | 1 |
| Async | `async-` | HIGH | 1 |
| Property-based | `prop-` | MEDIUM | 1 |
| Doc tests | `doc-` | MEDIUM | 1 |

## Structure

```
skills/rust-testing/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from the Rust part of `testing-patterns` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT), split into rule files; real sleeps replaced by paused time, and proptest and doc tests added.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
