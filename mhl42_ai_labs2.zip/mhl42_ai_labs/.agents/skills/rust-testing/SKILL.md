---
name: rust-testing
description: Use this skill when writing, reviewing, or fixing Rust tests — unit tests in cfg(test) modules, integration tests in tests/, tests that return Result, assertions and error matching, trait-based fakes, async tests with tokio (paused time), property tests with proptest, doc tests and test-only dependencies — even if the user only says "add tests for this module", "this test is flaky", or "test the retry logic". Not for application code (use rust-coding-standards) or tests in other languages.
license: MIT
compatibility: Rust 1.85+; async tests use tokio 1.x with the test-util feature for paused time; property tests use proptest 1.x. cargo-nextest is optional.
metadata:
  author: mhl42 (adapted from 0xMassi/Codex-skills, MIT)
  version: "1.0.2"
---

# Rust Testing

Rules for AI agents writing Rust tests that check behaviour, run fast and never wait on real time. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing tests**: unit tests next to the code, integration tests through the public API, fakes behind traits, paused time for async code. Check an expected error with `assert!(matches!(err, MyError::Variant { .. }))`, never `assert_eq!` against an `Err(...)`. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below and open the matching rule. Then break the code on purpose and check that a test fails.

| When the test contains... | Read |
|---------------------------|------|
| Tests of private helpers from `tests/`; one giant test; names like `test1` | [struct-unit-and-integration](rules/struct-unit-and-integration.md) |
| `assert_eq!(result, Err(...))`; `unwrap()` chains with no message; `assert!(a == b)`; `is_err()` as the only check | [assert-results-and-errors](rules/assert-results-and-errors.md) |
| Real HTTP or database calls in unit tests; mocking crates for one method | [iso-trait-fakes](rules/iso-trait-fakes.md) |
| `#[tokio::test]` with `sleep`; timeouts and retries tested in real time | [async-paused-time](rules/async-paused-time.md) |
| Parsers, encoders, money and date arithmetic tested with a few literals | [prop-proptest](rules/prop-proptest.md) |
| Public items without examples, or examples in docs that are never compiled | [doc-doctests](rules/doc-doctests.md) |

### Review Checklist

- [ ] Each test name states a behaviour; each test fails for one reason
- [ ] Values are compared with `assert_eq!`; errors are matched by variant with `matches!`, with the error in the message
- [ ] Unit tests need no network, database or real clock
- [ ] Async timing is tested with paused time, never with real sleeps
- [ ] `cargo test --all-targets` (or `cargo nextest run`) passes, doc tests included

## Gotchas

- `assert_eq!(result, Err(MailError::Unavailable))` needs `PartialEq` on the error type, which errors wrapping `std::io::Error` or `reqwest::Error` cannot derive; adding it only for tests changes the public API. `assert!(matches!(result, Err(MailError::Unavailable)), "got {result:?}")` needs nothing and can check fields with a guard.
- `#[should_panic]` passes for any panic, including an unrelated `unwrap`; add `expected = "..."`, or better, test the `Result`.
- Integration tests in `tests/` are separate crates and see only the public API; each file is its own binary, so shared helpers go in `tests/common/mod.rs`.
- Tests run in parallel threads by default; tests that change environment variables or the current directory interfere (and `std::env::set_var` is `unsafe` in edition 2024).
- `#[tokio::test]` uses a current-thread runtime by default; code that needs `spawn_blocking` or multiple workers needs `flavor = "multi_thread"`.
- `cargo test` does not run doc tests of a binary crate, and `cargo nextest` does not run doc tests at all; run `cargo test --doc` too.
- `assert_eq!(a, b)` prints both values only if they implement `Debug`; derive it on test-visible types.

## Categories

### Structure [CRITICAL]
Tests in the right place, checking the right thing.

| Rule | Description |
|------|-------------|
| [struct-unit-and-integration](rules/struct-unit-and-integration.md) | Unit tests in the module, integration tests through the public API |
| [assert-results-and-errors](rules/assert-results-and-errors.md) | Tests return Result; match error variants; assert with messages |

### Isolation [HIGH]
No real network, database or clock in unit tests.

| Rule | Description |
|------|-------------|
| [iso-trait-fakes](rules/iso-trait-fakes.md) | Depend on traits; test with small hand-written fakes |
| [async-paused-time](rules/async-paused-time.md) | Pause tokio time instead of sleeping |

### Coverage of Inputs [MEDIUM]
Properties and examples that keep running.

| Rule | Description |
|------|-------------|
| [prop-proptest](rules/prop-proptest.md) | Check invariants over generated inputs with proptest |
| [doc-doctests](rules/doc-doctests.md) | Examples in docs compile and run as tests |

## Quick Reference

```rust
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn refuses_zero_people() {
        let result = split(Cents(1000), 0);

        assert!(matches!(result, Err(SplitError::NoPeople)), "unexpected result: {result:?}");
    }

    #[test]
    fn splits_a_bill_into_parts_that_add_up() -> Result<(), SplitError> {
        let parts = split(Cents(1000), 3)?;

        assert_eq!(parts, vec![Cents(334), Cents(333), Cents(333)]);
        Ok(())
    }

    #[tokio::test(start_paused = true)]
    async fn gives_up_after_three_retries() {
        let api = FakeApi::always_unavailable();

        let result = fetch_with_retry(&api).await;

        assert!(matches!(result, Err(FetchError::Unavailable)));
        assert_eq!(api.calls(), 3);
    }
}
```

## See Also

These are separate skills; use them if installed.

- `rust-coding-standards` - The code under test: errors, async, types
