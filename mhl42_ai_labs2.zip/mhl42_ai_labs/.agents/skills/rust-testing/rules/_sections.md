# Section Definitions

## Structure (struct)
**Impact:** CRITICAL

Tests in the right place.

**Rules:**
- `struct-unit-and-integration` - Unit tests in the module, integration tests through the public API

## Assertions (assert)
**Impact:** CRITICAL

Failures that explain themselves.

**Rules:**
- `assert-results-and-errors` - Tests return Result; match error variants; assert with messages

## Isolation (iso)
**Impact:** HIGH

No real network or database in unit tests.

**Rules:**
- `iso-trait-fakes` - Depend on traits; test with small hand-written fakes

## Async (async)
**Impact:** HIGH

Deterministic time in async tests.

**Rules:**
- `async-paused-time` - Pause tokio time instead of sleeping

## Property-based (prop)
**Impact:** MEDIUM

Invariants over many inputs.

**Rules:**
- `prop-proptest` - Check invariants over generated inputs with proptest

## Doc tests (doc)
**Impact:** MEDIUM

Examples that keep compiling.

**Rules:**
- `doc-doctests` - Examples in docs compile and run as tests
