---
title: Tests Return Result; Match Error Variants; Assert with Messages
impact: CRITICAL
impactDescription: Failures name the value and the case; wrong errors do not pass as right ones
tags: [assertions, result, errors, matches, should-panic]
---

# Tests Return Result; Match Error Variants; Assert with Messages [CRITICAL]

## Description
A chain of `unwrap()` in a test fails with `called Result::unwrap() on an Err value` and a line number, not the reason. A test that returns `Result<(), E>` can use `?`, and the error is printed when it fails.

For an expected failure, check the variant with `matches!` (and its fields), not only `is_err()`: a different error would pass. `#[should_panic]` without `expected` passes for any panic, including a bug in the setup.

Use `assert_eq!`/`assert_ne!` for values rather than `assert!(a == b)`, so both values are printed, and add a message for context when the values alone are not enough. For errors, do not reach for `assert_eq!(result, Err(MyError::X))`: it needs `PartialEq` on the error, which errors wrapping `io::Error` or a client error cannot derive, and it cannot ignore fields. `matches!` with the result in the message does both.

## Bad Example
```rust
#[test]
fn parses() {
    let order = parse_line("a,2,500").unwrap();
    assert!(order.quantity == 2);
}

#[test]
fn rejects_bad_quantity() {
    assert!(parse_line("a,x,500").is_err());
}

#[test]
#[should_panic]
fn panics_on_empty() { parse_line("").unwrap(); }

#[tokio::test]
async fn gives_up() {
    assert_eq!(send_with_retry(&mailer, msg).await, Err(MailError::GaveUp)); // needs PartialEq on MailError
}
```

## Good Example
```rust
#[test]
fn parses_quantity_and_price() -> Result<(), ParseError> {
    let order = parse_line("a,2,500")?;
    assert_eq!(order.quantity, 2);
    assert_eq!(order.unit_cents, Cents(500));
    Ok(())
}

#[test]
fn rejects_a_non_numeric_quantity() {
    let err = parse_line("a,x,500").unwrap_err();
    assert!(
        matches!(err, ParseError::Field { ref name, .. } if name == "quantity"),
        "expected a quantity field error, got {err:?}"
    );
}

#[tokio::test(start_paused = true)]
async fn gives_up_after_three_retries() {
    let result = send_with_retry(&mailer, msg).await;
    assert!(matches!(result, Err(MailError::GaveUp)), "got {result:?}");
}
```

## Notes
- `pretty_assertions::assert_eq` shows a diff for large structs.
- `insta` snapshots suit large, stable outputs (generated SQL, rendered text) that a reviewer reads in the diff.

## References
- [The Rust Book: writing tests](https://doc.rust-lang.org/book/ch11-01-writing-tests.html)
