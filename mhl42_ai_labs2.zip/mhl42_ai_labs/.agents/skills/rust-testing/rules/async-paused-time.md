---
title: Pause tokio Time Instead of Sleeping
impact: HIGH
impactDescription: Timeouts, retries and intervals are tested instantly and deterministically
tags: [async, tokio, time, flaky, retries]
---

# Pause tokio Time Instead of Sleeping [HIGH]

## Description
A test that waits for a real retry backoff or timeout is slow, and flaky on a loaded CI machine. With tokio's `test-util` feature, `#[tokio::test(start_paused = true)]` starts the runtime with a paused clock: when every task is idle, time jumps to the next timer, so `sleep(Duration::from_secs(60))` completes instantly and in order. `tokio::time::advance` moves time by hand.

This affects `tokio::time` only; code that reads `std::time::Instant::now()` or `SystemTime` directly needs an injected clock.

## Bad Example
```rust
#[tokio::test]
async fn session_expires() {
    let sessions = Sessions::new(Duration::from_millis(50));
    let id = sessions.create();
    tokio::time::sleep(Duration::from_millis(80)).await; // real waiting
    assert!(sessions.get(id).is_none());
}
```

## Good Example
```rust
#[tokio::test(start_paused = true)]
async fn session_expires_after_thirty_minutes() {
    let sessions = Sessions::new(Duration::from_secs(30 * 60));
    let id = sessions.create();

    tokio::time::advance(Duration::from_secs(30 * 60 + 1)).await;

    assert!(sessions.get(id).is_none());
}

#[tokio::test(start_paused = true)]
async fn retries_three_times_with_backoff() {
    let api = FakeApi::always_unavailable();
    let started = tokio::time::Instant::now();

    let result = fetch_with_retry(&api).await;

    assert!(matches!(result, Err(FetchError::Unavailable)));
    assert_eq!(api.calls(), 3);
    assert_eq!(started.elapsed(), Duration::from_secs(1 + 2 + 4));
}
```

```toml
[dev-dependencies]
tokio = { version = "1", features = ["macros", "rt", "time", "test-util"] }
```

## Notes
- Paused time requires the current-thread runtime (the `#[tokio::test]` default).
- Use `tokio::time::Instant` in code that measures elapsed time, so tests can control it.

## References
- [tokio::time::pause](https://docs.rs/tokio/latest/tokio/time/fn.pause.html)
