---
title: Examples in Docs Compile and Run as Tests
impact: MEDIUM
impactDescription: Documentation examples never go stale
tags: [doc-tests, documentation, examples, rustdoc]
---

# Examples in Docs Compile and Run as Tests [MEDIUM]

## Description
Code blocks in `///` doc comments of a library are compiled and run by `cargo test`. An example that shows how to call a public function documents it and tests it at once; when the API changes, the example fails instead of misleading readers. Use `?` in examples (they can return `Result`), hide setup lines with `#`, and mark blocks that must not run with `no_run` (network) or `compile_fail` (to show what the type system forbids).

## Bad Example
```rust
/// Splits a bill. Example: split(1000, 3) gives [334, 333, 333]
pub fn split(total: Cents, people: u32) -> Result<Vec<Cents>, SplitError> { /* ... */ }
```

## Good Example
```rust
/// Splits a bill into `people` parts that add up to `total`, giving the extra cents to the first parts.
///
/// ```
/// # use billing::{split, Cents};
/// # fn main() -> Result<(), billing::SplitError> {
/// let parts = split(Cents(1000), 3)?;
/// assert_eq!(parts, vec![Cents(334), Cents(333), Cents(333)]);
/// # Ok(())
/// # }
/// ```
///
/// # Errors
/// Returns [`SplitError::NoPeople`] when `people` is zero.
pub fn split(total: Cents, people: u32) -> Result<Vec<Cents>, SplitError> { /* ... */ }
```

## Notes
- Doc tests run only for library crates; `cargo nextest` skips them, so CI also runs `cargo test --doc`.
- clippy's `missing_errors_doc` and `missing_panics_doc` (pedantic) ask for the `# Errors` and `# Panics` sections.

## References
- [rustdoc: documentation tests](https://doc.rust-lang.org/rustdoc/write-documentation/documentation-tests.html)
