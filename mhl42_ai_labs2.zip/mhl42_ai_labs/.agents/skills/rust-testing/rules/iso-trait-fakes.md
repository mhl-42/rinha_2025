---
title: Depend on Traits; Test with Small Hand-Written Fakes
impact: HIGH
impactDescription: Unit tests run offline and fast, and read as plain Rust
tags: [isolation, traits, fakes, mocks, dependency-injection]
---

# Depend on Traits; Test with Small Hand-Written Fakes [HIGH]

## Description
Code that calls an HTTP API or a database directly can only be tested against the real thing. Put the dependency behind a small trait with the methods the code uses, take it as a generic parameter (or `&dyn Trait` / `Arc<dyn Trait>`), and give tests a fake: a struct that returns scripted answers and records calls.

A hand-written fake is usually shorter and clearer than a mocking crate; reach for `mockall` when many expectations on call order really matter. Test the real implementation separately, in integration tests against a local server or database.

## Bad Example
```rust
pub async fn quote(sku: &str) -> Result<Cents, QuoteError> {
    let resp = reqwest::get(format!("https://prices.example/{sku}")).await?; // untestable offline
    // ...
}
```

## Good Example
```rust
pub trait PriceSource {
    async fn price(&self, sku: &Sku) -> Result<Cents, PriceError>;
}

pub async fn quote<P: PriceSource>(prices: &P, sku: &Sku, quantity: u32) -> Result<Cents, QuoteError> {
    let unit = prices.price(sku).await?;
    unit.0.checked_mul(u64::from(quantity)).map(Cents).ok_or(QuoteError::TooLarge)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    struct FakePrices { answer: Result<Cents, PriceError>, asked: Mutex<Vec<Sku>> }

    impl PriceSource for FakePrices {
        async fn price(&self, sku: &Sku) -> Result<Cents, PriceError> {
            self.asked.lock().expect("lock").push(sku.clone());
            self.answer.clone()
        }
    }

    #[tokio::test]
    async fn multiplies_the_unit_price() {
        let prices = FakePrices { answer: Ok(Cents(250)), asked: Mutex::new(vec![]) };
        assert_eq!(quote(&prices, &Sku::new("A1"), 4).await, Ok(Cents(1000)));
    }
}
```

## Notes
- Async functions in traits are stable since Rust 1.75; for `dyn` use, the `async-trait` crate or returning boxed futures is still needed.
- For HTTP clients, a local server (`wiremock`, `axum` on port 0) tests the real request building.

## References
- [The Rust Book: traits](https://doc.rust-lang.org/book/ch10-02-traits.html)
- [wiremock crate](https://docs.rs/wiremock)
