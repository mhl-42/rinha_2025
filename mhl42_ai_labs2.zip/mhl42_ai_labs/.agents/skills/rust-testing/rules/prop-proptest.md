---
title: Check Invariants over Generated Inputs with proptest
impact: MEDIUM
impactDescription: Finds the edge cases nobody wrote down, shrunk to the smallest failing input
tags: [property-based, proptest, invariants, parsers]
---

# Check Invariants over Generated Inputs with proptest [MEDIUM]

## Description
Example tests cover the inputs someone imagined. For code with a property that holds for all inputs (a round trip through encode and decode, a sort keeps every element, a split adds up to the total, a parser never panics), generate inputs with `proptest` and check the property. When it fails, proptest shrinks the input to a minimal case and stores the seed in `proptest-regressions/` so it is retried.

## Bad Example
```rust
#[test]
fn round_trips() {
    assert_eq!(decode(&encode("hello")).unwrap(), "hello");
}
```

## Good Example
```rust
use proptest::prelude::*;

proptest! {
    #[test]
    fn encode_then_decode_returns_the_input(text in ".*") {
        prop_assert_eq!(decode(&encode(&text))?, text);
    }

    #[test]
    fn split_parts_add_up_and_differ_by_at_most_one(total in 0u64..10_000_000, people in 1u32..50) {
        let parts = split(Cents(total), people)?;
        prop_assert_eq!(parts.iter().map(|c| c.0).sum::<u64>(), total);
        let max = parts.iter().max().map(|c| c.0).unwrap_or(0);
        let min = parts.iter().min().map(|c| c.0).unwrap_or(0);
        prop_assert!(max - min <= 1);
    }
}
```

## Notes
- Commit `proptest-regressions/`; each file is a case that once failed.
- For parsers of untrusted input, `cargo fuzz` (libFuzzer) explores much more than proptest in a long run.

## References
- [proptest book](https://proptest-rs.github.io/proptest/)
