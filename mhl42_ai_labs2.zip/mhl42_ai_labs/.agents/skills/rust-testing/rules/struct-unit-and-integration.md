---
title: Unit Tests in the Module, Integration Tests Through the Public API
impact: CRITICAL
impactDescription: Internals are tested where they live; the public contract is tested as callers use it
tags: [structure, unit-tests, integration-tests, cfg-test]
---

# Unit Tests in the Module, Integration Tests Through the Public API [CRITICAL]

## Description
Rust has two places for tests, with different purposes:
- **Unit tests** go in a `#[cfg(test)] mod tests` at the bottom of the file they test. They can reach private items, run fast, and are compiled only for tests.
- **Integration tests** go in `tests/`. Each file is a separate crate that sees only the public API, as a user of the crate would. Shared helpers live in `tests/common/mod.rs`.

Name each test after the behaviour it checks (`refuses_an_expired_coupon`), one behaviour per test.

## Bad Example
```rust
#[test]
fn test1() {
    let mut cart = Cart::new();
    cart.add(book(), 2);
    assert_eq!(cart.total(), Cents(5000));
    cart.remove(&book());
    assert_eq!(cart.total(), Cents(0));
    assert!(cart.add(book(), 0).is_err());
}
```

## Good Example
```rust
// src/cart.rs
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn totals_price_times_quantity() {
        let mut cart = Cart::new();
        cart.add(book(), 2).expect("adding a valid line");
        assert_eq!(cart.total(), Cents(5000));
    }

    #[test]
    fn refuses_a_zero_quantity() {
        assert!(matches!(Cart::new().add(book(), 0), Err(CartError::InvalidQuantity(0))));
    }
}

// tests/checkout.rs
#[test]
fn checkout_charges_the_cart_total() {
    let shop = common::shop_with_stock(&[("book", 10)]);
    let receipt = shop.checkout(common::cart_with("book", 2)).expect("checkout succeeds");
    assert_eq!(receipt.charged, Cents(5000));
}
```

## Notes
- A binary crate is easier to test when its logic lives in `src/lib.rs` and `main.rs` only calls it.
- Test-only dependencies go in `[dev-dependencies]`.

## References
- [The Rust Book: test organization](https://doc.rust-lang.org/book/ch11-03-test-organization.html)
