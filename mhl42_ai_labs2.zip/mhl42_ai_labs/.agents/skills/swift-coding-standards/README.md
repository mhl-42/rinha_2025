# Swift Coding Standards

Rules for AI agents writing Swift: no force unwraps, typed and surfaced errors, Swift 6 strict concurrency and task lifetimes, SwiftUI observation and state ownership, access control, some versus any, the Keychain, networking and the privacy manifest.

## Overview

This skill provides 10 rules across 8 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Optionals | `opt-` | CRITICAL | 1 |
| Errors | `err-` | CRITICAL | 1 |
| Concurrency | `conc-` | CRITICAL | 2 |
| State | `state-` | HIGH | 1 |
| Access | `access-` | HIGH | 1 |
| Types | `types-` | MEDIUM | 1 |
| Security | `sec-` | HIGH | 2 |
| App Store | `app-` | MEDIUM | 1 |

## Structure

```
skills/swift-coding-standards/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from `swift-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files; callback-era rules (Result for async callbacks, `[weak self]` in every closure) replaced by structured concurrency and task cancellation.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
