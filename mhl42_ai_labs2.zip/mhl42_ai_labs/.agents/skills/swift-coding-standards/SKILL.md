---
name: swift-coding-standards
description: Use this skill when writing, reviewing, or refactoring Swift code for iOS, macOS or server apps — optionals and force unwraps, error handling and typed throws, Swift 6 strict concurrency (Sendable, actors, @MainActor), async/await and Task lifetimes, SwiftUI state (@Observable, @State, @Environment), access control, secrets and the Keychain, networking and App Transport Security, and the privacy manifest — even if the user only says "add a screen", "fix this crash", or "this view model has a data race warning". Not for tests (use swift-testing) or code in other languages.
license: MIT
compatibility: Swift 6 language mode (Xcode 16+); the rules hold in Swift 5 mode with strict concurrency checking on. SwiftUI observation examples need iOS 17 / macOS 14 or later; typed throws needs Swift 6.
metadata:
  author: mhl42 (adapted from 0xMassi/Codex-skills, MIT)
  version: "1.1.0"
---

# Swift Coding Standards

Rules for AI agents writing Swift that does not crash on a nil, does not race, and keeps secrets out of plain storage. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing code**: unwrap with `guard`, throw typed errors, keep shared mutable state in actors and UI state on the main actor, and tie every task to a lifetime. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `value!`, `try!`, `as!`, implicitly unwrapped `Type!` properties outside outlets | [opt-no-force-unwrap](rules/opt-no-force-unwrap.md) |
| `try?` on saves or payments; `catch { print(error) }`; errors shown as `error.localizedDescription` of a raw error | [err-typed-and-surfaced](rules/err-typed-and-surfaced.md) |
| Concurrency warnings; classes shared across tasks; `DispatchQueue` locks; `@unchecked Sendable`; `nonisolated(unsafe)` | [conc-strict-concurrency](rules/conc-strict-concurrency.md) |
| `Task { }` stored nowhere; `Task.detached`; loops without cancellation checks; `[weak self]` everywhere or nowhere | [conc-task-lifetimes](rules/conc-task-lifetimes.md) |
| `ObservableObject` with `@Published` in iOS 17+ code; `@StateObject`/`@ObservedObject` mixups; state duplicated between views | [state-observation](rules/state-observation.md) |
| Everything `internal` or `public` by default; non-final classes; classes where a struct would do | [access-control](rules/access-control.md) |
| Tokens or passwords in `UserDefaults`, `@AppStorage`, plist files or source | [sec-keychain](rules/sec-keychain.md) |
| `NSAllowsArbitraryLoads`; URLs built from strings with user input; `URLSession` without timeouts | [sec-network](rules/sec-network.md) |
| `any Protocol` returned from functions; existential parameters on hot paths | [types-some-any](rules/types-some-any.md) |
| Uses of `UserDefaults`, file timestamps, disk space or system boot time in an app without `PrivacyInfo.xcprivacy` | [app-privacy-manifest](rules/app-privacy-manifest.md) |

### Review Checklist

- [ ] No `!`, `try!` or `as!` on values that can be absent at runtime
- [ ] Errors are typed, shown to the user in words they understand, and never dropped with `try?` on important work
- [ ] The target builds in Swift 6 mode (or with complete concurrency checking) with no warnings
- [ ] Every `Task` has an owner that cancels it; long loops check `Task.isCancelled`
- [ ] SwiftUI state has one owner; views receive what they read
- [ ] Secrets live in the Keychain; ATS has no blanket exceptions
- [ ] The privacy manifest declares every required-reason API the app and its SDKs use

## Gotchas

- `try?` turns every error into `nil`: a failed save looks like "nothing to save". Use it only when absence really is the answer.
- `@MainActor` on a type isolates its methods, but a closure passed to a non-isolated API runs wherever that API calls it; in Swift 6 the compiler checks this, in Swift 5 mode it may not.
- `Task { }` inherits the actor of where it is created; `Task.detached` inherits nothing, not even priority or task-locals. Prefer the first.
- A `Task` stored in a property keeps `self` alive until it finishes; cancel it in `deinit` or when the view disappears, or use SwiftUI's `.task`, which cancels on disappear.
- `[weak self]` in a `Task` closure does not stop the work; it only avoids keeping `self` alive. Cancellation stops the work.
- `@Observable` tracks the properties a view reads in `body`; reading a property in an `init` or a helper outside `body` does not subscribe to it.
- `@State` initializes once per view identity; passing a new value into a view's `init` does not reset it.
- `URLSession.shared` has a 60-second request timeout and retries nothing; set timeouts per request for user-facing calls.
- `UserDefaults` is a plain plist in the app container, readable from backups and on jailbroken devices.

## Categories

### Safety [CRITICAL]
No crashes on absent values; no silent failures.

| Rule | Description |
|------|-------------|
| [opt-no-force-unwrap](rules/opt-no-force-unwrap.md) | Unwrap with guard and if let; no !, try! or as! on runtime values |
| [err-typed-and-surfaced](rules/err-typed-and-surfaced.md) | Typed errors, user-facing messages, no try? on important work |

### Concurrency [CRITICAL]
Data-race freedom checked by the compiler.

| Rule | Description |
|------|-------------|
| [conc-strict-concurrency](rules/conc-strict-concurrency.md) | Swift 6 mode, Sendable values, actors for shared state, @MainActor for UI |
| [conc-task-lifetimes](rules/conc-task-lifetimes.md) | Structured tasks with an owner and cancellation |

### State and API Design [HIGH]
One owner per piece of state; small public surfaces.

| Rule | Description |
|------|-------------|
| [state-observation](rules/state-observation.md) | @Observable models, @State ownership, @Environment injection |
| [access-control](rules/access-control.md) | private by default, final classes, value types first |
| [types-some-any](rules/types-some-any.md) | some for opaque results and parameters, any only for storage |

### Security and Privacy [HIGH]
Secrets in the Keychain, traffic over TLS, APIs declared.

| Rule | Description |
|------|-------------|
| [sec-keychain](rules/sec-keychain.md) | Store secrets in the Keychain, never in UserDefaults or source |
| [sec-network](rules/sec-network.md) | ATS without exceptions, URLs built with URLComponents, explicit timeouts |
| [app-privacy-manifest](rules/app-privacy-manifest.md) | Declare required-reason APIs and tracking in PrivacyInfo.xcprivacy |

## Quick Reference

The model already applies the common rules of this skill unprompted (guard let instead of !, LocalizedError, @MainActor view models, the Keychain for tokens). The examples below are the ones it tends to miss.

```swift
// A search that cancels the previous request on every keystroke, debounced, with an explicit timeout.
struct SearchView: View {
    @State private var model = SearchModel()
    var body: some View {
        List(model.results) { Text($0.title) }
            .searchable(text: $model.query)
            .task(id: model.query) {                      // cancelled when query changes or the view goes away
                try? await Task.sleep(for: .milliseconds(300))
                guard !Task.isCancelled else { return }
                await model.search()
            }
    }
}

@MainActor
@Observable
final class SearchModel {
    var query = ""
    private(set) var results: [Item] = []
    private(set) var error: SearchError?

    func search() async {
        var components = URLComponents(string: "https://api.example.com/search")
        components?.queryItems = [URLQueryItem(name: "q", value: query)]
        guard let url = components?.url else { error = .invalidQuery; return }
        do {
            let (data, _) = try await URLSession.shared.data(for: URLRequest(url: url, timeoutInterval: 15))
            results = try JSONDecoder().decode([Item].self, from: data)
        } catch is CancellationError {
            return                                         // a newer query took over
        } catch let urlError as URLError where urlError.code == .cancelled {
            return
        } catch {
            self.error = .server
        }
    }
}
```

## See Also

These are separate skills; use them if installed.

- `swift-testing` - Swift Testing (@Test, #expect), fakes, async and main-actor tests
