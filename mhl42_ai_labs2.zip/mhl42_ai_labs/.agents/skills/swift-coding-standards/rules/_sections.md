# Section Definitions

## Optionals (opt)
**Impact:** CRITICAL

No crashes on absent values.

**Rules:**
- `opt-no-force-unwrap` - Unwrap with guard and if let; no !, try! or as! on runtime values

## Errors (err)
**Impact:** CRITICAL

No silent failures.

**Rules:**
- `err-typed-and-surfaced` - Typed errors, user-facing messages, no try? on important work

## Concurrency (conc)
**Impact:** CRITICAL

Data-race freedom checked by the compiler.

**Rules:**
- `conc-strict-concurrency` - Swift 6 mode, Sendable values, actors for shared state, @MainActor for UI
- `conc-task-lifetimes` - Structured tasks with an owner and cancellation

## State (state)
**Impact:** HIGH

One owner per piece of state.

**Rules:**
- `state-observation` - @Observable models, @State ownership, @Environment injection

## Access (access)
**Impact:** HIGH

Small public surfaces.

**Rules:**
- `access-control` - private by default, final classes, value types first

## Types (types)
**Impact:** MEDIUM

Static dispatch where it is free.

**Rules:**
- `types-some-any` - some for opaque results and parameters, any only for storage

## Security (sec)
**Impact:** HIGH

Secrets in the Keychain, traffic over TLS.

**Rules:**
- `sec-keychain` - Store secrets in the Keychain, never in UserDefaults or source
- `sec-network` - ATS without exceptions, URLs built with URLComponents, explicit timeouts

## App Store (app)
**Impact:** MEDIUM

What review requires.

**Rules:**
- `app-privacy-manifest` - Declare required-reason APIs and tracking in PrivacyInfo.xcprivacy
