---
title: private by Default, final Classes, Value Types First
impact: HIGH
impactDescription: Smaller surfaces to break, faster dispatch, and fewer shared-mutation bugs
tags: [access-control, final, structs, api-design]
---

# private by Default, final Classes, Value Types First [HIGH]

## Description
Swift's default access level is `internal`, so every property and helper is visible to the whole module unless marked otherwise. Start with `private`, widen to `fileprivate`, `internal` or `public` when a caller needs it, and expose state read-only with `private(set)`.

Mark classes `final` unless they are designed for subclassing: the compiler can then dispatch statically, and nobody overrides a method that was never meant to be. Prefer structs and enums for data: copies cannot be mutated behind your back and are `Sendable` for free.

## Bad Example
```swift
class SessionManager {
    var token: String?
    var refreshTimer: Timer?
    func refreshIfNeeded() { /* ... */ }
    func parseExpiry(_ jwt: String) -> Date? { /* ... */ }
}
```

## Good Example
```swift
final class SessionManager {
    private(set) var token: Token?
    private var refreshTask: Task<Void, Never>?

    func refreshIfNeeded() async { /* ... */ }

    private func expiry(of jwt: String) -> Date? { /* ... */ }
}

struct Token: Sendable, Equatable {
    let value: String
    let expiresAt: Date
}
```

## Notes
- In packages, `package` access (Swift 5.9+) shares code between modules of the package without making it `public`.
- SwiftLint has no rule for "final by default"; review for it.

## References
- [The Swift Programming Language: access control](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/accesscontrol/)
