---
title: Declare Required-Reason APIs and Tracking in PrivacyInfo.xcprivacy
impact: MEDIUM
impactDescription: App Store submissions are not rejected, and the privacy label matches what the app does
tags: [privacy, app-store, privacy-manifest, required-reason-api]
---

# Declare Required-Reason APIs and Tracking in PrivacyInfo.xcprivacy [MEDIUM]

## Description
Apple requires a privacy manifest (`PrivacyInfo.xcprivacy`) in apps and in third-party SDKs that declares the data collected, whether it is used for tracking, the tracking domains, and a reason for each use of "required reason" APIs: `UserDefaults`, file timestamps, system boot time, disk space and active keyboards. Submissions that use those APIs without a declared reason are rejected.

When code starts using one of those APIs, or an SDK is added, update the manifest in the same change.

## Bad Example
```swift
// Uses UserDefaults and reads file modification dates; the app has no PrivacyInfo.xcprivacy.
let lastSync = UserDefaults.standard.object(forKey: "lastSync") as? Date
let modified = try FileManager.default.attributesOfItem(atPath: path)[.modificationDate] as? Date
```

## Good Example
```swift
// PrivacyInfo.xcprivacy (property list), in the app target:
// NSPrivacyAccessedAPITypes:
//   - NSPrivacyAccessedAPIType: NSPrivacyAccessedAPICategoryUserDefaults
//     NSPrivacyAccessedAPITypeReasons: [CA92.1]   (data the app itself reads and writes)
//   - NSPrivacyAccessedAPIType: NSPrivacyAccessedAPICategoryFileTimestamp
//     NSPrivacyAccessedAPITypeReasons: [C617.1]   (timestamps of files inside the app container)
// NSPrivacyTracking: false
let lastSync = UserDefaults.standard.object(forKey: "lastSync") as? Date
```

## Notes
- Check the current list of API categories and reason codes in Apple's documentation; codes are specific to the use.
- Xcode's privacy report (Product → Archive → Generate Privacy Report) merges the app's and the SDKs' manifests.

## References
- [Apple: Privacy manifest files](https://developer.apple.com/documentation/bundleresources/privacy-manifest-files)
- [Apple: Describing use of required reason API](https://developer.apple.com/documentation/bundleresources/describing-use-of-required-reason-api)
