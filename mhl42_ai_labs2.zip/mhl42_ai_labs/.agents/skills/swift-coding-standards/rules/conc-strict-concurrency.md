---
title: Swift 6 Mode, Sendable Values, Actors for Shared State, @MainActor for UI
impact: CRITICAL
impactDescription: The compiler proves the absence of data races instead of a crash report finding them
tags: [concurrency, swift6, sendable, actors, mainactor]
---

# Swift 6 Mode, Sendable Values, Actors for Shared State, @MainActor for UI [CRITICAL]

## Description
The Swift 6 language mode turns data-race checks into errors: values crossing between tasks or actors must be `Sendable`, and mutable state is accessed only from its isolation domain. Build new targets in Swift 6 mode; for an existing target, enable complete concurrency checking in Swift 5 mode and fix the warnings first.

- **Value types** (structs and enums of Sendable fields) are Sendable for free; prefer them for data that crosses tasks.
- **Shared mutable state** lives in an `actor`, not in a class guarded by a `DispatchQueue` or a lock.
- **UI state and view models** are `@MainActor`.
- `@unchecked Sendable` and `nonisolated(unsafe)` turn the checks off; each use needs a comment proving why it is safe, as with `unsafe` code.

## Bad Example
```swift
final class ImageCache {
    private var images: [URL: UIImage] = [:]
    private let queue = DispatchQueue(label: "cache")

    func image(for url: URL) -> UIImage? { queue.sync { images[url] } }
    func store(_ image: UIImage, for url: URL) { images[url] = image } // forgot the queue: a race
}

final class ProfileViewModel: ObservableObject, @unchecked Sendable {
    @Published var name = "" // written from a background task
}
```

## Good Example
```swift
actor ImageCache {
    private var images: [URL: Data] = [:]

    func data(for url: URL) -> Data? { images[url] }
    func store(_ data: Data, for url: URL) { images[url] = data }
}

@MainActor
@Observable
final class ProfileViewModel {
    private(set) var name = ""
    private let api: any ProfileAPI

    init(api: any ProfileAPI) { self.api = api }

    func load() async throws {
        let profile = try await api.profile() // runs off the main actor inside the API
        name = profile.name                   // back on the main actor
    }
}
```

## Notes
- Swift 6.2's "approachable concurrency" settings (default main-actor isolation for app targets, `nonisolated(nonsending)` by default) reduce annotations; check which the project enables before adding or removing `@MainActor`.
- Avoid actor reentrancy bugs: state read before an `await` inside an actor may have changed after it.

## References
- [Swift 6 migration guide](https://www.swift.org/migration/documentation/migrationguide/)
- [The Swift Programming Language: concurrency](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/)
