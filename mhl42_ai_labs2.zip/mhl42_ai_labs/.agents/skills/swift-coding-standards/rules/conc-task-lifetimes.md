---
title: Structured Tasks with an Owner and Cancellation
impact: CRITICAL
impactDescription: Work stops when its screen or caller goes away; no leaked tasks or stale updates
tags: [concurrency, task, cancellation, task-group, swiftui]
---

# Structured Tasks with an Owner and Cancellation [CRITICAL]

## Description
Prefer structured concurrency: `async let` and `withThrowingTaskGroup` run child tasks that are awaited and cancelled with their parent. An unstructured `Task { }` runs until it finishes unless someone keeps it and cancels it. In SwiftUI, `.task { }` and `.task(id:)` start work tied to the view and cancel it on disappear or when the id changes.

Cancellation is cooperative: long loops check `try Task.checkCancellation()` or `Task.isCancelled`; system APIs like `URLSession` and `Task.sleep` stop on their own. `[weak self]` does not stop work; it only avoids extending `self`'s life. Use it for long-lived closures that outlive their owner, and cancel the task in any case.

`Task.detached` drops the actor, priority and task-local values; use it only for work that must not inherit them.

## Bad Example
```swift
struct SearchView: View {
    @State private var model = SearchModel()
    var body: some View {
        TextField("Search", text: $model.query)
            .onChange(of: model.query) {
                Task { await model.search() } // every keystroke starts a search nobody cancels
            }
    }
}

func importAll(_ files: [URL]) async throws {
    for file in files {
        Task { try await importFile(file) } // unstructured, errors lost, not awaited
    }
}
```

## Good Example
```swift
struct SearchView: View {
    @State private var model = SearchModel()
    var body: some View {
        TextField("Search", text: $model.query)
            .task(id: model.query) {
                try? await Task.sleep(for: .milliseconds(300)) // debounce; cancelled when query changes
                guard !Task.isCancelled else { return }
                await model.search()
            }
    }
}

func importAll(_ files: [URL]) async throws {
    try await withThrowingTaskGroup(of: Void.self) { group in
        for file in files {
            group.addTask { try await importFile(file) }
        }
        try await group.waitForAll()
    }
}
```

## Notes
- A `Task` stored in a property is cancelled in `deinit` or when the owner stops; otherwise it keeps running and keeps `self` alive.
- Limit concurrency in task groups for large inputs (add tasks as earlier ones finish).

## References
- [Apple: Task](https://developer.apple.com/documentation/swift/task)
- [Apple: task(id:priority:_:)](https://developer.apple.com/documentation/swiftui/view/task(id:priority:_:))
