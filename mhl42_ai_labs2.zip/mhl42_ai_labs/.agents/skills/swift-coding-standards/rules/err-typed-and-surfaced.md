---
title: Typed Errors, User-Facing Messages, No try? on Important Work
impact: CRITICAL
impactDescription: Failures reach the user in plain words and the logs with detail, instead of disappearing
tags: [errors, throws, typed-throws, localized-error, try]
---

# Typed Errors, User-Facing Messages, No try? on Important Work [CRITICAL]

## Description
Define an `Error` enum per feature, with one case per situation the caller or the user must tell apart, and associated values for the details. Conform to `LocalizedError` so the UI shows a sentence the user understands, not "The operation couldn't be completed (NSURLErrorDomain error -1009)". Log the underlying error with its detail separately.

`try?` replaces every error with `nil`. On a save, a payment or a sync, the failure disappears and the app behaves as if nothing happened. Use `do`/`catch` and handle or rethrow.

Swift 6 typed throws (`throws(ValidationError)`) fit closed sets of errors in a module, where callers switch over every case; for code that calls other libraries, untyped `throws` stays more flexible.

## Bad Example
```swift
func save(_ note: Note) {
    try? store.write(note) // a full disk looks like success
}

do {
    try await api.sync()
} catch {
    print(error)
}
```

## Good Example
```swift
enum NoteError: Error, LocalizedError {
    case diskFull
    case conflict(serverVersion: Int)

    var errorDescription: String? {
        switch self {
        case .diskFull: "There is no space left to save this note."
        case .conflict: "This note was changed on another device. Review the changes to continue."
        }
    }
}

func save(_ note: Note) throws(NoteError) {
    do {
        try store.write(note)
    } catch let error as CocoaError where error.code == .fileWriteOutOfSpace {
        throw .diskFull
    } catch {
        logger.error("saving note \(note.id, privacy: .public) failed: \(error)")
        throw .diskFull
    }
}
```

## Notes
- `Logger` from `os` marks interpolated values private by default in release logs; mark ids `.public` only when they are not personal data.
- `try?` is right when absence is the answer: `try? container.decodeIfPresent(...)` for an optional field, a cache read.

## References
- [Swift Evolution SE-0413: typed throws](https://github.com/swiftlang/swift-evolution/blob/main/proposals/0413-typed-throws.md)
- [Apple: LocalizedError](https://developer.apple.com/documentation/foundation/localizederror)
