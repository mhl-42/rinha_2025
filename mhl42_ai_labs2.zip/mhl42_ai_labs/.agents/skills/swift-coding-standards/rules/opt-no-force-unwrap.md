---
title: Unwrap with guard and if let; No !, try! or as! on Runtime Values
impact: CRITICAL
impactDescription: An absent value or a failed cast is handled instead of crashing the app
tags: [optionals, force-unwrap, guard, crashes]
---

# Unwrap with guard and if let; No !, try! or as! on Runtime Values [CRITICAL]

## Description
`value!`, `try!` and `as!` crash the app when the value is `nil`, the call throws, or the cast fails. On anything that depends on the outside world (a server response, a file, user input, a URL built from data, a dictionary lookup) that is a crash report waiting for the first unusual case.

Use `guard let` to exit early and keep the happy path unindented, `if let` for a value used in one branch, `??` for a real default, and `as?` for casts. A literal that is known at compile time (a URL constant) may be unwrapped once, where it is defined, with a message.

## Bad Example
```swift
let user = users.first(where: { $0.id == id })!
let data = try! JSONEncoder().encode(order)
let cell = tableView.dequeueReusableCell(withIdentifier: "Order") as! OrderCell
let url = URL(string: "https://api.example.com/orders/\(query)")!
```

## Good Example
```swift
guard let user = users.first(where: { $0.id == id }) else {
    throw LookupError.userNotFound(id)
}

let data = try JSONEncoder().encode(order)

guard let cell = tableView.dequeueReusableCell(withIdentifier: "Order") as? OrderCell else {
    preconditionFailure("Order cell is not registered") // a programmer error, found in development
}

static let baseURL = URL(string: "https://api.example.com")! // a literal, checked once
```

## Notes
- Implicitly unwrapped optionals (`var name: String!`) are acceptable only for Interface Builder outlets and two-phase initialization that the framework guarantees.
- SwiftLint's `force_unwrapping`, `force_try` and `force_cast` rules find these.

## References
- [The Swift Programming Language: optionals](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Optionals)
