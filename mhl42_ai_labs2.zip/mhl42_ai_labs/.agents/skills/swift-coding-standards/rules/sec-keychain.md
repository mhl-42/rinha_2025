---
title: Store Secrets in the Keychain, Never in UserDefaults or Source
impact: HIGH
impactDescription: Tokens and passwords are encrypted at rest and stay out of backups and the binary
tags: [security, keychain, userdefaults, secrets, tokens]
---

# Store Secrets in the Keychain, Never in UserDefaults or Source [HIGH]

## Description
`UserDefaults` and `@AppStorage` write a plain property list into the app container; anyone with a device backup or a jailbroken device can read it. Access tokens, refresh tokens and passwords go into the Keychain, with an accessibility class that matches their use (`kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly` for a token a background refresh needs).

API keys compiled into the app are extractable from the binary, obfuscated or not. A key that must stay secret lives on your server, which calls the third party on the app's behalf.

## Bad Example
```swift
UserDefaults.standard.set(session.refreshToken, forKey: "refreshToken")

enum Config {
    static let stripeSecretKey = "sk_live_51H..."
}
```

## Good Example
```swift
enum Keychain {
    static func save(_ value: Data, account: String) throws {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: Bundle.main.bundleIdentifier ?? "app",
            kSecAttrAccount as String: account,
        ]
        SecItemDelete(query as CFDictionary)
        var attributes = query
        attributes[kSecValueData as String] = value
        attributes[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let status = SecItemAdd(attributes as CFDictionary, nil)
        guard status == errSecSuccess else { throw KeychainError.unhandled(status) }
    }
}

try Keychain.save(Data(session.refreshToken.utf8), account: "refreshToken")
```

## Notes
- Clear Keychain items on sign-out; they survive app deletion on iOS unless removed.
- A publishable key (Stripe `pk_`, a maps key restricted by bundle id) may ship in the app; a secret key may not.

## References
- [Apple: Keychain services](https://developer.apple.com/documentation/security/keychain-services)
