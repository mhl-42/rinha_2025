---
title: ATS Without Exceptions, URLs Built with URLComponents, Explicit Timeouts
impact: HIGH
impactDescription: Traffic stays encrypted, user input cannot reshape URLs, and requests fail fast
tags: [security, networking, ats, urlsession, urls]
---

# ATS Without Exceptions, URLs Built with URLComponents, Explicit Timeouts [HIGH]

## Description
App Transport Security blocks plain HTTP and weak TLS. `NSAllowsArbitraryLoads` turns that off for every domain; if one legacy host needs an exception, scope it to that host in `NSExceptionDomains`, and plan to remove it.

A URL built by string interpolation with user input can gain extra path segments, query parameters or another host. Build URLs with `URLComponents` and `URLQueryItem`, which encode each part. Before opening a URL that came from content (a deep link, a message), check its scheme and host.

`URLSession` waits 60 seconds per request by default; a user-facing call needs a shorter, explicit timeout and a message when it expires.

## Bad Example
```swift
let url = URL(string: "https://api.example.com/search?q=\(query)&page=\(page)")!
let (data, _) = try await URLSession.shared.data(from: url)

if let link = URL(string: message.link) { UIApplication.shared.open(link) }
```

## Good Example
```swift
var components = URLComponents(string: "https://api.example.com/search")
components?.queryItems = [URLQueryItem(name: "q", value: query), URLQueryItem(name: "page", value: String(page))]
guard let url = components?.url else { throw SearchError.invalidQuery }

var request = URLRequest(url: url, timeoutInterval: 15)
let (data, response) = try await session.data(for: request)
guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
    throw SearchError.server
}

if let link = URL(string: message.link), link.scheme == "https", allowedHosts.contains(link.host() ?? "") {
    await UIApplication.shared.open(link)
}
```

## Notes
- Certificate pinning adds protection for high-risk apps and an outage risk when certificates rotate; pin public keys and ship a backup key.
- Decode responses into `Decodable` types and validate values before using them.

## References
- [Apple: Preventing insecure network connections](https://developer.apple.com/documentation/security/preventing-insecure-network-connections)
- [Apple: URLComponents](https://developer.apple.com/documentation/foundation/urlcomponents)
