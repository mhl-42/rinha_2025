---
title: "@Observable Models, @State Ownership, @Environment Injection"
impact: HIGH
impactDescription: Views update exactly when the data they read changes, and state has one source of truth
tags: [swiftui, observation, state, environment]
---

# @Observable Models, @State Ownership, @Environment Injection [HIGH]

## Description
On iOS 17 / macOS 14 and later, the `@Observable` macro replaces `ObservableObject` and `@Published`: views re-render only when a property they read in `body` changes, instead of on every published change. Ownership follows from where the model is created:
- the view that creates a model owns it with `@State`;
- a child that only reads gets it as a plain property; one that edits a value gets `@Bindable` or a `Binding`;
- app-wide dependencies (a session, a service) are injected with `.environment(...)` and read with `@Environment(Type.self)`.

Keep one source of truth: a value copied into a child's `@State` stops following the parent.

## Bad Example
```swift
final class CartModel: ObservableObject {
    @Published var lines: [Line] = []
    @Published var coupon: String = ""
}

struct CartView: View {
    @ObservedObject var model = CartModel() // recreated whenever the parent re-renders
    var body: some View { LineList(lines: model.lines) }
}

struct LineList: View {
    @State var lines: [Line] // a copy that no longer follows the cart
    var body: some View { List(lines) { Text($0.name) } }
}
```

## Good Example
```swift
@MainActor
@Observable
final class CartModel {
    var lines: [Line] = []
    var coupon = ""
}

struct CartView: View {
    @State private var model = CartModel()
    var body: some View {
        LineList(lines: model.lines)
        CouponField(model: model)
    }
}

struct LineList: View {
    let lines: [Line]
    var body: some View { List(lines) { Text($0.name) } }
}

struct CouponField: View {
    @Bindable var model: CartModel
    var body: some View { TextField("Coupon", text: $model.coupon) }
}
```

## Notes
- Projects that support iOS 16 or earlier keep `ObservableObject`; then `@StateObject` owns and `@ObservedObject` borrows.
- Mark properties the view must not observe with `@ObservationIgnored`.

## References
- [Apple: Migrating from ObservableObject to the Observable macro](https://developer.apple.com/documentation/swiftui/migrating-from-the-observable-object-protocol-to-the-observable-macro)
