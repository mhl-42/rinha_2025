---
title: some for Opaque Results and Parameters, any Only for Storage
impact: MEDIUM
impactDescription: Static dispatch and full type information where an existential adds nothing
tags: [types, generics, some, any, existentials]
---

# some for Opaque Results and Parameters, any Only for Storage [MEDIUM]

## Description
`any Shape` is an existential: a box that can hold any conforming type, with dynamic dispatch and a size the compiler does not know. `some Shape` is one specific type that the compiler knows and the caller does not. Use `some` for return types and parameters (`func draw(_ shape: some Shape)` is a generic function), and `any` where different conforming types must be stored together (an array of mixed shapes, a property that can be swapped for a fake).

## Bad Example
```swift
func makeFormatter() -> any Formatter { CurrencyFormatter() }

func render(_ items: [any Renderable]) { /* all items are the same type here */ }
```

## Good Example
```swift
func makeFormatter() -> some Formatter { CurrencyFormatter() }

func render(_ items: [some Renderable]) { /* one concrete type, statically dispatched */ }

final class OrderService {
    private let payments: any PaymentService // swapped for a fake in tests
    init(payments: any PaymentService) { self.payments = payments }
}
```

## Notes
- `some` in parameter position needs Swift 5.7+.
- Protocols with associated types can be used as `any P<Concrete>` with primary associated types.

## References
- [The Swift Programming Language: opaque and boxed types](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/opaquetypes/)
