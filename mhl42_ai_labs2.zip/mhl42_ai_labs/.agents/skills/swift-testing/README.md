# Swift Testing

Rules for AI agents writing tests with the Swift Testing framework: named and parameterized tests, #require and expected errors, protocol fakes and URLProtocol stubs, async confirmations, and state isolation for parallel runs.

## Overview

This skill provides 5 rules across 5 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Structure | `struct-` | CRITICAL | 1 |
| Assertions | `assert-` | CRITICAL | 1 |
| Isolation | `iso-` | HIGH | 1 |
| Async | `async-` | HIGH | 1 |
| State | `state-` | HIGH | 1 |

## Structure

```
skills/swift-testing/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Origin

Adapted from the Swift part of `testing-patterns` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT), split into rule files, with confirmations, URLProtocol stubs and parallel-safety added.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
