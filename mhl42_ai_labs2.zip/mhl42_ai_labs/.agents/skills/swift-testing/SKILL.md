---
name: swift-testing
description: Use this skill when writing, reviewing, or fixing Swift tests — the Swift Testing framework (@Test and @Suite, the expect and require macros, parameterized tests, traits), migrating from XCTest, testing thrown errors, async code and events, @MainActor view models, protocol-based fakes and URLProtocol stubs, and suites that share state — even if the user only says "add tests for this view model", "this test is flaky", or "test the login flow". Not for application code (use swift-coding-standards), UI tests with XCUITest, or tests in other languages.
license: MIT
compatibility: Swift Testing ships with Xcode 16+ and Swift 6 toolchains; on Linux it is part of the Swift 6 toolchain. XCTest notes apply to projects that have not migrated.
metadata:
  author: mhl42 (adapted from 0xMassi/Codex-skills, MIT)
  version: "1.0.1"
---

# Swift Testing

Rules for AI agents writing Swift tests with the Swift Testing framework. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing tests**: `@Test` functions with readable names, `#expect` for checks and `#require` for preconditions, parameterized arguments instead of copies, fakes behind protocols, and awaited async code. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below and open the matching rule. Then break the code on purpose and check that a test fails.

| When the test contains... | Read |
|---------------------------|------|
| `XCTAssert*` in new tests; copy-pasted tests differing in inputs; names like `testExample` | [struct-swift-testing](rules/struct-swift-testing.md) |
| `try!` or force unwraps in tests; `do/catch` with `Issue.record` to test an error; `XCTAssertThrowsError` | [assert-require-and-throws](rules/assert-require-and-throws.md) |
| Real network calls; singletons used directly by the code under test | [iso-protocol-fakes](rules/iso-protocol-fakes.md) |
| `Task.sleep` in tests; `XCTestExpectation` with waits; callbacks tested with flags | [async-confirmations](rules/async-confirmations.md) |
| View models tested off the main actor; tests sharing a database or defaults that fail in parallel | [state-isolation](rules/state-isolation.md) |

### Review Checklist

- [ ] Each test has a display name or a function name that states a behaviour
- [ ] Preconditions use `#require`; checks use `#expect`; errors are expected by type or case
- [ ] No real network; dependencies are fakes behind protocols
- [ ] No sleeping; async events use `confirmation` or awaited calls
- [ ] Suites pass in parallel (the default) or are explicitly `.serialized` with a reason

## Gotchas

- Swift Testing runs tests in parallel by default, including tests in different suites; shared singletons and `UserDefaults.standard` make them interfere.
- A `@Suite` struct is instantiated once per test: stored properties set up in `init` are fresh for each test, which replaces `setUp`.
- `#expect(a == b)` shows both values on failure; `#expect(a.isEmpty == false)` shows only `false`. Write the expression you would read.
- `#require` stops the test when it fails; `#expect` records the issue and continues.
- XCTest and Swift Testing can live in the same target; migrate file by file. Do not call `XCTAssert` inside a `@Test`.
- `@MainActor` on a test function or suite runs it on the main actor; a view model isolated to the main actor needs it.

## Categories

### Structure [CRITICAL]
Readable, parameterized tests with precise expectations.

| Rule | Description |
|------|-------------|
| [struct-swift-testing](rules/struct-swift-testing.md) | @Test with names and arguments; #expect on plain expressions |
| [assert-require-and-throws](rules/assert-require-and-throws.md) | #require for preconditions; #expect(throws:) for errors |

### Isolation [HIGH]
Fast, independent, deterministic tests.

| Rule | Description |
|------|-------------|
| [iso-protocol-fakes](rules/iso-protocol-fakes.md) | Inject dependencies behind protocols; stub URLSession with URLProtocol |
| [async-confirmations](rules/async-confirmations.md) | Await async code; use confirmation for events, never sleep |
| [state-isolation](rules/state-isolation.md) | Fresh state per test; @MainActor where the code is; serialize only with a reason |

## Quick Reference

```swift
import Testing
@testable import Shop

@MainActor
@Suite("Checkout")
struct CheckoutTests {
    let payments = FakePayments()
    let model: CheckoutModel

    init() { model = CheckoutModel(payments: payments) }

    @Test("pays a cart and keeps the receipt")
    func paysCart() async throws {
        payments.result = .success(Receipt(id: "r-1"))

        await model.pay(Cart(lines: [.book]))

        let receipt = try #require(model.receipt)
        #expect(receipt.id == "r-1")
    }

    @Test("refuses an empty cart without charging")
    func emptyCart() async {
        await model.pay(Cart(lines: []))

        #expect(model.error as? CheckoutError == .cartEmpty)
        #expect(payments.charges.isEmpty)
    }

    @Test("formats amounts in reais", arguments: [(0, "R$ 0,00"), (1050, "R$ 10,50"), (123456, "R$ 1.234,56")])
    func formats(cents: Int, expected: String) {
        #expect(Money(cents: cents).formatted(locale: Locale(identifier: "pt_BR")) == expected)
    }
}
```

## See Also

These are separate skills; use them if installed.

- `swift-coding-standards` - The code under test: optionals, errors, concurrency, state
