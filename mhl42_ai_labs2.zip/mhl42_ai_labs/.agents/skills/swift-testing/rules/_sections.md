# Section Definitions

## Structure (struct)
**Impact:** CRITICAL

Readable, parameterized tests.

**Rules:**
- `struct-swift-testing` - @Test with names and arguments; #expect on plain expressions

## Assertions (assert)
**Impact:** CRITICAL

Preconditions and expected errors.

**Rules:**
- `assert-require-and-throws` - #require for preconditions; #expect(throws:) for errors

## Isolation (iso)
**Impact:** HIGH

No real network or singletons.

**Rules:**
- `iso-protocol-fakes` - Inject dependencies behind protocols; stub URLSession with URLProtocol

## Async (async)
**Impact:** HIGH

No sleeping.

**Rules:**
- `async-confirmations` - Await async code; use confirmation for events, never sleep

## State (state)
**Impact:** HIGH

Tests that pass in parallel.

**Rules:**
- `state-isolation` - Fresh state per test; @MainActor where the code is; serialize only with a reason
