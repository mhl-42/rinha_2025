---
title: "#require for Preconditions; #expect(throws:) for Errors"
impact: CRITICAL
impactDescription: A missing value stops the test with a clear message; the right error is checked, not any error
tags: [swift-testing, require, throws, errors, optionals]
---

# #require for Preconditions; #expect(throws:) for Errors [CRITICAL]

## Description
Force unwraps in a test crash the whole test process, taking other tests with it. `try #require(optional)` unwraps or stops only this test with a message; `try #require(condition)` does the same for a precondition the rest of the test depends on.

For an expected failure, `#expect(throws: SpecificError.self)` or `#expect(throws: SpecificError.case)` checks the type or the exact case. A `do`/`catch` that records an issue when nothing is thrown is longer and easy to get wrong.

## Bad Example
```swift
@Test func decodesUser() throws {
    let user = try! JSONDecoder().decode(User.self, from: json)
    #expect(user.address!.city == "Recife")
}

@Test func rejectsExpiredToken() async {
    do {
        _ = try await auth.refresh(expired)
    } catch {
        // any error passes, and no error also passes
    }
}
```

## Good Example
```swift
@Test("decodes the user's city")
func decodesUser() throws {
    let user = try JSONDecoder().decode(User.self, from: json)
    let address = try #require(user.address)
    #expect(address.city == "Recife")
}

@Test("refuses to refresh an expired token")
func rejectsExpiredToken() async {
    await #expect(throws: AuthError.tokenExpired) {
        try await auth.refresh(expired)
    }
}
```

## Notes
- Matching a specific case needs the error to be `Equatable`; otherwise check the type, or use the closure form `#expect { ... } throws: { error in ... }`.
- `#expect(throws: Never.self)` documents that a call must not throw.

## References
- [Apple: Testing for errors in Swift code](https://developer.apple.com/documentation/testing/testing-for-errors-in-swift-code)
