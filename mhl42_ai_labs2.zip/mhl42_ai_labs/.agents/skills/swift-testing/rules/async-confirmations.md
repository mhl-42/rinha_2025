---
title: Await Async Code; Use confirmation for Events, Never Sleep
impact: HIGH
impactDescription: Async tests are fast and do not flake
tags: [async, confirmation, swift-testing, flaky, clock]
---

# Await Async Code; Use confirmation for Events, Never Sleep [HIGH]

## Description
An `async` test can `await` the code under test directly; no expectation objects are needed. For events delivered through a callback, a delegate or an `AsyncStream`, `confirmation` checks that the event happened (and how many times) within the scope.

`Task.sleep` to "give it time" makes the test slow and flaky. Code that waits on time (debounce, retry backoff, expiry) takes a `Clock` or a sleep function as a dependency so the test can pass one that returns immediately.

## Bad Example
```swift
@Test func notifiesOnSave() async throws {
    var notified = false
    store.onSave = { notified = true }
    store.save(note)
    try await Task.sleep(for: .seconds(1))
    #expect(notified)
}
```

## Good Example
```swift
@Test("notifies observers once when a note is saved")
func notifiesOnSave() async throws {
    try await confirmation("save notification", expectedCount: 1) { saved in
        store.onSave = { saved() }
        try await store.save(note)
    }
}

@Test("retries three times before giving up")
func retries() async {
    let api = FakeAPI(result: .failure(APIError.unavailable))
    let client = RetryingClient(api: api, sleep: { _ in }) // no real waiting

    await #expect(throws: APIError.unavailable) { try await client.fetch() }
    #expect(api.calls == 3)
}
```

## Notes
- `confirmation` must be satisfied before its closure returns; events that arrive later need the code to expose an awaitable result instead.
- For SwiftUI views, test the view model; UI tests (XCUITest) are a separate, slower layer.

## References
- [Apple: Testing asynchronous code](https://developer.apple.com/documentation/testing/testing-asynchronous-code)
