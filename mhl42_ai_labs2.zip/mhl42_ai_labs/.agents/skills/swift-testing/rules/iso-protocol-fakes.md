---
title: Inject Dependencies Behind Protocols; Stub URLSession with URLProtocol
impact: HIGH
impactDescription: Tests run offline and fast, and exercise the real code paths
tags: [isolation, protocols, fakes, urlprotocol, dependency-injection]
---

# Inject Dependencies Behind Protocols; Stub URLSession with URLProtocol [HIGH]

## Description
Code that calls `API.shared` or `URLSession.shared` directly can only be tested against the real server. Pass dependencies in through `init` as small protocols (`any PaymentService`), and give tests a fake that returns scripted results and records what it received.

To test the networking layer itself (request building, status handling, decoding), keep the real client and give it a `URLSession` configured with a `URLProtocol` subclass that answers requests from the test.

## Bad Example
```swift
@MainActor
@Observable
final class OrdersModel {
    var orders: [Order] = []
    func load() async throws { orders = try await API.shared.orders() } // untestable offline
}
```

## Good Example
```swift
protocol OrdersAPI: Sendable {
    func orders() async throws -> [Order]
}

final class FakeOrdersAPI: OrdersAPI, @unchecked Sendable { // test-only; accessed from one test at a time
    var result: Result<[Order], Error> = .success([])
    func orders() async throws -> [Order] { try result.get() }
}

final class StubProtocol: URLProtocol {
    nonisolated(unsafe) static var handler: ((URLRequest) throws -> (HTTPURLResponse, Data))?
    override class func canInit(with request: URLRequest) -> Bool { true }
    override class func canonicalRequest(for request: URLRequest) -> URLRequest { request }
    override func startLoading() {
        guard let handler = Self.handler else {
            client?.urlProtocol(self, didFailWithError: URLError(.unsupportedURL))
            return
        }
        do {
            let (response, data) = try handler(request)
            client?.urlProtocol(self, didReceive: response, cacheStoragePolicy: .notAllowed)
            client?.urlProtocol(self, didLoad: data)
            client?.urlProtocolDidFinishLoading(self)
        } catch {
            client?.urlProtocol(self, didFailWithError: error)
        }
    }
    override func stopLoading() {}
}

func stubbedSession() -> URLSession {
    let configuration = URLSessionConfiguration.ephemeral
    configuration.protocolClasses = [StubProtocol.self]
    return URLSession(configuration: configuration)
}
```

## Notes
- A static handler is shared state: suites using it are `.serialized`, or key the handler by a per-test header.
- Keep fakes small: the methods the code under test calls, nothing else.

## References
- [Apple: URLProtocol](https://developer.apple.com/documentation/foundation/urlprotocol)
