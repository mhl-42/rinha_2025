---
title: Fresh State per Test; @MainActor Where the Code Is; Serialize Only with a Reason
impact: HIGH
impactDescription: Tests pass in parallel and in any order
tags: [isolation, parallel, serialized, mainactor, suites]
---

# Fresh State per Test; @MainActor Where the Code Is; Serialize Only with a Reason [HIGH]

## Description
Swift Testing runs tests in parallel. A test that writes to `UserDefaults.standard`, a shared database file or a static property can break another test running at the same time. Create the state each test needs in the suite's `init` (a suite struct is created anew for each test): an in-memory store, a `UserDefaults(suiteName:)` with a unique name, a temporary directory.

Code isolated to the main actor (view models) is tested from `@MainActor` tests. When tests must share something that cannot be duplicated, mark that suite `.serialized` and say why.

## Bad Example
```swift
@Suite struct SettingsTests {
    @Test func savesTheme() {
        Settings.shared.theme = .dark          // global, read by other tests
        #expect(UserDefaults.standard.string(forKey: "theme") == "dark")
    }
}
```

## Good Example
```swift
@MainActor
@Suite("Settings")
struct SettingsTests {
    let defaults: UserDefaults
    let settings: Settings

    init() throws {
        defaults = try #require(UserDefaults(suiteName: "SettingsTests-\(UUID().uuidString)"))
        settings = Settings(defaults: defaults)
    }

    @Test("saves the chosen theme")
    func savesTheme() {
        settings.theme = .dark
        #expect(defaults.string(forKey: "theme") == "dark")
    }
}

@Suite("Keychain integration", .serialized) // the Keychain is shared by the whole test host
struct KeychainTests { /* ... */ }
```

## Notes
- A suite's `deinit` (when it is a class or an actor) runs after each test, for cleanup such as removing a temporary directory.
- Run the suite a few times in a row (`swift test --parallel` repeatedly, or Xcode's test repetitions) to expose order dependencies.

## References
- [Apple: Running tests serially or in parallel](https://developer.apple.com/documentation/testing/parallelization)
