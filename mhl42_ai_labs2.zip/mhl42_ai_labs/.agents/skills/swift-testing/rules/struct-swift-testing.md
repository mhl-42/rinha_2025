---
title: "@Test with Names and Arguments; #expect on Plain Expressions"
impact: CRITICAL
impactDescription: Failures name the behaviour and show the values; new cases are one line
tags: [swift-testing, structure, parameterized, naming]
---

# @Test with Names and Arguments; #expect on Plain Expressions [CRITICAL]

## Description
Swift Testing replaces `XCTestCase` subclasses and `XCTAssert*` functions with `@Test` functions and the `#expect` macro. `#expect` takes a normal Swift expression and, on failure, prints the value of each operand, so `#expect(total == 1050)` reports what `total` was.

Give each test a display name that states the behaviour (`@Test("refuses an expired coupon")`). When several tests differ only in inputs, use `arguments:`: each argument runs as its own test case, reported and rerunnable separately.

## Bad Example
```swift
final class MoneyTests: XCTestCase {
    func testFormat() {
        XCTAssertEqual(Money(cents: 0).formatted(), "R$ 0,00")
        XCTAssertEqual(Money(cents: 1050).formatted(), "R$ 10,50")
        XCTAssertTrue(Money(cents: -1).formatted().isEmpty == false)
    }
}
```

## Good Example
```swift
@Suite("Money formatting")
struct MoneyTests {
    @Test("formats cents as reais", arguments: [
        (0, "R$ 0,00"),
        (1050, "R$ 10,50"),
        (123456, "R$ 1.234,56"),
    ])
    func formats(cents: Int, expected: String) {
        #expect(Money(cents: cents).formatted(locale: Locale(identifier: "pt_BR")) == expected)
    }

    @Test("shows negative amounts with a minus sign")
    func negative() {
        #expect(Money(cents: -150).formatted(locale: Locale(identifier: "pt_BR")) == "-R$ 1,50")
    }
}
```

## Notes
- Two argument collections passed together run every combination; zip them for pairs.
- Tags (`@Test(.tags(.network))`) group tests to run or skip together.

## References
- [Apple: Swift Testing](https://developer.apple.com/documentation/testing)
- [Apple: Implementing parameterized tests](https://developer.apple.com/documentation/testing/parameterizedtesting)
