# TypeScript Coding Standards

Rules for AI agents writing TypeScript: type safety without escape hatches, validated boundaries, errors and promises that are never lost, injection-free output, a strict compiler setup, and React effects.

## Overview

This skill provides 11 rules across 8 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Type Safety | `type-` | CRITICAL | 3 |
| Boundaries | `boundary-` | CRITICAL | 2 |
| Errors | `err-` | HIGH | 1 |
| Async | `async-` | HIGH | 1 |
| Security | `sec-` | HIGH | 1 |
| Configuration | `config-` | MEDIUM | 1 |
| Modules | `mod-` | MEDIUM | 1 |
| React | `react-` | MEDIUM | 1 |

## Structure

```
skills/typescript-coding-standards/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Usage

The agent loads this skill when its `description` matches the task. Tests have their own skill (`typescript-testing`); Node runtime rules live in `javascript-coding-standards` and apply to TypeScript on Node too.

## Origin

Adapted from `typescript-strict` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT): split into rule files, with the stack-specific rules (Tauri, path aliases, `React.FC`) removed and `noUncheckedIndexedAccess`, floating promises and `using` added.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
