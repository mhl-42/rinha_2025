---
name: typescript-coding-standards
description: Use this skill when writing, reviewing, or refactoring TypeScript code (.ts, .tsx) — types and generics, any/unknown and type assertions, unions and exhaustive switches, error handling, validation of API input, JSON and environment variables, imports, tsconfig strictness, async code and promises, and React components — even if the user only asks to "fix the type error", "add an endpoint", or "clean up this component". Not for test code (use typescript-testing), plain JavaScript without types (use javascript-coding-standards), SQL and schema design (use postgres-database), or code in other languages.
license: MIT
compatibility: TypeScript 5.4+ (satisfies, using, NoInfer); the tsconfig rules hold for TypeScript 6 and the native 7 compiler. Examples validate input with zod; valibot, arktype or a hand-written guard fit the same rules. React rules apply to React 18+.
metadata:
  author: mhl42 (adapted from 0xMassi/claude-skills, MIT)
  version: "1.0.1"
---

# TypeScript Coding Standards

Rules for AI agents writing TypeScript that the compiler can actually check. The Quick Reference covers the common case; open a rule file when its trigger appears in the code you write or review.

## How to Use

- **Writing code**: keep every value typed from where it enters (a request, a file, `JSON.parse`, `process.env`) to where it is used, and let the compiler prove the rest. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below, highest impact first, and open the matching rule.

| When the code contains... | Read |
|---------------------------|------|
| `any`, `as any`, `@ts-ignore`, an untyped `catch (e)` used as an object | [type-no-any](rules/type-no-any.md) |
| `as SomeType`, `as unknown as`, `!` after an expression, `<T>value` casts | [type-no-assertions](rules/type-no-assertions.md) |
| Several booleans describing one state (`loading`, `error`, `data?`); a `switch` on a union with no `default` | [type-discriminated-unions](rules/type-discriminated-unions.md) |
| `request.json()`, `JSON.parse`, `await res.json()`, form data, message payloads used as typed values | [boundary-validate-input](rules/boundary-validate-input.md) |
| `process.env.X` read across the code; `NEXT_PUBLIC_`, `VITE_`, `PUBLIC_` variables holding keys | [boundary-env-at-startup](rules/boundary-env-at-startup.md) |
| `catch (err) { err.message }`, `catch {}`, errors logged and dropped, `throw "string"` | [err-narrow-and-propagate](rules/err-narrow-and-propagate.md) |
| A promise not awaited or returned; `forEach(async ...)`; a loop or batch calling an API per item (sync, import, notify); `try/finally` closing a handle | [async-handle-every-promise](rules/async-handle-every-promise.md) |
| `innerHTML`, `dangerouslySetInnerHTML`, `eval`, `new Function`, user data in a URL or query string | [sec-no-injection](rules/sec-no-injection.md) |
| `tsconfig.json` without `strict`, or a new project | [config-strict-tsconfig](rules/config-strict-tsconfig.md) |
| `import { SomeType }` used only as a type; side-effect imports; mixed value and type imports | [mod-type-imports](rules/mod-type-imports.md) |
| `useEffect` that subscribes, sets a timer or fetches; derived state copied into `useState` | [react-effects](rules/react-effects.md) |

### Review Checklist

- [ ] `tsc --noEmit` passes with `strict` and `noUncheckedIndexedAccess`, with no new `any`, `@ts-ignore` or `as`
- [ ] Every external value is parsed by a schema or a type guard before it gets a type
- [ ] Unions that describe states are discriminated and every `switch` on them is exhaustive
- [ ] Every `catch` narrows `unknown`, and no error is swallowed
- [ ] Every promise is awaited, returned, or explicitly handled
- [ ] No secret reaches the browser bundle or the logs
- [ ] The project's lint passes (typescript-eslint `strict-type-checked` when the project uses it)

## Gotchas

- `JSON.parse`, `response.json()` and `request.json()` return `any`: the value flows anywhere without a single error. Give it a type only through a schema.
- `strict: true` does not include `noUncheckedIndexedAccess`: without it `items[0]` and `record[key]` are typed as present when they may be `undefined`.
- `catch (err)` is `unknown` under `strict` (`useUnknownInCatchVariables`); `err.message` does not compile, and `catch (err: any)` silences that on purpose. Narrow instead.
- `as` does not convert or check anything at runtime: `"42" as unknown as number` is still a string.
- `array.forEach(async item => ...)` does not wait: the function returns before any item finishes, and rejections go unhandled. Use `for...of` with `await`, or `Promise.all`.
- `Promise.all` rejects on the first failure and leaves the others running; use `Promise.allSettled` when each result must be reported.
- Any variable prefixed `NEXT_PUBLIC_`, `VITE_` or `PUBLIC_` is inlined into the browser bundle at build time, visible to every user.
- Optional chaining (`a?.b`) hides a missing value; at a boundary where the value is required, fail loudly instead.
- `enum` and `namespace` emit runtime code and break Node's type stripping (`erasableSyntaxOnly`); a union of string literals or an `as const` object does the same job.
- `type` and `interface` are interchangeable for object shapes; follow the codebase. Use `type` for unions and mapped types.

## Categories

### Type Safety [CRITICAL]
Keep the compiler able to prove what the code assumes.

| Rule | Description |
|------|-------------|
| [type-no-any](rules/type-no-any.md) | Use unknown and narrowing, never any or @ts-ignore |
| [type-no-assertions](rules/type-no-assertions.md) | Prove types with guards and satisfies, not as or ! |
| [type-discriminated-unions](rules/type-discriminated-unions.md) | Model states as discriminated unions with exhaustive checks |

### Boundaries [CRITICAL]
Type external data only after it has been validated.

| Rule | Description |
|------|-------------|
| [boundary-validate-input](rules/boundary-validate-input.md) | Parse request bodies, JSON and messages with a schema |
| [boundary-env-at-startup](rules/boundary-env-at-startup.md) | Validate environment variables once at startup and keep secrets server-side |

### Errors and Async [HIGH]
Never lose an error or a promise.

| Rule | Description |
|------|-------------|
| [err-narrow-and-propagate](rules/err-narrow-and-propagate.md) | Narrow caught errors, keep the cause, never swallow |
| [async-handle-every-promise](rules/async-handle-every-promise.md) | Await, return or handle every promise; dispose resources with using |

### Security [HIGH]
Keep user data from becoming markup or code.

| Rule | Description |
|------|-------------|
| [sec-no-injection](rules/sec-no-injection.md) | No user data in innerHTML, eval or hand-built queries and URLs |

### Project Setup [MEDIUM]
Configure the compiler and the module graph for strictness.

| Rule | Description |
|------|-------------|
| [config-strict-tsconfig](rules/config-strict-tsconfig.md) | Turn on strict and the checks strict leaves off |
| [mod-type-imports](rules/mod-type-imports.md) | Import types with import type under verbatimModuleSyntax |

### React [MEDIUM]
Effects that clean up after themselves.

| Rule | Description |
|------|-------------|
| [react-effects](rules/react-effects.md) | Clean up subscriptions, cancel fetches, derive instead of syncing state |

## Quick Reference

### Types
```typescript
function isUser(value: unknown): value is User {
  return typeof value === "object" && value !== null && "id" in value && typeof value.id === "string";
}

type Load =
  | { state: "idle" }
  | { state: "loading" }
  | { state: "failed"; message: string }
  | { state: "loaded"; user: User };

function label(load: Load): string {
  switch (load.state) {
    case "idle": return "";
    case "loading": return "Loading…";
    case "failed": return load.message;
    case "loaded": return load.user.name;
    default: return assertNever(load);
  }
}

const routes = { home: "/", settings: "/settings" } satisfies Record<string, `/${string}`>;
```

### Boundaries and errors
```typescript
const CreateOrder = z.object({ productId: z.string().uuid(), quantity: z.number().int().positive() });

export async function POST(request: Request): Promise<Response> {
  const parsed = CreateOrder.safeParse(await request.json());
  if (!parsed.success) return Response.json({ error: parsed.error.flatten() }, { status: 400 });
  try {
    return Response.json(await createOrder(parsed.data), { status: 201 });
  } catch (err) {
    throw new Error(`creating order for ${parsed.data.productId}`, { cause: err });
  }
}
```

### Async
```typescript
const results = await Promise.allSettled(ids.map((id) => sync(id)));

for (const item of items) {
  await save(item); // sequential on purpose: the API allows one write at a time
}

await using file = await open(path); // closed when the scope ends, even on throw
```

## See Also

These are separate skills; use them if installed.

- `typescript-testing` - Vitest and node:test, mocks, fake timers, test data
- `javascript-coding-standards` - Node runtime rules (streams, AbortController, crypto) that apply to TypeScript on Node too
- `postgres-database` - Parameterized queries, transactions and migrations
