# Section Definitions

## Type Safety (type)
**Impact:** CRITICAL

Keep the compiler able to prove what the code assumes.

**Rules:**
- `type-no-any` - Use unknown and narrowing, never any or @ts-ignore
- `type-no-assertions` - Prove types with guards and satisfies, not as or !
- `type-discriminated-unions` - Model states as discriminated unions with exhaustive checks

## Boundaries (boundary)
**Impact:** CRITICAL

Type external data only after it has been validated.

**Rules:**
- `boundary-validate-input` - Parse request bodies, JSON and messages with a schema
- `boundary-env-at-startup` - Validate environment variables once at startup and keep secrets server-side

## Errors (err)
**Impact:** HIGH

Never lose an error.

**Rules:**
- `err-narrow-and-propagate` - Narrow caught errors, keep the cause, never swallow

## Async (async)
**Impact:** HIGH

Never lose a promise or a resource.

**Rules:**
- `async-handle-every-promise` - Await, return or handle every promise; dispose resources with using

## Security (sec)
**Impact:** HIGH

Keep user data from becoming markup or code.

**Rules:**
- `sec-no-injection` - No user data in innerHTML, eval or hand-built queries and URLs

## Configuration (config)
**Impact:** MEDIUM

Configure the compiler for strictness.

**Rules:**
- `config-strict-tsconfig` - Turn on strict and the checks strict leaves off

## Modules (mod)
**Impact:** MEDIUM

Keep the module graph explicit.

**Rules:**
- `mod-type-imports` - Import types with import type under verbatimModuleSyntax

## React (react)
**Impact:** MEDIUM

Effects that clean up after themselves.

**Rules:**
- `react-effects` - Clean up subscriptions, cancel fetches, derive instead of syncing state
