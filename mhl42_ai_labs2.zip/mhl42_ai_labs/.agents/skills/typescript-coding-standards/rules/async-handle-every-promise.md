---
title: Await, Return or Handle Every Promise; Dispose Resources with using
impact: HIGH
impactDescription: No unhandled rejection crashes the process; no handle leaks on an error path
tags: [async, promises, floating-promises, using, resources]
---

# Await, Return or Handle Every Promise; Dispose Resources with using [HIGH]

## Description
A promise that is neither awaited nor returned ("floating") runs detached: its rejection is unhandled (Node exits on unhandled rejections by default) and the caller continues as if the work were done. `array.forEach(async ...)` creates one floating promise per item.

Resources that must be closed (file handles, connections, locks) leak when an exception skips the cleanup. `using` and `await using` (TypeScript 5.2+, Node 24+ natively) dispose them when the scope ends, on every path.

## Bad Example
```typescript
function onSubmit(order: Order) {
  saveOrder(order); // floating: errors vanish, UI says "saved"
  notifyWarehouse(order);
}

orders.forEach(async (order) => {
  await ship(order); // the caller does not wait for any of these
});
```

## Good Example
```typescript
async function onSubmit(order: Order): Promise<void> {
  await saveOrder(order);
  await notifyWarehouse(order);
}

const outcomes = await Promise.allSettled(orders.map((order) => ship(order)));
const failed = outcomes.filter((o) => o.status === "rejected");

async function readConfig(path: string): Promise<string> {
  await using file = await open(path); // closed on return and on throw
  return file.readFile("utf8");
}

void analytics.track("opened"); // fire-and-forget on purpose, marked with void
```

## Notes
- In a batch (sync, import, notifications), one failed item must not hide the others: collect the outcomes with `Promise.allSettled` and report which ids failed and why.
- typescript-eslint's `no-floating-promises` and `no-misused-promises` catch these.
- Run independent work with `Promise.all`; sequential `await` in a loop only when order or rate limits require it, and say so.
- Pass an `AbortSignal` to long operations so callers can cancel them (see javascript-coding-standards).

## References
- [typescript-eslint no-floating-promises](https://typescript-eslint.io/rules/no-floating-promises/)
- [TypeScript 5.2: using declarations](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-5-2.html)
