---
title: Validate Environment Variables at Startup and Keep Secrets Server-Side
impact: CRITICAL
impactDescription: A missing setting stops the process at boot; no secret is shipped to browsers
tags: [environment, configuration, secrets, nextjs, vite]
---

# Validate Environment Variables at Startup and Keep Secrets Server-Side [CRITICAL]

## Description
`process.env.X` is `string | undefined` and read lazily: a missing variable surfaces as a failure on the first request that needs it, possibly hours after deploy. Parse the whole environment once, at startup, into one typed object, and import that object everywhere.

Frameworks inline variables with a public prefix (`NEXT_PUBLIC_`, `VITE_`, `PUBLIC_`, `EXPO_PUBLIC_`) into the client bundle at build time. Anything with that prefix is public. Keys, database URLs and signing secrets never get it.

## Bad Example
```typescript
// .env
// NEXT_PUBLIC_STRIPE_SECRET_KEY=sk_live_...

const client = new Stripe(process.env.NEXT_PUBLIC_STRIPE_SECRET_KEY!);
const pageSize = Number(process.env.PAGE_SIZE); // NaN when missing
```

## Good Example
```typescript
// src/env.server.ts — imported only by server code
const Env = z.object({
  DATABASE_URL: z.string().url(),
  STRIPE_SECRET_KEY: z.string().startsWith("sk_"),
  PAGE_SIZE: z.coerce.number().int().positive().default(20),
});

export const env = Env.parse(process.env); // throws at boot with the list of problems

const client = new Stripe(env.STRIPE_SECRET_KEY);
```

## Notes
- Mark server-only modules so a client import fails the build (`import "server-only"` in Next.js).
- Do not log the parsed object; log which keys were loaded, never their values.

## References
- [Next.js: environment variables](https://nextjs.org/docs/app/building-your-application/configuring/environment-variables)
- [Vite: env variables](https://vite.dev/guide/env-and-mode)
