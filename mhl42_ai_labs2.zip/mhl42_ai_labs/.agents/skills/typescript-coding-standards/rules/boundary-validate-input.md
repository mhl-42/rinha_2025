---
title: Parse External Input with a Schema
impact: CRITICAL
impactDescription: Malformed or hostile input is rejected at the edge instead of corrupting data deep inside
tags: [validation, zod, boundaries, json, api]
---

# Parse External Input with a Schema [CRITICAL]

## Description
A TypeScript type is erased at runtime: annotating a request body as `CreateUser` checks nothing. Every value that crosses a trust boundary (an HTTP body or query, a form, `JSON.parse`, a queue message, a file, a third-party API response, `localStorage`) is `unknown` until a runtime schema has parsed it. Derive the type from the schema so the two cannot drift.

Parse once, at the edge, and pass the parsed value inward; inner functions then take precise types and never re-check.

## Bad Example
```typescript
type CreateUser = { email: string; age: number };

app.post("/users", async (req, res) => {
  const body: CreateUser = req.body; // any, trusted as CreateUser
  await users.insert(body);          // age may be "abc", extra fields pass through
  res.status(201).end();
});
```

## Good Example
```typescript
const CreateUser = z.object({
  email: z.string().email().max(254),
  age: z.number().int().min(13).max(120),
}).strict(); // unknown keys are rejected

type CreateUser = z.infer<typeof CreateUser>;

app.post("/users", async (req, res) => {
  const parsed = CreateUser.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ errors: parsed.error.flatten().fieldErrors });
    return;
  }
  await users.insert(parsed.data);
  res.status(201).end();
});
```

## Notes
- Validate responses from other services too: their shape changes without your compiler knowing.
- Bound sizes (`max`) on strings and arrays; an unbounded field is a memory problem.
- Return the field errors to the client, never the stack or the raw input.

## References
- [Zod documentation](https://zod.dev/)
