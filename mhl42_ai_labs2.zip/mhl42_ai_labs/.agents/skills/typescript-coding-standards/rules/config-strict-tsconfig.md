---
title: Turn On strict and the Checks strict Leaves Off
impact: MEDIUM
impactDescription: The compiler catches undefined access and unused code that strict alone misses
tags: [tsconfig, strict, compiler, configuration]
---

# Turn On strict and the Checks strict Leaves Off [MEDIUM]

## Description
`strict` turns on the core checks (null checks, implicit any, unknown in catch). Several useful checks are outside it: `noUncheckedIndexedAccess` types `items[0]` and `record[key]` as possibly `undefined`; `noImplicitOverride` requires `override` on overriding methods; `noFallthroughCasesInSwitch` catches a missing `break`. `verbatimModuleSyntax` keeps imports as written so tools that strip types (Node, esbuild, swc) behave like `tsc`.

For an existing project, turn them on one at a time and fix the errors in the same change; never weaken a flag to make a build pass.

## Bad Example
```json
{
  "compilerOptions": {
    "strict": false,
    "skipLibCheck": true,
    "noImplicitAny": false
  }
}
```

## Good Example
```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "NodeNext",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noFallthroughCasesInSwitch": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "verbatimModuleSyntax": true,
    "isolatedModules": true,
    "skipLibCheck": true
  }
}
```

## Notes
- `module`: `NodeNext` for Node, `Preserve` (with `moduleResolution: "bundler"`) for code a bundler builds.
- `exactOptionalPropertyTypes` distinguishes a missing property from one set to `undefined`; worth it in new code, noisy to adopt late.
- `erasableSyntaxOnly` (TypeScript 5.8+) bans enums, namespaces and parameter properties, so the code runs under Node's type stripping.
- `skipLibCheck: true` is normal: it skips checking `.d.ts` files in `node_modules`, not your code.

## References
- [TSConfig reference](https://www.typescriptlang.org/tsconfig/)
