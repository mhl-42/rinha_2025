---
title: Narrow Caught Errors, Keep the Cause, Never Swallow
impact: HIGH
impactDescription: Failures stay visible and traceable to their origin
tags: [errors, catch, unknown, cause, logging]
---

# Narrow Caught Errors, Keep the Cause, Never Swallow [HIGH]

## Description
Anything can be thrown in JavaScript, so a caught value is `unknown`. Reading `err.message` without narrowing crashes when a library throws a string or an object. An empty `catch {}`, or a `catch` that only logs and continues, turns a failure into wrong data later.

Catch only where you can do something: add context, translate to a domain error, retry, or report to the user. When rethrowing, pass the original as `cause` so the stack trace keeps both. Throw `Error` subclasses, never strings.

## Bad Example
```typescript
try {
  await chargeCard(order);
} catch (err: any) {
  console.log(err.message);
}

try {
  config = JSON.parse(text);
} catch {}
```

## Good Example
```typescript
class PaymentDeclined extends Error {
  override name = "PaymentDeclined";
}

try {
  await chargeCard(order);
} catch (err) {
  if (err instanceof CardError && err.code === "card_declined") {
    throw new PaymentDeclined(`order ${order.id} declined`, { cause: err });
  }
  throw new Error(`charging order ${order.id}`, { cause: err });
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
```

## Notes
- A `catch` that recovers on purpose (a cache miss) says so in a comment and handles only the expected error.
- In a UI, an error reaches the user as a message and the log as the full error with its cause.
- `Error.cause` is ES2022; set `lib` to ES2022 or later.

## References
- [MDN: Error cause](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Error/cause)
