---
title: Import Types with import type under verbatimModuleSyntax
impact: MEDIUM
impactDescription: No runtime import for a type; no module loaded only for its side effects by accident
tags: [imports, modules, verbatimModuleSyntax, bundles]
---

# Import Types with import type under verbatimModuleSyntax [MEDIUM]

## Description
With `verbatimModuleSyntax`, the compiler keeps every import that is not marked as type-only. An `import { User }` used only as a type then loads the module at runtime: a slower start, a bigger bundle, and sometimes a circular import that only exists because of a type. Mark type-only imports with `import type`, or `type` on the specifier.

## Bad Example
```typescript
import { User, saveUser } from "./users"; // User is a type: the import is kept anyway
import { OrderStatus } from "./orders";    // type only, loads orders.ts and its imports
```

## Good Example
```typescript
import { saveUser, type User } from "./users";
import type { OrderStatus } from "./orders";
```

## Notes
- typescript-eslint's `consistent-type-imports` fixes these automatically.
- A module imported only for its side effects (`import "./polyfills"`) should be rare and obvious; `noUncheckedSideEffectImports` (TypeScript 5.6+) makes the compiler check it exists.
- Follow the project's path aliases (`@/components`) when it has them; do not introduce them in a change that does something else.

## References
- [TSConfig: verbatimModuleSyntax](https://www.typescriptlang.org/tsconfig/#verbatimModuleSyntax)
