---
title: Clean Up Effects, Cancel Fetches, Derive Instead of Syncing State
impact: MEDIUM
impactDescription: No leaked listeners, no state set on unmounted components, no stale copies of props
tags: [react, useEffect, cleanup, abortcontroller, state]
---

# Clean Up Effects, Cancel Fetches, Derive Instead of Syncing State [MEDIUM]

## Description
An effect that subscribes (an event listener, a WebSocket, an interval) must return a cleanup that undoes it; otherwise each re-render or remount adds another subscription. An effect that fetches must cancel the request when its inputs change, or a slow earlier response overwrites a newer one.

Many effects should not exist: a value computed from props or state is computed during render (with `useMemo` if expensive), not copied into state by an effect.

## Bad Example
```typescript
useEffect(() => {
  window.addEventListener("resize", onResize);
}, []);

useEffect(() => {
  fetch(`/api/users/${userId}`).then((r) => r.json()).then(setUser);
}, [userId]);

const [fullName, setFullName] = useState("");
useEffect(() => setFullName(`${first} ${last}`), [first, last]);
```

## Good Example
```typescript
useEffect(() => {
  window.addEventListener("resize", onResize);
  return () => window.removeEventListener("resize", onResize);
}, [onResize]);

useEffect(() => {
  const controller = new AbortController();
  fetch(`/api/users/${userId}`, { signal: controller.signal })
    .then((r) => r.json())
    .then((data: unknown) => setUser(UserSchema.parse(data)))
    .catch((err: unknown) => {
      if (!(err instanceof DOMException && err.name === "AbortError")) setError(err);
    });
  return () => controller.abort();
}, [userId]);

const fullName = `${first} ${last}`;
```

## Notes
- A data-fetching library (TanStack Query, SWR) or the framework's loaders handle cancellation and caching; prefer them over hand-written fetch effects.
- Keep the dependency array complete (`react-hooks/exhaustive-deps`); a missing dependency is a stale value.
- Write components as plain functions with typed props; `React.FC` adds nothing.

## References
- [React: You Might Not Need an Effect](https://react.dev/learn/you-might-not-need-an-effect)
- [React: synchronizing with effects](https://react.dev/learn/synchronizing-with-effects)
