---
title: No User Data in innerHTML, eval or Hand-Built Queries and URLs
impact: HIGH
impactDescription: Prevents cross-site scripting, code injection and query injection
tags: [security, xss, injection, innerHTML, urls]
---

# No User Data in innerHTML, eval or Hand-Built Queries and URLs [HIGH]

## Description
Text that comes from users becomes code when it is inserted as markup (`innerHTML`, `outerHTML`, `insertAdjacentHTML`, React's `dangerouslySetInnerHTML`), evaluated (`eval`, `new Function`, `setTimeout("string")`), or concatenated into SQL, shell commands or URLs. Insert text as text, pass values as parameters, and build URLs with `URL` and `URLSearchParams`.

When HTML from users must be rendered (rich text), sanitize it with a maintained library (DOMPurify) right before insertion.

## Bad Example
```typescript
comment.innerHTML = `<p>${input}</p>`;

const rows = await db.query(`SELECT * FROM orders WHERE customer = '${customer}'`);

const url = `https://api.example.com/search?q=${query}&page=${page}`;

<div dangerouslySetInnerHTML={{ __html: post.body }} />;
```

## Good Example
```typescript
const p = document.createElement("p");
p.textContent = input;
comment.replaceChildren(p);

const rows = await db.query("SELECT id, total FROM orders WHERE customer = $1", [customer]);

const url = new URL("https://api.example.com/search");
url.search = new URLSearchParams({ q: query, page: String(page) }).toString();

<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(post.body) }} />;
```

## Notes
- A redirect to a URL from the query string (`?next=`) must be checked against an allow-list of paths or hosts.
- Tagged-template query builders (`sql\`...\``) are safe because they parameterize; string concatenation inside them is not.
- A Content Security Policy is a second line of defense, not a replacement.

## References
- [OWASP: Cross Site Scripting Prevention](https://cheatsheetseries.owasp.org/cheatsheets/Cross_Site_Scripting_Prevention_Cheat_Sheet.html)
