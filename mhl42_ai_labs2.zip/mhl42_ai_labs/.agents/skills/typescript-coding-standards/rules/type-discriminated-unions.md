---
title: Model States as Discriminated Unions with Exhaustive Checks
impact: CRITICAL
impactDescription: Impossible states cannot be represented; a new case breaks the build where it is unhandled
tags: [types, unions, exhaustiveness, never, state]
---

# Model States as Discriminated Unions with Exhaustive Checks [CRITICAL]

## Description
Several booleans and optional fields describing one thing (`loading`, `error`, `data?`) allow combinations that should never exist: loading and failed at once, loaded without data. A discriminated union, one variant per state with a literal tag, makes those states unrepresentable, and narrowing on the tag gives each branch exactly the fields it has.

When a `switch` on the tag ends in a `default` that passes the value to a function taking `never`, adding a variant later makes every unhandled `switch` a compile error instead of a silent fall-through.

## Bad Example
```typescript
type Payment = { pending: boolean; failed: boolean; error?: string; receiptId?: string };

function message(p: Payment): string {
  if (p.failed) return p.error ?? "failed";
  if (p.pending) return "Processing";
  return `Paid: ${p.receiptId}`; // receiptId may be undefined
}
```

## Good Example
```typescript
type Payment =
  | { status: "pending" }
  | { status: "failed"; error: string }
  | { status: "paid"; receiptId: string };

function assertNever(value: never): never {
  throw new Error(`unhandled variant: ${JSON.stringify(value)}`);
}

function message(p: Payment): string {
  switch (p.status) {
    case "pending": return "Processing";
    case "failed": return p.error;
    case "paid": return `Paid: ${p.receiptId}`;
    default: return assertNever(p);
  }
}
```

## Notes
- The same applies to results: `{ ok: true; value: T } | { ok: false; error: E }` instead of a value and an error that may both be set.
- typescript-eslint's `switch-exhaustiveness-check` reports a missing case even without `assertNever`.
- Keep the tag a string literal; a union of classes narrows with `instanceof` instead.

## References
- [TypeScript handbook: discriminated unions](https://www.typescriptlang.org/docs/handbook/2/narrowing.html#discriminated-unions)
