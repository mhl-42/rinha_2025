---
title: Use unknown and Narrowing, Never any
impact: CRITICAL
impactDescription: Type errors surface at compile time instead of in production
tags: [types, any, unknown, ts-ignore, narrowing]
---

# Use unknown and Narrowing, Never any [CRITICAL]

## Description
`any` switches the type checker off for a value and for everything derived from it: a property typo, a wrong argument or a missing `await` all compile. It also spreads: a function returning `any` makes every caller untyped. `unknown` says the same thing ("I do not know the type yet") but forces a check before use.

`@ts-ignore` hides every error on the next line, including the ones introduced later. When an error must be suppressed, `@ts-expect-error` with a reason fails as soon as the error disappears, so the suppression cannot outlive its cause.

## Bad Example
```typescript
function total(data: any) {
  return data.items.reduce((sum: any, item: any) => sum + item.price, 0);
}

// @ts-ignore
legacyWidget.init(config);
```

## Good Example
```typescript
type Cart = { items: ReadonlyArray<{ price: number }> };

function total(cart: Cart): number {
  return cart.items.reduce((sum, item) => sum + item.price, 0);
}

function readCart(raw: unknown): Cart {
  return CartSchema.parse(raw); // the type comes from a check, not a promise
}

// @ts-expect-error -- legacy-widget 2.x types omit init(); remove after upgrading to 3.x
legacyWidget.init(config);
```

## Notes
- A third-party API typed as `any` is narrowed once, at the wrapper you write around it, with a comment.
- Generic code needs type parameters (`<T>`), not `any`; `Record<string, unknown>` for objects of unknown shape.
- typescript-eslint's `no-explicit-any`, `no-unsafe-*` and `ban-ts-comment` enforce this rule.

## References
- [TypeScript handbook: unknown](https://www.typescriptlang.org/docs/handbook/2/functions.html#unknown)
- [typescript-eslint no-unsafe-assignment](https://typescript-eslint.io/rules/no-unsafe-assignment/)
