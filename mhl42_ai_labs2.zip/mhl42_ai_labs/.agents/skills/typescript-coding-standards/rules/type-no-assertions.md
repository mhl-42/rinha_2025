---
title: Prove Types with Guards and satisfies, Not as or !
impact: CRITICAL
impactDescription: No value is assumed to be what it was never checked to be
tags: [types, assertions, satisfies, non-null, type-guards]
---

# Prove Types with Guards and satisfies, Not as or ! [CRITICAL]

## Description
`value as User` tells the compiler to stop checking; nothing happens at runtime. When the value is not a `User`, the failure shows up far from the cast, as `undefined is not a function`. The non-null assertion `value!` does the same for `null` and `undefined`.

Most casts have a checked replacement:
- a **type guard** (`value is User`) or `instanceof` narrows after a runtime check;
- **`satisfies`** checks a literal against a type and keeps its narrow inferred type, which is what `as Config` on a literal was trying to do;
- an early `throw` or `return` removes `null` without `!`.

## Bad Example
```typescript
const user = (await res.json()) as User;
const root = document.getElementById("root") as HTMLDivElement;
const config = { retries: 3, mode: "fast" } as Config;
const name = users.find((u) => u.id === id)!.name;
```

## Good Example
```typescript
const user = UserSchema.parse(await res.json());

const root = document.getElementById("root");
if (!(root instanceof HTMLDivElement)) throw new Error("#root is missing or not a div");

const config = { retries: 3, mode: "fast" } satisfies Config;

const found = users.find((u) => u.id === id);
if (!found) throw new NotFoundError(`user ${id}`);
const name = found.name;
```

## Notes
- `as const` is not a cast: it narrows a literal and is fine.
- A justified cast (a library type that is wrong) goes through `as unknown as T` with a comment that says why it holds, so it is visible in review.
- `!` right after a check the compiler cannot follow (a `Map.has` then `get`) is better written as `const value = map.get(key); if (value === undefined) ...`.

## References
- [TypeScript: the satisfies operator](https://www.typescriptlang.org/docs/handbook/release-notes/typescript-4-9.html#the-satisfies-operator)
- [typescript-eslint no-non-null-assertion](https://typescript-eslint.io/rules/no-non-null-assertion/)
