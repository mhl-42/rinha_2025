# TypeScript and JavaScript Testing

Rules for AI agents writing Vitest, Jest and node:test tests for TypeScript and JavaScript: one behaviour per test, mocks only at boundaries, fake time, awaited async assertions, factories, property tests and coverage floors.

## Overview

This skill provides 8 rules across 7 sections:

| Section | Prefix | Impact | Rules |
|---------|--------|--------|-------|
| Structure | `struct-` | CRITICAL | 2 |
| Mocks | `mock-` | HIGH | 1 |
| Time | `time-` | HIGH | 1 |
| Async | `async-` | HIGH | 1 |
| Data | `data-` | MEDIUM | 1 |
| Property-based | `prop-` | MEDIUM | 1 |
| Coverage | `cov-` | LOW | 1 |

## Structure

```
skills/typescript-testing/
├── SKILL.md          # Skill overview with quick reference
├── metadata.json     # Metadata (version, counts); keep in sync with SKILL.md frontmatter
├── README.md         # This file
├── evals/            # Output-quality cases and trigger queries
└── rules/            # One file per rule, listed in _sections.md
```

## Usage

The agent loads this skill for tests in TypeScript and in JavaScript; there is no separate javascript-testing skill.

## Origin

Adapted from the Vitest part of `testing-patterns` in [0xMassi/claude-skills](https://github.com/0xMassi/claude-skills) (MIT), split into rule files, with rules on async assertions, fake timers, MSW and property tests.

## Contributing

1. Copy `rules/_template.md` and use a prefix from `_sections.md`
2. Update `_sections.md`, `SKILL.md` (category table and the trigger table) and `metadata.json`
3. Run `py -3 scripts/validate_skills.py` from the repository root
