---
name: typescript-testing
description: Use this skill when writing, reviewing, or fixing tests for TypeScript or JavaScript code — Vitest, Jest or node:test unit and integration tests, mocks and spies, fetch/HTTP mocking, fake timers and dates, async assertions, test data factories, React component tests, property-based tests and coverage — even if the user only says "add tests", "this test is flaky", or "why does this test pass when the code is broken". Not for application code (use typescript-coding-standards or javascript-coding-standards), end-to-end browser suites (Playwright projects follow their own docs), or tests in other languages.
license: MIT
compatibility: Examples use Vitest 3+; the same rules apply to Jest (vi → jest) and to node:test (Node 22+). React examples use Testing Library; HTTP mocking uses MSW 2. Property tests use fast-check.
metadata:
  author: mhl42 (adapted from 0xMassi/claude-skills, MIT)
  version: "1.0.0"
---

# TypeScript and JavaScript Testing

Rules for AI agents writing tests that fail when the code is wrong and only then. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing tests**: one behaviour per test, through the public API, with controlled time, network and data. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below and open the matching rule. Then break the code on purpose (flip a condition) and check that a test fails.

| When the test contains... | Read |
|---------------------------|------|
| Several unrelated `expect` groups, names like `"works"`, setup copied between tests | [struct-one-behavior](rules/struct-one-behavior.md) |
| Assertions on private fields, call order of internal helpers, or large snapshots | [struct-test-the-contract](rules/struct-test-the-contract.md) |
| `vi.mock` of the module under test or of pure helpers; mocks not restored; mocked `fetch` by hand | [mock-boundaries-only](rules/mock-boundaries-only.md) |
| `setTimeout`/`sleep` waits, `new Date()` or `Date.now()` in the code under test, flaky timing | [time-fake-timers](rules/time-fake-timers.md) |
| `expect(fn()).rejects` without `await`, `done` callbacks, `try/catch` around an expected failure | [async-assert-rejections](rules/async-assert-rejections.md) |
| Big literal objects repeated in tests, shared mutable fixtures, hard-coded ids | [data-factories](rules/data-factories.md) |
| Parsers, serializers, money or date arithmetic, sorting — code with an invariant over many inputs | [prop-property-based](rules/prop-property-based.md) |
| A coverage threshold being raised or lowered, `/* v8 ignore */`, tests written to hit lines | [cov-meaningful-thresholds](rules/cov-meaningful-thresholds.md) |

### Review Checklist

- [ ] Each test name states a behaviour and its condition; each test fails for one reason
- [ ] Only boundaries are mocked (network, clock, filesystem, randomness), and mocks are restored after each test
- [ ] No real waiting: timers and dates are faked; async failures are awaited with `rejects`
- [ ] Test data comes from factories with explicit overrides for what the test is about
- [ ] Breaking the rule under test makes at least one test fail
- [ ] The suite passes in random order and in parallel (`--sequence.shuffle`)

## Gotchas

- `expect(promise).rejects.toThrow()` without `await` (or `return`) always passes: the assertion runs after the test ended.
- `vi.mock` calls are hoisted above the imports; variables used in the factory must be created with `vi.hoisted`.
- `vi.spyOn` and `vi.fn` keep their state across tests unless `restoreMocks: true` (or `mockReset`) is set in the config.
- `vi.useFakeTimers()` also fakes `Date` by default; call `vi.useRealTimers()` in `afterEach` or every later test sees a frozen clock.
- A snapshot of a whole component or API response passes whatever it contains the first time; reviewers approve diffs they do not read.
- `toEqual` ignores `undefined` properties and class types; `toStrictEqual` does not. Use the strict one for API payloads.
- Testing Library queries by role and visible text (`getByRole("button", { name: "Save" })`) fail when the UI breaks for users; `querySelector(".btn-primary")` fails when the CSS changes.
- `node:test` is built into Node and needs no dependency: `node --test` runs it, `mock.timers` fakes time, and TypeScript runs through type stripping.

## Categories

### Structure [CRITICAL]
Tests that name a behaviour and fail for one reason.

| Rule | Description |
|------|-------------|
| [struct-one-behavior](rules/struct-one-behavior.md) | One behaviour per test, named for the behaviour, arrange-act-assert |
| [struct-test-the-contract](rules/struct-test-the-contract.md) | Test through the public API, not the implementation |

### Isolation [HIGH]
Control what the code under test does not own.

| Rule | Description |
|------|-------------|
| [mock-boundaries-only](rules/mock-boundaries-only.md) | Mock only boundaries, prefer fakes and MSW, restore after each test |
| [time-fake-timers](rules/time-fake-timers.md) | Fake timers and the clock instead of waiting |
| [async-assert-rejections](rules/async-assert-rejections.md) | Await every async assertion; assert rejections with rejects |

### Data [MEDIUM]
Readable, independent test data.

| Rule | Description |
|------|-------------|
| [data-factories](rules/data-factories.md) | Build test data with factories and explicit overrides |
| [prop-property-based](rules/prop-property-based.md) | Check invariants over generated inputs with fast-check |

### Coverage [LOW]
A floor, not a goal.

| Rule | Description |
|------|-------------|
| [cov-meaningful-thresholds](rules/cov-meaningful-thresholds.md) | Set branch coverage floors per area; never test for lines |

## Quick Reference

```typescript
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

describe("applyCoupon", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-03-01T12:00:00Z"));
  });
  afterEach(() => vi.useRealTimers());

  it("takes 10% off a cart over the coupon minimum", () => {
    const cart = aCart({ subtotalCents: 20_000 });
    const coupon = aCoupon({ percentOff: 10, minimumCents: 10_000 });

    expect(applyCoupon(cart, coupon).totalCents).toBe(18_000);
  });

  it("rejects an expired coupon", async () => {
    const coupon = aCoupon({ expiresAt: new Date("2026-02-28T23:59:59Z") });

    await expect(redeem(aCart(), coupon)).rejects.toThrow(CouponExpired);
  });
});
```

```typescript
// vitest.config.ts
export default defineConfig({
  test: {
    restoreMocks: true,
    sequence: { shuffle: true },
    coverage: { provider: "v8", thresholds: { branches: 80 } },
  },
});
```

## See Also

These are separate skills; use them if installed.

- `typescript-coding-standards` - The code under test: types, boundaries, errors
- `javascript-coding-standards` - Node runtime rules for JavaScript code
