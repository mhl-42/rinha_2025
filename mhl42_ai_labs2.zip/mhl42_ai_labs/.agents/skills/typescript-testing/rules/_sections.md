# Section Definitions

## Structure (struct)
**Impact:** CRITICAL

Tests that name a behaviour and fail for one reason.

**Rules:**
- `struct-one-behavior` - One behaviour per test, named for the behaviour, arrange-act-assert
- `struct-test-the-contract` - Test through the public API, not the implementation

## Mocks (mock)
**Impact:** HIGH

Replace only what the code under test does not own.

**Rules:**
- `mock-boundaries-only` - Mock only boundaries, prefer fakes and MSW, restore after each test

## Time (time)
**Impact:** HIGH

Control the clock instead of waiting on it.

**Rules:**
- `time-fake-timers` - Fake timers and the clock instead of waiting

## Async (async)
**Impact:** HIGH

Assertions that run before the test ends.

**Rules:**
- `async-assert-rejections` - Await every async assertion; assert rejections with rejects

## Data (data)
**Impact:** MEDIUM

Readable, independent test data.

**Rules:**
- `data-factories` - Build test data with factories and explicit overrides

## Property-based (prop)
**Impact:** MEDIUM

Invariants checked over many inputs.

**Rules:**
- `prop-property-based` - Check invariants over generated inputs with fast-check

## Coverage (cov)
**Impact:** LOW

A floor, not a goal.

**Rules:**
- `cov-meaningful-thresholds` - Set branch coverage floors per area; never test for lines
