---
title: Await Every Async Assertion; Assert Rejections with rejects
impact: HIGH
impactDescription: Async tests fail when the code is wrong instead of passing vacuously
tags: [async, promises, rejects, assertions]
---

# Await Every Async Assertion; Assert Rejections with rejects [HIGH]

## Description
An async assertion that is not awaited runs after the test has finished, so the test passes whatever happens. A `try/catch` around a call expected to fail passes when nothing is thrown, unless the test counts assertions. Await `expect(promise).rejects.toThrow(...)`, which fails when the promise resolves.

`done` callbacks belong to callback APIs; with promises they hide failures behind timeouts.

## Bad Example
```typescript
it("rejects a duplicate e-mail", () => {
  expect(register("ana@example.com")).rejects.toThrow(); // not awaited: always passes
});

it("fails on a closed account", async () => {
  try {
    await withdraw(closedAccount, 100);
  } catch (err) {
    expect(err).toBeInstanceOf(AccountClosed); // never runs if withdraw resolves
  }
});
```

## Good Example
```typescript
it("rejects a duplicate e-mail", async () => {
  await register("ana@example.com");

  await expect(register("ana@example.com")).rejects.toThrow(EmailTaken);
});

it("fails on a closed account and keeps the balance", async () => {
  const account = anAccount({ status: "closed", balanceCents: 500 });

  await expect(withdraw(account, 100)).rejects.toBeInstanceOf(AccountClosed);
  expect(account.balanceCents).toBe(500);
});
```

## Notes
- `@vitest/eslint-plugin`'s `valid-expect` and typescript-eslint's `no-floating-promises` report unawaited assertions.
- For an event that must happen, `await vi.waitFor(() => expect(...))` retries until it passes or times out.

## References
- [Vitest API: rejects](https://vitest.dev/api/expect#rejects)
