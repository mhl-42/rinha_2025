---
title: Set Branch Coverage Floors per Area; Never Test for Lines
impact: LOW
impactDescription: Coverage stops regressions without rewarding assertion-free tests
tags: [coverage, thresholds, v8, ci]
---

# Set Branch Coverage Floors per Area; Never Test for Lines [LOW]

## Description
Coverage says which code ran, not which behaviour was checked: a test with no assertions covers as many lines as a good one. Use it as a floor that stops untested code from entering, set on branches (which catch the untested `else`), higher for business rules than for glue code. Never write a test only to touch lines.

## Bad Example
```typescript
it("covers the module", () => {
  formatInvoice(anInvoice());
  formatInvoice(anInvoice({ currency: "EUR" }));
}); // no assertion

/* v8 ignore next 5 */
```

## Good Example
```typescript
export default defineConfig({
  test: {
    coverage: {
      provider: "v8",
      include: ["src/**"],
      thresholds: {
        branches: 80,
        "src/domain/**": { branches: 95, functions: 95 },
      },
    },
  },
});
```

## Notes
- An ignore comment needs a reason next to it (`/* v8 ignore next -- unreachable: exhaustive switch */`).
- Lowering a threshold is a decision for review, not a fix for a red build.

## References
- [Vitest: coverage](https://vitest.dev/guide/coverage)
