---
title: Build Test Data with Factories and Explicit Overrides
impact: MEDIUM
impactDescription: Each test shows only the data it is about and cannot be broken by another test
tags: [test-data, factories, builders, fixtures]
---

# Build Test Data with Factories and Explicit Overrides [MEDIUM]

## Description
Large literal objects repeated in every test hide which field matters, and break all at once when the type gains a required field. A module-level fixture mutated by one test changes the result of the next. Use a factory per type that returns a fresh, valid object with sensible defaults, and pass only the fields the test is about.

## Bad Example
```typescript
const user = { id: "1", name: "Ana", email: "ana@x.com", role: "admin", createdAt: new Date(), active: true };

it("blocks inactive users", () => {
  user.active = false; // later tests now see an inactive user
  expect(canLogin(user)).toBe(false);
});
```

## Good Example
```typescript
let sequence = 0;

export function aUser(overrides: Partial<User> = {}): User {
  sequence += 1;
  return {
    id: `user-${sequence}`,
    name: "Ana Souza",
    email: `user${sequence}@example.com`,
    role: "member",
    createdAt: new Date("2026-01-01T00:00:00Z"),
    active: true,
    ...overrides,
  };
}

it("blocks inactive users", () => {
  expect(canLogin(aUser({ active: false }))).toBe(false);
});
```

## Notes
- Keep factories next to the tests (`test/factories.ts`), typed with the production type so a new required field fails to compile there once.
- Unique ids and e-mails per call let tests run in parallel against a shared database.

## References
- [Vitest: test context and fixtures](https://vitest.dev/guide/test-context)
