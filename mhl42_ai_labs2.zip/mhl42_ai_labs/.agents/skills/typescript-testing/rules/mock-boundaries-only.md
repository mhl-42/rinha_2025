---
title: Mock Only Boundaries, Prefer Fakes, Restore After Each Test
impact: HIGH
impactDescription: Tests exercise the real logic and do not leak state into each other
tags: [mocks, vi.mock, msw, fakes, isolation]
---

# Mock Only Boundaries, Prefer Fakes, Restore After Each Test [HIGH]

## Description
Mock what the code does not own and cannot run fast and deterministically in a test: the network, the clock, randomness, the filesystem, a payment provider. Mocking the module under test, or the pure helpers it calls, tests the mock.

For HTTP, intercept at the network level with MSW instead of replacing `fetch` by hand: the code under test keeps its real request building and parsing. For a dependency passed in (a repository, a mailer), a small in-memory fake is easier to read than a chain of `mockResolvedValueOnce`.

Mocks keep their calls and implementations across tests unless restored. Set `restoreMocks: true` in the config.

## Bad Example
```typescript
vi.mock("./pricing"); // the module whose logic the test is about
global.fetch = vi.fn().mockResolvedValue({ json: async () => ({ rate: 1.1 }) }) as any;

it("converts", async () => {
  vi.mocked(convert).mockResolvedValue(110);
  expect(await convert(100, "EUR")).toBe(110); // tests the mock
});
```

## Good Example
```typescript
const server = setupServer(
  http.get("https://rates.example/latest", ({ request }) => {
    const base = new URL(request.url).searchParams.get("base");
    return HttpResponse.json({ base, rates: { EUR: 0.9 } });
  }),
);
beforeAll(() => server.listen({ onUnhandledRequest: "error" }));
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

it("converts with the latest rate", async () => {
  expect(await convert(100, "USD", "EUR")).toBe(90);
});

it("reports the provider being down", async () => {
  server.use(http.get("https://rates.example/latest", () => new HttpResponse(null, { status: 503 })));
  await expect(convert(100, "USD", "EUR")).rejects.toThrow(RatesUnavailable);
});

class InMemoryOrders implements OrderRepository {
  readonly saved: Order[] = [];
  async save(order: Order): Promise<void> { this.saved.push(order); }
}
```

## Notes
- `onUnhandledRequest: "error"` makes an unexpected real request fail the test instead of reaching the internet.
- Assert on what reached the boundary (the request body, the saved order) rather than on `toHaveBeenCalledWith` of an internal function.

## References
- [MSW: getting started](https://mswjs.io/docs/getting-started)
- [Vitest: mocking](https://vitest.dev/guide/mocking)
