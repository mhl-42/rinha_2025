---
title: Check Invariants over Generated Inputs with fast-check
impact: MEDIUM
impactDescription: Finds the edge cases nobody thought to write down
tags: [property-based, fast-check, invariants, parsers]
---

# Check Invariants over Generated Inputs with fast-check [MEDIUM]

## Description
Example tests cover the cases someone imagined. For code with a property that holds for every input (a parser and its printer round-trip, a sort keeps every element, a money split adds up to the total), generate many inputs and check the property. fast-check shrinks a failure to the smallest input that breaks it.

## Bad Example
```typescript
it("splits the bill", () => {
  expect(split(1000, 3)).toEqual([334, 333, 333]);
});
```

## Good Example
```typescript
import fc from "fast-check";

it("splits a bill into parts that add up to the total and differ by at most one cent", () => {
  fc.assert(
    fc.property(fc.integer({ min: 0, max: 10_000_000 }), fc.integer({ min: 1, max: 50 }), (total, people) => {
      const parts = split(total, people);
      expect(parts).toHaveLength(people);
      expect(parts.reduce((a, b) => a + b, 0)).toBe(total);
      expect(Math.max(...parts) - Math.min(...parts)).toBeLessThanOrEqual(1);
    }),
  );
});
```

## Notes
- Keep the example tests too: they document the behaviour; the property guards it.
- When a property fails, add the shrunk counterexample as an example test so it stays fixed.

## References
- [fast-check documentation](https://fast-check.dev/)
