---
title: One Behaviour per Test, Named for the Behaviour
impact: CRITICAL
impactDescription: A failing test name says what broke without reading the code
tags: [structure, naming, aaa, readability]
---

# One Behaviour per Test, Named for the Behaviour [CRITICAL]

## Description
A test that checks creation, update and deletion fails with one message for three possible causes, and stops at the first. Write one test per behaviour, named as a sentence about the behaviour and its condition, with the three parts visible: arrange the inputs, act once, assert on the outcome.

Several `expect` calls are fine when they describe one outcome (the fields of the returned object); they are a smell when they describe several actions.

## Bad Example
```typescript
it("cart works", () => {
  const cart = new Cart();
  cart.add(book, 2);
  expect(cart.total()).toBe(5000);
  cart.remove(book);
  expect(cart.total()).toBe(0);
  expect(() => cart.add(book, -1)).toThrow();
});
```

## Good Example
```typescript
describe("Cart", () => {
  it("totals the price times the quantity of each line", () => {
    const cart = new Cart();

    cart.add(aProduct({ priceCents: 2500 }), 2);

    expect(cart.total()).toBe(5000);
  });

  it("is empty after its only line is removed", () => {
    const book = aProduct();
    const cart = new Cart();
    cart.add(book, 1);

    cart.remove(book);

    expect(cart.total()).toBe(0);
  });

  it("refuses a negative quantity", () => {
    expect(() => new Cart().add(aProduct(), -1)).toThrow(InvalidQuantity);
  });
});
```

## Notes
- `it.each` covers the same behaviour over a table of inputs, with the input in the name (`"rounds $input to $expected"`).
- Shared setup goes in a factory or `beforeEach` only when every test in the block needs it.
- Name the error type in `toThrow`, so a different failure does not pass.

## References
- [Vitest API: test.each](https://vitest.dev/api/#test-each)
