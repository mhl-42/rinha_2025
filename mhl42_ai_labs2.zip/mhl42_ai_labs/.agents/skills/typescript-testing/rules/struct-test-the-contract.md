---
title: Test Through the Public API, Not the Implementation
impact: CRITICAL
impactDescription: Refactors keep the tests green; behaviour changes turn them red
tags: [structure, refactoring, snapshots, testing-library]
---

# Test Through the Public API, Not the Implementation [CRITICAL]

## Description
A test that asserts private fields, the order of calls to internal helpers, or the exact markup of a component breaks on every refactor and still passes when the behaviour is wrong. Test what callers rely on: the return value, the error, the state visible through public methods, the request sent to a boundary, what a user sees and can click.

Snapshots are for small, stable outputs that a reviewer can read (a generated SQL string, an error message). A snapshot of a whole page or response is approved without being read.

## Bad Example
```typescript
it("calculates", () => {
  const service = new PricingService();
  const spy = vi.spyOn(service as any, "applyTaxInternal");
  service.price(order);
  expect(spy).toHaveBeenCalledTimes(1);
});

it("renders", () => {
  const { container } = render(<Checkout cart={cart} />);
  expect(container).toMatchSnapshot();
});
```

## Good Example
```typescript
it("adds 10% tax to the subtotal", () => {
  expect(new PricingService().price(anOrder({ subtotalCents: 1000 })).totalCents).toBe(1100);
});

it("disables Pay until the terms are accepted", async () => {
  const user = userEvent.setup();
  render(<Checkout cart={aCart()} />);

  expect(screen.getByRole("button", { name: "Pay" })).toBeDisabled();
  await user.click(screen.getByRole("checkbox", { name: /accept the terms/i }));
  expect(screen.getByRole("button", { name: "Pay" })).toBeEnabled();
});
```

## Notes
- If a private function needs its own tests, it is probably a module with its own public API; extract it.
- Inline snapshots (`toMatchInlineSnapshot`) keep small expected outputs in the test where they are read.

## References
- [Testing Library: guiding principles](https://testing-library.com/docs/guiding-principles)
