---
title: Fake Timers and the Clock Instead of Waiting
impact: HIGH
impactDescription: Fast tests that do not flake on slow machines or at midnight
tags: [time, fake-timers, dates, flaky, vitest]
---

# Fake Timers and the Clock Instead of Waiting [HIGH]

## Description
A test that sleeps to let a debounce, retry or timeout happen is slow and still flaky: on a busy CI machine the sleep is too short. Code that reads `new Date()` gives different results depending on when the test runs (a month boundary, a time zone, daylight saving). Fake the timers and set the clock, then advance time explicitly.

## Bad Example
```typescript
it("retries after a second", async () => {
  const promise = fetchWithRetry(url);
  await new Promise((r) => setTimeout(r, 1100));
  expect(fetchMock).toHaveBeenCalledTimes(2);
});

it("marks the invoice overdue", () => {
  expect(isOverdue(anInvoice({ dueAt: new Date("2026-01-10") }))).toBe(true); // true only after that date
});
```

## Good Example
```typescript
beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

it("retries once after a second", async () => {
  const promise = fetchWithRetry(url);

  await vi.advanceTimersByTimeAsync(1000);

  expect(requests).toHaveLength(2);
  await promise;
});

it("marks an invoice overdue the day after it is due", () => {
  vi.setSystemTime(new Date("2026-01-11T09:00:00-03:00"));

  expect(isOverdue(anInvoice({ dueAt: new Date("2026-01-10T23:59:59-03:00") }))).toBe(true);
});
```

## Notes
- Use the `*Async` variants (`advanceTimersByTimeAsync`, `runAllTimersAsync`) when promises run between timers.
- Run the suite with a fixed time zone (`TZ=UTC` in the test script) unless a test sets its own.
- Injecting a clock (`now: () => Date`) into the code is often clearer than faking globals.

## References
- [Vitest: fake timers](https://vitest.dev/guide/mocking#timers)
