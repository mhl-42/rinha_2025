---
name: go-testing
description: Use this skill when writing, reviewing, or fixing Go tests — table-driven tests and subtests, t.Helper, t.Cleanup and t.TempDir, comparing results and errors, fakes for interfaces, httptest servers and recorders, time and concurrency (testing/synctest), the race detector, fuzzing, benchmarks and integration tests — even if the user only says "add tests for this handler", "this test is flaky", or "test the retry logic". Not for application code (use go-coding-standards) or tests in other languages.
license: MIT
compatibility: Go 1.22+; t.Context and b.Loop need Go 1.24+, testing/synctest Go 1.25+. Comparisons use github.com/google/go-cmp when the project has it; the standard library otherwise.
metadata:
  author: mhl42 (adapted from 0xMassi/claude-skills, MIT)
  version: "1.0.0"
---

# Go Testing

Rules for AI agents writing Go tests that are fast, independent and fail for the right reason. The Quick Reference covers the common case; open a rule file when its trigger appears.

## How to Use

- **Writing tests**: one table per behaviour, subtests with names, helpers marked with `t.Helper`, fakes for interfaces, and `-race` on. Follow the Quick Reference and Gotchas.
- **Reviewing**: scan for the triggers below and open the matching rule. Then break the code on purpose and check that a test fails.

| When the test contains... | Read |
|---------------------------|------|
| Copy-pasted test functions differing in inputs; loops without `t.Run`; unnamed cases | [struct-table-driven](rules/struct-table-driven.md) |
| Setup repeated in every test; manual cleanup at the end; temp files in the working directory | [struct-helpers-and-cleanup](rules/struct-helpers-and-cleanup.md) |
| `reflect.DeepEqual` with `t.Errorf("not equal")`; `err.Error() ==` checks; `err != nil` as the only assertion | [assert-diffs-and-errors](rules/assert-diffs-and-errors.md) |
| Mocking frameworks for one method; real HTTP calls; handlers tested by starting the whole server | [iso-fakes-and-httptest](rules/iso-fakes-and-httptest.md) |
| `time.Sleep` in tests; `time.Now()` in the code under test; flaky timing | [time-control](rules/time-control.md) |
| Tests that pass alone and fail together; shared package variables; no `-race` in CI | [race-and-order](rules/race-and-order.md) |
| Parsers, decoders and validators tested with a handful of inputs | [fuzz-native](rules/fuzz-native.md) |

### Review Checklist

- [ ] Each behaviour has a table of named cases run with `t.Run`
- [ ] Failure messages show the input, the got and the want (`cmp.Diff` for structs)
- [ ] Errors are checked with `errors.Is`/`errors.As` against the expected kind
- [ ] Dependencies are fakes or `httptest` servers; no real network
- [ ] No `time.Sleep`; time is injected or run in a `synctest` bubble
- [ ] `go test -race -shuffle=on ./...` passes

## Gotchas

- `t.Fatal` from a goroutine other than the test's own does not stop the test; send the error back and fail in the test goroutine.
- `t.Parallel()` in subtests runs them after the parent's body returns: cleanup in the parent with `defer` runs too early; use `t.Cleanup`.
- `reflect.DeepEqual` treats a nil slice and an empty slice as different; `cmp.Diff` with `cmpopts.EquateEmpty` does not.
- A test that only checks `err == nil` passes when the function returns zero values and no error.
- `httptest.NewRecorder` does not run middleware; test the handler chain you mount, not only the inner handler.
- Test files in `package foo_test` see only the exported API (black-box); `package foo` sees internals. Prefer the first.
- `go test` caches passing results; `-count=1` forces a rerun when the test reads files or the environment.

## Categories

### Structure [CRITICAL]
Named cases and clean setup.

| Rule | Description |
|------|-------------|
| [struct-table-driven](rules/struct-table-driven.md) | Table-driven tests with named subtests |
| [struct-helpers-and-cleanup](rules/struct-helpers-and-cleanup.md) | t.Helper, t.Cleanup, t.TempDir and t.Context instead of manual setup |
| [assert-diffs-and-errors](rules/assert-diffs-and-errors.md) | Show got and want with cmp.Diff; check errors by kind |

### Isolation [HIGH]
Control what the code does not own.

| Rule | Description |
|------|-------------|
| [iso-fakes-and-httptest](rules/iso-fakes-and-httptest.md) | Hand-written fakes for small interfaces; httptest for HTTP |
| [time-control](rules/time-control.md) | Inject the clock or use testing/synctest instead of sleeping |
| [race-and-order](rules/race-and-order.md) | Run with -race and -shuffle; no shared mutable state |

### Inputs [MEDIUM]
Inputs nobody thought of.

| Rule | Description |
|------|-------------|
| [fuzz-native](rules/fuzz-native.md) | Fuzz parsers and decoders with go test -fuzz |

## Quick Reference

```go
func TestParseAmount(t *testing.T) {
	tests := []struct {
		name    string
		in      string
		want    int64
		wantErr error
	}{
		{name: "whole reais", in: "12", want: 1200},
		{name: "with cents", in: "12,34", want: 1234},
		{name: "negative is refused", in: "-1", wantErr: ErrNegative},
		{name: "letters are refused", in: "abc", wantErr: ErrInvalid},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := ParseAmount(tt.in)
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("ParseAmount(%q) error = %v, want %v", tt.in, err, tt.wantErr)
			}
			if got != tt.want {
				t.Errorf("ParseAmount(%q) = %d, want %d", tt.in, got, tt.want)
			}
		})
	}
}
```

```bash
go test -race -shuffle=on -count=1 ./...
go test -fuzz=FuzzParseAmount -fuzztime=30s ./internal/money
```

## See Also

These are separate skills; use them if installed.

- `go-coding-standards` - The code under test: errors, context, goroutines, HTTP
